<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$_SESSION['cuPages']='sel_sinvlist.php';   
$cuPage='sel_sinvlist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
?>
<?php 
function get_prodliqty($invno){
global $con;
$invty=substr($invno,0,3);
if($invty=='DLI'){    
$sql="SELECT SUM(p_out) AS rdata FROM tbl_traproduct WHERE invno='$invno'";
}else{
$sql="SELECT SUM(s_qty) AS rdata FROM tbl_traproduct WHERE invno='$invno'";    
}
$query=mysqli_query($con,$sql)or die(mysqli_error($con));    
$row=mysqli_fetch_array($query);
return $row['rdata'];    
}
?>
<?php 
if(isset($_POST['invid'])){
$piid=$_POST['invid'];
$type=$_POST['type'];    
$cusid=$_POST['cusid'];
$sql="SELECT tbl_pdlirecord.id,tbl_pdlirecord.invno,tbl_pdlirecord.refinv,tbl_pdlirecord.apdate FROM tbl_pdlirecord LEFT JOIN tbl_sales ON tbl_sales.invno=tbl_pdlirecord.refinv WHERE tbl_sales.type='$type' AND tbl_sales.cusid='$cusid' ORDER BY apdate DESC,id DESC";        
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$invno=$row['invno'];
$refinv=$row['refinv'];    
?>
<li <?php if($row['id']==$piid){echo 'class="invpiv active"';}else{echo 'class="invpiv"';}?> id="pi_<?php echo $row['id'];?>"><p><strong class="pino"><?php echo $row['invno'];?></strong><br><strong><?php echo date("d M Y", strtotime($row['apdate']));?></strong></p>
<div class="sname" style="margin-top: -52px;float: right; position: relative;top: 6px;"><strong><?php echo 'Deliver Qty: '.get_prodliqty($invno); ?></strong><br><strong><?php echo 'Total Qty: '.get_prodliqty($refinv); ?></strong></div>
</li>
<?php }} ?>