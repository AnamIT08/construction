<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='inv_comstock.php';   
$cuPage='inv_comstock.php';    
$aid=$_SESSION['uid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='inventor';
$menuh='Inventory';
$phead='comstock';
$page='Combined Stock';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">All Over Stock Status (Warehouse + Branch)</h3>
</div>
<div class="box-body">    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped table-hover table_list" id="datarec">
<thead>
<tr>
<th rowspan="2" style="width:40px;" class="text-center">SN</th>
<th rowspan="2" style="width:80px;">Image</th>
<th rowspan="2">Name</th>
<th rowspan="2">SKU</th>    
<th colspan="4" class="text-center">Purchase Details</th>
<th colspan="4" class="text-center">Sold Details</th>
<th rowspan="2" class="text-center">Adjust</th>     
<th rowspan="2" class="text-center">Available</th>    
</tr>
<tr>
<th class="text-center">Purchase</th>
<th class="text-center">Receive</th>    
<th class="text-center">Return</th>
<th class="text-center">Balance</th>
<th class="text-center">Sold</th>
<th class="text-center">Deliverd</th>    
<th class="text-center">Return</th>
<th class="text-center">Balance</th>    
</tr>    
</thead>    
<tbody>
<?php
$tpqty=0;$tprqty=0;$tpavqty=0; $tsoqty=0;$tsrqty=0;$tsavqty=0;$tfavqty=0;$tpoqty=0;$tsorqty=0;$tadqty=0;   
$sql="SELECT stk.pid,pro.name,pro.bname,pro.code,pro.image,IFNULL(puo.poqty,0) AS poqty,IFNULL(puq.pqty,0) AS pqty,IFNULL(pur.prqty,0) AS prqty,IFNULL(seo.soqty,0) AS soqty,IFNULL(sel.sold,0) AS sold,IFNULL(ser.srqty,0) AS srqty,IFNULL(dis.adjqty,0) AS adjqty,((puq.pqty-IFNULL(pur.prqty,0))-((IFNULL(sel.sold,0)-IFNULL(ser.srqty,0))+IFNULL(dis.adjqty,0))) AS avqty FROM (SELECT pid FROM tbl_stock GROUP BY pid) stk LEFT JOIN (SELECT pid,SUM(p_qty) AS poqty FROM tbl_traproduct WHERE mods='PU' GROUP BY pid) puo ON puo.pid=stk.pid LEFT JOIN (SELECT pid,SUM(p_in) AS pqty FROM tbl_traproduct WHERE mods IN ('PU','RC') GROUP BY pid) puq ON puq.pid=stk.pid LEFT JOIN (SELECT pid,SUM(p_out) AS prqty FROM tbl_traproduct WHERE mods='PR' GROUP BY pid) pur ON pur.pid=stk.pid LEFT JOIN (SELECT pid,SUM(s_qty) AS soqty FROM tbl_traproduct WHERE mods='SE' GROUP BY pid) seo ON seo.pid=stk.pid LEFT JOIN (SELECT pid,SUM(p_out) AS sold FROM tbl_traproduct WHERE mods IN ('SE','DL') GROUP BY pid) sel ON sel.pid=stk.pid LEFT JOIN (SELECT pid,SUM(p_in) AS srqty FROM tbl_traproduct WHERE mods='SR' GROUP BY pid) ser ON ser.pid=stk.pid LEFT JOIN (SELECT pid,SUM(p_out) AS adjqty FROM tbl_traproduct WHERE mods='DS' GROUP BY pid) dis ON dis.pid=stk.pid LEFT JOIN (SELECT id,code,name,bname,image FROM tbl_item WHERE status='1') pro ON pro.id=stk.pid ORDER BY pro.name ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$tpqty+=$row['pqty'];$tprqty+=$row['prqty'];$tpavqty+=($row['pqty']-$row['prqty']); $tsoqty+=$row['sold'];$tsrqty+=$row['srqty'];$tsavqty+=($row['sold']-$row['srqty']);$tfavqty+=$row['avqty'];$tadqty+=$row['adjqty'];
$tpoqty+=$row['poqty'];$tsorqty+=$row['soqty'];    
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td class="text-center"><img src="../img/product/<?php if(empty($row['image'])){echo "no_image.png";}else{echo $row['image'];} ?>" height="40px" width="40px"></td>
<td><b class="prodetail" id="PI_<?php echo $row['pid'];?>" style="cursor: pointer;"><?php echo $row['name']; ?></b></td>
<td><?php echo $row['code']; ?></td>
<td class="text-center"><?php echo $row['poqty']; ?></td>    
<td class="text-center"><?php echo $row['pqty']; ?></td>
<td class="text-center"><?php echo $row['prqty']; ?></td>
<td class="text-center"><?php echo ($row['pqty']-$row['prqty']); ?></td>
<td class="text-center"><?php echo $row['soqty']; ?></td>    
<td class="text-center"><?php echo $row['sold']; ?></td>
<td class="text-center"><?php echo $row['srqty']; ?></td>
<td class="text-center"><?php echo ($row['sold']-$row['srqty']); ?></td>
<td class="text-center"><?php echo $row['adjqty']; ?></td>     
<td class="text-center"><?php echo $row['avqty']; ?></td>    
</tr>    
<?php } ?>     
</tbody>
<tfoot>
<tr>
<td class="text-center" colspan="4"><strong>-Total-</strong></td>
<td class="text-center"><strong><?php echo $tpoqty; ?></strong></td>    
<td class="text-center"><strong><?php echo $tpqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tprqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tpavqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tsorqty; ?></strong></td>    
<td class="text-center"><strong><?php echo $tsoqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tsrqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tsavqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tadqty; ?></strong></td>    
<td class="text-center"><strong><?php echo $tfavqty; ?></strong></td>    
</tr>    
</tfoot>    
</table>    
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->
<?php include('../layout/details.php'); ?>    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script src='../plugins/chart/Chart.js'></script>
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
});
    
$(document).on('click', '.prodetail', function(e) { 
id_arr = $(this).attr('id');
id = id_arr.split("_");

$.ajax({
url: 'axe_prodetails.php',
method: "POST",
data:{ prodet: 1,pid: id[1] },
success: function(data){
$('#profile').html(data);    
}
});    
    
$.ajax({
url: 'axe_prodetails.php',
method: "POST",
data:{ details: 1,pid: id[1] },
success: function(data){
$('#details').html(data);   
}
});    
    
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);   
e.preventDefault();    
});
    
$(document).on('click', '#closedet', function() {
$('#profile').html('');
$('#details').html('');    
if($('.right-side-details').is(':visible')) {
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);
}   
});     
</script>    
<!-- /page script -->
</html>    