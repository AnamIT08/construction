<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
include ('../inc/repfunctions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
$today = strftime("%Y-%m-%d", time());    
$dtnow = date("Y-m-d h:i:s", time());    
}else{
header('Location:../index.php');
exit;    
}

if(isset($_POST['additem'])){
$pid=intval($_POST['additem']);
$col=$_POST['col'];
$siz=$_POST['siz'];    
addtopur($pid,1,$col,$siz);    
}

if(isset($_POST['scanbarcode'])){	
$bcode=remove_junk(escape($_POST['scanbarcode']));
$qty=$_POST['qty'];
$mod=$_POST['mod']; 

$type=substr($bcode,0,3);
if(substr($type,0,2)==='OU'){$type='JOU';$bcode='J'.$bcode;}    
$parray = array('EMP','JOU','REV','PAV','EXP','PRE','PUR','POR','SRE','SEL','EST','SER','RCI','DLI','PDR','CLA','TRB','TRW');     
if(strlen(array_search($type,$parray))>0){
$pmsg=array(
'status' => 'invno',
'invoice'=> $bcode    
);
echo json_encode($pmsg);
return;    
}
    
if($mod!=0){
$sql="SELECT id,code,name FROM tbl_item WHERE barcode='$bcode' AND status='1'";
$result=mysqli_query($con,$sql) or die(mysqli_error($con));
if($result->num_rows > 0){
$pmsg=array(
'status' => 'bcode',
'message'=> 'This is not serial! Its SKU Barcode!!!'    
);    
}else{
if(check_imei($bcode)){
$pmsg=array(
'status' => 'exits',
'message'=> 'Serial Key Already Added!!!'    
);
echo json_encode($pmsg);
return;	
}
if(check_eximei($bcode)){
$pmsg=array(
'status' => 'exits',
'message'=> 'Serial Key Already Added!!!'    
);
echo json_encode($pmsg);
return;		
}
if(pid_exists_wos($mod)>0){
$sid=pid_exists_wos($mod)-1;
$_SESSION['axes_purse'][$sid]['imei']=$bcode;    
$pmsg=array(
'status' => 'success',
'message'=> 'Serial Add to cart Successfully!!'    
);
echo json_encode($pmsg);
return;    
}else{
addtopur($mod,1,'','',$bcode);
add_purserial($mod,$bcode,'A');
$pmsg=array(
'status' => 'success',
'message'=> 'Product Add to cart Successfully!!'    
);    	
}
}	
}else{
$sql="SELECT id,code,name FROM tbl_item WHERE barcode='$bcode' AND status='1'";
$result=mysqli_query($con,$sql) or die(mysqli_error($con));
if($result->num_rows > 0){ 
$row=mysqli_fetch_array($result);
$pid=$row['id'];
addtopur($pid,1,'','');
$pmsg=array(
'status' => 'success',
'message'=> 'Product Add to cart Successfully!!'    
);	
}else{
$pmsg=array(
'status' => 'fail',
'message'=> 'No item found!!'    
);
}
}
echo json_encode($pmsg);    
}

if(isset($_POST['itmsear'])){
$search = $_POST['search'];
$sql = "SELECT id,code,name FROM tbl_item WHERE status='1' AND (name LIKE '%$search%' OR code LIKE '%$search%') LIMIT 20";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
while($row = mysqli_fetch_array($result) ){
$response[] = array("value"=>$row['id'],"label"=>$row['code'].' | '.$row['name']);
}

echo json_encode($response);
exit;    
}

if(isset($_POST['remove'])){
$ids = floatval($_POST['remove']);
$pid=$_SESSION['axes_purchase'][$ids]['pid'];    
remove_purchase($ids);    
if(isset($_SESSION['axes_purse'])){    
remove_puimei($pid);
}    
$max=count($_SESSION['axes_purchase']);
if($max <= 0){
unset($_SESSION['axes_purchase']);
unset($_SESSION['axes_purde']);
if(isset($_SESSION['axes_purse'])){
unset($_SESSION['axes_purse']);	
}	
}
if(isset($_SESSION['axes_purse'])){
$smax=count($_SESSION['axes_purse']);
if($smax <= 0){    
unset($_SESSION['axes_purse']);
}
}   
}

if(isset($_POST['upqty'])){
$ids=intval($_POST['upqty']);
$qty=floatval($_POST['qty']);
if($qty<0 || $qty==''){exit;}
$dis = $_SESSION['axes_purchase'][$ids]['disf']; 
$_SESSION['axes_purchase'][$ids]['qty']=$qty;
$cost = $_SESSION['axes_purchase'][$ids]['cost'];
$sqty = $_SESSION['axes_purchase'][$ids]['qty'];
$disamo = ($dis*$sqty);
$stot = ($cost*$sqty);
if($cost>0){
$disp=(($dis/$cost)*100);
}else{
$disp=0;	
}
$_SESSION['axes_purchase'][$ids]['disp']=getfloatval($disp);
$_SESSION['axes_purchase'][$ids]['disamo']=$disamo;
$_SESSION['axes_purchase'][$ids]['subtot'] = ($stot-$disamo);
}

if(isset($_POST['upcost'])){
$ids=intval($_POST['upcost']);
$amo=floatval($_POST['amo']);
if($amo<0 || $amo==''){exit;}
$qty=$_SESSION['axes_purchase'][$ids]['qty'];
$dis=$_SESSION['axes_purchase'][$ids]['disf'];
$rep=$_SESSION['axes_purchase'][$ids]['rebp'];   
$_SESSION['axes_purchase'][$ids]['cost']=$amo;
$disamo= ($dis*$qty);
$disp=(($dis/$amo)*100);
$rbamo=(($rep/100)*$amo);    
$_SESSION['axes_purchase'][$ids]['rebf']=getfloatval($rbamo);    
$_SESSION['axes_purchase'][$ids]['disp']=getfloatval($disp);
$_SESSION['axes_purchase'][$ids]['disamo']=$disamo;
$_SESSION['axes_purchase'][$ids]['subtot']=(($amo*$qty)-$disamo);	
}

if(isset($_POST['check'])){
$ids=$_POST['pid'];
$val=$_POST['check'];
$max=count($_SESSION['axes_purchase']);
for($i=0;$i<$max;$i++){
if($ids==$i){
$_SESSION['axes_purchase'][$i]['check']=$val;	
}else{
$_SESSION['axes_purchase'][$i]['check']=0;	
}	
}	
}

if(isset($_POST['upprice'])){
$ids=intval($_POST['upprice']);
$amo=floatval($_POST['amo']);
if($amo<0 || $amo==''){exit;}
$_SESSION['axes_purchase'][$ids]['price']=$amo;
}

if(isset($_POST['itemdisp'])){
$ids=intval($_POST['itemdisp']);
$disc=floatval($_POST['disp']);
//if( $disc==''){exit;}
$_SESSION['axes_purchase'][$ids]['disp']=$disc;
$cost=$_SESSION['axes_purchase'][$ids]['cost'];
$uqty=$_SESSION['axes_purchase'][$ids]['qty'];
$dis=(($cost*$disc)*0.01);
$disamo = ($dis*$uqty); 
$_SESSION['axes_purchase'][$ids]['disf']=getfloatval($dis);
$_SESSION['axes_purchase'][$ids]['disamo']=getfloatval($disamo);
$_SESSION['axes_purchase'][$ids]['subtot']=(($cost*$uqty)-$disamo);
}

if(isset($_POST['itemdisf'])){
$ids=intval($_POST['itemdisf']);
$dica=floatval($_POST['disf']);
$cost=$_SESSION['axes_purchase'][$ids]['cost'];
$uqty=$_SESSION['axes_purchase'][$ids]['qty'];
$disp=(($dica/$cost)*100);
$_SESSION['axes_purchase'][$ids]['disf']=getfloatval($dica);
$disamo = ($dica*$uqty);
$_SESSION['axes_purchase'][$ids]['disamo']=getfloatval($disamo);
if($dica<=0){
$_SESSION['axes_purchase'][$ids]['disp']=getfloatval(0);	
}else{
$_SESSION['axes_purchase'][$ids]['disp']=getfloatval($disp);	
}
$_SESSION['axes_purchase'][$ids]['subtot']=(($cost*$uqty)-$disamo);
}

if(isset($_POST['warranty'])){
$ids=intval($_POST['warranty']);
$wday=floatval($_POST['wday']);
if($wday<0 || $wday==''){$wday=0;}
$_SESSION['axes_purchase'][$ids]['wday']=$wday;
}

if(isset($_POST['seldisp'])){
$ids=intval($_POST['seldisp']);
$per=$_POST['per'];
if($per<0 || $per==''){$per=0;}
$price=$_SESSION['axes_purchase'][$ids]['price'];    
$_SESSION['axes_purchase'][$ids]['sdisp']=getfloatval($per);
$dis=(($price*$per)*0.01);
$_SESSION['axes_purchase'][$ids]['sdisf']=getfloatval($dis);    	
}

if(isset($_POST['seldisf'])){
$ids=intval($_POST['seldisf']);
$per=$_POST['per'];
if($per<0 || $per==''){$per=0;}
$price=$_SESSION['axes_purchase'][$ids]['price'];    
$_SESSION['axes_purchase'][$ids]['sdisf']=getfloatval($per);
$disp=(($per/$price)*100);
$_SESSION['axes_purchase'][$ids]['sdisp']=getfloatval($disp);    	
}

if(isset($_POST['rebeatp'])){
$ids=intval($_POST['rebeatp']);
$per=$_POST['per'];
if($per<0 || $per==''){$per=0;}
$cost=$_SESSION['axes_purchase'][$ids]['cost'];    
$_SESSION['axes_purchase'][$ids]['rebp']=getfloatval($per);
$dis=(($cost*$per)*0.01);
$_SESSION['axes_purchase'][$ids]['rebf']=getfloatval($dis);    	
}

if(isset($_POST['rebeatf'])){
$ids=intval($_POST['rebeatf']);
$per=$_POST['per'];
if($per<0 || $per==''){$per=0;}
$cost=$_SESSION['axes_purchase'][$ids]['cost'];    
$_SESSION['axes_purchase'][$ids]['rebf']=getfloatval($per);
$disp=(($per/$cost)*100);
$_SESSION['axes_purchase'][$ids]['rebp']=getfloatval($disp);    	
}

if(isset($_POST['itmde'])){
$ids=$_POST['itmde'];    
$redata=array($_SESSION['axes_purchase'][$ids]['qty'],$_SESSION['axes_purchase'][$ids]['cost'],$_SESSION['axes_purchase'][$ids]['disp'],$_SESSION['axes_purchase'][$ids]['disf'],$_SESSION['axes_purchase'][$ids]['wday'],$_SESSION['axes_purchase'][$ids]['subtot'],$_SESSION['axes_purchase'][$ids]['price'],$_SESSION['axes_purchase'][$ids]['sdisp'],$_SESSION['axes_purchase'][$ids]['sdisf'],$_SESSION['axes_purchase'][$ids]['disamo'],$_SESSION['axes_purchase'][$ids]['rebp'],$_SESSION['axes_purchase'][$ids]['rebf']);
echo json_encode($redata);    
}

if(isset($_POST['foot'])){
$disp=$_SESSION['axes_purde'][0]['disp'];
$redata=array($_SESSION['axes_purde'][0]['disp'],(get_purdiscount_total(floatval($disp))-get_purdiscount_total()),get_purdiscount_total($disp),$_SESSION['axes_purde'][0]['vatp'],$_SESSION['axes_purde'][0]['vatamo'],$_SESSION['axes_purde'][0]['freight'],$_SESSION['axes_purde'][0]['less'],$_SESSION['axes_purde'][0]['gtotal'],$_SESSION['axes_purde'][0]['taxp'],$_SESSION['axes_purde'][0]['taxamo'],$_SESSION['axes_purde'][0]['spmony'],$_SESSION['axes_purde'][0]['others'],$_SESSION['axes_purde'][0]['name']);
echo json_encode($redata);	
exit;
}

if(isset($_POST['purdis'])){
$disp=floatval($_POST['purdis']);
if(isset($_SESSION['axes_purde'])){
if($disp>0){
$_SESSION['axes_purde'][0]['disp']= getfloatval($disp);
$_SESSION['axes_purde'][0]['disamo']=getfloatval(get_purdiscount_total(floatval($disp)));    
}else{    
$_SESSION['axes_purde'][0]['disp']= getfloatval(0);
$_SESSION['axes_purde'][0]['disamo']=getfloatval(0);    
}
}
}

if(isset($_POST['purvat'])){
$rvat=floatval($_POST['purvat']);
$disp=$_SESSION['axes_purde'][0]['disp'];    
if(isset($_SESSION['axes_purde'])){
if($rvat>0){	
$_SESSION['axes_purde'][0]['vatp']= getfloatval($rvat);
$_SESSION['axes_purde'][0]['vatamo']= getfloatval((((get_purchase_total()-(get_purdiscount_total($disp)-get_purdiscount_total()))*$rvat)*0.01));    
}else{    
$_SESSION['axes_purde'][0]['vatp']= 0;
$_SESSION['axes_purde'][0]['vatamo']= 0;    
}
} 
}

if(isset($_POST['purtax'])){
$rtax=floatval($_POST['purtax']);
$disp=$_SESSION['axes_purde'][0]['disp'];    
if(isset($_SESSION['axes_purde'])){
if($rtax>0){	
$_SESSION['axes_purde'][0]['taxp']= getfloatval($rtax);
$_SESSION['axes_purde'][0]['taxamo']= getfloatval((((get_purchase_total()-(get_purdiscount_total($disp)-get_purdiscount_total()))*$rtax)*0.01));    
}else{    
$_SESSION['axes_purde'][0]['taxp']= 0;
$_SESSION['axes_purde'][0]['taxamo']= 0;    
}
}
}

if(isset($_POST['others'])){
$ota=floatval($_POST['others']);
if(isset($_SESSION['axes_purde'])){
$_SESSION['axes_purde'][0]['others']=getfloatval($ota);	
}
}

if(isset($_POST['otname'])){
$otn=$_POST['otname'];
if($otn==''){return;}
if(isset($_SESSION['axes_purde'])){
$_SESSION['axes_purde'][0]['name']=ucwords($otn);	
}	
}

if(isset($_POST['spmoney'])){
$spe=floatval($_POST['spmoney']);
if(isset($_SESSION['axes_purde'])){
$_SESSION['axes_purde'][0]['spmony']=getfloatval($spe);	
} 
}

if(isset($_POST['freight'])){
$fre=floatval($_POST['freight']);
if(isset($_SESSION['axes_purde'])){
$_SESSION['axes_purde'][0]['freight']=getfloatval($fre);	
}
}

if(isset($_POST['less'])){
$less=floatval($_POST['less']);
if(isset($_SESSION['axes_purde'])){
if($less>0){
$_SESSION['axes_purde'][0]['less']= getfloatval($less);    
}else{    
$_SESSION['axes_purde'][0]['less']= 0;   
}
}
}

if(isset($_SESSION['axes_purde'])){
if(is_array($_SESSION['axes_purde'])){    
$disps=$_SESSION['axes_purde'][0]['disp'];
if($disps>0){
$_SESSION['axes_purde'][0]['disamo']=getfloatval(get_purdiscount_total(floatval($disps)));	
}else{
$_SESSION['axes_purde'][0]['disamo']=getfloatval(get_purdiscount_total());	
}
$vatps=$_SESSION['axes_purde'][0]['vatp'];
if($vatps>0){
$_SESSION['axes_purde'][0]['vatamo']= getfloatval(((get_purchase_total()-(get_purdiscount_total($disps)- get_purdiscount_total()))*$vatps)*0.01);	
}
$taxps=$_SESSION['axes_purde'][0]['taxp'];
if($taxps>0){
$_SESSION['axes_purde'][0]['taxamo']= getfloatval(((get_purchase_total()-(get_purdiscount_total($disps)- get_purdiscount_total()))*$taxps)*0.01);	
}
$freight=$_SESSION['axes_purde'][0]['freight'];
$vatamos=$_SESSION['axes_purde'][0]['vatamo'];
$taxamos=$_SESSION['axes_purde'][0]['taxamo'];
$spmoney=$_SESSION['axes_purde'][0]['spmony'];
$other=$_SESSION['axes_purde'][0]['others'];
$lesss=$_SESSION['axes_purde'][0]['less'];    
}else{
$disps=0;
$vatps=0;
$vatamos=0;
$taxamos=0;
$spmoney=0;
$freight=0;
$other=0;
$lesss=0;    
}
$_SESSION['axes_purde'][0]['gtotal']=getfloatval((get_purchase_total()+$vatamos+$spmoney+$other+$taxamos+$freight)-((get_purdiscount_total(floatval($disps))- get_purdiscount_total())+$lesss));
}

if(isset($_POST['removeitmsl'])){
$ids = floatval($_POST['removeitmsl']);
$pid=$_SESSION['axes_purse'][$ids]['pid'];
$itid=get_pucartitemid($pid);
$itmqty=$_SESSION['axes_purchase'][$itid]['qty'];    
    
remove_imei($ids);
if($itmqty<=1){
remove_purchase($itid);    
}else{
$_SESSION['axes_purchase'][$itid]['qty']=($itmqty-1);
$dis = $_SESSION['axes_purchase'][$itid]['disf'];    
$cost = $_SESSION['axes_purchase'][$itid]['cost'];
$sqty = $_SESSION['axes_purchase'][$itid]['qty'];
$disamo = getfloatval(($dis*$sqty));
$stot = ($cost*$sqty);
if($cost>0){
$disp=(($dis/$cost)*100);
}else{
$disp=0;	
}
$_SESSION['axes_purchase'][$itid]['disp']=getfloatval($disp);
$_SESSION['axes_purchase'][$itid]['disamo']=$disamo;
$_SESSION['axes_purchase'][$itid]['subtot'] = getfloatval(($stot-$disamo));    
}

$max=count($_SESSION['axes_purchase']);
if($max <= 0){
unset($_SESSION['axes_purchase']);
unset($_SESSION['axes_purde']);
if(isset($_SESSION['axes_purse'])){
unset($_SESSION['axes_purse']);	
}	
}    	
}

if(isset($_POST['upimei'])){
$ids=intval($_POST['upimei']);
$imei=strtoupper(remove_junk(escape($_POST['imeidata'])));
if(check_imei($imei)){
$redata=array($_SESSION['axes_purse'][$ids]['imei']);
echo json_encode($redata);
return;	
}
if(check_eximei($imei)){
$redata=array($_SESSION['axes_purse'][$ids]['imei']);
echo json_encode($redata);
return;	
}	
$_SESSION['axes_purse'][$ids]['imei']= $imei;
$redata=array($_SESSION['axes_purse'][$ids]['imei']);
echo json_encode($redata);
}

if(isset($_POST['clear'])){
if(isset($_SESSION['axes_purchase'])){
unset($_SESSION['axes_purchase']);
unset($_SESSION['axes_purde']);    
}
if(isset($_SESSION['axes_purse'])){
unset($_SESSION['axes_purse']);	
}
}

if(isset($_POST['supbal'])){
if(strlen($_POST['supbal'])>0){    
$id=str_replace('_','',$_POST['supbal']);
$ldebit=get_ledgerval($id,'D','N');
$lcredit=get_ledgerval($id,'C','N');
$lnet=($ldebit-$lcredit);
echo number_format($lnet,2);
}else{
echo '0.00';    
}    
}

if(isset($_POST['purdata'])){
//$edata=array(getcheck_price('IC'),getcheck_price('PC'),get_mobile_count(),get_imei_count(),check_empty(),getcheck_price('SP'));
//echo json_encode($edata);
$cdata = purcheck();
if(strlen($cdata)>0){    
echo json_encode(array(
'status' => 'error',
'message'=> purcheck()
));
return;
}else{
echo json_encode(array(
'status' => 'ok',
'message'=> ''
));    
}
}

if(isset($_POST['addpurchase'])){
$invno = gen_newinvno('tbl_purchase','PUR');
$apdate = remove_junk(escape($_POST['purdt']));
$nxtdt = remove_junk(escape($_POST['nextdt']));    
    
$sdata=explode('_',remove_junk(escape($_POST['customer'])));
$dty=$sdata['0'];    
$did = $sdata['1'];
    
$baid = remove_junk(escape($_POST['baid']));    
$chkno = remove_junk(escape($_POST['chkno']));
$chkdt = remove_junk(escape($_POST['chkdt']));
if($chkno=='' || strlen($chkno)<2){$chkdt='NULL';$chkno='NULL';}//else{$chkdt="'".$chkdt."'";$chkno="'".$chkno."'";} 

$caname = remove_junk(escape($_POST['caname']));    
$chbid = remove_junk(escape($_POST['chbid']));
$caid = remove_junk(escape($_POST['caid']));
if(strlen($caname)<2){$chbid='NULL';$caid='NULL';}//else{$chbid="'".$chbid."'";$caid="'".$caid."'";}    

$mobid = remove_junk(escape($_POST['mobid']));    
$trxid = remove_junk(escape($_POST['trxid']));

if($baid!=''){
$creditid=$baid;
$details="'".'CHK_'.$chkno.'_'.$chkdt."'";    
}elseif(strlen($caname)>0){
$creditid=$caid;
$details="'".'CRD_'.$caname.'_'.$chbid."'";    
}elseif($mobid!=''){
$creditid=$mobid;
$details="'".'MOB_'.$trxid."'";    
}else{
$creditid='LE_2';
$details='NULL';    
} 

$ref = remove_junk(escape($_POST['ref']));
$note = remove_junk(escape($_POST['note']));
$purp = remove_junk(escape($_POST['purp']));
if($purp=='' || $purp=='-Select-'){$purp='NULL';}else{$purp="'".$purp."'";}     

$adjust = remove_junk(escape($_POST['adjust']));
if($adjust==''){$adjust=0;}     
$cash = remove_junk(escape($_POST['cash']));
if($cash==''){$cash=0;}    
    
$divt = explode('_',remove_junk(escape($_POST['ivt'])));   
$ivty = $divt['0'];
$ivt = $divt['1'];   
if($ivty=='BR'){
    $ibrid="'".$ivt."'"; 
    $iwhid='NULL';
}elseif($ivty=='WH'){
    $ibrid='NULL'; 
    $iwhid="'".$ivt."'";
}    
     
$itmdis=remove_junk(escape(get_purdiscount_total()));    
$disp=remove_junk(escape($_SESSION['axes_purde'][0]['disp']));
$disamo=remove_junk(escape($_SESSION['axes_purde'][0]['disamo']));   
$vatp=remove_junk(escape($_SESSION['axes_purde'][0]['vatp']));
$vatamo=remove_junk(escape($_SESSION['axes_purde'][0]['vatamo']));
$taxp=remove_junk(escape($_SESSION['axes_purde'][0]['taxp']));
$itax=$taxp;    
$taxamo=remove_junk(escape($_SESSION['axes_purde'][0]['taxamo']));
$freight=remove_junk(escape($_SESSION['axes_purde'][0]['freight']));
$spmony=remove_junk(escape($_SESSION['axes_purde'][0]['spmony']));
$otname=remove_junk(escape($_SESSION['axes_purde'][0]['name']));
$otamo=remove_junk(escape($_SESSION['axes_purde'][0]['others']));
$less=remove_junk(escape($_SESSION['axes_purde'][0]['less']));
$subtot=get_purchase_total();    
$gtotal=remove_junk(escape($_SESSION['axes_purde'][0]['gtotal']));

$prjid= sqloutdata($_POST['prjid'],'U');    
$lcno= sqloutdata($_POST['lcno'],'U');    
$pino=sqloutdata($_POST['pino'],'U');
$lcvlue=sqloutdata($_POST['lcvlue']);
$lcdate=sqloutdata($_POST['lcdate']);
$pidate=sqloutdata($_POST['pidate']);
$lcbank=sqloutdata($_POST['lcbank']);
    
if($disp>0){
$invdis=($disamo-$itmdis);    
}else{
$invdis=0;    
}

if(($adjust+$cash)>=$gtotal){
$rcash=($gtotal-$adjust);
$change=(($adjust+$cash)-$gtotal);
$due=0;
$duedt='NULL';    
}else{
$rcash=$cash;
$change=0;
$due=($gtotal-($adjust+$cash));
$duedt="'".$nxtdt."'";    
}    
    
if(!isset($_SESSION['axes_purchase'])){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! No item found!!'
));
return;
exit;  
}   

if($did==0 && $due>0){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Due not permitted for Local Purchase!!'
));
return;
exit;    
}    
    
if(isset($_SESSION['coninv'])){
$orno="'".$_SESSION['coninv']."'";
}else{
$orno='NULL';
}    
    
$sql="INSERT INTO tbl_purchase (invno,refinv,type,supid,itemdis,subtot,disp,disamo,totdis,vatp,vatamo,taxp,taxamo,spmoney,otname,otamo,freight,less,adamo,total,curid,ref,note,apdate,nxtduedate,rawcash,changes,purp,creditid,details,prjno,lcno,lcdate,pino,pidate,lcbank,lcvalu,brid,uid,date) VALUES ('$invno',$orno,'$dty','$did','$itmdis','$subtot','$disp','$invdis','$disamo','$vatp','$vatamo','$taxp','$taxamo','$spmony','$otname','$otamo','$freight','$less','$adjust','$gtotal','0','$ref','$note','$apdate',$duedt,'$cash','$change',$purp,'$creditid',$details,$prjid,$lcno,$lcdate,$pino,$pidate,$lcbank,$lcvlue,'$brid','$aid','$dtnow')";
   
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sid=$con->insert_id;    
$efid=mysqli_affected_rows($con);
   
if($efid>0){
$max=count($_SESSION['axes_purchase']);
for($i=0;$i<$max;$i++){
$pid=$_SESSION['axes_purchase'][$i]['pid'];
$unqid=gen_protrucking('tbl_traproduct','GP');    
$col=$_SESSION['axes_purchase'][$i]['col'];
$siz=$_SESSION['axes_purchase'][$i]['siz'];
$cost=$_SESSION['axes_purchase'][$i]['cost'];
$puqty=$_SESSION['axes_purchase'][$i]['qty'];
    
if(get_fild_data('tbl_setting','2','sval')==0){    
$qtyin=$_SESSION['axes_purchase'][$i]['qty'];
}else{
if(isset($_POST['purcv']) && $_POST['purcv']==0){
$qtyin=$_SESSION['axes_purchase'][$i]['qty'];    
}else{
$qtyin=0;     
}       
}
    
$soqty=0;
$qtyout=0;
$taxp=0;
$taxamo=0;
$idisp=$_SESSION['axes_purchase'][$i]['disp'];
$idisf=$_SESSION['axes_purchase'][$i]['disf'];
$disamo=$_SESSION['axes_purchase'][$i]['disamo'];
$sdisp=$_SESSION['axes_purchase'][$i]['sdisp'];
$sdisf=$_SESSION['axes_purchase'][$i]['sdisf'];
$rebp=$_SESSION['axes_purchase'][$i]['rebp'];
$rebf=$_SESSION['axes_purchase'][$i]['rebf'];    
$price=$_SESSION['axes_purchase'][$i]['price'];
$isubtot=$_SESSION['axes_purchase'][$i]['subtot'];
$wday=$_SESSION['axes_purchase'][$i]['wday'];    
    
$sql="INSERT INTO tbl_traproduct (type,tid,invno,refinv,pid,unqid,colid,sizid,cost,price,p_qty,p_in,s_qty,p_out,taxp,taxamo,disp,disf,disamo,subtot,wday,mods,brid,waid,tramod,isinv,rbp,rbf,uid,apdate,date) VALUES ('$dty','$did','$invno',NULL,'$pid','$unqid','$col','$siz','$cost','$price','$puqty','$qtyin','$soqty','$qtyout','$taxp','$taxamo','$idisp','$idisf','$disamo','$isubtot','$wday','PU',$ibrid,$iwhid,NULL,'Y','$rebp','$rebf','$aid','$apdate','$dtnow')";
   
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$efit=mysqli_affected_rows($con);
if($efit>0){
$code=get_fild_data('tbl_item',$pid,'code').'B'.$sid;    
$pcost=get_proacost(floatval($cost),floatval($idisf),floatval($disp),floatval($vatp),floatval($itax),floatval($subtot),floatval($otamo),floatval($spmony),floatval($freight),floatval($less));
$invdis=getfloatval(($cost-$idisf)*($disp/100));     
//$pcost=getfloatval(($cost-$idisf)-$invdis);       
$sql="INSERT INTO tbl_stock (invno,prjid,pid,unqid,code,icdis,icinvdis,cost,price,taxp,disp,disf,wday,ofid,status) VALUES ('$invno',$prjid,'$pid','$unqid','$code','$idisf','$invdis','$pcost','$price','$taxp','$sdisp','$sdisf','$wday',NULL,'1')";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
}    
}

if(isset($_SESSION['axes_purse'])){
$max=count($_SESSION['axes_purse']);
for($i=0;$i<$max;$i++){
$pid=$_SESSION['axes_purse'][$i]['pid'];
$serial=$_SESSION['axes_purse'][$i]['imei'];

if(get_fild_data('tbl_setting','2','sval')==0){    
$rci='Y';
}else{
if(isset($_POST['purcv']) && $_POST['purcv']==0){
$rci='Y';    
}else{
$rci='N';     
}       
}    
    
$sql="INSERT INTO tbl_serial (purinv,pid,unqid,serial,rci,brid,whid,status) VALUES ('$invno','$pid','N/A','$serial','$rci',$ibrid,$iwhid,'0')";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));    
}    
}

//purchase_update($sid,'tbl_purchase',$dtnow);    
unset($_SESSION['axes_purchase']);
unset($_SESSION['axes_purde']);
if(isset($_SESSION['axes_purse'])){
unset($_SESSION['axes_purse']);
}    

if(isset($_SESSION['conpor'])){
unset($_SESSION['conpor']);   
unset($_SESSION['coninv']);
unset($_SESSION['supval']);    
}    
    
$act =remove_junk(escape('Purchase Invoice: '.$invno));    
write_activity($aid,'PUR','New purchase invoice has been Created',$act);
echo json_encode(array(
'status' => 'success',
'message'=> 'Purchase Save Successfully!!',
'invid'=> $sid     
));
exit;    
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));    
}
    
}
?>

<?php 
if(isset($_POST['checkview'])){
$cusd=explode('_',$_POST['cusid']);
$typ=$cusd[0];    
$cusid=$cusd[1];   
if(isset($_SESSION['axes_purde'])){    
$gtotal=$_SESSION['axes_purde'][0]['gtotal'];
}else{
$gtotal=0;    
}
$id=str_replace('_','',$_POST['cusid']);
$ldebit=get_ledgerval($id,'D','N');
$lcredit=get_ledgerval($id,'C','N');
if($cusid!=0){
$lnet=($ldebit-$lcredit);     
}else{
$lnet=0;    
}        
?>
<div class="addpurchase">
<div class="row">
<div class="col-md-3 col-xs-6">
<div class="small-box">
<div class="inner">
<h3 id="pabamo"><?php echo $gtotal;?></h3>
<p>Total Payable</p>
</div>

</div>
<input type="hidden" value="<?php echo $_POST['cusid']; ?>" id="customer" name="customer" readonly />
<input type="hidden" value="<?php if($lnet<0){echo ABS($lnet);}else{echo 0;} ?>" id="balance" name="balance" readonly />
<input type="hidden" name="addpurchase" readonly />
<input type="hidden" name="scusid" id="scusid" value="<?php echo $cusid; ?>" readonly />    
</div>
<div class="col-md-3 col-xs-6">
<div class="small-box">
<div class="inner">
<h3 id="paidamo">0</h3>
<p>Paid Amount</p>
<input type="hidden" value="" id="recamo" name="recamo" readonly />    
</div>

</div>
</div>
<div class="col-md-3 col-xs-6">
<div class="small-box">
<div class="inner">
<h3 id="dueamo"><?php echo $gtotal;?></h3>
<p>Total Due</p>
</div>

</div>
</div>
<div class="col-md-3 col-xs-6">
<div class="small-box">
<div class="inner">
<h3 id="changamo">0</h3>
<p>Change</p>
</div>

</div>
</div>    
</div>
<div class="row">
<div class="col-md-4 col-xs-6">
<div class="form-group">
<label>Balance (<?php echo $lnet;?>)</label>    
<input type="text" maxlength="10" class="form-control cashr" value="0" name="adjust" id="adjust"  onkeypress="return isNumberKey(event)" placeholder="e.g. 500" autocomplete="off" <?php if($lnet<=0){echo 'disabled';}?>>    
</div>    
</div>
<div class="col-md-4 col-xs-6">
<div class="form-group">
<label>Cash</label>    
<input type="text" maxlength="10" class="form-control cashr" name="cash" id="cash"  onkeypress="return isNumberKey(event)" placeholder="e.g. 500" autocomplete="off">    
</div>    
</div>
<div class="col-md-2 col-xs-6">
<div class="form-group" >
<label>Purchase Date</label>
<input type="text" class="form-control datetimepicker" name="purdt" id="purdt" value="<?php echo $today;?>" placeholder="Purchase Date" autocomplete="off" readonly>
</div>
</div>
<div class="col-md-2 col-xs-6">
<div class="form-group" >
<label>Next Due Date</label>
<input type="text" class="form-control datetimepicker" name="nextdt" id="nextdt" value="<?php echo date('Y-m-d', strtotime('+7 days',strtotime($today)));?>" placeholder="Next Due Date" autocomplete="off" readonly>
</div>    
</div>
</div>
<div class="row" style="border-top: 2px solid red; border-bottom: 2px solid black;">
<div class="col-xs-3"> <!-- required for floating -->
<!-- Nav tabs -->
<ul class="nav nav-tabs tabs-left sideways">
<li class="active"><a href="#bankpay" data-toggle="tab" class="tabpoint" id="tbank">Bank</a></li>
<li><a href="#cardpay" data-toggle="tab" class="tabpoint" id="tcard">Card</a></li>
<li><a href="#mobilepay" data-toggle="tab" class="tabpoint" id="tmobile">Mobile</a></li>
</ul>
</div>

<div class="col-xs-9">
<!-- Tab panes -->
<div class="tab-content" style="padding-top: 10px;">
<div class="tab-pane active" id="bankpay">
<div class="row">
<div class="col-md-8">
<div class="form-group">
<label>Select Bank</label>    
<select class="form-control select2" name="baid" id="baid">
<option value="">-Select-</option>    
<?php
$sql="SELECT tbl_bacount.id,CONCAT(tbl_bank.sort,' - ',tbl_bacount.acno) AS name FROM tbl_bacount LEFT JOIN tbl_bank ON tbl_bank.id=tbl_bacount.bid ORDER BY tbl_bank.sort ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'BA_'.$rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>   
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group">
<label>Cheque No</label>
<input type="text" maxlength="20" class="form-control" name="chkno" id="chkno" value="" placeholder="e.g. KA7865467" autocomplete="off" disabled="disabled">
</div>    
</div>
<div class="col-md-6">
<div class="form-group" >
<label>Cheque Date</label>
<input type="text" class="form-control datetimepicker" name="chkdt" id="chkdt" value="" placeholder="Cheque Date" autocomplete="off" disabled="disabled" readonly>
</div>    
</div>    
</div>    
</div>
<div class="tab-pane" id="cardpay">
<div class="row">
<div class="col-md-8">    
<div class="form-group">
<label>Card Holder Name</label>
<input type="text" maxlength="35" class="form-control" name="caname" id="caname" value="" placeholder="e.g. Md.Sumon" autocomplete="off">
</div> 
</div>     
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group">
<label>Card Holder Bank</label>    
<select class="form-control select2" name="chbid" id="chbid">
<option value="">-Select-</option>    
<?php
$sql="SELECT id,name FROM tbl_bank ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'BA_'.$rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>   
</div>    
</div>    
<div class="col-md-6">    
<div class="form-group">
<label>Withdrwn Bank</label>    
<select class="form-control select2" name="caid" id="caid">
<option value="">-Select-</option>    
<?php
$sql="SELECT tbl_bacount.id,CONCAT(tbl_bank.sort,' - ',tbl_bacount.acno) AS name FROM tbl_bacount LEFT JOIN tbl_bank ON tbl_bank.id=tbl_bacount.bid ORDER BY tbl_bank.sort ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'BA_'.$rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>   
</div>
</div>
</div>     
</div>
<div class="tab-pane" id="mobilepay">
<div class="row">
<div class="col-md-6">
<div class="form-group">
<label>Mobile Account</label>    
<select class="form-control select2" name="mobid" id="mobid">
<option value="">-Select-</option>    
<?php
$sql="SELECT id,name,mobile FROM tbl_acmobile ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'MO_'.$rows['id'];?>"><?php echo $rows['name'].' - '.$rows['mobile'];?></option>
<?php } ?>
</select>   
</div>    
</div> 
<div class="col-md-6">
<div class="form-group">
<label>TrxID</label>
<input type="text" maxlength="20" class="form-control" name="trxid" id="trxid" value="" placeholder="e.g. KA7865467" autocomplete="off">
</div>    
</div>     
</div>    
</div>
</div>
</div>
<div class="clearfix"></div>    
</div>
<div class="row">
<br>   
<div class="col-md-4">
<div class="form-group">
<label>Product Store</label>    
<select class="form-control select2" name="ivt" id="ivt">
<optgroup label="Branch">
<?php if($brid==0){ ?>
<option selected value="BR_0">-No Branch-</option>    
<?php }else{ ?>
<option value="BR_0">-No Branch-</option>    
<?php } ?>    
<?php 
$sql="SELECT id,name FROM tbl_branch Order by name ASC";
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){    
?>
<?php if($rows['id']==$brid){?>
<option selected value="<?php echo 'BR_'.$rows['id'];?>"><?php echo $rows['name'];?></option>    
<?php }else{ ?>
<option value="<?php echo 'BR_'.$rows['id'];?>"><?php echo $rows['name'];?></option>    
<?php } ?>    
<?php } ?>    
</optgroup>    
<?php
$sql="SELECT id,name FROM tbl_warehouse ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
if($querys->num_rows > 0) {?>
<optgroup label="Warehouse">    
<?php    
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'WH_'.$rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</optgroup> 
<?php } ?>
</select>   
</div>    
<div class="form-group">
<label>Ref</label>
<input type="text" maxlength="25" class="form-control" name="ref" id="ref" value="" placeholder="e.g. #ORD8976453" autocomplete="off">    
</div>
<div class="form-group">
<label>Purchase Person</label>    
<select class="form-control select2" name="purp" id="purp">
<option value="">-Select-</option>    
<?php
$sql="SELECT id,name FROM tbl_employe ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>    
</div>
<div class="form-group" >
<label>Project</label>        
<select class="form-control select2" name="prjid" id="prjid">
<option value="">-Select-</option>
<?php
$sql="SELECT * FROM tbl_project WHERE status IN ('0','1','3') ORDER BY date DESC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($prj=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $prj['id'];?>"><?php echo $prj['prjid'];?></option>
<?php } ?>
</select>      
</div>    
</div>
<div class="col-md-8">    
<div class="form-group">    
<label>Note</label>
<textarea class="form-control" name="note" id="note" maxlength="150" rows="5" placeholder="Invoice Note"></textarea>    
</div>
<div class='col-md-6'>
<div class="form-group">
<label>L/C No:</label>
<input type="text" maxlength="25" class="form-control" name="lcno" id="lcno" value="" placeholder="e.g. #LC8976453" autocomplete="off">    
</div>
<div class="form-group">
<label>PI No:</label>
<input type="text" maxlength="25" class="form-control" name="pino" id="pino" value="" placeholder="e.g. #PI8976453" autocomplete="off">    
</div>
<div class="form-group">
<label>L/C Value:</label>
<input type="text" maxlength="25" class="form-control" name="lcvlue" id="lcvlue" onkeypress="return isNumberKey(event)" value="" placeholder="e.g. 560" autocomplete="off">    
</div>    
</div>
<div class='col-md-6'>
<div class="form-group">
<label>L/C Date:</label>
<input type="text" class="form-control datetimepicker" name="lcdate" id="lcdate" value="" placeholder="PI Date" autocomplete="off" readonly>    
</div>
<div class="form-group">
<label>PI Data:</label>
<input type="text" class="form-control datetimepicker" name="pidate" id="pidate" value="" placeholder="PI Date" autocomplete="off" readonly>    
</div>
<div class="form-group">
<label>L/C Bank:</label>
<select class="form-control select2" name="lcbank" id="lcbank">
<option value="">-Select-</option>    
<?php
$sql="SELECT id,name FROM tbl_bank ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>    
</div>    
</div>    
<?php if(get_fild_data('tbl_setting','2','sval')==1){ ?>    
<div class="form-group">
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Purchase Received Now';}else{echo 'ক্রয় কৃত পণ্য গ্রহণ এখনি';}?></label>    
<select class="form-control select2" name="purcv" id="purcv">    
<option <?php if(get_fild_data('tbl_setting','2','sval')==0){echo 'selected';} ?> value="0"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Yes';}else{echo 'হ্যাঁ';}?></option>
<option <?php if(get_fild_data('tbl_setting','2','sval')==1){echo 'selected';} ?> value="1"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'No';}else{echo 'না';}?></option> 
</select>    
</div>
<?php } ?>    
</div>    
</div>
</div>    
<div class="row">
<div class="col-md-12 text-center side-checkhead">
<button class="btn btn-flat bg-blue saveseinv" id="saveinv"><i class="fa fa-floppy-o"></i>&nbsp;&nbsp;Save</button>    
<button class="btn btn-flat bg-gray saveseinv" id="sinvprint"><i class="fa fa-floppy-o"></i>&nbsp;&nbsp; Invoice &nbsp;&nbsp;<i class="fa fa-print"></i></button>   
</div>    
</div>
<script type="text/javascript">
function cashcalculation(){
var pab = parseFloat($('#pabamo').html());
var cash = parseFloat($('#cash').val());
var adv = parseFloat($('#balance').val());
var adj = parseFloat($('#adjust').val());    
var paid=0; due=0; chang=0;
if(isNaN(cash)){
cash=0;    
}
if(isNaN(adj)){
adj=0;    
}
    
if((cash+adj)<=pab){
paid=cash;
due=(pab-(cash+adj));
chang=0;    
}else{
paid=pab;
due=0;
chang=((cash+adj)-pab);    
}
$('#paidamo').html(paid);
$('#dueamo').html(due);
$('#changamo').html(chang);   
}
    
$(document).on('keyup', '#cash', function() { 
cashcalculation();
});
    
$(document).on('keyup', '#adjust', function() {
var pab = parseFloat($('#pabamo').html());    
var adv = parseFloat($('#balance').val());
var adj = parseFloat($('#adjust').val());    
var maxad = 0;
if(pab<=adv){
maxad=pab;
}else{
maxad=adv;    
}
if(adj>maxad){
$('#adjust').val(maxad);    
}    
cashcalculation();
});
    
$(document).on('change', '#baid', function() {
id_arr = $(this).val();
id = id_arr.split("_");
type=id[0];
if(type=='BA'){
document.getElementById("chkno").disabled=false; 
document.getElementById("chkdt").disabled=false;     
}else{
$('#chkno').val('');
$('#chkdt').val('');    
document.getElementById("chkno").disabled=true; 
document.getElementById("chkdt").disabled=true;    
}    
});    
    
$(document).on('click', '.tabpoint', function() { 
var tval=$(this).attr('id');
if (tval=='tbank'){
$("#caname").val("");    
$("#chbid").val("").trigger("change");
$("#caid").val("").trigger("change");
$("#mobid").val("").trigger("change");
$("#trxid").val("");    
}else if(tval=='tcard'){
$("#baid").val("").trigger("change");
$("#chkno").val("");
$("#chkdt").val("");    
$("#mobid").val("").trigger("change");
$("#trxid").val("");
}else if(tval=='tmobile'){
$("#baid").val("").trigger("change");
$("#chkno").val("");
$("#chkdt").val("");
$("#caname").val("");    
$("#chbid").val("").trigger("change");
$("#caid").val("").trigger("change");    
}
          
});    

function chek_error(){
var result = true;    
var baid = $('#baid').val();
var chkno = $('#chkno').val();
var chkdt = $('#chkdt').val();
    
var caname = $('#caname').val();
var chbid = $('#chbid').val();
var caid = $('#caid').val();
    
var mobid = $('#mobid').val();
var trxid = $('#trxid').val(); 

$('.LV_invalid_field').removeClass('LV_invalid_field');     
$('.LV_validation_message').remove();    
    
if(baid != ''){
if(chkno.length>=0 && chkno.length<5){
$('#chkno').addClass('LV_invalid_field');   
$('#chkno').after("<span class='LV_validation_message LV_invalid'>Enter Valid Cheque No!</span>").addClass('has-error'); 
result=false;
}else{
$('#chkno').removeClass('LV_invalid_field');
result=true;    
} 

if(chkdt.length<=0){
$('#chkdt').addClass('LV_invalid_field');   
$('#chkdt').after("<span class='LV_validation_message LV_invalid'>Enter Cheque Date!</span>").addClass('has-error');
result=false;    
}else{
$('#chkdt').removeClass('LV_invalid_field');
result=true;    
}    
}    

if(caname.length>0){
if(chbid == '-Select-' || chbid == ''){
$('#chbid').addClass('LV_invalid_field');   
$('#chbid').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
} else {
$('#chbid').removeClass('LV_invalid_field');
result=true;    
}
    
if(caid == '-Select-' || caid == ''){
$('#caid').addClass('LV_invalid_field');   
$('#caid').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
} else {
$('#caid').removeClass('LV_invalid_field');
result=true;    
}    
}    

if(mobid != ''){
if(trxid.length>=0 && trxid.length<5){
$('#trxid').addClass('LV_invalid_field');   
$('#trxid').after("<span class='LV_validation_message LV_invalid'>Enter Valid TrxID No!</span>").addClass('has-error'); 
result=false;
}else{
$('#trxid').removeClass('LV_invalid_field');
result=true;    
}    
}    

if(!result){
return false;    
}else{
return true;     
}    
    
}
    
$(".select2").select2();    
$('.datetimepicker').datepicker({format: "yyyy-mm-dd", autoclose: true, clearBtn: true, orientation: 'auto bottom'});    
</script>    
<?php } ?>

<?php 
if(isset($_POST['checkout'])){
$cusd=explode('_',$_POST['cusid']);
$typ=$cusd[0];    
$cusid=$cusd[1];    
?>
<div class="col-md-12 cart-border-left text-center">
<div class="horizontal-scroll">
<h5 class="text-center" style="font-size: 20px;">Purchase Details</h5> 
<div>
<div class="text-center header-line-height">
<small class="text-center" style="font-size: 15px;"><?php echo get_cominfo('1','name');?></small>
<br> <small class="text-center"><?php echo date("d M Y", strtotime($today));?></small>
<br> <small class="text-center" style="font-size: 12px;"><strong>Purchase Receipt</strong></small>
<!--<br> <small class="text-left">Sold By: John Doe</small>--> 
<br> <small><span>Purchase From: <?php if($cusid!=0){if($typ=='SU'){echo get_fild_data('tbl_supplier',$cusid,'name');}else{echo get_fild_data('tbl_customer',$cusid,'name');}}else{echo 'Walk-In Customer';};?></span></small> 
<small class="text-left invoice-show" style="display: none;">Invoice ID:</small>
</div> 
<div class="invoice-table">
<table class="table product-card-font" style="font-weight: 500;">
<thead class="border-top-0">    
<tr>
<th class="cart-summary-table text-left">Items</th> 
<th class="cart-summary-table text-left">Qty</th> 
<th class="cart-summary-table text-right">Price</th>
<th class="cart-summary-table text-right">Discount</th>
<th class="cart-summary-table text-right" width="80px;">Total</th>
</tr>   
</thead> 
<tbody>
<?php 
$s=0;    
if(isset($_SESSION['axes_purchase'])){
$max=count($_SESSION['axes_purchase']);
for($i=($max-1);$i>=0;$i=$i-1){
$name=$_SESSION['axes_purchase'][$i]['name'];
$col=$_SESSION['axes_purchase'][$i]['col'];
if($col==0){$col='';}
$siz=$_SESSION['axes_purchase'][$i]['siz'];
if($siz==0){$siz='';}    
$qty=$_SESSION['axes_purchase'][$i]['qty'];
$price=$_SESSION['axes_purchase'][$i]['price'];
$disp=$_SESSION['axes_purchase'][$i]['disp'];    
$subtot=$_SESSION['axes_purchase'][$i]['subtot'];
$pnote=$_SESSION['axes_purchase'][$i]['price'];
if($col=='' && $siz==''){
$name=$name;    
}elseif($col!='' && $siz==''){
$name= $name.' '.get_fild_data('tbl_color',$col,'name');    
}elseif($col=='' && $siz!=''){
$name= $name.' '.get_fild_data('tbl_size',$siz,'sval');    
}elseif($col!='' && $siz!=''){    
$name= $name.' '.get_fild_data('tbl_color',$col,'name').' '.get_fild_data('tbl_size',$siz,'sval');    
}     
$s+=1;    
?>    
<tr>
<td class="cart-summary-table text-left"><?php echo $name;?><br></td>
<td class="cart-summary-table"><?php echo $qty;?></td> 
<td class="text-right cart-summary-table"><?php echo numtolocal($price,''); ?></td> 
<td class="text-right cart-summary-table"><?php echo $disp;?> %</td> 
<td class="text-right cart-summary-table"><?php echo numtolocal($subtot,''); ?></td>
<?php }} ?>     
</tbody> 
<tfoot>
<?php 
$disp=$_SESSION['axes_purde'][0]['disp'];
$vatp=$_SESSION['axes_purde'][0]['vatp'];
$vatamo=$_SESSION['axes_purde'][0]['vatamo'];
$taxp=$_SESSION['axes_purde'][0]['taxp'];
$taxamo=$_SESSION['axes_purde'][0]['taxamo'];
$otname=$_SESSION['axes_purde'][0]['name'];
$others=$_SESSION['axes_purde'][0]['others'];
$spmony=$_SESSION['axes_purde'][0]['spmony'];    
$less=$_SESSION['axes_purde'][0]['less'];
$freight=$_SESSION['axes_purde'][0]['freight'];
$gtotal=$_SESSION['axes_purde'][0]['gtotal'];    
?>    
<tr>
<td class="cart-summary-table font-weight-bold text-left">Sub Total</td> 
<td class="cart-summary-table"></td>
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table"><?php echo numtolocal(get_purchase_total(),'Tk');?></td>
</tr>
<?php if(get_purdiscount_total()>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">Discount(<?php echo $disp.'';?>%)</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal(get_purdiscount_total($disp),'Tk');?></td>
</tr>    
<?php } ?>
<?php if($vatamo>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">VAT(<?php echo $vatp.'';?>%)</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($vatamo,'Tk');?></td>
</tr>    
<?php } ?>
<?php if($taxamo>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">TAX(<?php echo $taxp.'';?>%)</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($taxamo,'Tk');?></td>
</tr>    
<?php } ?>    
<?php if($others>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left"><?php echo $otname;?></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($others,'Tk');?></td>
</tr>    
<?php } ?>
<?php if($spmony>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">Speed Money</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($spmony,'Tk');?></td>
</tr>    
<?php } ?>    
<?php if($freight>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">Freight</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($freight,'Tk');?></td>
</tr>    
<?php } ?> 
<?php if($less>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">Adjust</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($less,'Tk');?></td>
</tr>    
<?php } ?>     
<tr>
<td class="cart-summary-table font-weight-bold text-left">Total</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($gtotal,'Tk');?></td>
</tr> 
</tfoot>
</table>
</div>
</div>
</div>
</div>   
<?php } ?>