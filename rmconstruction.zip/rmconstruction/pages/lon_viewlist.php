<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/invfunctions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){       
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
?>
<?php 
if(isset($_POST['loid'])){
$piid=$_POST['loid'];    
$sql="SELECT * FROM tbl_loanid ORDER BY id ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$bnid='LO'.$row['id'];
$ldebit=get_ledgerval($bnid,'D','N');
$lcredit=get_ledgerval($bnid,'C','N');
$lnet=($ldebit-$lcredit);
if($row['type']==1){$acno=$row['mobile'];}else{$acno=$row['acno'];}    
?>
<li <?php if($row['id']==$piid){echo 'class="invpiv active"';}else{echo 'class="invpiv"';}?> id="pi_<?php echo $row['id'];?>"><p><strong class="pino"><?php echo $acno;?></strong><br><strong><?php echo $row['name'];?></strong></p>
<div class="sname" style="margin-top: -52px;float: right; position: relative;top: 6px;"><strong><?php echo 'Debit: '.numtolocal($ldebit,get_fild_data('tbl_currency','1','symbol')); ?></strong><br><strong><?php echo 'Credit: '.numtolocal($lcredit,get_fild_data('tbl_currency','1','symbol')); ?></strong></div>
</li>
<?php }} ?>