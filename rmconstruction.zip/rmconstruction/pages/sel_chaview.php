<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
$body='';
$foot='';
$buton='';
$s=0;
$totqty=0;

if(isset($_SESSION['axes_rawmat'])){
if(is_array($_SESSION['axes_rawmat'])){
$max=count($_SESSION['axes_rawmat']);
for($i=($max-1);$i>=0;$i=$i-1){
$unqid=$_SESSION['axes_rawmat'][$i]['unqid'];
$pid=$_SESSION['axes_rawmat'][$i]['pid'];    
$code=$_SESSION['axes_rawmat'][$i]['code'];
$name=$_SESSION['axes_rawmat'][$i]['name'];
$unit=$_SESSION['axes_rawmat'][$i]['unid'];  
$cost=$_SESSION['axes_rawmat'][$i]['cost']; 
$qty=$_SESSION['axes_rawmat'][$i]['qty'];
$price=$_SESSION['axes_rawmat'][$i]['price'];
$pnote=$_SESSION['axes_rawmat'][$i]['pnote'];    
$subtot=$_SESSION['axes_rawmat'][$i]['subtot'];
    
$s+=1;
$totqty+=$qty;    

$body.='<tr>';
$body.='<td class="text-center" width="30px">'.$s.'</td>';    
$body.='<td data-toggle="collapse" data-target="#sitem'.$i.'" class="accordion-toggle" style="cursor: pointer;" width="214px">'.$name.'</td>';
$body.='<td width="72px"><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control quantity" id="qty_'.$i.'" value="'.$qty.'"  size="2" style="height: 24px;"/></td>';
$body.='<td width="72px">'.$price.'</td>';
$body.='<td width="77px" id="stotal_'.$i.'" class="text-right">'.getfloatval($subtot).'</td>';
$body.='<td class="text-center" width="25px"><a id="'.$i.'" class="remove"><span style="cursor: pointer;" class="fa fa-times"></span></a></td>';    
$body.='</tr>';
    
$body.='<tr>';
$body.='<td colspan="6" class="hiddenRow"><div class="accordian-body collapse" id="sitem'.$i.'">';
$body.='<table class="table table-bordered table-striped" style="margin-bottom: 0;">';
$body.='<thead>';
$body.='<tr>';
$body.='<th colspan="6" class="text-center" width="316px">Product Note</th>';       
$body.='</tr>';
$body.='</thead>';
$body.='<tbody>';
$body.='<tr>';
$body.='<td colspan="6"><input type="text" maxlength="45" class="form-control pnote" id="pnote_'.$i.'" value="'.$pnote.'"  size="2" style="height: 24px;"/></td>';      
$body.='</tr>';    
$body.='</tbody></table></div></td></tr>';     
}    

if($max>0){
if (!isset($_SESSION['axes_usede'])) {
$_SESSION['axes_usede'] = array();
$_SESSION['axes_usede'][0]['freight']=0;
$_SESSION['axes_usede'][0]['gtotal']=$subtot;    
}
}else{
if(isset($_SESSION['axes_usede'])){
unset($_SESSION['axes_usede']);    
}    
}
if(isset($_SESSION['axes_usede'])){
if(is_array($_SESSION['axes_usede'])){    
$freight=$_SESSION['axes_usede'][0]['freight'];
$gtotal=$_SESSION['axes_usede'][0]['gtotal'];    
}else{
$freight=0;
$gtotal=0;    
}
}else{
$freight=0;
$gtotal=0;    
}    

$foot.='<tr>';
$foot.='<td width="30px"></td>';
$foot.='<td width="214px"></td>';
$foot.='<td width="72px"></td>';
$foot.='<td width="72px"></td>';
$foot.='<td width="35px"></td>';
$foot.='<td width="77px"></td>';
$foot.='<td width="25px"></td>';
$foot.='</tr>';    
$foot.='<tr>';
$foot.='<td colspan="2" class="text-center" width="244px"><strong>-Total-</strong></td>';
$foot.='<td width="72px"><strong>'.$totqty.'</strong></td>';
$foot.='<td colspan="2" width="107px"></td>';
$foot.='<td width="77px" class="text-right"><strong>'.getfloatval(get_rawmat_total()).'</strong></td>';
$foot.='<td></td>';
$foot.='</tr>';	
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>Freight:</strong></td>';
$foot.='<td colspan="2"><input type="text" maxlength="6" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="freight" value="'.getfloatval($freight).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="freightd" class="text-right"><strong>'.getfloatval($freight).'</strong></td>';
$foot.='<td></td>';    
$foot.='</tr>';
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>Grand Total:</strong></td>';
$foot.='<td colspan="2"></td>'; 
$foot.='<td id="grtotal" class="text-right"><strong>'.getfloatval($gtotal).'</strong></td>';
$foot.='<td></td>';    
$foot.='</tr>';    
}else{
$body.='<tr>';
$body.='<td colspan="7" class="text-center">There are no Challan Item!</td>';
$body.='</tr>'; 
} 
}else{
$body.='<tr>';
$body.='<td colspan="7" class="text-center">There are no Challan Item!</td>';
$body.='</tr>';
}
    
$body.="<script>";
$body.="$('.accordian-body').on('show.bs.collapse', function () {";
$body.="$(this).closest('table')";
$body.=".find('.collapse.in')";
$body.=".not(this)";
$body.=".collapse('toggle')";
$body.="})";
$body.="</script>";

if(isset($_SESSION['axes_rawmat'])){
$buton.='<div class="col-md-6">';
$buton.='<input type="button" id="emptycart" class="btn btn-flat bg-red btn-sm" value="Empty"/></div>';
$buton.='<div class="col-md-6 text-right">';   
$buton.='<input type="button" id="save_sales" class="btn btn-flat bg-purple btn-sm" value="Checkout"/>'; 
$buton.='</div>';
}

if(isset($_POST['body'])){
echo $body;
}elseif(isset($_POST['foot'])){
echo $foot;
}elseif(isset($_POST['buton'])){
echo $buton;    
}
exit; 