<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
$body='';
$foot='';
$s=0;
$totamo=0;
if(isset($_SESSION['axes_jouitem'])){
if(is_array($_SESSION['axes_jouitem'])){
$max=count($_SESSION['axes_jouitem']);
for($i=($max-1);$i>=0;$i=$i-1){

$dsgrid = $_SESSION['axes_jouitem'][$i]['dsgrid'];     
$dty = $_SESSION['axes_jouitem'][$i]['dty'];
$did=$_SESSION['axes_jouitem'][$i]['did'];
$dname = get_ledgername($dsgrid,$did);    
$amo=$_SESSION['axes_jouitem'][$i]['amo'];
$cid=$_SESSION['axes_jouitem'][$i]['cid'];
$cty=$_SESSION['axes_jouitem'][$i]['cty'];
$csgrid = $_SESSION['axes_jouitem'][$i]['csgrid'];
$cname = get_ledgername($csgrid,$cid);    
$chkno=$_SESSION['axes_jouitem'][$i]['chkno'];
$chkdt=$_SESSION['axes_jouitem'][$i]['chkdt'];
$ref=$_SESSION['axes_jouitem'][$i]['ref'];
    
$s+=1;
$body.='<tr>';
$body.='<td style="text-align:center">'.$s.'</td>';
$body.='<td>'.get_fild_data('tbl_acsubgroup',$dsgrid,'name').'</td>';
$body.='<td>'.$dname.'</td>';    
$body.='<th class="text-right">'.number_format($amo,2).'</th>';
$body.='<td>'.$cname.'</td>';
$body.='<td>'.get_fild_data('tbl_acsubgroup',$csgrid,'name').'</td>';
$body.='<td>'.$chkno.'</td>'; 
$body.='<td>'.$chkdt.'</td>';     
$body.='<td>'.$ref.'</td>';
$body.='<td style="text-align:center"><a id="'.$i.'" class="remove"><span style="cursor: pointer;color:red;" class="fa fa-times"></span></a></td>';    
$body.='</tr>';     
}
$foot.='<tr>';
$foot.='<th colspan="3" class="text-right">TOTAL</th>';
$foot.='<th class="text-right">'.number_format(total_jouvalue(),2).'</th>';    
$foot.='<th colspan="6"></th>';    
$foot.='</tr>';    
}else{
$body.='<tr>';
$body.='<td colspan="10" class="text-center">There are no items in your journal list!</td>';
$body.='</tr>'; 
} 
}else{
$body.='<tr>';
$body.='<td colspan="10" class="text-center">There are no items in your journal list!</td>';
$body.='</tr>';
}
            
if(isset($_POST['body'])){
echo $body;
}elseif(isset($_POST['foot'])){
echo $foot;	
}
exit;    
?>    