<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('5','prints','R');     
$_SESSION['cuPages']='opr_pilist.php';   
$cuPage='opr_pilist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
?>
<?php 
if(isset($_POST['invid'])){
$piid=$_POST['invid'];
$sql="SELECT * FROM tbl_payvoucher ORDER BY apdate,id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
?>
<li <?php if($row['id']==$piid){echo 'class="invpayv active"';}else{echo 'class="invpayv"';}?> id="py_<?php echo $row['id'];?>"><p><strong class="pino"><?php echo $row['invno'];?></strong><br><strong class="name"><?php echo date("d M Y", strtotime($row['apdate']));?></strong></p>
<div class="sname" style="margin-top: -52px;float: right; position: relative;top: 6px;"><strong><?php echo numtolocal($row['amount'],get_fild_data('tbl_currency','1','symbol')); ?></strong></div>
</li>
<?php }} ?>