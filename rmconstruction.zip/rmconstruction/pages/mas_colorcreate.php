<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('21','creates','R');      
$_SESSION['cuPages']='mas_colorcreate.php';   
$cuPage='mas_colorcreate.php';    
$aid=$_SESSION['uid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='master';
$menuh='Master Process';
$phead='colorcre';
$page='Add Color';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['save_color'])){
	$name = ucwords(remove_junk(escape($_POST['name'])));
    $colval = remove_junk(escape($_POST['colval']));
	
	if(isset($_POST['name'])){
	$ducode = mysqli_query($con,"SELECT * FROM tbl_color WHERE name = '$name'");
	}
	
	if($ducode->num_rows > 0) {
		save_msg('i','Color name alrady used! Plz try another');
		echo "<script>window.location='mas_colorcreate.php'</script>";
	}else{
    $sql="INSERT INTO tbl_color(name,sval,uid,date) VALUES ('$name','$colval','$aid','$dtnow')";    
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $efid=mysqli_affected_rows($con);    
    if($efid>0){
    $act =remove_junk(escape('Color name: '.$name));    
    write_activity($aid,'COL','New color has been Added',$act);
    save_msg('s','Data Successfully Saved!');    
    }else{
    save_msg('w','Data Fail to Saved!');    
    }
    echo "<script>window.location='mas_colorcreate.php'</script>";  
	}  
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Add Color</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="mas_colorcreate.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">

<div class="row">
<div class="col-md-12">
<div class="col-md-3"></div>
<div class="col-md-6">
<div class="col-md-12">
<div class="row">
<div class="col-md-9">    
<div class="form-group">
<label>Name</label>
<input type="text" name="name" maxlength="25" value="" id="name" class="form-control" placeholder="e.g. Green"  />
</div>
</div>
<div class="col-md-3">     
<div class="form-group">
<label>Color</label>
<br>    
<input type="text" class="basic" id="basic" data-preferred-format="hex" value="#f20b02" data-fouc />
<input type="hidden" name="colval" id="colval">
</div>
</div>
    
</div>
</div>    
</div>    
<div class="col-md-3"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="save_color" id="submit" class="btn btn-flat bg-purple btn-sm " value="Save"/> <a href="mas_colorlist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'COL','A');}else{echo read_activity($aid,'COL','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function () {  
var name = new LiveValidation('name');
name.add(Validate.Presence);
});    
var col = $("#basic").val();
	$(".basic").spectrum({	
    color: col,
	showInput: true,
    change: function(color) {
	$("#colval").val(color.toHexString());
    }
	});
</script>    
<!-- /page script -->
</html>    