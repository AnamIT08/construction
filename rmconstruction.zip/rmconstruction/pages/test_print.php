<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/invfunctions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='rep_invsumer.php';   
$cuPage='rep_invsumer.php';    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='report';
$menuh='Report';
$phead='report';
$page='Inventory Summary';
$ractive='C';
$print='print';
$today = strftime("%Y-%m-%d", time());
$dtnow = date("Y-m-d h:i:s", time());
$oavno='REP'.date("dmy", strtotime($today)).'IPST';

if(isset($_POST['ibrid']) && $_POST['ibrid']!=''){
$det=explode('_',$_POST['ibrid']);    
$ibrid=$det[1];
$type=$det[0];    
}else{
$ibrid=$brid;
$type='B';    
}
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
<div class="printableArea">    
<!DOCTYPE html>
<html>

<head>
  <style>
  /* Styles go here */

.page-header, .page-header-space {
  height: 100px;
}

.page-footers, .page-footer-space {
  height: 50px;

}

.page-footers {   
  position: fixed;
  bottom: 0;
  width: 100%;
  border-top: 1px solid black; /* for demo */
  background: yellow; /* for demo */
}
      
.page-header {
  position: fixed;
  top: 0mm;
  width: 100%;
  background: yellow; /* for demo */
}

/*==========*/
.invoice_header{
        background: #ffffff;
        color: #000000 !important;
        margin: -0.5cm -0.5cm 0 -0.5cm;
        padding: 0.5cm 0.5cm 0 0.5cm;
      }
      
.invoice_header *{
        color: #000000 !important;
        margin: 0;
      }
      
.invoice-logo{
    height: 120px;
    line-height: 120px;
    text-align: center;
  }
  
.invoice-logo-center{
    height: 90px;
    line-height: 90px;
    text-align: center;
  }
  
.invoice-logo img{
    margin: auto !important;
  }
  
.invoice-header-invoice{
    padding:10px;
    font-size:12px;
	text-align:right;
    min-height: 120px;
  }
  
.invoice-header-invoice{
    border-left: 3px solid #dfdfdf;
  }
  
.invoice-header-info {
    padding:10px;
    font-size:12px;
    min-height: 120px;
  }
 
 .invoice-logo {
    min-width: 120px;
    max-width: 170px;
  }
  
.invoice-header-info{
    border-left: 3px solid #dfdfdf;
  }
  
.invoice-header-info{
    padding:10px;
    font-size:12px;
    min-height: 120px;
  }
  
.invoice-header-info{
    border-left: 3px solid #dfdfdf;
  }      
/*==========*/      
.page {
  page-break-after: always;
}

@page {
  margin: 5mm;
}

@media print {
   thead {display: table-header-group;} 
   tfoot {display: table-footer-group;}
   
   button {display: none;}
   
   body {margin: 0;}
}  
  </style>
</head>

<body>

<div class="page-header">
<div class="invoice_header etat_header">
<div class="row">
<div class="col-xs-3 invoice-logo">
<img src="../img/<?php if(empty(get_cominfo('1','logo'))){echo "no_logo.png";}else{echo get_cominfo('1','logo');}?>" alt="<?php echo get_cominfo('1','name');?>" style="vertical-align:middle; width: 100%;">
</div>
<div class="col-xs-5 invoice-header-info" id="adheight">
<h4><?php echo get_cominfo('1','name');?></h4>
<?php echo get_cominfo('1','',$brid);?>
</div>
<div class="col-xs-4 invoice-header-invoice" id="inheight" style="height: 140px;">
<?php echo "<img src = '../inc/barcode.php?text=".$oavno."&codetype=code128&orientation=horizontal&size=30&print=false' style='margin-right: -10px;padding-bottom: 5px;'/>"; ?>
<?php echo "<br><strong>Ref N°:</strong> ".$oavno;?>
<?php echo "<br><strong>Date:</strong> ".date("d M Y", strtotime($today));?>
<?php if($uty==1){ ?>
<?php if($type=='B'){ ?>    
<?php if($ibrid=='A'){echo '<br><strong>Branch: </strong>All Branch';}elseif($ibrid=='0'){echo '<br><strong>Branch: </strong>Main Branch';}else{echo '<br><strong>Branch: </strong>'.get_fild_data('tbl_branch',$ibrid,'name');}?>
<?php }else{ ?>
<?php echo '<br><strong>Warehouse: </strong>'.get_fild_data('tbl_warehouse',$ibrid,'name');  ?>
<?php } ?>
<?php } ?>    
</div>
</div>
<div class="clearfix"></div>
</div>
<center>
<h3 class="page-title">CUSTOMER BALANCE</h3>
</center>    
<br/>
<button type="button" id="print" style="background: pink">
PRINT ME!
</button>
</div>

  <div class="page-footers">
   Page
  </div>

  <table>

    <thead>
      <tr>
        <td>
          <!--place holder for the fixed-position header-->
          <div class="page-header-space"></div>
        </td>
      </tr>
    </thead>

    <tbody>
      <tr>
        <td>
          <!--*** CONTENT GOES HERE ***-->
          <div class="page">PAGE 1</div>
          <div class="page">PAGE 2</div>
          <div class="page" style="line-height: 3;">
            PAGE 3 - Long Content
            <br/> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc tincidunt metus eu consectetur rutrum. Praesent tempor facilisis dapibus. Aliquam cursus diam ac vehicula pulvinar. Integer lacinia non odio et condimentum. Aenean faucibus cursus
            mi, sed interdum turpis sagittis a. Quisque quis pellentesque mi. Ut erat eros, posuere sed scelerisque ut, pharetra vitae tellus. Suspendisse ligula sapien, laoreet ac hendrerit sit amet, viverra vel mi. Pellentesque faucibus nisl et dolor
            pharetra, vel mattis massa venenatis. Integer congue condimentum nisi, sed tincidunt velit tincidunt non. Nulla sagittis sed lorem pretium aliquam. Praesent consectetur volutpat nibh, quis pulvinar est volutpat id. Cras maximus odio posuere
            suscipit venenatis. Donec rhoncus scelerisque metus, in tempus erat rhoncus sed. Morbi massa sapien, porttitor id urna vel, volutpat blandit velit. Cras sit amet sem eros. Quisque commodo facilisis tristique. Proin pellentesque sodales rutrum.
            Vestibulum purus neque, congue vel dapibus in, venenatis ut felis. Donec et ligula enim. Sed sapien sapien, tincidunt vitae lectus quis, ultricies rhoncus mi. Nunc dapibus nulla tempus nunc interdum, sed facilisis ex pellentesque. Nunc vel
            lorem leo. Cras pharetra sodales metus. Cras lacus ex, consequat at consequat vel, laoreet ac dui. Curabitur aliquam, sapien quis congue feugiat, nisi nisl feugiat diam, sed vehicula velit nulla ac nisl. Aliquam quis nisi euismod massa blandit
            pharetra nec eget nunc. Etiam eros ante, auctor sit amet quam vel, fringilla faucibus leo. Morbi a pulvinar nulla. Praesent sed vulputate nisl. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean commodo
            mollis iaculis. Maecenas consectetur enim vitae mollis venenatis. Ut scelerisque pretium orci id laoreet. In sit amet pharetra diam. Vestibulum in molestie lorem. Nunc gravida, eros non consequat fermentum, ex orci vestibulum orci, non accumsan
            sem velit ac lectus. Vivamus malesuada lacus nec velit dignissim, ac fermentum nulla pretium. Aenean mi nisi, convallis sed tempor in, porttitor eu libero. Praesent et molestie ante. Duis suscipit vitae purus sit amet aliquam. Vestibulum lectus
            justo, lobortis a purus a, dapibus efficitur metus. Suspendisse potenti. Duis dictum ex lorem. Suspendisse nec ligula consectetur magna hendrerit ullamcorper et eget mauris. Etiam vestibulum sodales diam, eget venenatis nunc luctus quis. Ut
            fermentum placerat neque nec elementum. Praesent orci erat, rhoncus vitae est eu, dictum molestie metus. Cras et fermentum elit. Aenean eget augue lacinia, varius ante in, ullamcorper dolor. Cras viverra purus non egestas consectetur. Nulla
            nec dolor ac lectus convallis aliquet sed a metus. Suspendisse eu imperdiet nunc, id pulvinar risus. Maecenas varius sagittis est, vel fermentum risus accumsan at. Vestibulum sollicitudin dui pharetra sapien volutpat, id convallis mi vestibulum.
            Phasellus commodo sit amet lorem quis imperdiet. Proin nec diam sed urna euismod ultricies at sed urna. Quisque ornare, nulla et vehicula ultrices, massa purus vehicula urna, ac sodales lacus leo vitae mi. Sed congue placerat justo at placerat.
            Aenean suscipit fringilla vehicula. Quisque iaculis orci vitae arcu commodo maximus. Maecenas nec nunc rutrum, cursus elit quis, porttitor sapien. Sed ac hendrerit ipsum, lacinia fringilla velit. Donec ultricies feugiat dictum.
          </div>
        </td>
      </tr>
    </tbody>

    <tfoot>
      <tr>
        <td>
          <!--place holder for the fixed-position footer-->
          <div class="page-footer-space"></div>
        </td>
      </tr>
    </tfoot>

  </table>

</body>

</html>
</div>    
<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$("#print").click(function() {    
var mode = 'iframe'; //popup
var close = mode == "popup";
var options = {
mode: mode,
popClose: close
};
$("div.printableArea").printArea(options);
}); 
</script>    
<!-- /page script -->
</html>    