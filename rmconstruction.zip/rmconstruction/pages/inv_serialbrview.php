<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
?>
<?php 
function get_pidsl_count($unqid){
if(isset($_SESSION['axes_transbr'])){
$max=count($_SESSION['axes_transbr']);
$sum=0;
$qty=0;
for($i=0;$i<$max;$i++){
$qty=$_SESSION['axes_transbr'][$i]['qty'];
$epid=$_SESSION['axes_transbr'][$i]['unqid'];
if($unqid==$epid){
$sum+=$qty;
}
}
if($sum > 0){
return $sum;
}else{
return 0;    
}
}else{
return 0;        
}	
}

function get_slpid_count($unqid){
if(isset($_SESSION['axes_trbse'])){
$max=count($_SESSION['axes_trbse']);
$sum=0;
for($i=0;$i<$max;$i++){
$epid=$_SESSION['axes_trbse'][$i]['unqid'];
if($unqid==$epid){
$sum+=1;
}    
}
return $sum;    
}else{
return 0;    
}
}
    
function pid_slexits($unqid){   
$max=count($_SESSION['axes_trbse']);
$flag=0;    
for($i=0;$i<$max;$i++){
if($unqid==$_SESSION['axes_trbse'][$i]['unqid']){
$flag=1;    
break;    
}    
}
return $flag;    
}

function remove_slpid($unqid,$dmax){
$c=0;    
$max=count($_SESSION['axes_trbse']);
for($i=($max-1);$i>=0;$i=$i-1){    
if($unqid==$_SESSION['axes_trbse'][$i]['unqid']){
$c+=1;    
unset($_SESSION['axes_trbse'][$i]);
if($c==$dmax){
break;    
}     
}    
}
$_SESSION['axes_trbse']=array_values($_SESSION['axes_trbse']);    
}
?>
<table class="table table-bordered table-striped">
<?php if(get_trnbrserial_count()>0){ ?>
    
<?php 
$max=count($_SESSION['axes_transbr']);    
for($i=0;$i<$max;$i++){
if($_SESSION['axes_transbr'][$i]['imei']>=1){
$pid=$_SESSION['axes_transbr'][$i]['pid'];
$unqid=$_SESSION['axes_transbr'][$i]['unqid'];    
$qty=$_SESSION['axes_transbr'][$i]['qty'];    
$eqty=get_pidsl_count($unqid);
if(isset($_SESSION['axes_trbse'])){    
if(pid_slexits($unqid)){
$dmax=0;    
$sqty=get_slpid_count($unqid);
if($sqty!=$eqty){
if($sqty<$eqty){
$dmax=($eqty-$sqty);   
for($p=0;$p<$dmax;$p++){
add_trbserial($pid,$unqid,'','B');    
}   
}elseif($sqty>$eqty){
$dmax=($sqty-$eqty);    
remove_slpid($unqid,$dmax);    
}        
}    
}else{
add_trbserial($pid,$unqid,'','B');    
}
}else{
add_trbserial($pid,$unqid,'','B');    
}    
}        
}
?>     
<tr>
<td colspan="4" align="center">
</td>
</tr>
<tr>
<th width="30px" align="center">#</th>
<th width="300px">Name</th>
<th width="170px">IMEI/Serial</th>
<th width="25px" align="center"><i class="fa fa-trash"></i></th>
</tr>    
<?php } ?>
<?php
if(isset($_SESSION['axes_trbse'])){
usort($_SESSION['axes_trbse'], function ($a, $b) {
return $a['cartid'] <=> $b['cartid'];
});    
if(is_array($_SESSION['axes_trbse'])){    
?>	
<?php
$s=0;
$max=count($_SESSION['axes_trbse']);
for($i=($max-1);$i>=0;$i=$i-1){ ?>
<?php if($_SESSION['axes_trbse'][$i]['reumei']>=1){
$requ=1;	
}else{
$requ=0;	
}
?>
<?php $s=$s+1; ?>

<tr>
<td align="center"><?php echo $s; ?></td>
<td <?php if($requ){echo 'style="color:red;"';}?>><?php echo $_SESSION['axes_trbse'][$i]['name']; ?></td>
<td><input type="text" name="imei_<?php echo $i; ?>" maxlength="25" class="form-control imei" id="imei_<?php echo $i; ?>" value="<?php echo $_SESSION['axes_trbse'][$i]['imei']; ?>"  size="2" style="height: 24px;" autocomplete="off"/></td>
<td align="center"><a id="<?php echo $i; ?>" class="slremove"><span style="cursor: pointer;" class="fa fa-times"></span></a></td>
</tr>
<?php } ?>	
<?php }else{ ?>
<tr>
<td colspan="4" align="center">No IMEI or Product Serial!</td>
</tr> 
<?php } ?> 
<?php }else{ ?>
<tr><td colspan="4" align="center">No IMEI or Product Serial!</td>
</tr>
<?php } ?>
</table>