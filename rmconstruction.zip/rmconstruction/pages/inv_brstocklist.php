<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='inv_brstocklist.php';   
$cuPage='inv_brstocklist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='inventor';
$menuh='Inventory';
$phead='brstock';
$page='Branch Stock';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Branch Stock Status</h3>
</div>
<div class="box-body">    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped table-hover table_list" id="datarec">
<thead>
<tr>
<th rowspan="2" style="width:40px;" class="text-center">SN</th>
<th rowspan="2" style="width:80px;">Image</th>
<th rowspan="2">Name</th>
<th rowspan="2">SKU</th>    
<th colspan="4" class="text-center">Purchase Details</th>
<th colspan="3" class="text-center">Transaction Details</th>    
<th colspan="5" class="text-center">Sold Details</th>
<th colspan="3" class="text-center">Warranty</th>    
<th rowspan="2" class="text-center">DP.Qty</th>    
<th rowspan="2" class="text-center">In-Stock</th>
<th colspan="2" class="text-center">Sold Summary</th>    
</tr>
<tr>
<th class="text-center">Purchase</th>
<th class="text-center">Received</th>
<th class="text-center">Return</th>
<th class="text-center">Balance</th>    
<th class="text-center">Received</th>
<th class="text-center">Send</th>
<th class="text-center">Balance</th>    
<th class="text-center bg-aqua">Sold</th>   
<th class="text-center">Deli</th>
<th class="text-center">AD.Bal</th>    
<th class="text-center">Return</th>    
<th class="text-center">Balance</th>
<th class="text-center">Replace</th>
<th class="text-center">Sup.Rec</th>    
<th class="text-center">Balance</th>
<th class="text-center bg-aqua">UnDeli</th>     
<th class="text-center bg-aqua">Net.Sales</th>    
</tr>    
</thead>    
<tbody>
<?php
$tpoqty=0;$tpqty=0;$tprqty=0;$trcqty=0;$tseqty=0;$tpval=0;$tpavqty=0;$tsorqty=0;$tsoqty=0;$tsrqty=0;$tsavqty=0;$tfavqty=0;$tsloc=0;$tadjq=0;$tbalasel=0;$tadqty=0;$twoqty=0;$twrqty=0;$twfqty=0;   
$sql="SELECT pid,image,name,pcode,SUM(poqty) AS poqty,SUM(pqty) AS pqty,SUM(prqty) AS prqty,SUM(rcvqty) AS rcvqty,SUM(senqty) AS senqty,SUM(avpqty) AS avpqty,SUM(soqty) AS soqty,SUM(sold) AS sold,SUM(sloc) AS sloc,SUM(srqty) AS srqty,SUM(fsqty) AS fsqty,SUM(woqty) AS woqty,SUM(wrqty) AS wrqty,SUM(adjqty) AS adjqty,SUM(avqty) AS avqty FROM tbl_brstock WHERE brid='$brid' GROUP BY pid ORDER BY name ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$tpoqty+=$row['poqty'];$tpqty+=$row['pqty'];$trcqty+=$row['rcvqty'];$tseqty+=$row['senqty'];$tprqty+=$row['prqty'];$tpavqty+=$row['avpqty'];$tpval+=($row['pqty']-$row['prqty']); $tsorqty+=$row['soqty'];$tsoqty+=$row['sold'];$tsloc+=$row['sloc'];$tsrqty+=$row['srqty'];$tsavqty+=($row['fsqty']+$row['sloc']);$tfavqty+=$row['avqty'];$tadjq+=$row['adjqty'];
$tbalasel+=$row['avpqty']-$row['fsqty'];$tadqty+=$row['avpqty']-$row['sold'];$twoqty+=$row['woqty'];$twrqty+=$row['woqty'];$twfqty+=((($row['avpqty']-$row['fsqty'])-$row['woqty'])+$row['woqty']);    
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td class="text-center"><img src="../img/product/<?php if(empty($row['image'])){echo "no_image.png";}else{echo $row['image'];} ?>" height="40px" width="40px"></td>
<td><b class="prodetail" id="PI_<?php echo $row['pid'];?>" style="cursor: pointer;"><?php echo $row['name']; ?></b></td>
<td><?php echo $row['pcode']; ?></td>
<td class="text-center"><?php echo $row['poqty']; ?></td>
<td class="text-center"><?php echo $row['pqty']; ?></td>    
<td class="text-center"><?php echo $row['prqty']; ?></td>
<td class="text-center"><?php echo ($row['pqty']-$row['prqty']); ?></td>    
<td class="text-center"><?php echo $row['rcvqty']; ?></td>
<td class="text-center"><?php echo $row['senqty']; ?></td> 
<td class="text-center"><?php echo $row['avpqty']; ?></td>
<td class="text-center"><?php echo $row['soqty']; ?></td>    
<td class="text-center"><?php echo $row['sold']; ?></td>
<td class="text-center"><?php echo ($row['avpqty']-$row['sold']); ?></td>    
<td class="text-center"><?php echo $row['srqty']; ?></td>    
<td class="text-center"><?php echo ($row['avpqty']-$row['fsqty']); ?></td>
<td class="text-center"><?php echo $row['woqty']; ?></td>    
<td class="text-center"><?php echo $row['wrqty']; ?></td>    
<td class="text-center"><?php echo ((($row['avpqty']-$row['fsqty'])-$row['woqty'])+$row['wrqty']);?></td>    
<td class="text-center"><?php echo $row['adjqty']; ?></td>    
<td class="text-center"><?php echo $row['avqty']; ?></td>
<td class="text-center"><?php echo $row['sloc']; ?></td>     
<td class="text-center"><?php echo ($row['fsqty']+$row['sloc']); ?></td>       
</tr>    
<?php } ?>     
</tbody>
<tfoot>
<tr>
<td class="text-center" colspan="4"><strong>-Total-</strong></td>
<td class="text-center"><strong><?php echo $tpoqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tpqty; ?></strong></td>    
<td class="text-center"><strong><?php echo $tprqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tpval; ?></strong></td>    
<td class="text-center"><strong><?php echo $trcqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tseqty; ?></strong></td>    
<td class="text-center"><strong><?php echo $tpavqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tsorqty; ?></strong></td>    
<td class="text-center"><strong><?php echo $tsoqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tadqty; ?></strong></td>    
<td class="text-center"><strong><?php echo $tsrqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tbalasel; ?></strong></td>    
<td class="text-center"><strong><?php echo $twoqty; ?></strong></td>
<td class="text-center"><strong><?php echo $twrqty; ?></strong></td>
<td class="text-center"><strong><?php echo $twfqty; ?></strong></td>    
<td class="text-center"><strong><?php echo $tadjq; ?></strong></td>     
<td class="text-center"><strong><?php echo $tfavqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tsloc; ?></strong></td>
<td class="text-center"><strong><?php echo $tsavqty; ?></strong></td>    
</tr>    
</tfoot>    
</table>    
</div>

<div class="clearfix" ></div>     
<div class="row text-center" style="margin-top: 15px" >
<span style="font-size: 12px; font-style: oblique; font-weight: bold; color: red;">DELI: Delivered, AD.BAL: Balance after Delivered, SUP.REC: Warrany Received from Supplier, DP.QTY: Disposal or Adjust Product, UNDELI: Undelivered Product after Sold.</span>
</div>    
</div>
</div>
</div>
</div>
 
<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->
<?php include('../layout/details.php'); ?>    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script src='../plugins/chart/Chart.js'></script>
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
});
    
$(document).on('click', '.prodetail', function(e) { 
id_arr = $(this).attr('id');
id = id_arr.split("_");
$.ajax({
url: 'axe_prodetails.php',
method: "POST",
data:{ prodet: 1,pid: id[1]},
success: function(data){
$('#profile').html(data);    
}
});    
    
$.ajax({
url: 'axe_prodetails.php',
method: "POST",
data:{ details: 1,pid: id[1] },
success: function(data){
$('#details').html(data);   
}
});    
    
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);    
e.preventDefault();    
});
    
$(document).on('click', '#closedet', function() {
$('#profile').html('');
$('#details').html('');    
if($('.right-side-details').is(':visible')) {
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);
}    
});     
</script>    
<!-- /page script -->
</html>    