<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/invfunctions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];
$today = strftime("%Y-%m-%d", time());    
$dtnow = date("Y-m-d h:i:s", time());     
}else{
header('Location:../index.php');
exit;    
}
?>
<?php 
if(isset($_POST['prodet'])){ 
$pid=$_POST['pid'];    
if(empty(get_fild_data('tbl_item',$pid,'image'))){
$pimage = '../img/product/no_image.png';
}else{
$pimage = '../img/product/'.get_fild_data('tbl_item',$pid,'image');
}         
?>
<ul class="list-group">
<li class="list-group-item text-center"><img title="profile image" class="img-responsive" src="<?php echo $pimage; ?>" style="display: block; margin: 0 auto; width: 200px; padding: 4px; border: 1px solid #ddd; border-radius: 4px !important;"></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Name:</strong></span> <?php echo get_fild_data('tbl_item',$pid,'name');?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">SKU/Code</strong></span> <?php echo get_fild_data('tbl_item',$pid,'code');?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Category</strong></span><?php if(get_fild_data('tbl_item',$pid,'catid')!=0){echo get_fild_data('tbl_category',get_fild_data('tbl_item',$pid,'catid'),'name');}?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Sub-Category: </strong></span> <?php if(get_fild_data('tbl_item',$pid,'scatid')!=0){echo get_fild_data('tbl_subcat',get_fild_data('tbl_item',$pid,'scatid'),'name');}?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Brand</strong></span> <?php if(get_fild_data('tbl_item',$pid,'brid')!=0){echo get_fild_data('tbl_brand',get_fild_data('tbl_item',$pid,'brid'),'name');}?></li>    
</ul>
<div class="panel panel-default">
<div class="panel-heading">Description

</div>
<div class="panel-body">
<?php echo get_fild_data('tbl_item',$pid,'description');?>
</div>
</div>
<?php } ?>

<?php 
if(isset($_POST['details'])){ 
$pid=$_POST['pid'];   
?>
<div class="lightpage">  
<div class="axestab">
<ul>
<li><a href="#basicdetails">
<span>Basic Details</span></a></li>
<li><a href="#purchase">
<span>Purchase</span></a></li>
<li><a href="#salest">
<span>Sales</span></a></li>
<li><a href="#return">
<span>Return</span></a></li>    
<li><a href="#statement">
<span>Statement</span></a></li>
<li><a href="#serial">
<span>Serial Record</span></a></li>  
</ul>
    
<div class="tabcontents">
<div id="basicdetails">
<div class="row">
<div class="col-md-6">
<?php 
$pqty=get_pdinfo($pid,'H','PU');
$prcv=get_pdinfo($pid,'H','PC');
$pret=get_pdinfo($pid,'H','PR');
$pbal=($prcv-$pret);
$cost=get_proavgval($pid,'C');
$cval=ROUND($pbal*$cost,2);    
?>    
<ul class="list-group">
<li class="list-group-item text-muted">Purchase (All)</li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Total Purchase</strong></span> <?php echo $pqty;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Received</strong></span> <?php echo $prcv;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Return</strong></span> <?php echo $pret;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Balance</strong></span> <?php echo $pbal;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Average Cost</strong></span> <?php echo numtolocal($cost,'');?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Cost Value</strong></span> <?php echo numtolocal($cval,'');?></li>    
</ul>
</div>    
<div class="col-md-6">    
<?php 
$bpqty=get_pdinfo($pid,'H','PU',$brid);
$bprcv=get_pdinfo($pid,'H','PC',$brid);
$bpret=get_pdinfo($pid,'H','PR',$brid);
$btrrc=get_pdinfo($pid,'H','ER',$brid);
$btrse=get_pdinfo($pid,'H','ES',$brid);    
$bpbal=(($prcv+$btrrc)-($pret+$btrse));
$bcval=ROUND($bpbal*$cost,2);    
?>    
<ul class="list-group">
<li class="list-group-item text-muted">This Branch (Purchase + Received)</li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Total Purchase</strong></span> <?php echo $bpqty;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Received</strong></span> <?php echo $bprcv;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Return</strong></span> <?php echo $bpret;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Internal Received</strong></span> <?php echo $btrrc;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Internal Send</strong></span> <?php echo $btrse;?></li>    
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Balance</strong></span> <?php echo $bpbal;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Average Cost</strong></span> <?php echo numtolocal($cost,'');?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Cost Value</strong></span> <?php echo numtolocal($bcval,'');?></li>    
</ul>      
</div>
</div>
<div class="row">    
<div class="col-md-6">
<?php 
$sqty=get_pdinfo($pid,'H','SO');
$sdlie=get_pdinfo($pid,'H','DL');
$sret=get_pdinfo($pid,'H','SR');
$swaro=get_pdinfo($pid,'H','WO');
$swari=get_pdinfo($pid,'H','WI');
$sadju=get_pdinfo($pid,'H','DS');    
$sbal=(($sdlie+$swaro+$sadju)-($sret+$swari));
$price=get_proavgval($pid,'P');
$sval=ROUND($sbal*$price,2);    
?>    
<ul class="list-group">
<li class="list-group-item text-muted">Sold (All)</li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Total Sold</strong></span> <?php echo $sqty;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Deliverd</strong></span> <?php echo $sdlie;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Return</strong></span> <?php echo $sret;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Warranty Out</strong></span> <?php echo $swaro;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Warranty In</strong></span> <?php echo $swari;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Disposal</strong></span> <?php echo $sadju;?></li>    
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Balance</strong></span> <?php echo $sbal;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Average Price</strong></span> <?php echo numtolocal($price,'');?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Price Value</strong></span> <?php echo numtolocal($sval,'');?></li>    
</ul>         
</div>
<div class="col-md-6">    
<?php 
$bsqty=get_pdinfo($pid,'H','SO',$brid);
$bdlie=get_pdinfo($pid,'H','DL',$brid);
$bsret=get_pdinfo($pid,'H','PR',$brid);
$bwaro=get_pdinfo($pid,'H','WO',$brid);
$bwari=get_pdinfo($pid,'H','WI',$brid);
$badju=get_pdinfo($pid,'H','DS',$brid);    
$bsbal=(($bdlie+$bwaro+$badju)-($bsret+$bwari));
$bsval=ROUND($bsbal*$price,2);    
?>    
<ul class="list-group">
<li class="list-group-item text-muted">This Branch (Sold + Other Out)</li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Total Sold</strong></span> <?php echo $bsqty;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Deliverd</strong></span> <?php echo $bdlie;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Return</strong></span> <?php echo $bsret;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Warranty Out</strong></span> <?php echo $bwaro;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Warranty In</strong></span> <?php echo $bwari;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Disposal</strong></span> <?php echo $badju;?></li>     
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Balance</strong></span> <?php echo $bsbal;?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Average Price</strong></span> <?php echo numtolocal($price,'');?></li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Price Value</strong></span> <?php echo numtolocal($bsval,'');?></li>    
</ul>    
</div>    
</div>
<div class="row">
<div class="col-md-6">
<ul class="list-group">
<li class="list-group-item text-muted">Final Balance (All)</li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Availabel Quantity</strong></span> <?php echo ($pbal-$sbal);?></li>
<li class="list-group-item text-muted">Final Balance (This Branch)</li>
<li class="list-group-item text-right"><span class="pull-left"><strong class="">Availabel Quantity</strong></span> <?php echo ($bpbal-$bsbal);?></li>    
</ul>    
</div>
<div class="col-md-6">
<style>
.cont {
  width: 80%;
  margin: 15px auto;
}   
</style>
<div class="cont">
<div>
<canvas id="myChart"></canvas>
</div>
</div>    
</div>    
</div>        
</div>    
<div id="purchase">
<div class="col-md-12">
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<thead>
<tr>
<th style="width: 40px !important;">SN</th>
<th>Date</th>
<th>Invoice</th>
<th>Supplier</th>
<th>Quantity</th>
<th>Received</th>    
<th>Price</th>
<th>Discount</th>
<th>Total</th>    
</thead>
<tbody>
<?php
$sn=0;
$tcost=0; $tpdis=0; $tptot=0;    
$sql="SELECT pid,tid,invno,p_qty,p_in,cost,disamo,subtot,apdate FROM tbl_traproduct WHERE mods='PU' AND pid='$pid'";    
$results=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($results)){
$sn+=1;
$tcost+=$row['cost']; $tpdis+=$row['disamo']; $tptot+=$row['subtot'];    
$ssql="refinv='".$row['invno']."' AND pid='".$pid."'";    
?>    
<tr>
<td style="text-align:center;"><?php echo $sn;?></td>
<td><?php echo date("d M Y", strtotime($row['apdate']));?></td>    
<td><?php echo $row['invno'];?></td>
<td><?php echo get_fild_data('tbl_supplier',$row['tid'],'name');?></td>
<td style="text-align:center;"><?php echo $row['p_qty'];?></td>    
<td style="text-align:center;"><?php if($row['p_in']<=0){echo ($row['p_in']+get_fild_data('tbl_traproduct','','p_in',$ssql));}else{echo $row['p_in'];}?></td> 
<td style="text-align:right;"><?php echo numtolocal($row['cost'],'');?></td>
<td style="text-align:right;"><?php echo numtolocal($row['disamo'],'');?></td>
<td style="text-align:right;"><?php echo numtolocal($row['subtot'],'');?></td>    
</tr>
<?php } ?>
<tr>
<td style="text-align:center;" colspan="4"><strong>-Total-</strong></td>
<td style="text-align:center;"><strong><?php echo $pqty;?></strong></td>
<td style="text-align:center;"><strong><?php echo $prcv;?></strong></td>
<td style="text-align:right;"><strong><?php echo numtolocal($tcost,'');?></strong></td>
<td style="text-align:right;"><strong><?php echo numtolocal($tpdis,'');?></strong></td>
<td style="text-align:right;"><strong><?php echo numtolocal($tptot,'');?></strong></td>    
</tr>        
</tbody>
</table>    
</div>    
</div>
<div id="salest">
<div class="col-md-12">
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<thead>
<tr>
<th style="width: 40px !important;">SN</th>
<th>Date</th>
<th>Invoice</th>
<th>Customer</th>
<th>Quantity</th>
<th>Delivered</th>    
<th>Price</th>
<th>Discount</th>
<th>Total</th>    
</thead>
<tbody>
<?php
$sn=0;
$tprice=0; $tsdis=0; $tstot=0;    
$sql="SELECT pid,type,tid,invno,s_qty,p_out,price,disamo,subtot,apdate FROM tbl_traproduct WHERE mods='SE' AND pid='$pid'";    
$results=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($results)){
$sn+=1;
$tprice+=$row['price']; $tsdis+=$row['disamo']; $tstot+=$row['subtot'];    
$ssql="refinv='".$row['invno']."' AND pid='".$pid."'";
if($row['type']=='SU'){
$cname=get_fild_data('tbl_supplier',$row['tid'],'name');     
}else{
if($row['tid']!='0'){
$cname=get_fild_data('tbl_customer',$row['tid'],'name');    
}else{
$rsql="invno='".$row['invno']."'";    
$cname=get_fild_data('tbl_sales','','name',$rsql);    
}    
}
   
?>    
<tr>
<td style="text-align:center;"><?php echo $sn;?></td>
<td><?php echo date("d M Y", strtotime($row['apdate']));?></td>    
<td><?php echo $row['invno'];?></td>
<td><?php echo $cname;?></td>
<td style="text-align:center;"><?php echo $row['s_qty'];?></td>    
<td style="text-align:center;"><?php if($row['p_out']<=0){echo ($row['p_in']+get_fild_data('tbl_traproduct','','p_out',$ssql));}else{echo $row['p_out'];}?></td> 
<td style="text-align:right;"><?php echo numtolocal($row['price'],'');?></td>
<td style="text-align:right;"><?php echo numtolocal($row['disamo'],'');?></td>
<td style="text-align:right;"><?php echo numtolocal($row['subtot'],'');?></td>    
</tr>
<?php } ?>
<tr>
<td style="text-align:center;" colspan="4"><strong>-Total-</strong></td>
<td style="text-align:center;"><strong><?php echo $sqty;?></strong></td>
<td style="text-align:center;"><strong><?php echo $sdlie;?></strong></td>
<td style="text-align:right;"><strong><?php echo numtolocal($tprice,'');?></strong></td>
<td style="text-align:right;"><strong><?php echo numtolocal($tsdis,'');?></strong></td>
<td style="text-align:right;"><strong><?php echo numtolocal($tstot,'');?></strong></td>    
</tr>        
</tbody>
</table>    
</div>        
</div>
<div id="return"></div>
<div id="statement"></div>
<div id="serial"></div>    
</div>    
</div>
</div>
<script type="text/javascript">
$(".axestab").tabs({ 
//show: { effect: "slide", direction: "left", duration: 200, easing: "easeOutBack" } ,
//hide: { effect: "slide", direction: "right", duration: 200, easing: "easeInQuad" } 
});
$('.datetimepicker').datepicker({format: "yyyy-mm-dd", autoclose: true, clearBtn: true, orientation: 'auto bottom'});
$("#stprint").click(function() {    
var mode = 'iframe'; //popup
var close = mode == "popup";
var options = {
mode: mode,
popClose: close
};
$("div.printableArea").printArea(options);
});
    
var ctx = document.getElementById("myChart").getContext('2d');
var myChart = new Chart(ctx, {
type: 'pie',
data: {
labels: ["Purchase","Return", "Sold", "Disposed", "Available"],
datasets: [{
backgroundColor: [
"#2ecc71",
"#3498db",
"#95a5a6",
"#9b59b6",
"#e74c3c"  
],
data: [<?php echo $prcv.','.$pret.','.$sdlie.','.$sadju.','.($pbal-$sbal); ?>]
}]
}
});    
</script>    
<?php } ?>