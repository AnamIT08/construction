<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='sel_sinvlist.php';   
$cuPage='sel_sinvlist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='sales';
$menuh='Sales';
$phead='srecreate';
$page='Return Create';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<?php
if(isset($_POST['cansre'])){
if(isset($_SESSION['returninv'])){
unset($_SESSION['returninv']);       
}
if(isset($_SESSION['axes_sereturn'])){
unset($_SESSION['axes_sereturn']);
unset($_SESSION['axes_returnde']);    
}   
echo "<script>window.location='sel_sinvlist.php'</script>";     
}


if(isset($_POST['selret']) && isset($_SESSION['returninv']) && $_POST['selret'] == $_SESSION['returninv']){
$inv = $_POST['selret'];
$sql="SELECT * FROM tbl_sales WHERE id='".$inv."' LIMIT 1";    
$selre=mysqli_query($con,$sql) or die(mysqli_error($con));    
$ret=mysqli_fetch_array($selre);    
}elseif(isset($_POST['selret'])){
$inv = $_POST['selret'];
$sql="SELECT * FROM tbl_sales WHERE id='".$inv."' LIMIT 1";    
$selre=mysqli_query($con,$sql) or die(mysqli_error($con));    
$ret=mysqli_fetch_array($selre);
read_returndata($ret['invno']);
$_SESSION['returninv']=$_POST['selret'];       
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Sales Return</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>

<div class="col-md-12">
<div class="row">
<div class="col-md-4">
<div class="form-group">  
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>
<input type="text" class="form-control"  id="searinv" placeholder="e.g. Type Invoice Numbre" autocomplete="off">    
</div>
</div>    
</div>
<div class="col-md-4"></div>
<div class="col-md-4">
<div class="form-group">  
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>
<input type="text" class="form-control"  id="searsrl" placeholder="e.g. Type Product Serial" autocomplete="off">    
</div>
</div>    
</div>    
</div>
<div id="invdata">    

</div>    
<hr>    
<div class="row">
<div class="cart cart-sm">     
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<thead>
<th style="width:35px; max-width:35px;" class="text-center">SN</th>
<th style="width:300px; max-width:300px;">Item</th>
<th style="width:75px; max-width:75px;" class="text-center">Qty</th>
<th style="width:75px; max-width:75px;" class="text-right">Price</th>
<th style="width:60px; max-width:60px;" class="text-right">Dis(%)</th>
<th style="width:60px; max-width:60px;" class="text-right">Dis(F)</th>       
<th style="width:75px; max-width:75px;" class="text-center">Re.Qty</th>
<th style="width:75px; max-width:75px;" class="text-center">R.Qty</th>    
<th style="width:75px; max-width:75px;" class="text-right">SubTotal</th>   
</thead>
</table>
<div class="cart-msg style-3 item" style="padding:0px;">    
<table class="table table-bordered table-striped" style="margin-bottom: 0;">    
<tbody id="itemdata">

</tbody>    
</table>
</div>
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<tfoot id="itemfoot">

</tfoot>
</table>    
</div>    
</div>
    
<div class="row" id="serialpro">
  
</div>    
  
<div class="row" id="extra">
 
</div>     
    
</div>    
    
</div>
</div>  
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'SRE','A');}else{echo read_activity($aid,'SRE','U');}?>
</div>
</div>
</div>
</div>        
</div>    
</div>

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->
<?php include('../layout/rside.php'); ?>
<form action="sel_sreturncteate.php" id="cansre" method="post" >
<input type="hidden" name="cansre" value="0" />
</form>    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">   
function take_action(id) {
document.getElementById(id).submit(); 
}     
    
ReadData();
function ReadData(){
$.ajax({
url: "sel_retview.php",
method: "POST",
data:{ 
invdata:1
},
success: function(data){
$('#invdata').html(data);
}
})    
    
$.ajax({
url: "sel_retview.php",
method: "POST",
data:{ 
body:1
},
success: function(data){
$('#itemdata').html(data);
}
})

$.ajax({
url: "sel_retview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})
ReadButon();
ReadIMEI();    
};
    
function ReadFoot(){
$.ajax({
url: "sel_retview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})	
};    

function ReadButon(){
$.ajax({
url: "sel_retview.php",
method: "POST",
data:{ 
buton:1
},
success: function(data){
$('#extra').html(data);
}
})	
};
   
function ReadIMEI() {
$.ajax({
url: "sel_retserialview.php",
method: "POST",
success: function(data) {
$('#serialpro').html(data);
}
})
};

$(document).on('keydown', '#searsrl', function () {
$('#searsrl' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'sel_recart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term,srlsear:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
var te='';
$(this).val(te); // display the selected text
var invno = ui.item.value; // selected id to input

$.ajax({
url: 'sel_recart.php',
type: 'post',
data: {addretinv:invno},
success:function(response){
ReadData();
}
});
return false;
}
});        
});    
   
$(document).on('keydown', '#searinv', function () {
$('#searinv' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'sel_recart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term,invsear:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
var te='';
$(this).val(te); // display the selected text
var invno = ui.item.value; // selected id to input

$.ajax({
url: 'sel_recart.php',
type: 'post',
data: {addretinv:invno},
success:function(response){
ReadData();
}
});
return false;
}
});        
});
    
$(document).on('blur', '.quantity', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var qty = parseFloat($('#qty_'+id[1]).val());
$.ajax({
url: 'sel_recart.php',
method: "POST",
data:{ 
upreqty: ids, qty: qty
},
dataType: 'json',
success: function(data){ 
$('#qty_'+id[1]).val(data[0]);    
$('#stotal_'+id[1]).html(data[1]);       
ReadFoot();
ReadIMEI();    
}
});     
});
    
$(document).on('change', '.bscan', function () {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var chkid = 0;	
//$('.bscan').not(this).prop('checked', false);
if ($('#bscan_'+ids).is(":checked")){
chkid = 1;
}else{
chkid = 0;	
}

$.ajax({
url: 'sel_recart.php',
method: "POST",
data: {
check: chkid, pid:ids
},
dataType: 'json',    
success: function(data) {
if(data[0]){    
document.getElementById('bscan_'+ids).checked=true;
}else{
document.getElementById('bscan_'+ids).checked=false;    
}    
}
});

});
    
$(document).on('blur', '#less', function() {
var less = parseFloat($('#less').val());
$.ajax({
url: 'sel_recart.php',
method: "POST",
data: {
less: less
},
success: function(data) {
ReadFoot();
}
});
});
    
$(document).on('click', '#save_return', function() {   
toastr.options = {'positionClass': 'toast-top-center'};    
$.ajax({
url: 'sel_recart.php',
method: "POST",
data:{ 
seldata:1
},
dataType: 'json',
success: function(response) {

var qty = parseFloat(response[1]);    
var err = response[0];

if(qty<=0){
toastr.warning("No return quantity found!!")	
return;
}    
    
if(err>0){
toastr.warning("Selected serial doesn't match with return quantity!!")	
return;
}    

selreturn(); 
}
});          
});    

function selreturn(){    
$.ajax({
url: "sel_recart.php",
method: "POST",
data:{saveret:1},
success: function(data){
$('#addsitem').html(data);
$('.right-side-add').toggle('slide', { direction: 'right' }, 300);     
}
})    
}
    
$(document).on('click', '#closepop', function() {    
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
});
    
$(document).on('click', '#finret', function() { 
var cash_data = $('.addpurchase input, .addpurchase select, .addpurchase textarea');
toastr.options = {'positionClass': 'toast-top-center'};    
if(!chek_error()){   
return;   
}
$.ajax({
url: "sel_recart.php",
data: cash_data,
type: 'post',
dataType: 'json',    
beforeSend: function () {
chek_error();    
},    
success: function(data){
if(data.status === "success"){
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');
ReadData();    
toastr.success(data.message);    
}else{
toastr.error(data.message);    
}         
}
})    
});
    
$(document).on('click', function(e){
if (!$(e.target).is(".right-side-add, .side-cont") && !$(e.target).parents(".right-side-add").length && $('.right-side-add').hasClass('open-right-add')) {
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');
}    
});    
</script>    
<!-- /page script -->
</html>    