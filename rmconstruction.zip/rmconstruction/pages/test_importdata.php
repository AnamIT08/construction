<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='test_importdata.php';   
$cuPage='test_importdata.php';    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];
if(isset($_SESSION["impdbname"])){
include ('test_dbcon.php');    
}    
}else{
header('Location:../index.php');
exit;    
}
$mhead='';
$menuh='';
$phead='';
$page='Import Data';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php 
if(isset($_POST['db_submit'])){
$dbiname=remove_junk(escape($_POST['dbname']));
$dbiuser=remove_junk(escape($_POST['dbuser']));
$dbipass=remove_junk(escape($_POST['dbpass']));
    
if($dbiname!='' && $dbiuser!='' && $dbipass!=''){
$_SESSION["impdbname"]=$dbiname; 
$_SESSION["impdbuse"]=$dbiuser;  
$_SESSION["impdbpass"]=$dbipass;    
}
echo "<script>window.location='test_importdata.php'</script>";    
}
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">    
<div class="row">
<div class="col-md-12">
<div class="col-md-3">    
<div class="box box-solid">

<div class="box-body">
<div class="col-md-12">    
<form action="test_importdata.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<!--From Data-->
<div class="col-md-12">    
<div class="row">
<div class="form-group" >
<label>Database Name</label>
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-database"></span></span>
<input type="text" maxlength="35" class="form-control" name="dbname" value="<?php if(isset($_SESSION["impdbname"])){echo $_SESSION["impdbname"];} ?>" required autocomplete="off" required>
</div>
</div>
<div class="form-group" >
<label>Database User</label>
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-user"></span></span>
<input type="text" maxlength="35" class="form-control" name="dbuser" value="<?php if(isset($_SESSION["impdbuse"])){echo $_SESSION["impdbuse"];} ?>" required autocomplete="off" required>
</div>
</div>
<div class="form-group" >
<label>Database Password</label>
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-key"></span></span>
<input type="password" maxlength="35" class="form-control" name="dbpass" value="<?php if(isset($_SESSION["impdbpass"])){echo $_SESSION["impdbpass"];} ?>" required autocomplete="off" required>
</div>
</div>    
</div>
</div>
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-4"></div>
<div class="col-md-8 text-right" >
<input type="submit" name="db_submit" id="submit" class="btn btn-flat bg-purple btn-sm " value="Submit"/> <a href="axe_report.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div> 
    
</form>    
</div>
</div>
</div>  
</div>
<div class="col-md-8">
<!--brand
=========-->
<?php
$sql="SELECT * FROM brands ORDER BY id ASC";
$result=mysqli_query($icon,$sql) or die(mysqli_error($icon));
if($result->num_rows > 0){
mysqli_query($con,'TRUNCATE tbl_brand') or die(mysqli_error($con));    
while($row = mysqli_fetch_array($result)){
?>
<?php
$id=$row['id'];
$name=remove_junk(escape($row['name']));
$description=remove_junk(escape($row['description']));    
$sql="INSERT INTO tbl_brand(id,name,description,uid,date) VALUES ('$id','$name','$description','$aid','$dtnow')";      
mysqli_query($con,$sql) or die(mysqli_error($con));    
?>
<?php }} ?>

<!--Manufacture
=============-->
<?php
$sql="SELECT * FROM manfacture ORDER BY id ASC";
$result=mysqli_query($icon,$sql) or die(mysqli_error($icon));
if($result->num_rows > 0){
mysqli_query($con,'TRUNCATE tbl_manfacturer') or die(mysqli_error($con));    
while($row = mysqli_fetch_array($result)){
?>
<?php
$id=$row['id'];
$name=remove_junk(escape($row['name']));
$address=remove_junk(escape($row['address']));
$email=remove_junk(escape($row['email']));
$web=remove_junk(escape($row['web']));
$cmobile=remove_junk(escape($row['mobile']));    
$sql="INSERT INTO tbl_manfacturer(id,name,address,cmobile,email,web,description,uid,date) VALUES ('$id','$name','$address','$cmobile','$email','$web',NULL,'$aid','$dtnow')";   
mysqli_query($con,$sql) or die(mysqli_error($con));    
?>
<?php }} ?>

<!--units
===========-->
<?php
$sql="SELECT * FROM units ORDER BY id ASC";
$result=mysqli_query($icon,$sql) or die(mysqli_error($icon));
if($result->num_rows > 0){
mysqli_query($con,'TRUNCATE tbl_unit') or die(mysqli_error($con));    
while($row = mysqli_fetch_array($result)){
?>
<?php
$id=$row['id'];
$name=remove_junk(escape($row['name']));
$description=remove_junk(escape($row['description']));    
$sql="INSERT INTO tbl_unit(id,name,description,uid,date) VALUES ('$id','$name','$description','$aid','$dtnow')";       
mysqli_query($con,$sql) or die(mysqli_error($con));    
?>
<?php }} ?>

<!--category
===========-->
<?php
$sql="SELECT * FROM proser ORDER BY id ASC";
$result=mysqli_query($icon,$sql) or die(mysqli_error($icon));
if($result->num_rows > 0){
mysqli_query($con,'TRUNCATE tbl_category') or die(mysqli_error($con));    
while($row = mysqli_fetch_array($result)){
?>
<?php
$id=$row['id'];
$name=remove_junk(escape($row['name']));
$description=remove_junk(escape($row['description']));    
$sql="INSERT INTO tbl_category(id,pid,name,description,uid,date) VALUES ('$id',NULL,'$name','$description','$aid','$dtnow')";       
mysqli_query($con,$sql) or die(mysqli_error($con));    
?>
<?php }} ?>

<!--sub-category
===========-->
<?php
$sql="SELECT * FROM subcategory ORDER BY id ASC";
$result=mysqli_query($icon,$sql) or die(mysqli_error($icon));
if($result->num_rows > 0){
mysqli_query($con,'TRUNCATE tbl_subcat') or die(mysqli_error($con));    
while($row = mysqli_fetch_array($result)){
?>
<?php
$id=$row['id']; 
$catid=remove_junk(escape($row['mcatid']));
$name=remove_junk(escape($row['name']));
$description=remove_junk(escape($row['description']));    
$sql="INSERT INTO tbl_subcat(id,pid,catid,name,description,uid,date) VALUES ('$id',NULL,'$catid','$name','$description','$aid','$dtnow')";
mysqli_query($con,$sql) or die(mysqli_error($con));    
?>
<?php }} ?> 

<!--Product
===========-->
<?php
$sql="SELECT * FROM product ORDER BY id ASC";
$result=mysqli_query($icon,$sql) or die(mysqli_error($icon));
if($result->num_rows > 0){
mysqli_query($con,'TRUNCATE tbl_item') or die(mysqli_error($con));    
while($row = mysqli_fetch_array($result)){
?>
<?php
$id=$row['id'];
$code=get_genid('PU','ABA');    
$name=remove_junk(escape($row['name']));
$description=remove_junk(escape($row['description']));
if(strlen($row['catid'])>0){
$catid="'".remove_junk(escape($row['catid']))."'";    
}else{
$catid='NULL';    
}    
if(strlen($row['subcatid'])>0){
$scatid="'".remove_junk(escape($row['subcatid']))."'";    
}else{
$scatid='NULL';    
}
if(strlen($row['brandid'])>0){
$braid="'".remove_junk(escape($row['brandid']))."'";    
}else{
$braid='NULL';    
}
$manid='NULL';    
if(strlen($row['unitid'])>0){
$unid="'".remove_junk(escape($row['unitid']))."'";    
}else{
$unid='NULL';    
}
$couid='NULL';
$minst=remove_junk(escape($row['minstock']));
if(strlen($row['barcode'])>0){
$barcode="'".remove_junk(escape($row['barcode']))."'";    
}else{
$barcode='NULL';    
}    
if(strlen($row['certific'])>0){
$certi="'".remove_junk(escape($row['certific']))."'";    
}else{
$certi='NULL';    
}
if(strlen($row['brandno'])>0){
$brandno="'".remove_junk(escape($row['brandno']))."'";    
}else{
$brandno='NULL';    
}
if(strlen($row['modelno'])>0){
$modelno="'".remove_junk(escape($row['modelno']))."'";    
}else{
$modelno='NULL';    
}    
$cost=0;
if(strlen($row['price'])>0){
$price=remove_junk(escape($row['price']));    
}else{
$price=0;    
}
$pmod=remove_junk(escape($row['reimei']));
$status=remove_junk(escape($row['status']));    
$sql="INSERT INTO tbl_item(id,code,name,description,prid,catid,scatid,brid,manid,unid,couid,minstock,barcode,certificate,modelno,brandno,cost,price,pmod,status,uid,date) VALUES ('$id','$code','$name','$description',NULL,$catid,$scatid,$braid,$manid,$unid,$couid,'$minst',$barcode,$certi,$modelno,$brandno,'$cost','$price','$pmod','$status','$aid','$dtnow')";
mysqli_query($con,$sql) or die(mysqli_error($con));    
?>
<?php }} ?>

<!--Service
===========-->
<?php
$sql="SELECT * FROM gpservice ORDER BY id ASC";
$result=mysqli_query($icon,$sql) or die(mysqli_error($icon));
if($result->num_rows > 0){
mysqli_query($con,'TRUNCATE tbl_seritem') or die(mysqli_error($con));    
while($row = mysqli_fetch_array($result)){
?>
<?php
$id=$row['id'];
$code=get_genid('SE','ABA');    
$name=remove_junk(escape($row['name']));
$description=remove_junk(escape($row['description']));
$price=remove_junk(escape($row['price']));;    
$status=remove_junk(escape($row['status']));    
$sql="INSERT INTO tbl_seritem (id,code,name,description,catid,scatid,cost,price,status,brid,uid,date) VALUES ('$id','$code','$name','$description',NULL,NULL,'0','$price','$status','$brid','$aid','$dtnow')";
mysqli_query($con,$sql) or die(mysqli_error($con));    
?>
<?php }} ?> 

<!--customer
===========-->
<?php
$sql="SELECT * FROM customer ORDER BY id ASC";
$result=mysqli_query($icon,$sql) or die(mysqli_error($icon));
if($result->num_rows > 0){
mysqli_query($con,'TRUNCATE tbl_customer') or die(mysqli_error($con));    
while($row = mysqli_fetch_array($result)){
?>
<?php
$id=$row['id'];
$code=get_genid('CU');    
$name=remove_junk(escape($row['name']));
$cperson=remove_junk(escape($row['mlname']));    
$cnumber=remove_junk(escape($row['mobile']));
$cemail=remove_junk(escape($row['email']));    
if(strlen($row['acbabkno'])>0){
$nid="'".remove_junk(escape($row['acbabkno']))."'";    
}else{
$nid='NULL';     
}
$climit=remove_junk(escape($row['crlimit']));
$address=remove_junk(escape($row['address']));
$faddress=remove_junk(escape($row['mladdress']));    
$status=remove_junk(escape($row['status']));    
$sql="INSERT INTO tbl_customer(id,code,name,cperson,mname,cnumber,cphone,cemail,nid,creditlimit,crepreiod,address,saddress,did,zid,rank,status,uid,date) VALUES ('$id','$code','$name','$cperson',NULL,'$cnumber',NULL,'$cemail',$nid,'$climit','0','$address','$faddress',NULL,NULL,NULL,'$status','$aid','$dtnow')";
mysqli_query($con,$sql) or die(mysqli_error($con));    
?>
<?php }} ?>


<!--supliers
===========-->
<?php
$sql="SELECT * FROM supliers ORDER BY id ASC";
$result=mysqli_query($icon,$sql) or die(mysqli_error($icon));
if($result->num_rows > 0){
mysqli_query($con,'TRUNCATE tbl_supplier') or die(mysqli_error($con));    
while($row = mysqli_fetch_array($result)){
?>
<?php
$id=$row['id'];
$code=get_genid('SU');    
$name=remove_junk(escape($row['name']));
$cperson=remove_junk(escape($row['mlname']));    
$cnumber=remove_junk(escape($row['mobile']));
$cemail=remove_junk(escape($row['email']));    
$climit=remove_junk(escape($row['crlimit']));
$address=remove_junk(escape($row['address']));
$faddress=remove_junk(escape($row['mladdress']));    
$status=remove_junk(escape($row['status']));    
$sql="INSERT INTO tbl_supplier(id,code,name,cperson,cnumber,cphone,cemail,creditlimit,crepreiod,address,saddress,rank,status,uid,date) VALUES ('$id','$code','$name','$cperson','$cnumber',NULL,'$cemail','$climit','0','$address','$faddress',NULL,'$status','$aid','$dtnow')";
mysqli_query($con,$sql) or die(mysqli_error($con));    
?>
<?php }} ?>


<!--department
===========-->
<?php
$sql="SELECT * FROM department ORDER BY id ASC";
$result=mysqli_query($icon,$sql) or die(mysqli_error($icon));
if($result->num_rows > 0){
mysqli_query($con,'TRUNCATE tbl_department') or die(mysqli_error($con));    
while($row = mysqli_fetch_array($result)){
?>
<?php
$id=$row['id'];
$name=remove_junk(escape($row['name']));
$description=remove_junk(escape($row['description']));    
$sql="INSERT INTO tbl_department(id,name,description,uid,date) VALUES ('$id','$name','$description','$aid','$dtnow')";       
mysqli_query($con,$sql) or die(mysqli_error($con));    
?>
<?php }} ?> 

<!--designation
===========-->
<?php
$sql="SELECT * FROM designation ORDER BY id ASC";
$result=mysqli_query($icon,$sql) or die(mysqli_error($icon));
if($result->num_rows > 0){
mysqli_query($con,'TRUNCATE tbl_designation') or die(mysqli_error($con));    
while($row = mysqli_fetch_array($result)){
?>
<?php
$id=$row['id'];
$name=remove_junk(escape($row['name']));
$description=remove_junk(escape($row['description']));    
$sql="INSERT INTO tbl_designation(id,name,description,uid,date) VALUES ('$id','$name','$description','$aid','$dtnow')";       
mysqli_query($con,$sql) or die(mysqli_error($con));    
?>
<?php }} ?>

<!--employe
===========-->
<?php
$sql="SELECT * FROM employe ORDER BY id ASC";
$result=mysqli_query($icon,$sql) or die(mysqli_error($icon));
if($result->num_rows > 0){
mysqli_query($con,'TRUNCATE tbl_employe') or die(mysqli_error($con));    
while($row = mysqli_fetch_array($result)){
?>
<?php
$id=$row['id'];
$code=get_empcode($row['dipid']);
$dipid=remove_junk(escape($row['dipid']));    
$desid=remove_junk(escape($row['degid']));    
$name=remove_junk(escape($row['name']));
$fname=remove_junk(escape($row['fname']));
$mname=remove_junk(escape($row['mname']));
$dob=remove_junk(escape($row['dob']));
$job=remove_junk(escape($row['joindate']));    
$salary=remove_junk(escape($row['gsalary']));
$address=remove_junk(escape($row['addressres']));
$paddress=remove_junk(escape($row['addressper']));
$mobile=remove_junk(escape($row['mobile']));
$email=remove_junk(escape($row['email']));    
$status=remove_junk(escape($row['status']));    
$sql="INSERT INTO tbl_employe(id,dipid,desid,name,fname,mname,dob,job,code,salary,address,paddress,mobile,phone,email,nidno,status,wbrid,brid,uid,date) VALUES ('$id','$dipid','$desid','$name','$fname','$mname','$dob','$job','$code','$salary','$address','$paddress','$mobile',NULL,'$email',NULL,'$status','0','$brid','$aid','$dtnow')";       
mysqli_query($con,$sql) or die(mysqli_error($con));    
?>
<?php }} ?>    
    
</div>
    
</div>    
</div>    
<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
  
</script>    
<!-- /page script -->
</html>    