<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}

$output=''; 

if(isset($_POST['catid'])){
$catid=intval($_POST['catid']);
if($catid>0){
$sql = "SELECT * FROM tbl_brstock WHERE brid='$brid' AND catid='$catid' AND status='1' AND (avqty-sloc)>0 ORDER BY name ASC";    
}else{
$sql = "SELECT * FROM tbl_brstock WHERE brid='$brid' AND status='1' AND (avqty-sloc)>0 ORDER BY name ASC";    
}        
}elseif(isset($_POST['subcatid'])){
$scatid=intval($_POST['subcatid']);
$sql = "SELECT * FROM tbl_brstock WHERE brid='$brid' AND scatid='$scatid' AND status='1' AND (avqty-sloc)>0 ORDER BY name ASC";     
}elseif(isset($_POST['brandid'])){    
$brnid=intval($_POST['brandid']);
if($brnid>0){
$sql = "SELECT * FROM tbl_brstock WHERE brid='$brid' AND brnid='$brnid' AND status='1' AND (avqty-sloc)>0 ORDER BY name ASC";     
}else{
$sql = "SELECT * FROM tbl_brstock WHERE brid='$brid' AND status='1' AND (avqty-sloc)>0 ORDER BY name ASC";    
}    
}else{
$sql = "SELECT * FROM tbl_brstock WHERE brid='$brid' AND status='1' AND (avqty-sloc)>0 ORDER BY name ASC";
}
$result = mysqli_query($con, $sql);
while ($row=mysqli_fetch_array($result)){
$unqid=$row['unqid'];
$output.='<div class="product-content product-select selitem" id="AX_'.$row['unqid'].'" title="'.$row['name'].'"><img src="../img/product/';
if(empty($row['image'])){$output.='no_image.png';}else{$output.=$row['image'];} 
$output.='" class="product-image"><div class="info"><h3>'.get_prostinfo($row['unqid'],'price').'</h3><p>Qty: '.($row['avqty']-$row['sloc']);
if(get_fild_data('tbl_setting','4','sval')==0){
$output.='<br>Cost: '.numtolocal(get_fild_data('tbl_stock','','cost',"unqid='$unqid'"),'');    
}   
$output.='</p></div><div class="product-detail"><b class="name">'.$row['name'].'</b></div><div class="product-code"><b class="sku">'.$row['code'].'</b><b class="indexg" style="display:none;">'.strtoupper(substr($row['name'],0,1)).'</b></div></div>';	
}   
echo $output;
exit;