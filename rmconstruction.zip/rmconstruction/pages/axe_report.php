<?php session_start();
require_once '../inc/dbcon.php';
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='axe_report.php';   
$cuPage='axe_report.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='report';
$menuh='Report';
$phead='report';
$page='Report';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">

<div class="box-body">
<div class="row">
<div class="col-md-12 form-group"><div style="width: 200px" class="input-group pull-right">
<div class="input-group-addon"><i class="fa fa-search"></i></div>
<input type="text" class="form-control search_text" placeholder="Search.." onkeyup="search_text()" >
</div></div>
<div class="col-md-4">
<ul class="smenu">
<!--<li class="smenu-treeview"><a href="#" class="smenu-title"><i class="fa fa-exchange" aria-hidden="true"></i> <?php //if(get_fild_data('tbl_setting','1','sval')==0){echo ' Daily Report';}else{echo ' রোজকার প্রতিবেদন';}?></a>
<ul class="smenu-treeview-menu">
<li><a href="rep_dailypurchase.php" ><i class="fa fa-caret-right"></i> <?php //if(get_fild_data('tbl_setting','1','sval')==0){echo ' Purchase';}else{echo '  ক্রয়ের প্রতিবেদন';}?></a></li>
<li><a href="rep_dailysales.php" ><i class="fa fa-caret-right"></i>   <?php //if(get_fild_data('tbl_setting','1','sval')==0){echo ' Sales';}else{echo ' বিক্রয়ের প্রতিবেদন ';}?></a></li>
<li><a href="rep_dailyexpense.php" ><i class="fa fa-caret-right"></i>  <?php //if(get_fild_data('tbl_setting','1','sval')==0){echo ' Expenses';}else{echo ' খরচের  প্রতিবেদন  ';}?></a></li>
<li><a href="rep_dailycashst.php" ><i class="fa fa-caret-right"></i>  <?php //if(get_fild_data('tbl_setting','1','sval')==0){echo ' Daily Cash Statement';}else{echo ' নগদ লেনদেন      ';}?></a></li>
<li><a href="rep_dailyprolosinv.php" ><i class="fa fa-caret-right"></i>  <?php //if(get_fild_data('tbl_setting','1','sval')==0){echo ' Profit &amp; Loss (Invoice)';}else{echo ' লাভ ও ক্ষতির প্রতিবেদন ';}?></a></li>
<li><a href="rep_dailyprolos.php" ><i class="fa fa-caret-right"></i>  <?php //if(get_fild_data('tbl_setting','1','sval')==0){echo ' Profit &amp; Loss (Item)';}else{echo ' লাভ ও ক্ষতির প্রতিবেদন';}?></a></li>
<li><a href="rep_dailyovrview.php" ><i class="fa fa-caret-right"></i>  <?php //if(get_fild_data('tbl_setting','1','sval')==0){echo ' Overview';}else{echo ' সামগ্রিক অবস্থা (ওভারভিউ)';}?></a></li>    
</ul>
</li>-->

<li class="smenu-treeview"><a href="#" class="smenu-title"><i class="fa fa-exchange" aria-hidden="true"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Project Report';}else{echo ' রোজকার প্রতিবেদন';}?></a>
<ul class="smenu-treeview-menu">
<li><a href="rep_prjprojectlist.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Project Status';}else{echo '  ক্রয়ের প্রতিবেদন';}?></a></li>
<li><a href="rep_prjprodetails.php" ><i class="fa fa-caret-right"></i>   <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Project Details';}else{echo ' বিক্রয়ের প্রতিবেদন ';}?></a></li>
<li><a href="rep_prjcontructor.php" ><i class="fa fa-caret-right"></i>  <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Contructor List';}else{echo ' খরচের  প্রতিবেদন  ';}?></a></li>
<li><a href="rep_prjconconbalance.php" ><i class="fa fa-caret-right"></i>  <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Contructor Balance';}else{echo ' নগদ লেনদেন      ';}?></a></li>
<li><a href="rep_prjconstmnt.php" ><i class="fa fa-caret-right"></i>  <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Contructor Statement';}else{echo ' লাভ ও ক্ষতির প্রতিবেদন ';}?></a></li>
<li><a href="rep_prjovrview.php" ><i class="fa fa-caret-right"></i>  <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Overview';}else{echo ' সামগ্রিক অবস্থা (ওভারভিউ)';}?></a></li>    
</ul>
</li>    
    
<li class="smenu-treeview"><a href="#" class="smenu-title"><i class="fa fa-puzzle-piece" aria-hidden="true"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Sales';}else{echo '  বিক্রয়ের প্রতিবেদন  ';}?></a>
<ul class="smenu-treeview-menu">
<li><a href="rep_salesinvrec.php" ><i class="fa fa-caret-right"></i>  <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Sales Record (Invoice)';}else{echo ' বিক্রয়ের প্রতিবেদন চালান অনুযায়ী';}?></a></li>
<li><a href="rep_salesreturnrec.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Return Reord (Invoice)';}else{echo ' বিক্রয় ফেরত প্রতিবেদন চালান অনুযায়ী';}?></a></li>
<li><a href="rep_salescuswise.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Customer Wise (Invoce)';}else{echo ' বিক্রয়  প্রতিবেদন গ্রাহক অনুযায়ী';}?></a></li>
<li><a href="rep_salesitm.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Item Wise';}else{echo ' ক্রয় প্রতিবেদন পদ অনুযায়ী';}?></a></li>    
<li><a href="rep_salesitmst.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Item Statement';}else{echo ' বিক্রয় পদ প্রতিবেদন';}?></a></li>
<li><a href="rep_salesperiod.php" ><i class="fa fa-caret-right"></i>  <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Periodic Sales Record';}else{echo ' পর্যায়ক্রমিক বিক্রয় প্রতিবেদন';}?></a></li>
<li><a href="rep_salesovrview.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Overview';}else{echo ' সামগ্রিক অবস্থা (ওভারভিউ)';}?></a></li>    
</ul>
</li>

<li class="smenu-treeview">
<a href="#" class="smenu-title"><i class="fa fa-sticky-note" aria-hidden="true"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Account';}else{echo ' অ্যাকাউন্ট';}?></a>
<ul class="smenu-treeview-menu">
<li><a href="rep_accledgerst.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Ledger Statement';}else{echo ' খতিয়ান  বিবরণ ';}?></a></li>
<li><a href="rep_acccashst.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Cash Statement';}else{echo ' নগদ  বিবরণ';}?></a></li>
<li><a href="rep_accbankst.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Bank Statement';}else{echo ' ব্যাংকের বিবরণ ';}?></a></li>
<li><a href="rep_accmobist.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Mobile Statement';}else{echo ' Mobile বিবরণ ';}?></a></li>    
<li><a href="rep_accjourhis.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Journal History';}else{echo ' জার্নালের  বিবরণ ';}?></a></li>    
<li><a href="rep_acctrialbal.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Trial Balance';}else{echo ' ট্রায়াল ব্যালেন্স';}?></a></li>
<li><a href="rep_accbalshet.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Balance Sheet';}else{echo ' ব্যালেন্স শীট';}?></a></li>
<li><a href="rep_accprolos.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Profit &amp; Loss';}else{echo ' লাভ ও ক্ষতি  বিবরণ ';}?></a></li>
<li><a href="rep_accovrview.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Overview';}else{echo ' সামগ্রিক অবস্থা (ওভারভিউ)';}?></a></li>    
</ul>
</li>
</ul>
</div>
<div class="col-md-4">
<ul class="smenu">
<li class="smenu-treeview"><a href="#" class="smenu-title"><i class="fa fa-exchange" aria-hidden="true"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Purchase';}else{echo ' ক্রয়';}?></a>
<ul class="smenu-treeview-menu">
<li><a href="rep_purinvrec.php" ><i class="fa fa-caret-right"></i>  <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Purchase Record (Invoice)';}else{echo '  ক্রয়ের প্রতিবেদন';}?></a></li>
<li><a href="rep_purretrec.php" ><i class="fa fa-caret-right"></i>  <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Retrun Record (Invoice)';}else{echo ' ক্রয় ফেরত প্রতিবেদন চালান অনুযায়ী';}?></a></li>
<li><a href="rep_pursupwise.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Supplier Wise (Invoice)';}else{echo ' ক্রয়  প্রতিবেদন    বিক্রেতা  অনুযায়ী';}?></a></li>
<li><a href="rep_puritm.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Item Wise';}else{echo ' ক্রয় প্রতিবেদন পদ অনুযায়ী';}?></a></li>
<li><a href="rep_puritmst.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Item Statement';}else{echo ' ক্রয়  পদ বিবরণ ';}?></a></li>
<li><a href="rep_purperiod.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Periodic Purchase Record';}else{echo ' পর্যায়ক্রমিক ক্রয়ের বিবরণ ';}?></a></li>
<li><a href="rep_purovrview.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Overview';}else{echo ' সামগ্রিক অবস্থা (ওভারভিউ)';}?></a></li>    
</ul>
</li>

<li class="smenu-treeview"><a href="#" class="smenu-title"><i class="fa fa-puzzle-piece" aria-hidden="true"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Receivables';}else{echo ' প্রাপ্য(রিসিভ) ';}?></a>
<ul class="smenu-treeview-menu">
<li><a href="rep_recabcust.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Customer List';}else{echo ' প্রাপ্য গ্রাহক তালিকা';}?></a></li>
<li><a href="rep_recabcusbal.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Customer Balance';}else{echo ' গ্রাহক ব্যালেন্স';}?></a></li>
<li><a href="rep_recabcusstm.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Customer Statement';}else{echo ' গ্রাহক বিবরণী';}?></a></li>
<li><a href="rep_recabcuitmst.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Customer Statement (Item)';}else{echo ' গ্রাহক বিবরণী পদ অনুযায়ী';}?></a></li>    
<li><a href="rep_recabcuducol.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Customer Due Collection';}else{echo ' গ্রাহক বকেয়া সংগ্রহ';}?></a></li>
<li><a href="rep_recabcusovw.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Customer Overview';}else{echo ' গ্রাহক ওভারভিউ';}?></a></li>
<li><a href="rep_recabyovrview.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Overview';}else{echo ' সামগ্রিক অবস্থা (ওভারভিউ)';}?></a></li>    
</ul>
</li>

<li class="smenu-treeview">
<a href="#" class="smenu-title"><i class="fa fa-sticky-note" aria-hidden="true"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Voucher';}else{echo 'ভাউচার(রসিদ)';}?></a>
<ul class="smenu-treeview-menu">
<li><a href="rep_voupaym.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Payment';}else{echo ' আদায়  প্রতিবেদন ';}?></a></li>
<li><a href="rep_vourecpt.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Receipt';}else{echo ' রসিদ প্রতিবেদন ';}?></a></li>
<li><a href="rep_voujournal.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Journal';}else{echo 'জার্নাল রিপোর্ট';}?></a></li>
<li><a href="rep_voupayrecstm.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Payment &amp; Receipt Statement';}else{echo ' আদায় এবং রসিদ প্রতিবেদন ';}?></a></li>
<li><a href="rep_vouinttra.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Internal Transaction';}else{echo ' অভ্যন্তরীণ লেনদেন';}?></a></li>
<li><a href="rep_vouyovrview.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Overview';}else{echo ' সামগ্রিক অবস্থা (ওভারভিউ)';}?></a></li>    
</ul>
</li>
</ul>
</div>
<div class="col-md-4">
<ul class="smenu">
    
<li class="smenu-treeview"><a href="#" class="smenu-title"><i class="fa fa-exchange" aria-hidden="true"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Inventory';}else{echo '  ইনভেন্টরি ';}?></a>
<ul class="smenu-treeview-menu">
<li><a href="rep_invproli.php" ><i class="fa fa-caret-right"></i>  <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Product List';}else{echo ' পণ্যের  তালিকা';}?></a></li>
<li><a href="rep_invsrrec.php" ><i class="fa fa-caret-right"></i>  <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Serial Record';}else{echo ' ধারাবাহিক তালিকা';}?></a></li>
<li><a href="rep_invsumer.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Inventory Summary';}else{echo ' তালিকাভুক্ত জিনিস পত্রের সংক্ষিপ্তসার';}?></a></li>
<li><a href="rep_invpreco.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Periodic Inventory Count';}else{echo ' পর্যায়ক্রমিক ইনভেন্টরি গণনা';}?></a></li>
<li><a href="rep_invvalue.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Inventory Valuation';}else{echo ' তালিকাভুক্ত জিনিসপত্রের মাননির্ণয়';}?></a></li>
<li><a href="rep_invproval.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Periodic Inventory Valuation';}else{echo ' তালিকাভুক্ত জিনিসপত্রের পর্যায়ক্রমিক মাননির্ণয় ';}?></a></li>
<li><a href="rep_invovrview.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Overview';}else{echo ' সামগ্রিক অবস্থা (ওভারভিউ)';}?></a></li>    
</ul>
</li>

<li class="smenu-treeview"><a href="#" class="smenu-title"><i class="fa fa-puzzle-piece" aria-hidden="true"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Payables';}else{echo ' প্রদেয় (পেএবল)';}?></a>
<ul class="smenu-treeview-menu">
<li><a href="rep_payabsuli.php" ><i class="fa fa-caret-right"></i>  <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Supplier List';}else{echo ' সরবরাহকারীর তালিকা';}?></a></li>
<li><a href="rep_payabsubal.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Supplier Balance';}else{echo ' সরবরাহকারীর ব্যালেন্স';}?></a></li>
<li><a href="rep_payabsustm.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Supplier Statement';}else{echo ' সরবরাহকারীর  প্রতিবেদন';}?></a></li>
<li><a href="rep_payabsuitmst.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Supplier Statement (Item)';}else{echo ' সরবরাহকারীর প্রতিবেদন পদ অনুযায়ী';}?></a></li>
<li><a href="rep_payabsuovw.php" ><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Supplier Overview';}else{echo ' সরবরাহকারীর ওভারভিউ';}?></a></li>    
</ul>
</li>    

<li class="smenu-treeview">
<a href="#" class="smenu-title"><i class="fa fa-sticky-note" aria-hidden="true"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Payroll';}else{echo ' বেতনের হিসাব';}?></a>
<ul class="smenu-treeview-menu">
<li><a href="rep_emppayli.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Employee List';}else{echo ' কর্মচারীর তালিকা';}?></a></li>
<li><a href="rep_empattre.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Attendance';}else{echo ' উপস্থিতি';}?></a></li>
<li><a href="rep_emplevre.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Leave Record';}else{echo ' ছুটির তালিকা';}?></a></li>
<li><a href="rep_empsalre.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Salary Report';}else{echo 'বেতন রিপোর্ট';}?></a></li>
<li><a href="rep_empcomre.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Commission Report';}else{echo ' কমিশন রিপোর্ট';}?></a></li>
<li><a href="rep_empovrview.php"><i class="fa fa-caret-right"></i> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Overview';}else{echo ' সামগ্রিক অবস্থা (ওভারভিউ';}?></a></li>    
</ul>
</li>
</ul>
</div>    
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
function search_text() {
var term = $(".search_text").val();
$('.smenu-treeview-menu a').each(function () {
var str = $(this).text().toLowerCase();
if (term.trim() && str.indexOf(term) >= 0) {
$(this).css("background-color", "yellow");
} else {
$(this).css("background-color", "transparent");
}
});
}
</script>    
<!-- /page script -->
</html>    