<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='prj_contruclist.php';   
$cuPage='prj_contruclist.php';    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='project';
$menuh='Manage Project';
$phead='ctlist';
$page='Contractor List';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php 
if(isset($_POST['delcot'])){
$id=$_POST['delcot'];
if(delete_check('tbl_project','coid',$id)>0 || delete_check('tbl_trarecord','did',$id,'dty','CO')>0 || delete_check('tbl_trarecord','cid',$id,'cty','CO')>0){
save_msg('w','Contractor Depend On Other Table!!!');
echo "<script>window.location='prj_contruclist.php'</script>";
return;    
}
$name=get_fild_data('tbl_contractor',$id,'name');   
$sql="DELETE FROM tbl_contractor WHERE id='$id'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);    
if($efid>0){    
$act =remove_junk(escape('Contractor name: '.$name));    
write_activity($aid,'COT','Contractor has been deleted',$act);       
save_msg('s','Contractor Successfully Deleted!!!');
}else{
save_msg('w','Contractor Fail to Delete!!!');   
}
echo "<script>window.location='prj_contruclist.php'</script>";     
}
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-9">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Contractor List</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px;">SN</th>
<th>Name</th>    
<th>Code</th>
<th>Address</th>    
<th style="width:40px; text-align:center;">Action</th>    
</tr>    
</thead>    
<tbody>
<?php
$sql="SELECT * FROM tbl_contractor ORDER BY name ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$id=$row['id'];
?>
<tr>
<td class="center"><?php echo count_id();?></td>
<td><?php echo show_addres($row['name'],$row['mobile'],$row['email'],'','','CO_'.$row['id']);?></td>     
<td><?php echo $row['code'];?></td>
<td><?php echo $row['address'];?></td>    
<td nowrap="">
<?php //if(get_pagesecurity('36','edits','P')){?>    
<a class="btn btn-flat bg-purple" href="#" onclick="edit_item('ED_<?php echo $row['id'];?>')"><i class="fa fa-edit"></i></a>
<?php //} ?>    
<?php //if(get_pagesecurity('36','deletes','P')){?>    
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
<form action="prj_contruclist.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delcot" value="<?php echo $row['id']; ?>" />
</form>
<?php //} ?>    
<?php //if(get_pagesecurity('36','edits','P')){?>    
<form action="prj_contructedit.php" id="ED_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="editcot" value="<?php echo $row['id']; ?>" />
</form>
<?php //} ?>    
</td>    
</tr>    
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<?php //if(get_pagesecurity('36','creates','P')){?>    
<a href="prj_contruccteate.php" class="btn btn-flat bg-purple">Add Contractor</a>
<?php //} ?>    
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'COT','A');}else{echo read_activity($aid,'COT','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>
        
<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
});
function edit_item(id) {
document.getElementById(id).submit(); 
}
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});

}
    
$(document).on('click', '.detailsrec', function(e) {  
id_arr = $(this).attr('id');
id = id_arr.split("_");
if(id[1]==0)return;

$.ajax({
url: 'axe_details.php',
method: "POST",
data:{ 
cusdet: 1,cusid: id[1],type:id[0]
},
success: function(data){
$('#profile').html(data);    
}
});    
    
$.ajax({
url: 'axe_details.php',
method: "POST",
data:{ 
tradet: 1,cusid: id[1],type:id[0]
},
success: function(data){
$('#details').html(data);   
}
});    
    
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);   
e.preventDefault();    
});
    
$(document).on('click', '#closedet', function() {
$('#profile').html('');
$('#details').html('');    
if($('.right-side-details').is(':visible')) {
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);
}    
}); 
</script>    
<!-- /page script -->
</html>    