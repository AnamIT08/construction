<?php
session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;     
}
$today = strftime("%Y-%m-%d", time()); 
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php 
if(isset($_POST['serial'])){
$search = $_POST['search'];
//$sql="SELECT pro.type,pro.tid AS cusid,srl.invno,srl.pid,srl.unqid,pro.colid,pro.sizid,srl.serial,pro.cost,pro.price,pro.apdate AS seldate,DATE_ADD(pro.apdate, INTERVAL pro.wday DAY) AS expdate FROM (SELECT invno,pid,unqid,serial FROM tbl_serialsale WHERE mods IN ('S','W')) srl LEFT JOIN (SELECT * FROM tbl_traproduct) pro ON pro.invno=srl.invno AND pro.unqid=srl.unqid WHERE srl.serial LIKE '%$search%' ORDER BY serial ASC LIMIT 30";    
$sql="SELECT invno, serial,mods FROM (SELECT invno,serial,mods FROM tbl_serialsale WHERE mods='S' AND dli='Y' UNION ALL SELECT refinv AS invno,rep_serial AS serial,'W' AS mods FROM tbl_waranty WHERE LENGTH(rep_serial)>1) srl WHERE srl.serial LIKE '%$search%' ORDER BY srl.serial ASC LIMIT 10";		
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
while($row = mysqli_fetch_array($result) ){
$response[] = array("value"=>$row['serial'],"label"=>$row['invno'].' - '.$row['serial'],"mods"=>$row['mods']);
}

// encoding array to json format
echo json_encode($response);
exit;    
}

if(isset($_POST['chesrl'])){
$serial = strtoupper(remove_junk(escape($_POST['chesrl'])));
if($serial!='' && strlen($serial)>1){
$sql="SELECT * FROM (SELECT serial FROM tbl_serial UNION ALL SELECT rep_serial AS serial FROM tbl_waranty WHERE LENGTH(rep_serial)>1) srl WHERE srl.serial='$serial'";
$ducode = mysqli_query($con,$sql);
if($ducode->num_rows > 0) {
echo '';    
}else{
echo $serial;    
}    
}else{
echo '';    
}    
exit;    
}

if(isset($_POST['getwpin'])){
$serial=$_POST['sre'];
$mods=$_POST['mods'];
if($mods=='S'){    
$sql="SELECT pro.type,pro.tid AS cusid,(SELECT supid FROM tbl_purchase WHERE invno=psrl.purinv) AS supid,IF(pro.type='CU',(SELECT name FROM tbl_customer WHERE id=pro.tid),(SELECT name FROM tbl_supplier WHERE id=pro.tid)) AS cuname,srl.invno,srl.pid,(SELECT name FROM tbl_item WHERE id=srl.pid) AS pname,srl.unqid,pro.colid,pro.sizid,srl.serial,pro.cost,pro.price,pro.apdate AS seldate,DATE_ADD(pro.apdate, INTERVAL pro.wday DAY) AS expdate FROM (SELECT invno,pid,unqid,serial FROM tbl_serialsale WHERE mods='S') srl LEFT JOIN (SELECT purinv,serial FROM tbl_serial) psrl ON psrl.serial = srl.serial LEFT JOIN (SELECT * FROM tbl_traproduct) pro ON pro.invno=srl.invno AND pro.unqid=srl.unqid WHERE srl.serial='$serial'";
}elseif($mods=='W'){
$sql="SELECT type,cusid,supid,IF(type='CU',(SELECT name FROM tbl_customer WHERE id=cusid),(SELECT name FROM tbl_supplier WHERE id=cusid)) AS cuname,refinv AS invno,IF(LENGTH(rep_pid)>1,rep_pid,pid) AS pid,(SELECT name FROM tbl_item WHERE id=IF(LENGTH(rep_pid)>1,rep_pid,pid)) AS pname,unqid,colid,sizid,IF(LENGTH(rep_serial)>1,rep_serial,serial) AS serial,cost,price,sel_date AS seldate,exp_date AS expdate FROM `tbl_waranty` WHERE IF(LENGTH(rep_serial)>1,rep_serial,serial)='$serial'";
}
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$row = mysqli_fetch_array($result);    
echo json_encode($row);
exit;    
}

if(isset($_POST['clmsave'])){
$invno = gen_newinvno('tbl_waranty','CLA');
$seldate = remove_junk(escape($_POST['seldate']));
$expdate = remove_junk(escape($_POST['expdate']));
$estdate = remove_junk(escape($_POST['estdate']));
$rcvdate = remove_junk(escape($_POST['rcvdate']));

$type = remove_junk(escape($_POST['type']));
$cusid = remove_junk(escape($_POST['cusid']));
$supid = remove_junk(escape($_POST['supid']));    
$refinv = remove_junk(escape($_POST['invoiceno']));
$pid = remove_junk(escape($_POST['pid']));
$unqid = remove_junk(escape($_POST['unqid']));
$pserial = remove_junk(escape($_POST['pserial']));     
$colid = remove_junk(escape($_POST['colid']));
$sizid = remove_junk(escape($_POST['sizid']));
$cost = remove_junk(escape($_POST['cost']));
$price = remove_junk(escape($_POST['price']));
$rcvstatus = remove_junk(escape($_POST['rcvstatus']));
$wast = remove_junk(escape($_POST['wast']));
$note = remove_junk(escape($_POST['note']));

if($wast!=1){
$p_in=0;
$p_out=1;
}else{
$p_in=1;
$p_out=0;    
}    

if(isset($_POST['pserial'])){
$exser = mysqli_query($con,"SELECT * FROM tbl_waranty WHERE serial = '$pserial'");
}
	
if($exser->num_rows > 0) {
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Product Already Exists!!'
));
exit;
return;    
}    
 
if($expdate<$today) {
//if($expdate<$rcvdate) {    
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Product Warranty Already Expired!!'
));
exit;
return;    
}    
    
$sql="INSERT INTO tbl_waranty (type,cusid,supid,invno,refinv,pid,unqid,colid,sizid,cost,price,p_in,p_out,p_conid,serial,sel_date,exp_date,warn_status,cl_note,ck_note,d_note,src_id,rep_pid,rep_unqid,rep_serial,sat_amount,d_status,estdate,brid,uid,apdate,date) VALUES ('$type','$cusid','$supid','$invno','$refinv','$pid','$unqid','$colid','$sizid','$cost','$price','$p_in','$p_out','$rcvstatus','$pserial','$seldate','$expdate','$wast','$note',NULL,NULL,NULL,NULL,NULL,NULL,'0','0','$estdate','$brid','$aid','$rcvdate','$dtnow')";     

$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sid=$con->insert_id;    
$efid=mysqli_affected_rows($con);

if($efid>0){    
$act =remove_junk(escape('Warranty Claim: '.$invno));    
write_activity($aid,'CLA','New warranty claim has been Created',$act);
echo json_encode(array(
'status' => 'success',
'message'=> 'Claim Save Successfully!!',
'invid'=> $sid    
));
exit;    
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));    
}         
}

function check_decla($id){
$flage=0;
global $con;
$sql="SELECT * FROM tbl_waranty WHERE id='$id' AND (d_status!=0 OR warn_status!=1)";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}

if($flage>0){
return $flage;
exit;    
}    
return $flage;    
}

if(isset($_POST['delwaclm'])){
$id=intval($_POST['item']);
    
if(check_decla($id)){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Claim Depend On Other Data!!'
));
exit;
return;    
}

$name=get_fild_data('tbl_waranty',$id,'invno');
$sql="DELETE FROM tbl_waranty WHERE id='$id'";
$fdel=mysqli_query($con,$sql)or die(mysqli_error($con));    
$efid=mysqli_affected_rows($con);
if($efid>0){
$act =remove_junk(escape('Warranty Claim: '.$name));    
write_activity($aid,'CLA','Warranty claim has been deleted',$act);        
echo json_encode(array(
'status' => 'success',
'message'=> 'Data Deleted Successfully!!'   
));
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Delete!!'
));    
}       
}

if(isset($_POST['editclm'])){
$claid = remove_junk(escape($_POST['claid']));
$name = remove_junk(escape($_POST['invoiceno']));    
$rcvstatus = remove_junk(escape($_POST['rcvstatus']));    
$wast = remove_junk(escape($_POST['wast']));
$note = remove_junk(escape($_POST['note']));

$estdate = remove_junk(escape($_POST['estdate']));
$rcvdate = remove_junk(escape($_POST['rcvdate']));    
    
if($wast!=1){
$p_in=0;
$p_out=1;
}else{
$p_in=1;
$p_out=0;    
}
$sql="UPDATE tbl_waranty SET p_in='$p_in',p_out='$p_out',p_conid='$rcvstatus',warn_status='$wast',cl_note='$note' WHERE id='$claid'";    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));   
$efid=mysqli_affected_rows($con);    
if($efid>0){    
$act =remove_junk(escape('Warranty Claim: '.$name));    
write_activity($aid,'CLA','Warranty claim has been Updated',$act);    
echo json_encode(array(
'status' => 'success',
'message'=> 'Data Update Successfully!!'   
));
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Update!!'
));    
}        
}

if(isset($_POST['savecheck'])){
$claid = remove_junk(escape($_POST['claid']));
$name = remove_junk(escape($_POST['invoiceno']));        
$wast = remove_junk(escape($_POST['wast']));
$note = remove_junk(escape($_POST['note']));
    
if($wast==2){
$p_out=1;
$p_in=0;    
}else{
$p_out=0;
$p_in=1;    
}
if($wast==3){
$dst="'1'";    
}else{
$dst='NULL';    
}    
    
$sql="UPDATE tbl_waranty SET p_in='$p_in',p_out='$p_out',warn_status='$wast',ck_note='$note',ck_date='$dtnow',d_type=$dst WHERE id='$claid'";    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));   
$efid=mysqli_affected_rows($con);    
if($efid>0){    
$act =remove_junk(escape('Warranty Claim: '.$name));    
write_activity($aid,'CLA','Warranty Claim has been Checked',$act);    
echo json_encode(array(
'status' => 'success',
'message'=> 'Data Save Successfully!!'   
));
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Save!!'
));    
}        
}

function update_eserial($id){
global $con;
$sql="SELECT * FROM tbl_waranty WHERE id='$id' AND rep_type='E'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$row = mysqli_fetch_array($result);
$clinv= $row['invno'];   
$serial = $row['rep_serial'];
if(strlen($clinv)>1){
$sql="DELETE FROM tbl_traproduct WHERE invno='$clinv'";
mysqli_query($con,$sql) or die(mysqli_error($con)); 
$sql="DELETE FROM tbl_serialsale WHERE invno='$clinv'";
mysqli_query($con,$sql) or die(mysqli_error($con));     
}    
if(strlen($serial)>1){
$sql="UPDATE tbl_serial SET status='0' WHERE serial='$serial'";
mysqli_query($con,$sql) or die(mysqli_error($con));    
}
if($row['rep_type']=='E'){
$sql="UPDATE tbl_waranty SET b_in='0',b_out='0' WHERE id='$id' AND rep_type='E'";
mysqli_query($con,$sql) or die(mysqli_error($con));    
}    
}

if(isset($_POST['promanag'])){
$claid = remove_junk(escape($_POST['claid']));       
$name = remove_junk(escape($_POST['invoiceno'])); 
    
$sertype = remove_junk(escape($_POST['sertype']));
if($sertype==1){
$wast=3;    
}else{
$wast=4;    
}       
$repro = remove_junk(escape($_POST['repro']));
$repserial = strtoupper(remove_junk(escape($_POST['repserial'])));
$repeserial = strtoupper(remove_junk(escape($_POST['repeserial'])));
if($repserial=='' && $repeserial==''){
$serial='NULL';    
}elseif($repserial!='' && $repeserial==''){
$serial="'".$repserial."'";
}elseif($repserial=='' && $repeserial!=''){    
$serial="'".$repeserial."'";    
}    
$repero = remove_junk(escape($_POST['repero']));
$price = remove_junk(escape($_POST['price']));
$satamo = remove_junk(escape($_POST['satamo']));
if($satamo==''){
$satamo=0;    
}    
$rep_pid = remove_junk(escape($_POST['rep_pid']));
if($rep_pid!=''){$rep_pid="'".$rep_pid."'";}else{$rep_pid='NULL';}
$rep_unqid = remove_junk(escape($_POST['rep_unqid']));
if($rep_unqid!=''){$rep_unqid="'".$rep_unqid."'";}else{$rep_unqid='NULL';}    
$note = remove_junk(escape($_POST['dnote']));     
    
if($sertype!=5){
$p_in=1;
$p_out=0;    
}else{
$p_in=0;
$p_out=1;    
}
    
if($sertype==3){
$retype="'"."O"."'";
}elseif($sertype==4){
$retype="'"."E"."'";    
}else{
$retype='NULL';    
}

if($sertype==3){
if(strlen($repro)<1 || strlen($repserial)<1){
echo json_encode(array(
'status' => 'error',
'message'=> "Sorry! Product & Serial can't empty !!"
));
exit;
return;     
}    
}    

if($sertype==4){
if(strlen($repeserial)<1 || strlen($repero)<1){
echo json_encode(array(
'status' => 'error',
'message'=> "Sorry! Serial & Product can't empty !!"
));
exit;
return;     
}

if(strlen($repeserial)>0){
if(!check_exserialvalid($serial)){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Serial not exist!!'
));
exit;
return;    
}    
}    
}     
    
if($serial!='NULL'){
if($retype!="'E'"){    
if(check_exserial($serial)){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Exist Serial!!'
));
exit;
return;    
}
}
}
    
update_eserial($claid);    
 
if($retype!="'E'"){
$sql="UPDATE tbl_waranty SET p_in='$p_in',p_out='$p_out',warn_status='$wast',d_note='$note',d_type='$sertype',rep_type=$retype,rep_pid=$rep_pid,rep_unqid=$rep_unqid,rep_serial=$serial,rep_date='$today',sat_amount='$satamo' WHERE id='$claid'";     
}else{
$sql="UPDATE tbl_waranty SET p_in='$p_in',p_out='$p_out',b_in='$p_in',b_out='0',warn_status='$wast',d_note='$note',d_type='$sertype',rep_type=$retype,rep_pid=$rep_pid,rep_unqid=$rep_unqid,rep_serial=$serial,rep_date='$today',sat_amount='$satamo' WHERE id='$claid'";     
}    
  
$result = mysqli_query($con,$sql) or die(mysqli_error($con));   
$efid=mysqli_affected_rows($con);    
if($efid>0){

if($retype=="'E'"){
$sql="SELECT * FROM tbl_waranty WHERE id='$claid'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$erow = mysqli_fetch_array($result);
$cty=$erow['type'];
$cid=$erow['cusid'];
$invno=$erow['invno'];
$col=get_unqidinfo($rep_unqid,'colid');
$siz=get_unqidinfo($rep_unqid,'sizid');
$icdis=get_otinfo($rep_unqid,'icdis');
$icinvdis=get_otinfo($rep_unqid,'icinvdis');
$cost=get_otinfo($rep_unqid,'cost');
$date1=date_create($erow['rep_date']);
$date2=date_create($erow['exp_date']);
$diff=date_diff($date1,$date2);
$wday=intval($diff->format("%R%a"));
if($wday<=0){
$wday=0;    
}    
$sql="INSERT INTO tbl_traproduct (type,tid,invno,refinv,pid,unqid,colid,sizid,icdis,icinvdis,cost,price,p_qty,p_in,s_qty,p_out,taxp,taxamo,disp,disf,disamo,subtot,wday,mods,brid,waid,tramod,isinv,pnote,uid,apdate,date) VALUES ('$cty','$cid','$invno',NULL,$rep_pid,$rep_unqid,'$col','$siz','$icdis','$icinvdis','$cost','0','0','0','1','1','0','0','0','0','0','0','$wday','WR','$brid',NULL,NULL,'Y',NULL,'$aid','$today','$dtnow')";
mysqli_query($con,$sql) or die(mysqli_error($con));
$sql="UPDATE tbl_serial SET status='1' WHERE serial=$serial";
mysqli_query($con,$sql) or die(mysqli_error($con));    
//$sql="INSERT INTO tbl_serialsale (invno,pid,unqid,serial,mods) VALUES ('$invno',$rep_pid,$rep_unqid,$serial,'W')";
//mysqli_query($con,$sql) or die(mysqli_error($con));    
}    
    
$act =remove_junk(escape('Warranty Claim: '.$name));    
write_activity($aid,'CLA','Warranty Claim has been sent to deliver!!',$act);    
echo json_encode(array(
'status' => 'success',
'message'=> 'Data Save Successfully!!'   
));
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Save!!'
));    
}        
}

function check_exserial($serial){
global $con;
$flage=0;    
$serial=str_replace("'","",$serial);    
$sql="SELECT * FROM tbl_serial WHERE serial='$serial'";
$ducode = mysqli_query($con,$sql);
if($ducode->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}    
return $flage;    
}

function check_exserialvalid($serial){
global $con;
$flage=0;    
$serial=str_replace("'","",$serial);    
$sql="SELECT * FROM tbl_serial WHERE serial='$serial' AND status='0'";
$ducode = mysqli_query($con,$sql);
if($ducode->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}    
return $flage;    
}

function get_otinfo($unqid,$key){
global $con;
$unqid=str_replace("'","",$unqid);    
$sql="SELECT ".$key." AS rdata FROM tbl_stock WHERE unqid='$unqid'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$row = mysqli_fetch_array($result);
return $row['rdata'];     
}

function get_unqidinfo($unqid,$key){
global $con;
$unqid=str_replace("'","",$unqid);    
$sql="SELECT ".$key." AS rdata FROM tbl_traproduct WHERE unqid='$unqid' AND mods='PU'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$row = mysqli_fetch_array($result);
return $row['rdata'];    
}

function get_unqid($invno,$pid,$key){
global $con;
$sql="SELECT ".$key." AS rdata FROM tbl_traproduct WHERE invno='$invno' AND pid='$pid'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$row = mysqli_fetch_array($result);
return $row['rdata'];    
}

if(isset($_POST['reserial'])){  
$search = $_POST['search'];
    
$sql="SELECT pid,serial,purinv FROM tbl_serial WHERE serial LIKE '%$search%' AND brid='$brid' AND rci='Y' AND status='0' ORDER BY serial ASC LIMIT 30";		
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
while($row = mysqli_fetch_array($result)){
$name=get_fild_data('tbl_item',$row['pid'],'name');
$unqid=get_unqid($row['purinv'],$row['pid'],'unqid');    
$response[] = array("value"=>$row['pid'],"label"=>$row['serial'],"name"=>$name,"unqid"=>$unqid);
}

// encoding array to json format
echo json_encode($response);
exit;    
}

if(isset($_POST['procode'])){  
$search = $_POST['search'];
    
$sql="SELECT id,name,code FROM tbl_item WHERE (code LIKE '%$search%' OR name LIKE '%$search%') AND status='1' ORDER BY name ASC LIMIT 30";		
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
while($row = mysqli_fetch_array($result) ){   
$response[] = array("value"=>$row['id'],"label"=>$row['code'].' - '.$row['name']);
}

// encoding array to json format
echo json_encode($response);
exit;    
}

if(isset($_POST['prodliver'])){
$claid = remove_junk(escape($_POST['claid']));       
$name = remove_junk(escape($_POST['invoiceno']));
$dnote = remove_junk(escape($_POST['dnote']));
$dstatus = remove_junk(escape($_POST['dstatus']));
$dedate = remove_junk(escape($_POST['deldate']));    
    
if($dstatus==2){
$sql="UPDATE tbl_waranty SET warn_status='2' WHERE id='$claid'";
mysqli_query($con,$sql)or die(mysqli_error($con));
echo json_encode(array(
'status' => 'error',
'message'=> 'Infomation! Product Back Warranty Manage!!'
));
exit;
return;    
}    

$sql="UPDATE tbl_waranty SET p_in=0,p_out=1,d_date='$dtnow',d_status='1' WHERE id='$claid'";    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));   
$efid=mysqli_affected_rows($con);    
if($efid>0){
//update_settelamo($claid);    
$act =remove_junk(escape('Warranty Claim: '.$name));    
write_activity($aid,'CLA','Warranty Claim has been delivered to Custome!!',$act);    
echo json_encode(array(
'status' => 'success',
'message'=> 'Data Save Successfully!!'   
));
exit;    
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Save!!'
));    
}    
}

function update_settelamo($clid){
global $con;
$aid=$_SESSION['uid'];    
$sql="SELECT * FROM tbl_waranty WHERE id='$clid'";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
$row=mysqli_fetch_array($query);    

$camo=$row['sat_amount'];
$invno=$row['invno'];    
$unqid=$row['unqid'];    
$supid=$row['supid'];//get_unqidinfo($unqid,'tid');
$stype='SU';//get_unqidinfo($unqid,'type');    
$cusid=$row['cusid'];
$ctype=$row['type'];
$pid=$row['pid'];
$xrate=0;
$ref='';
$otnote='NULL';
$chkno='NULL';    
$chkdt='NULL';
    
$ibrid=$row['brid'];
$dt = new DateTime($row['d_date']);    
$apdate=$dt->format('Y-m-d');
$date=$row['date'];    
if($camo>0){    
$sql="INSERT INTO tbl_trarecord (invno,refinv,dty,did,amo,cid,cty,chkno,chkdt,otnote,ref,curid,xrate,apdate,brid,uid,date) VALUES ('$invno',NULL,'PD','$pid','$camo','$cusid','$ctype',$chkno,$chkdt,$otnote,'$ref','0','$xrate','$apdate','$ibrid','$aid','$date')";    
mysqli_query($con,$sql) or die(mysqli_error($con));

$sql="INSERT INTO tbl_trarecord (invno,refinv,dty,did,amo,cid,cty,chkno,chkdt,otnote,ref,curid,xrate,apdate,brid,uid,date) VALUES ('$invno',NULL,'$stype','$supid','$camo','$pid','PD',$chkno,$chkdt,$otnote,'$ref','0','$xrate','$apdate','$ibrid','$aid','$date')";    
mysqli_query($con,$sql) or die(mysqli_error($con));
}
}
?>

<?php if(isset($_POST['viewmanage'])){
$sql="SELECT * FROM tbl_waranty WHERE warn_status IN ('2','5') AND d_status=0 ORDER BY apdate,id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$name='';
$name=get_fild_data('tbl_item',$row['pid'],'name');
if($row['colid']!='0'){$name.=' - '.get_fild_data('tbl_color',$row['colid'],'name');}
if($row['sizid']!='0'){$name.=' - '.get_fild_data('tbl_size',$row['sizid'],'sval');}
if($row['warn_status']==1){
$wst='Checking';    
}elseif($row['warn_status']==2){
$wst='Waiting For Received';
}elseif($row['warn_status']==3){
$wst='Warranty Denied &amp; Send To Delivered';
}elseif($row['warn_status']==4){
$wst='Product Send To Delivery';
}elseif($row['warn_status']==5){
$wst='Replace With exists product';    
}
  
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td><?php echo date("d M Y", strtotime($row['apdate']));?></td>
<td><?php echo $row['invno'];?></td>
<td><?php echo $name;?></td>
<td><?php echo $row['serial'];?></td>    
<td><?php echo $row['cl_note'];?></td>
<td><?php echo $row['d_note'];?></td>    
<td><?php echo $wst;?></td>    
<td nowrap="">
<a class="btn btn-flat bg-purple details-claim" href="#" id="inv_<?php echo $row['id'].'_'.$row['cusid'].'_'.$row['type']; ?>"><i class="fa fa-eye cat-child"></i></a> 
<?php if($row['d_status']==0){?>    
<a class="btn btn-flat bg-purple details-manage" href="#" id="src_<?php echo $row['id']; ?>"><i class="fa fa-edit cat-child"></i></a>
<?php } ?>
</td>    
</tr>    
<?php }} ?>

<?php if(isset($_POST['viewdeliver'])){
$sql="SELECT * FROM tbl_waranty WHERE warn_status IN ('3','4') AND d_status=0 ORDER BY apdate DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$name='';
$name=get_fild_data('tbl_item',$row['pid'],'name');
if($row['colid']!='0'){$name.=' - '.get_fild_data('tbl_color',$row['colid'],'name');}
if($row['sizid']!='0'){$name.=' - '.get_fild_data('tbl_size',$row['sizid'],'sval');}
if($row['warn_status']==1){
$wst='Checking';    
}elseif($row['warn_status']==2){
$wst='Waiting For Received';
}elseif($row['warn_status']==3){
$wst='Warranty Denied &amp; Ready To Delivered';
}elseif($row['warn_status']==4){
$wst='Product Ready To Delivery';
}elseif($row['warn_status']==5){
$wst='Replace With exists product';    
}
  
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td><?php echo date("d M Y", strtotime($row['apdate']));?></td>
<td>
<?php echo '<strong><span style="color:blue;">'.$row['invno'].'</span></strong>';?>
<br>    
<?php if($row['type']=='SU'){
echo show_addres(get_fild_data('tbl_supplier',$row['cusid'],'name'),get_fild_data('tbl_supplier',$row['cusid'],'cnumber'),get_fild_data('tbl_supplier',$row['cusid'],'cemail'),'',get_fild_data('tbl_supplier',$row['cusid'],'code'),$row['type'].'_'.$row['cusid']);    
}else{
echo show_addres(get_fild_data('tbl_customer',$row['cusid'],'name'),get_fild_data('tbl_customer',$row['cusid'],'cnumber'),get_fild_data('tbl_customer',$row['cusid'],'cemail'),'',get_fild_data('tbl_customer',$row['cusid'],'code'),$row['type'].'_'.$row['cusid']);
  }?>    
</td>    
<td><?php echo $name;?></td>
<td><?php echo $row['serial'];?></td>
<td><?php if($row['rep_pid']!=''){echo get_fild_data('tbl_item',$row['rep_pid'],'name');}?></td>
<td><?php if($row['rep_serial']!=''){echo $row['rep_serial'];}?></td>    
<td><?php if($row['sat_amount']>0){echo numtolocal($row['sat_amount'],get_fild_data('tbl_currency','1','symbol'));}?></td>
<td><?php echo $row['d_note'];?></td>    
<td><?php echo $wst;?></td>    
<td nowrap="">
<a class="btn btn-flat bg-purple details-deliver" href="#" id="inv_<?php echo $row['id'].'_'.$row['cusid'].'_'.$row['type']; ?>"><i class="fa fa-eye cat-child"></i></a> 
<?php if($row['d_status']==0){?>    
<a class="btn btn-flat bg-purple details-wardeli" href="#" id="src_<?php echo $row['id']; ?>"><i class="fa fa-edit cat-child"></i></a>
<?php } ?>
</td>    
</tr>    
<?php }} ?>

<?php if(isset($_POST['manwadeliver'])){ 
$item=intval($_POST['item']);
?>
<div class="col-md-12 popup_details_div addservice">
<div class="row">
<div id="server-results"><!-- For server results --></div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<?php 
$sql="SELECT * FROM tbl_waranty WHERE id='".$item."' ORDER BY id ASC LIMIT 1";    
$admin=mysqli_query($con,$sql) or die(mysqli_error($con));    
$adm=mysqli_fetch_array($admin);    
?>
<div class="row">
<div class="col-md-6">   
<div class="form-group">
<label>Claim No</label>
<input type="text" maxlength="18" class="form-control" name="invoiceno"  id="invoiceno" value="<?php echo $adm['invno'];?>" placeholder="Claim No" readonly>
</div>
</div>     
<div class="col-md-6">
<div class="form-group">
<label>Claim Date</label>
<input type="text" maxlength="18" class="form-control" name="seldate"  id="seldate" value="<?php echo $adm['apdate'];?>" placeholder="Claim Date" readonly>
</div>    
</div>     
</div>    
<div class="row">
<div class="col-md-12">   
<div class="form-group">
<label>Customer</label>
<input type="text" maxlength="35" class="form-control" name="cusname"  id="cusname" value="<?php if($adm['type']=='CU'){echo get_fild_data('tbl_customer',$adm['cusid'],'name');}else{echo get_fild_data('tbl_supplier',$adm['cusid'],'name');}?>" placeholder="e.g Md.Sumon" readonly>
</div>     
<input type="hidden" maxlength="2" class="form-control" name="type"  id="type" readonly>
<input type="hidden" maxlength="15" class="form-control" name="cusid"  id="cusid" readonly>
<input type="hidden" maxlength="15" class="form-control" name="supid"  id="supid" readonly>    
</div>
</div>    
<div class="row">
<div class="col-md-12">     
<div class="form-group">
<label>Product</label>
<input type="text" maxlength="65" class="form-control" name="product"  id="product" value="<?php echo get_fild_data('tbl_item',$adm['pid'],'name');?>" placeholder="e.g ViewSonic VX-3124-WQHD-2K" readonly>
</div>     
<input type="hidden" maxlength="11" value="<?php echo $adm['id'];?>" class="form-control" name="claid" autocomplete="off" readonly>
<input type="hidden" name="prodliver" readonly />    
</div>
</div>    
<div class="row">
<div class="col-md-8">
<div class="form-group">
<label>Serial</label>
<input type="text" maxlength="64" class="form-control" name="pserial"  id="pserial" value="<?php echo $adm['serial'];?>" placeholder="e.g Md.Sumon" readonly>
</div>    
</div>
<div class="col-md-4">
<div class="form-group">
<label>Expired</label>
<input type="text" maxlength="18" class="form-control" name="expdate"  id="expdate" value="<?php echo $adm['exp_date'];?>" placeholder="Expired Date" readonly>
</div>    
</div>    
</div>
<div class="secdiv"><span>Warranty Details</span></div>
<br>
<?php if($adm['d_type']==1){?>    
<div class="row">
<div class="col-md-12 text-center">
<span style="color:red;font-size: 16px;font-weight: bold;">Warranty Denied</span>    
</div>    
</div>
<?php }elseif($adm['d_type']==2){?>
<div class="row">
<div class="col-md-12 text-center">    
<span style="color:green;font-size: 16px;font-weight: bold;">Product Repair</span>
</div>    
</div>
<?php }elseif($adm['d_type']==3 || $adm['d_type']==4){?>
<div class="row">
<div class="col-md-12 text-center">    
<span style="color:green;font-size: 16px;font-weight: bold;">Product Replace</span>
</div>    
</div>
<?php }elseif($adm['d_type']==5){?>
<div class="row">
<div class="col-md-12 text-center">    
<span style="color:blue;font-size: 16px;font-weight: bold;">Settelment<br><?php echo numtolocal($adm['sat_amount'],get_fild_data('tbl_currency','1','symbol'));?></span>
</div>    
</div>    
<?php } ?>
<div class="row">
<div class="col-md-12"> 
<div class="form-group">    
<label>Delivery Note</label>
<textarea class="form-control" name="dnote" id="dnote" maxlength="150" rows="3" placeholder="Delivery Note"><?php echo $adm['d_note'];?></textarea>    
</div>        
</div>
</div>
    
<div class="row">
<div class="col-md-6">     
<div class="form-group">
<label>Delivery Status</label>
<select class="form-control" name="dstatus" id="dstatus">
<option value="1">Product Delivered</option>
<option value="2">Product Back Manage</option>    
</select>    
</div>        
</div>
<div class="col-md-6">     
<div class="form-group">
<label>Delivery Date</label>
<input type="text" class="form-control datetimepicker" name="deldate" id="deldate" value="<?php echo $today;?>" placeholder="Delivery Date" autocomplete="off" readonly>
</div>    
</div>    
</div>    
    
</div>   
<div class="col-md-1"></div>
</div>    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row" style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-2 text-right" >
<input type="button" id="additem" class="btn btn-flat bg-purple btn-sm " value="Save"/>
</div>
<div class="col-md-2"></div>    
</div>
<script type="text/javascript">
$(".select2").select2();    
$('.datetimepicker').datepicker({format: "yyyy-mm-dd", autoclose: true, clearBtn: true, orientation: 'auto bottom'});     
</script>    
<?php } ?>


<?php if(isset($_POST['manproduct'])){ 
$item=intval($_POST['item']);
?>
<div class="col-md-12 popup_details_div addservice">
<div class="row">
<div id="server-results"><!-- For server results --></div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<?php 
$sql="SELECT * FROM tbl_waranty WHERE id='".$item."' ORDER BY id ASC LIMIT 1";    
$admin=mysqli_query($con,$sql) or die(mysqli_error($con));    
$adm=mysqli_fetch_array($admin);    
?>
<div class="row">
<div class="col-md-6">   
<div class="form-group">
<label>Claim No</label>
<input type="text" maxlength="18" class="form-control" name="invoiceno"  id="invoiceno" value="<?php echo $adm['invno'];?>" placeholder="Claim No" readonly>
</div>
</div>     
<div class="col-md-6">
<div class="form-group">
<label>Claim Date</label>
<input type="text" maxlength="18" class="form-control" name="seldate"  id="seldate" value="<?php echo $adm['apdate'];?>" placeholder="Claim Date" readonly>
</div>    
</div>     
</div>    
<div class="row">
<div class="col-md-12">   
<div class="form-group">
<label>Customer</label>
<input type="text" maxlength="35" class="form-control" name="cusname"  id="cusname" value="<?php if($adm['type']=='CU'){echo get_fild_data('tbl_customer',$adm['cusid'],'name');}else{echo get_fild_data('tbl_supplier',$adm['cusid'],'name');}?>" placeholder="e.g Md.Sumon" readonly>
</div>     
<input type="hidden" maxlength="2" class="form-control" name="type"  id="type" readonly>
<input type="hidden" maxlength="15" class="form-control" name="cusid"  id="cusid" readonly> 
<input type="hidden" maxlength="15" class="form-control" name="supid"  id="supid" readonly>     
</div>
</div>    
<div class="row">
<div class="col-md-12">     
<div class="form-group">
<label>Product</label>
<input type="text" maxlength="65" class="form-control" name="product"  id="product" value="<?php echo get_fild_data('tbl_item',$adm['pid'],'name');?>" placeholder="e.g ViewSonic VX-3124-WQHD-2K" readonly>
</div>     
<input type="hidden" maxlength="11" value="<?php echo $adm['id'];?>" class="form-control" name="claid" autocomplete="off" readonly>
<input type="hidden" name="promanag" readonly />    
</div>
</div>    
<div class="row">
<div class="col-md-8">
<div class="form-group">
<label>Serial</label>
<input type="text" maxlength="64" class="form-control" name="pserial"  id="pserial" value="<?php echo $adm['serial'];?>" placeholder="e.g Md.Sumon" readonly>
</div>    
</div>
<div class="col-md-4">
<div class="form-group">
<label>Expired</label>
<input type="text" maxlength="18" class="form-control" name="expdate"  id="expdate" value="<?php echo $adm['exp_date'];?>" placeholder="Expired Date" readonly>
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-8">
<div class="form-group">
<label>Supplier</label>
<input type="text" class="form-control" value="<?php echo get_fild_data('tbl_supplier',$adm['supid'],'name');?>" placeholder="e.g Axes Global" readonly>
</div>    
</div>
<div class="col-md-4">
<div class="form-group">
<label>Code</label>
<input type="text" class="form-control" value="<?php echo get_fild_data('tbl_supplier',$adm['supid'],'code');?>" placeholder="Code" readonly>
</div>    
</div>    
</div>    
<div class="secdiv"><span>Received or Replace Details</span></div>
<br>    
<div class="row">
<div class="col-md-12">     
<div class="form-group">
<label>Service Type</label>
<select class="form-control" name="sertype" id="sertype">
<option <?php if($adm['d_type']==1){echo 'selected';}?> value="1">Warranty Denied</option>
<option <?php if($adm['d_type']==2){echo 'selected';}?> value="2">Product Repair</option>
<option <?php if($adm['d_type']==3){echo 'selected';}?> value="3">Replace From Supplier</option>
<option <?php if($adm['d_type']==3){echo 'selected';}?> value="4">Replace With Exists</option>
<option <?php if($adm['d_type']==3){echo 'selected';}?> value="5">Settlement</option>    
</select>    
</div>        
</div>
</div>
<div class="row">
<div class="col-md-12">     
<div class="replace" style="display: none;">
<div class="form-group">
<label>With Replace</label>
<input type="text" maxlength="65" class="form-control" name="repro"  id="repro" value="<?php if(strlen(get_fild_data('tbl_item',$adm['rep_pid'],'name'))>1){echo get_fild_data('tbl_item',$adm['rep_pid'],'name');}?>" placeholder="Type Product Code Or Name">
</div>
<div class="form-group">
<label>Serial</label>
<input type="text" maxlength="64" class="form-control" name="repserial"  id="repserial" value="<?php echo $adm['rep_serial'];?>" placeholder="Replace Serial">
</div>     
</div>
<div class="repexits" style="display: none;">
<div class="form-group">
<label>Type Serial</label>
<input type="text" maxlength="64" class="form-control" name="repeserial"  id="repeserial" value="<?php echo $adm['rep_serial'];?>" placeholder="Type Product Serial">
</div>    
<div class="form-group">
<label>With Replace</label>
<input type="text" maxlength="65" class="form-control" name="repero"  id="repero" value="<?php if(strlen(get_fild_data('tbl_item',$adm['rep_pid'],'name'))>1){echo get_fild_data('tbl_item',$adm['rep_pid'],'name');}?>" placeholder="Replaced Product" readonly>
</div>     
</div>
<div class="repsatel" style="display: none;">
<div class="row">
<div class="col-md-6">   
<div class="form-group">    
<label>Product Price</label>
<input type="text" maxlength="15" class="form-control" name="price"  id="price" value="<?php echo $adm['price'];?>" placeholder="Product Price" readonly>    
</div>    
</div>
<div class="col-md-6">   
<div class="form-group">    
<label>Settlement Amount</label>
<input type="text" maxlength="8" class="form-control" onkeypress="return isNumberKey(event)" name="satamo"  id="satamo" value="0" placeholder="Product Price">     
</div>    
</div>    
</div>
    
</div>    
</div>
<input type="hidden" class="form-control" name="rep_pid"  id="rep_pid" readonly> 
<input type="hidden" class="form-control" name="rep_unqid"  id="rep_unqid" readonly>     
</div>
    
<div class="row">
<div class="col-md-12"> 
<div class="form-group">    
<label>Reason Note</label>
<textarea class="form-control" name="dnote" id="dnote" maxlength="150" rows="3" placeholder="Reson Note"><?php echo $adm['d_note'];?></textarea>    
</div>        
</div>
</div>    
</div>   
<div class="col-md-1"></div>
</div>    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="additem" class="btn btn-flat bg-purple btn-sm " value="Save"/>
</div> 
</div>
<script type="text/javascript">
$(document).on('change', '#sertype', function() {
var t = $(this).val();    
if(t==3){
$(".replace").slideDown(); 
$(".repexits").slideUp("fast"); 
$(".repsatel").slideUp("fast");     
}else if(t==4){
$(".replace").slideUp("fast"); 
$(".repexits").slideDown(); 
$(".repsatel").slideUp("fast");     
}else if(t==5){
$(".replace").slideUp("fast"); 
$(".repexits").slideUp("fast"); 
$(".repsatel").slideDown();     
}else{
$(".replace").hide(); 
$(".repexits").hide(); 
$(".repsatel").hide();     
}
tval_defa();    
}); 

function tval_defa(){
$('#repro').val('');
$('#repserial').val('');
$('#repeserial').val('');
$('#repero').val('');
$('#rep_pid').val('');
$('#rep_unqid').val('');    
$('#satamo').val(0);    
}    

$(document).on('blur', '#repserial', function() {
var repsrl = $('#repserial').val();
$.ajax({
url: 'war_cla_cart.php',
type: 'post',
data: {
chesrl: repsrl
},
success: function(data) {
$('#repserial').val(data);
}
});    
})    
    
$(document).on('keydown', '#repro', function() {
$('#repro').autocomplete({
source: function( request, response ) {
$.ajax({
url: 'war_cla_cart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term, procode:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
var pid = ui.item.value;   
var nam = ui.item.label; // selected id to input
$('#rep_pid').val(pid);    
$(this).val(nam);   
return false;
}
});    
});    
    
$(document).on('keydown', '#repeserial', function() {
$('#repeserial').autocomplete({
source: function( request, response ) {
$.ajax({
url: 'war_cla_cart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term, reserial:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
var pid = ui.item.value;
var unqid = ui.item.unqid;    
var name = ui.item.name;     
var srl = ui.item.label; // selected id to input
$(this).val(srl);
$('#rep_pid').val(pid);
$('#rep_unqid').val(unqid);    
$('#repero').val(name);    
return false;
}
});    
});    

    
    
function chek_error(){
var result = true;
var t = parseFloat($('#sertype').val());    
var repro = $('#repro').val();
var repserial = $('#repserial').val(); 
    
var repeserial = $('#repeserial').val(); 
var repero = $('#repero').val(); 
    
var price = parseFloat($('#price').val()); 
var satamo = parseFloat($('#satamo').val());     

if(isNaN(satamo)){
satamo=0;    
}    
    
$('.LV_invalid_field').removeClass('LV_invalid_field');     
$('.LV_validation_message').remove();     

if(t==3){    
if(repro.length<1){
$('#repro').addClass('LV_invalid_field');   
$('#repro').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#repro').removeClass('LV_invalid_field');
result=true;    
}

if(repserial.length<1){
$('#repserial').addClass('LV_invalid_field');   
$('#repserial').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#repserial').removeClass('LV_invalid_field');
result=true;    
} 
}

if(t==4){    
if(repeserial.length<1){
$('#repeserial').addClass('LV_invalid_field');   
$('#repeserial').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#repeserial').removeClass('LV_invalid_field');
result=true;    
}

if(repero.length<1){
$('#repero').addClass('LV_invalid_field');   
$('#repero').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#repero').removeClass('LV_invalid_field');
result=true;    
} 
}    

if(t==5){    
if(satamo<=0){
$('#satamo').addClass('LV_invalid_field');   
$('#satamo').after("<span class='LV_validation_message LV_invalid'>Can't be zero or empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#satamo').removeClass('LV_invalid_field');
result=true;    
}
    
if(satamo>price){
$('#satamo').addClass('LV_invalid_field');   
$('#satamo').after("<span class='LV_validation_message LV_invalid'>Can't be greater than price!</span>").addClass('has-error'); 
result=false;
}else{
$('#satamo').removeClass('LV_invalid_field');
result=true;    
}     
}     
    
if(!result){
return false;    
}else{
return true;     
}        
}
    
$(document).on('blur', '#repro, #repserial, #repeserial, #reper, #satamo', function() {
chek_error();    
});    

    
    
$(".select2").select2();    
$('.datetimepicker').datepicker({format: "yyyy-mm-dd", autoclose: true, clearBtn: true, orientation: 'auto bottom'});     
</script>    
<?php } ?>


<?php if(isset($_POST['viewitem'])){
$sql="SELECT * FROM tbl_waranty ORDER BY id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$name='';
$name=get_fild_data('tbl_item',$row['pid'],'name');
if($row['colid']!='0'){$name.=' - '.get_fild_data('tbl_color',$row['colid'],'name');}
if($row['sizid']!='0'){$name.=' - '.get_fild_data('tbl_size',$row['sizid'],'sval');}
if($row['d_status']!=1){
if($row['warn_status']==1){
$wst='Checking';    
}elseif($row['warn_status']==2){
$wst='Send for Warranty';
}elseif($row['warn_status']==3){
$wst='Warranty Denied &amp; Send To Delived';
}elseif($row['warn_status']==4){
if($row['sat_amount']>0){
$wst='Product Successfully Settled!!!';
}else{
$wst='Product Send To Delivery';
}    
}elseif($row['warn_status']==5){
$wst='Replace With exists product';    
}
}else{
$wst='Product Successfully Delivered!!!';
}
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td><?php echo date("d M Y", strtotime($row['apdate']));?></td>
<td>
<?php echo '<strong><span style="color:blue;">'.$row['invno'].'</span></strong>';?>
<br>    
<?php if($row['type']=='SU'){
echo show_addres(get_fild_data('tbl_supplier',$row['cusid'],'name'),get_fild_data('tbl_supplier',$row['cusid'],'cnumber'),get_fild_data('tbl_supplier',$row['cusid'],'cemail'),'',get_fild_data('tbl_supplier',$row['cusid'],'code'),$row['type'].'_'.$row['cusid']);    
}else{
echo show_addres(get_fild_data('tbl_customer',$row['cusid'],'name'),get_fild_data('tbl_customer',$row['cusid'],'cnumber'),get_fild_data('tbl_customer',$row['cusid'],'cemail'),'',get_fild_data('tbl_customer',$row['cusid'],'code'),$row['type'].'_'.$row['cusid']);
  }?>     
</td>
<td><?php echo $name;?></td>
<td><?php echo $row['serial'];?></td>    
<td><?php echo $row['refinv'];?></td>
<td><?php echo date("d M Y", strtotime($row['sel_date']));?></td>
<td><?php echo date("d M Y", strtotime($row['exp_date']));?></td>    
<td><?php echo $wst;?></td>    
<td nowrap="">
<a class="btn btn-flat bg-purple details-claim" href="#" id="inv_<?php echo $row['id'].'_'.$row['cusid'].'_'.$row['type']; ?>"><i class="fa fa-eye cat-child"></i></a> 
<?php if($row['d_status']==0){?>    
<a class="btn btn-flat bg-purple details-invoice" href="#" id="src_<?php echo $row['id']; ?>"><i class="fa fa-edit cat-child"></i></a>
<?php } ?>
<?php if($row['d_status']!=1){?>     
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
<?php } ?>    
</td>    
</tr>    
<?php }} ?>

<?php if(isset($_POST['viewcheck'])){
$sql="SELECT * FROM tbl_waranty WHERE warn_status IN ('1','2','3') ORDER BY apdate,id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$name='';
$name=get_fild_data('tbl_item',$row['pid'],'name');
if($row['colid']!='0'){$name.=' - '.get_fild_data('tbl_color',$row['colid'],'name');}
if($row['sizid']!='0'){$name.=' - '.get_fild_data('tbl_size',$row['sizid'],'sval');}
if($row['warn_status']==1){
$wst='Waiting';    
}elseif($row['warn_status']==2){
$wst='Send for Warranty';
}elseif($row['warn_status']==3){
$wst='Warranty Denied &amp; Send To Delivery';
}elseif($row['warn_status']==4){
$wst='Product Send To Delivery';
}elseif($row['warn_status']==5){
$wst='Replace With exists product';   
}
  
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td><?php echo date("d M Y", strtotime($row['apdate']));?></td>
<td><?php echo $row['invno'];?></td>
<td><?php echo $name;?></td>
<td><?php echo $row['serial'];?></td>    
<td><?php echo $row['cl_note'];?></td>
<td><?php echo $row['ck_note'];?></td>  
<td><?php echo $wst;?></td>    
<td nowrap="">   
<a class="btn btn-flat bg-purple details-edit" href="#" id="src_<?php echo $row['id']; ?>"><i class="fa fa-edit cat-child"></i></a>  
</td>    
</tr>    
<?php }} ?>

<?php 
if(isset($_POST['viewitemhis'])){
if($_SESSION['utype']=='1'){echo read_activity($aid,'CLA','A');}else{echo read_activity($aid,'CLA','U');}
}?>


<?php 
if(isset($_POST['editcheck'])){
$item=intval($_POST['item']); 
?>
<div class="col-md-12 popup_details_div addservice">
<div class="row">
<div id="server-results"><!-- For server results --></div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<?php 
$sql="SELECT * FROM tbl_waranty WHERE id='".$item."' ORDER BY id ASC LIMIT 1";    
$admin=mysqli_query($con,$sql) or die(mysqli_error($con));    
$adm=mysqli_fetch_array($admin);    
?>
<div class="row">
<div class="col-md-6">   
<div class="form-group">
<label>Claim No</label>
<input type="text" maxlength="18" class="form-control" name="invoiceno"  id="invoiceno" value="<?php echo $adm['invno'];?>" placeholder="Claim No" readonly>
</div>
</div>     
<div class="col-md-6">
<div class="form-group">
<label>Claim Date</label>
<input type="text" maxlength="18" class="form-control" name="seldate"  id="seldate" value="<?php echo $adm['apdate'];?>" placeholder="Claim Date" readonly>
</div>    
</div>     
</div>
<div class="row">
<div class="col-md-12">   
<div class="form-group">
<label>Customer</label>
<input type="text" maxlength="35" class="form-control" name="cusname"  id="cusname" value="<?php if($adm['type']=='CU'){echo get_fild_data('tbl_customer',$adm['cusid'],'name');}else{echo get_fild_data('tbl_supplier',$adm['cusid'],'name');}?>" placeholder="e.g Md.Sumon" readonly>
</div>     
<input type="hidden" maxlength="2" class="form-control" name="type"  id="type" readonly>
<input type="hidden" maxlength="15" class="form-control" name="cusid"  id="cusid" readonly>
<input type="hidden" maxlength="15" class="form-control" name="supid"  id="supid" readonly>    
</div>
</div>    
<div class="row">
<div class="col-md-12">     
<div class="form-group">
<label>Product</label>
<input type="text" maxlength="65" class="form-control" name="product"  id="product" value="<?php echo get_fild_data('tbl_item',$adm['pid'],'name');?>" placeholder="e.g ViewSonic VX-3124-WQHD-2K" readonly>
</div>     
<input type="hidden" maxlength="11" value="<?php echo $adm['id'];?>" class="form-control" name="claid" autocomplete="off" readonly>
<input type="hidden" name="savecheck" readonly />    
</div>
</div>    
<div class="row">
<div class="col-md-8">
<div class="form-group">
<label>Serial</label>
<input type="text" maxlength="64" class="form-control" name="pserial"  id="pserial" value="<?php echo $adm['serial'];?>" placeholder="e.g AXE096785" readonly>
</div>    
</div>
<div class="col-md-4">
<div class="form-group">
<label>Expired</label>
<input type="text" maxlength="18" class="form-control" name="expdate"  id="expdate" value="<?php echo $adm['exp_date'];?>" placeholder="Expired Date" readonly>
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-8">
<div class="form-group">
<label>Supplier</label>
<input type="text" class="form-control" value="<?php echo get_fild_data('tbl_supplier',$adm['supid'],'name');?>" placeholder="e.g Axes Global" readonly>
</div>    
</div>
<div class="col-md-4">
<div class="form-group">
<label>Code</label>
<input type="text" class="form-control" value="<?php echo get_fild_data('tbl_supplier',$adm['supid'],'code');?>" placeholder="Code" readonly>
</div>    
</div>    
</div>    
<div class="row">
<div class="col-md-12"> 
<div class="form-group">    
<label>Received Note</label>
<textarea class="form-control" maxlength="150" rows="5" placeholder="Received Note" readonly><?php echo $adm['cl_note'];?></textarea>    
</div>        
</div>
</div>    
<div class="row">
<div class="col-md-6">   
<div class="form-group">
<label>Received Condition</label>
<select class="form-control" name="rcvstatus" id="rcvstatus" disabled>
<option <?php if($adm['p_conid']==1){echo 'selected';}?> value="1">Power Problem</option>
<option <?php if($adm['p_conid']==2){echo 'selected';}?> value="2">Device Broken</option>
<option <?php if($adm['p_conid']==3){echo 'selected';}?> value="3">Other</option>
</select>
</div>
</div>     
<div class="col-md-6">
<div class="form-group">
<label>Place For</label>
<select class="form-control" name="wast" id="wast">
<option <?php if($adm['warn_status']==2){echo 'selected';}?> value="2">Send for Warranty</option>
<option <?php if($adm['warn_status']==3){echo 'selected';}?> value="3">Warranty Denied &amp; Send To Delivery</option>
<!--<option <?php if($adm['warn_status']==5){echo 'selected';}?> value="5">Replace With Exists Product</option>-->    
</select>
</div>    
</div>     
</div>
<div class="row">
<div class="col-md-12"> 
<div class="form-group">    
<label>Note</label>
<textarea class="form-control" name="note" id="note" maxlength="150" rows="5" placeholder="Checking Note"><?php echo $adm['ck_note'];?></textarea>    
</div>        
</div>
</div>    
</div>   
<div class="col-md-1"></div>
</div>    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="additem" class="btn btn-flat bg-purple btn-sm " value="Save"/>
</div> 
</div>
<script type="text/javascript">
$(".select2").select2();    
$('.datetimepicker').datepicker({format: "yyyy-mm-dd", autoclose: true, clearBtn: true, orientation: 'auto bottom'});     
</script>    
<?php } ?>

<?php 
if(isset($_POST['addsitem'])){
$item=intval($_POST['item']); 
?>
<div class="col-md-12 popup_details_div addservice">
<div class="row">
<div id="server-results"><!-- For server results --></div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<?php if($item <=0){ ?>     
<div class="row">
<div class="col-md-12">    
<div class="form-group">
<input type="text" maxlength="25" class="form-control form-control-lg" id="serial" placeholder="Product Serial No">
</div>
</div>    
</div>    
<div class="secdiv"><span>Product Details</span></div>
<br>    
<div class="row">
<div class="col-md-6">   
<div class="form-group">
<label>Invoice Number</label>
<input type="text" maxlength="18" class="form-control" name="invoiceno"  id="invoiceno" placeholder="Invoice No" readonly>
</div>
</div>     
<div class="col-md-6">
<div class="form-group">
<label>Sales Date</label>
<input type="text" maxlength="18" class="form-control" name="seldate"  id="seldate" placeholder="Sales Date" readonly>
</div>    
</div>     
</div>
<div class="row">
<div class="col-md-12">   
<div class="form-group">
<label>Customer</label>
<input type="text" maxlength="35" class="form-control" name="cusname"  id="cusname" placeholder="e.g Md.Sumon" readonly>
</div>     
<input type="hidden" maxlength="2" class="form-control" name="type"  id="type" readonly>
<input type="hidden" maxlength="15" class="form-control" name="cusid"  id="cusid" readonly>
<input type="hidden" maxlength="15" class="form-control" name="supid"  id="supid" readonly>    
</div>
</div>    
<div class="row">
<div class="col-md-12">     
<div class="form-group">
<label>Product</label>
<input type="text" maxlength="65" class="form-control" name="product"  id="product" placeholder="e.g ViewSonic VX-3124-WQHD-2K" readonly>
</div>     
<input type="hidden" maxlength="2" class="form-control" name="pid" id="pid" readonly>
<input type="hidden" maxlength="15" class="form-control" name="unqid"  id="unqid" readonly>
<input type="hidden" maxlength="2" class="form-control" name="colid" id="colid" readonly>
<input type="hidden" maxlength="15" class="form-control" name="sizid"  id="sizid" readonly>    
<input type="hidden" maxlength="15" class="form-control" name="cost"  id="cost" readonly>
<input type="hidden" maxlength="15" class="form-control" name="price"  id="price" readonly>
<input type="hidden" maxlength="15" class="form-control" name="clmsave" value="" readonly>    
</div>
</div>    
<div class="row">
<div class="col-md-8">
<div class="form-group">
<label>Serial</label>
<input type="text" maxlength="64" class="form-control" name="pserial"  id="pserial" placeholder="e.g Md.Sumon" readonly>
</div>    
</div>
<div class="col-md-4">
<div class="form-group">
<label>Expired</label>
<input type="text" maxlength="18" class="form-control" name="expdate"  id="expdate" placeholder="Expired Date" readonly>
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-6">   
<div class="form-group">
<label>Received Condition</label>
<select class="form-control" name="rcvstatus" id="rcvstatus">
<option value="1">Power Problem</option>
<option value="2">Device Broken</option>
<option value="3">Other</option>
</select>
</div>
</div>     
<div class="col-md-6">
<div class="form-group">
<label>Place For</label>
<select class="form-control" name="wast" id="wast">
<option value="1">Checking</option>
<option value="2">Send for Warranty</option>
</select>
</div>    
</div>     
</div>
<div class="row">
<div class="col-md-12"> 
<div class="form-group">    
<label>Note</label>
<textarea class="form-control" name="note" id="note" maxlength="150" rows="5" placeholder="Received Note"></textarea>    
</div>        
</div>
</div>    
<div class="row">
<div class="col-md-6">   
<div class="form-group">
<label>Estimate Delivery</label>
<input type="text" class="form-control datetimepicker" name="estdate" id="estdate" value="<?php echo date('Y-m-d', strtotime('+7 days',strtotime($today)));?>" placeholder="Estimate Delivery" autocomplete="off" readonly>
</div>
</div>     
<div class="col-md-6">
<div class="form-group">
<label>Received Date</label>
<input type="text" class="form-control datetimepicker" name="rcvdate" id="rcvdate" value="<?php echo $today;?>" placeholder="Received Date" autocomplete="off" readonly>
</div>    
</div>     
</div>
<?php }else{
$sql="SELECT * FROM tbl_waranty WHERE id='".$item."' ORDER BY id ASC LIMIT 1";    
$admin=mysqli_query($con,$sql) or die(mysqli_error($con));    
$adm=mysqli_fetch_array($admin);    
?>
<div class="row">
<div class="col-md-6">   
<div class="form-group">
<label>Invoice Number</label>
<input type="text" maxlength="18" class="form-control" name="invoiceno"  id="invoiceno" value="<?php echo $adm['refinv'];?>" placeholder="Invoice No" readonly>
</div>
</div>     
<div class="col-md-6">
<div class="form-group">
<label>Sales Date</label>
<input type="text" maxlength="18" class="form-control" name="seldate"  id="seldate" value="<?php echo $adm['sel_date'];?>" placeholder="Sales Date" readonly>
</div>    
</div>     
</div>
<div class="row">
<div class="col-md-12">   
<div class="form-group">
<label>Customer</label>
<input type="text" maxlength="35" class="form-control" name="cusname"  id="cusname" value="<?php if($adm['type']=='CU'){echo get_fild_data('tbl_customer',$adm['cusid'],'name');}else{echo get_fild_data('tbl_supplier',$adm['cusid'],'name');}?>" placeholder="e.g Md.Sumon" readonly>
</div>     
<input type="hidden" maxlength="2" class="form-control" name="type"  id="type" readonly>
<input type="hidden" maxlength="15" class="form-control" name="cusid"  id="cusid" readonly>
<input type="hidden" maxlength="15" class="form-control" name="supid"  id="supid" readonly>    
</div>
</div>    
<div class="row">
<div class="col-md-12">     
<div class="form-group">
<label>Product</label>
<input type="text" maxlength="65" class="form-control" name="product"  id="product" value="<?php echo get_fild_data('tbl_item',$adm['pid'],'name');?>" placeholder="e.g ViewSonic VX-3124-WQHD-2K" readonly>
</div>     
<input type="hidden" maxlength="11" value="<?php echo $adm['id'];?>" class="form-control" name="claid" autocomplete="off" readonly>
<input type="hidden" name="editclm" readonly />    
</div>
</div>    
<div class="row">
<div class="col-md-8">
<div class="form-group">
<label>Serial</label>
<input type="text" maxlength="64" class="form-control" name="pserial"  id="pserial" value="<?php echo $adm['serial'];?>" placeholder="e.g Md.Sumon" readonly>
</div>    
</div>
<div class="col-md-4">
<div class="form-group">
<label>Expired</label>
<input type="text" maxlength="18" class="form-control" name="expdate"  id="expdate" value="<?php echo $adm['exp_date'];?>" placeholder="Expired Date" readonly>
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-6">   
<div class="form-group">
<label>Received Condition</label>
<select class="form-control" name="rcvstatus" id="rcvstatus">
<option <?php if($adm['p_conid']==1){echo 'selected';}?> value="1">Power Problem</option>
<option <?php if($adm['p_conid']==2){echo 'selected';}?> value="2">Device Broken</option>
<option <?php if($adm['p_conid']==3){echo 'selected';}?> value="3">Other</option>
</select>
</div>
</div>     
<div class="col-md-6">
<div class="form-group">
<label>Place For</label>
<select class="form-control" name="wast" id="wast">
<option <?php if($adm['warn_status']==1){echo 'selected';}?> value="1">Checking</option>
<option <?php if($adm['warn_status']==2){echo 'selected';}?> value="2">Send for Warranty</option>
</select>
</div>    
</div>     
</div>
<div class="row">
<div class="col-md-12"> 
<div class="form-group">    
<label>Note</label>
<textarea class="form-control" name="note" id="note" maxlength="150" rows="5" placeholder="Received Note"><?php echo $adm['cl_note'];?></textarea>    
</div>        
</div>
</div>    
<div class="row">
<div class="col-md-6">   
<div class="form-group">
<label>Estimate Delivery</label>
<input type="text" class="form-control datetimepicker" name="estdate" id="estdate" value="<?php echo $adm['estdate'];?>" placeholder="Estimate Delivery" autocomplete="off" readonly>
</div>
</div>     
<div class="col-md-6">
<div class="form-group">
<label>Received Date</label>
<input type="text" class="form-control datetimepicker" name="rcvdate" id="rcvdate" value="<?php echo $adm['apdate'];?>" placeholder="Received Date" autocomplete="off" readonly>
</div>    
</div>     
</div>    
<?php } ?>     
</div>   
<div class="col-md-1"></div>
</div>    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="additem" class="btn btn-flat bg-purple btn-sm " value="<?php if($item <=0){echo 'Save';}else{echo 'Update';} ?>"/>
</div> 
</div>
<script type="text/javascript">

$(document).on('keydown', '#serial', function() {
$('#serial' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'war_cla_cart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term, serial:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
var sre = ui.item.value;    
var srl = ui.item.label; // selected id to input
var mods = ui.item.mods;
$(this).val(srl);
    
$.ajax({
url: 'war_cla_cart.php',
method: "POST",
data:{ 
getwpin:1, sre:sre, mods:mods
},
dataType: 'json',    
success: function(data){
    
$('#invoiceno').val(data.invno);
$('#seldate').val(data.seldate);
$('#cusname').val(data.cuname);
$('#product').val(data.pname);
$('#pserial').val(data.serial);
$('#expdate').val(data.expdate);
    
$('#type').val(data.type);
$('#cusid').val(data.cusid);
$('#supid').val(data.supid);    
$('#pid').val(data.pid);
$('#unqid').val(data.unqid);
$('#colid').val(data.colid);
$('#sizid').val(data.sizid);    
$('#cost').val(data.cost);
$('#price').val(data.price);        
}
});

return false;
}
});    
});    
    
function chek_error(){
var result = true;
var serial = $('#pserial').val();
var product = $('#product').val();  

$('.LV_invalid_field').removeClass('LV_invalid_field');     
$('.LV_validation_message').remove();     

if(serial.length<1){
$('#pserial').addClass('LV_invalid_field');   
$('#pserial').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#pserial').removeClass('LV_invalid_field');
result=true;    
}    

if(product.length<1){
$('#product').addClass('LV_invalid_field');   
$('#product').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#product').removeClass('LV_invalid_field');
result=true;    
} 
    
if(serial.length<0 || product.length<0 || !result){
return false;    
}else{
return true;     
}        
}
    
$(document).on('blur', '#pserial, #product', function() {
chek_error();    
});
    
$(".select2").select2();    
$('.datetimepicker').datepicker({format: "yyyy-mm-dd", autoclose: true, clearBtn: true, orientation: 'auto bottom'});    
</script>
<?php } ?>    