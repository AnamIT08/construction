<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/repfunctions.php');
include ('../inc/cartfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('3','creates','R');     
$_SESSION['cuPages']='dai_expensescreate.php';   
$cuPage='dai_expensescreate.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='daily';
$menuh='Daily Process';
$phead='expcre';
$page='Add Expenses';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['save_expenses'])){
	//if(!isset($_SESSION['axes_expdata'])){
    //save_msg('w','No Expen data found!!');
	//echo "<script>window.location='dai_expensescreate.php'</script>";
    //exit;    
    //}
 
	if(!isset($_SESSION['axes_expitem'])){
    save_msg('w','No Expenses Head found!!');
	echo "<script>window.location='dai_expensescreate.php'</script>";
    exit;    
    }
    
    $expno = gen_newinvno('tbl_expenses','EXP');
    $apdate = remove_junk(escape($_POST['apdate']));
    $prjid = remove_junk(escape($_POST['prjid']));
    $epjid = remove_junk(escape($_POST['prjid']));
    if($prjid==''){$prjid='NULL'; $prjno='NULL';}else{$prjid="'".$prjid."'"; $prjno="'".get_fild_data('tbl_project',$epjid,'prjid')."'";}
    $note = remove_junk(escape($_POST['note']));
    $total = total_expvalue();
    
    $sql="INSERT INTO tbl_expenses (invno,note,amount,apdate,pjid,brid,uid,date) VALUES ('$expno','$note','$total','$apdate',$prjid,'$brid','$aid','$dtnow')";
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $sid=$con->insert_id;
    $efid=mysqli_affected_rows($con);
    
    if($efid>0){
    if(isset($_SESSION['axes_expitem'])){
    if(is_array($_SESSION['axes_expitem'])){
    $max=count($_SESSION['axes_expitem']);
    for($i=0;$i<$max;$i++){
    $cty=$_SESSION['axes_expitem'][$i]['cty'];
    $cid=$_SESSION['axes_expitem'][$i]['cid'];    
    $expid=$_SESSION['axes_expitem'][$i]['expid'];
    $amount=$_SESSION['axes_expitem'][$i]['amount'];
    $mtype=$_SESSION['axes_expitem'][$i]['mtype'];    
    $ref=$_SESSION['axes_expitem'][$i]['ref'];
               
    $sql="INSERT INTO tbl_trarecord (invno,pjid,prjno,mtype,dty,did,amo,cid,cty,ref,curid,xrate,apdate,brid,uid,date) VALUES ('$expno',$prjid,$prjno,'$mtype','LE','$expid','$amount','$cid','$cty','$ref','0','0','$apdate','$brid','$aid','$dtnow')";
    
    mysqli_query($con,$sql) or die(mysqli_error($con)); 
        
    }}}
    unset($_SESSION['axes_expdata']);
    unset($_SESSION['axes_expitem']);    
    $act =remove_junk(escape('Expenses No: '.$expno));    
    write_activity($aid,'EXL','Expenses has been Added',$act);    
    save_msg('s','Data Successfully Saved!');
    }else{
    save_msg('w','Data Fail to Saved!');    
    }
    echo "<script>window.location='dai_expensescreate.php'</script>";  
	}  
?>    
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Add Expenses</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="dai_expensescreate.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">    
<div class="row">    
<center>
<h3 class="page-title">EXPENSES VOUCHER</h3>
</center>
</div>
<div class="row">
<div class="col-md-4">
<div class="form-group">
<?php 
$ldebit=get_ledgerval('LE1','D','N','','',$brid);
$lcredit=get_ledgerval('LE1','C','N','','',$brid);
$lnet=($ldebit-$lcredit);    
?>    
<center>
<a id="addcash" style="cursor: pointer;font-size: 16px;margin-right: 4px;color: red;"><span class="fa fa-plus"></span></a>    
<span style="font-size: 20px;font-weight: bold;">Balance: </span><span style="font-size: 20px;font-weight: bold;color:<?php if($lnet>0){echo 'blue;';}else{echo 'red;';}?>" id="cbal"><?php echo number_format($lnet,2); ?></span>   
</center>    
</div>
<div class="form-group" >
<label>Other Credit</label>
<select class="form-control select2" name="cid" id="cid">    
<option value="LE_1">Petty Cash</option>
<optgroup label="Cash &amp; Mobile">    
<option value="LE_2">Cash</option>
<?php
$sql="SELECT id,CONCAT(name,' - ',mobile) AS cname,name FROM tbl_acmobile ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'MO_'.$rows['id'];?>"><?php echo $rows['cname'];?></option>
<?php } ?>
</optgroup>    
<optgroup label="Employee">
<?php
$sql="SELECT * FROM tbl_employe ORDER BY id ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'EM_'.$rows['id'];?>"><?php echo $rows['code'].' - '.$rows['name'];?></option>
<?php } ?>
</optgroup>    
<optgroup label="Loan & Advaced">
<?php
$sql="SELECT * FROM tbl_loanid ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'LO_'.$rows['id'];?>"><?php echo $rows['code'].' - '.$rows['name'];?></option>
<?php } ?>
</optgroup>    
</select> 
</div>    
</div>
<div class="col-md-4"></div>    
<div class="col-md-4">
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><b>Expenses No:</b></span>
<input type="text" class="form-control" maxlength="15" name="invno" id="invno" value="<?php if(isset($_SESSION['axes_expdata']['invno'])){$_SESSION['axes_expdata']['invno']=gen_newinvno('tbl_expenses','EXP');echo $_SESSION['axes_expdata']['invno'];}else{echo gen_newinvno('tbl_expenses','EXP');}?>" placeholder="e.g. AXE121119101" autocomplete="off">
</div>
</div>
<div class="form-group" >
<div class="input-group">
<span class="input-group-addon"><b>Date:</b></span>
<input type="text" class="form-control datetimepicker" name="apdate" id="apdate" value="<?php if(isset($_SESSION['axes_expdata']['date'])){echo $_SESSION['axes_expdata']['date'];}else{ echo date('Y-m-d');}?>" placeholder="Date:" autocomplete="off" readonly>
</div>
</div>
<div class="form-group" >
<div class="input-group">
<span class="input-group-addon"><b>Project:</b></span>    
<select class="form-control select2" name="prjid" id="prjid">
<option value="">-Select-</option>
<?php
$sql="SELECT * FROM tbl_project WHERE status IN ('0','1','3') ORDER BY date DESC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($prj=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $prj['id'];?>"><?php echo $prj['prjid'];?></option>
<?php } ?>
</select>    
</div>   
</div>    
</div>
</div>
<div class="row">
<div class="col-md-4">
<div class="form-group" >
<label>Expenses Head</label>
<div class="input-group">
<select class="form-control select2" name="expid" id="expid">
<option value="">-Select-</option>
<?php
$sql="SELECT * FROM tbl_acledger WHERE grid IN (8,9) AND sgrid IN (20,21) ORDER BY id ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['code'].' - '.$rows['name'];?></option>
<?php } ?>
</select>
<span class="input-group-addon"><a id="aexpi"><span class="fa fa-plus"></span></a></span>     
</div>   
</div>
</div>
<div class="col-md-3">
<div class="form-group" >
<label>Ref</label>
<input type="text" maxlength="45" class="form-control" name="ref" id="ref" placeholder="e.g. Sumon" autocomplete="off">    
</div>    
</div>
<div class="col-md-2">
<div class="form-group">
<label>Amount</label>    
<input type="text" maxlength="6" class="form-control" name="amount" id="amount"  onkeypress="return isNumberKey(event)" placeholder="e.g. 500" autocomplete="off">    
</div> 
</div>
<div class="col-md-2">
<div class="form-group">
<label>Type</label>    
<select class="form-control select2" name="mtype" id="mtype">
<option value="0">-Select-</option>
<?php
$sql="SELECT id,name FROM tbl_prjtype ORDER BY date DESC";    
$quer=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($typ=mysqli_fetch_array($quer)){
?>
<option value="<?php echo $typ['id'];?>"><?php echo $typ['name'];?></option>
<?php } ?>
</select>     
</div> 
</div>    
<div class="col-md-1">
<div class="form-group">
<label>&nbsp;</label>    
<input type="button" id="addexp" class="btn btn-flat bg-red" value="Add"/>    
</div>
</div>    
</div>
<div class="row">
<div class="col-md-12">
<table class="table table-bordered table-striped">
<thead>    
<th style="width:40px; text-align:center">SN</th>
<th>Expenses Head</th>
<th>Type</th>    
<th>Amount</th>
<th>Ref</th>
<th style="width:40px; text-align:center"><a class="empty" style="cursor: pointer;"><i class="fa fa-trash"></i></a></th>    
</thead>
<tbody id="itemdata">

</tbody>
<tfoot id="itemfoot">

</tfoot>    
</table> 
</div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="form-group">
<label>Note</label>
<textarea class="form-control" name="note" id="note" maxlength="250" rows="3" placeholder="e.g. Note"><?php if(isset($_SESSION['axes_expdata']['note'])){echo $_SESSION['axes_expdata']['note'];}?></textarea>
</div>    
</div>   
</div>    
</div>    
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="expreset" class="btn btn-flat bg-red btn-sm " value="Reset"/>    
<input type="submit" name="save_expenses" id="submit" class="btn btn-flat bg-purple btn-sm" value="Save"/> <a href="dai_expenlist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'EXL','A');}else{echo read_activity($aid,'EXL','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->
<?php include('../layout/rside.php'); ?>    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function (){ 
var apdate = new LiveValidation('apdate');
apdate.add(Validate.Presence);
});
    
ReadData();
function ReadData(){
$.ajax({
url: "dai_expview.php",
method: "POST",
data:{ 
body:1
},
success: function(data){
$('#itemdata').html(data);
}
})

$.ajax({
url: "dai_expview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})    
};    

function ReadFoot(){
$.ajax({
url: "dai_expview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})	
}
 
$(document).on('blur change', '#apdate', function() {
apdate=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
expdate: apdate
},
dataType: 'json',
success: function(data){
$('#apdate').val(data[0]);
}
});     
});    

$(document).on('blur', '#note', function() {
note = $(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
expnote: note
},
dataType: 'json',
success: function(data){
$('#note').val(data[0]);
}
});     
});    

$(document).on('click','.empty',function() {
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
expdata: 1
},
success: function(data){
ReadData();    
}
});    
});    

$(document).on('click', '.remove', function () {
var id = $(this).attr('id');
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
expremove: id
},
success: function(data){
ReadData();
}
});    
});    

$(document).on('click','#expreset',function() {
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
expclear: 1
},
success: function(data){
$("#note").val("");   
ReadData();    
}
});    
});     
    
$(document).on('click', '#addexp', function() {
var scid = $('#cid').val();    
var expid = $('#expid').val();    
var amount = parseFloat($('#amount').val());
var mtype = $('#mtype').val();    
var ref = $('#ref').val();    
toastr.options = {'positionClass': 'toast-top-center'};    

ecid = scid.split("_");
cty=ecid[0];
cid=ecid[1];    
    
if(expid == '-Select-' || expid == ''){
toastr.info('Please Select Expen!');
return;
}    
    
if(isNaN(amount) != false || amount <= 0){
toastr.info('Please Enter Amount!');
return;
}

$.ajax({
url: 'axe_cart.php',
type: 'post',
data: {cty:cty, cid:cid, expid:expid, amount:amount, ref:ref, mtype:mtype},
success:function(response){
$("#expid").val("").trigger("change");    
$('#ref').val("");
$('#amount').val("");    
ReadData();
}
});    
    
});

$(document).on('change', '#cid', function () {
id = $(this).val();
$.ajax({
url: 'axe_cart.php',
type: 'post',
data: {checkbales:id},
success:function(data){
$('#cbal').html(data);
}
});   
});    
    
$(document).on('click', '#aexpi', function() {
$.ajax({
url: "axe_additem.php",
method: "POST",
data:{addexpi:1},
success: function(data){
$('#addsitem').html(data);
$('.right-side-add').toggle('slide', { direction: 'right' }, 300);     
}
})       
});
    
$(document).on('click', '#addcash', function() {
$.ajax({
url: "axe_additem.php",
method: "POST",
data:{addcash:1},
success: function(data){
$('#addsitem').html(data);
$('.right-side-add').toggle('slide', { direction: 'right' }, 300);     
}
})       
});    

$(document).on('click', '#closepop', function() {    
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
});    
</script>    
<!-- /page script -->
</html>    