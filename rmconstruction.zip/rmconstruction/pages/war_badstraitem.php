<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}

$output='';
$output.='<tr>';     
$output.='<td width="30px" class="text-center"></td>';
$output.='<td width="60px" class="text-center"></td>';
$output.='<td width="380px"></td>';
$output.='<td width="95px" class="text-center"></td>';
$output.='<td width="130px" class="text-center"></td>';    
$output.='<td width="30px" class="text-center"></td>'; 
$output.='</tr>';
    
$sql="SELECT * FROM (SELECT DISTINCT supid AS id FROM (SELECT pid,colid,sizid,IFNULL(b_in,0) AS b_in,IFNULL(b_out,0) AS b_out,supid,serial,exp_date FROM (SELECT supid,IF(rep_pid IS NULL,pid,rep_pid) AS pid,colid,sizid,b_in,b_out,IF(rep_pid IS NULL,serial,rep_serial) AS serial,exp_date FROM tbl_waranty WHERE b_in>0 AND (b_in-b_out)>0) stwar) wst LEFT JOIN (SELECT id,name,image,code FROM tbl_item) itm ON itm.id=wst.pid ORDER BY name ASC) sup LIMIT 1";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
$rows=mysqli_fetch_array($query);    
if(isset($_POST['supid'])){    
$isupid=$_POST['supid'];
if(isset($_SESSION['axes_badstclaim'])){
unset($_SESSION['axes_badstclaim']);
}    
}else{
$isupid=$rows['id'];    
}
$isql="SELECT wst.id,wst.pid,itm.name,itm.image,itm.code,wst.colid,wst.sizid,wst.b_in,wst.b_out,wst.supid,wst.serial,wst.exp_date FROM (SELECT id,pid,colid,sizid,IFNULL(b_in,0) AS b_in,IFNULL(b_out,0) AS b_out,supid,serial,exp_date FROM (SELECT id,supid,pid,colid,sizid,b_in,b_out,serial,exp_date FROM tbl_waranty WHERE (b_in>0 AND (b_in-b_out)>0) AND supid='$isupid' AND brid='$brid') stwar) wst LEFT JOIN (SELECT id,name,image,code FROM tbl_item) itm ON itm.id=wst.pid ORDER BY name ASC";    

$result = mysqli_query($con, $isql) or die(mysqli_error($con));
if($result->num_rows > 0) {
$s=0;
$totqty=0;    
while ($row=mysqli_fetch_array($result)){
$s+=1;
$totqty+=$row['b_in'];    
$output.='<tr>';
$output.='<td width="30px" class="text-center">'.$s.'</td>';
$output.='<td width="60px" class="text-center"><img src="../img/product/';
if(empty($row['image'])){
$output.='no_image.png';}else{
$output.=$row['image'];
}
$output.='" height="40px" width="40px"></td>';    
$output.='<td width="380px">'.$row['name'].'</td>'; 
$output.='<td width="95px" class="text-center">'.$row['code'].'</td>'; 
$output.='<td width="130px" class="text-center">'.$row['serial'].'</td>';
$output.='<td class="text-center" width="25px"><a id="CLI_'.$row['id'].'_'.$row['serial'].'" class="climbad"><span style="cursor: pointer;" class="fa fa-plus"></span></a></td>';     
$output.='</tr>';    
}
$output.='<tr>';
$output.='<td colspan="4" class="text-center"><strong>-Total-</strong></td>';
$output.='<td colspan="2" class="text-center"><strong>'.$totqty.'</strong></td>';    
$output.='</tr>';     
}else{
$output.='<tr>';
$output.='<td colspan="6" class="text-center">No Item For Clim</td>';    
$output.='</tr>';    
}
    
}else{
$output.='<tr>';
$output.='<td colspan="6" class="text-center">No Item For Clim</td>';    
$output.='</tr>';
}
echo $output;
exit;