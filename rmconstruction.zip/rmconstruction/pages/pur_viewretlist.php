<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$_SESSION['cuPages']='pur_preturnlist.php';   
$cuPage='pur_preturnlist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
?>
<?php 
if(isset($_POST['invid'])){
$piid=$_POST['invid'];
$type=$_POST['type'];    
$cusid=$_POST['cusid'];    
$sql="SELECT * FROM tbl_preturn WHERE type='$type' AND cusid='$cusid' ORDER BY apdate DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$invno=$row['invno'];    
?>
<li <?php if($row['id']==$piid){echo 'class="invpiv active"';}else{echo 'class="invpiv"';}?> id="pi_<?php echo $row['id'];?>"><p><strong class="pino"><?php echo $row['invno'];?></strong><br><strong><?php echo date("d M Y", strtotime($row['apdate']));?></strong></p>
<div class="sname" style="margin-top: -52px;float: right; position: relative;top: 6px;"><strong><?php echo 'A: '.numtolocal($row['adjust'],get_fild_data('tbl_currency','1','symbol')); ?></strong><br><strong><?php echo 'R: '.numtolocal($row['total'],get_fild_data('tbl_currency','1','symbol')); ?></strong></div>
</li>
<?php }} ?>