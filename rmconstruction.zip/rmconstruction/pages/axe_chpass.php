<?php
session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;     
}
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php 
if(isset($_POST['chagepass'])){
$uid=remove_junk(escape($_POST['userid']));    
$pass=remove_junk(escape($_POST['pass']));
$cpass=remove_junk(escape($_POST['cpass']));
$spass= sha1($pass);

if($pass!=$cpass){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Password Not Match!!'
));
return;
exit;  
}    

$sql="UPDATE tbl_user SET password='$spass' WHERE id='$uid'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);
    
if($efid>0){
echo json_encode(array(
'status' => 'success',
'message'=> 'Password Change Successfully!!'   
));
exit;    
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Password fail to change!!'
));    
}    
    
}
?>
<?php 
if(isset($_POST['chpass'])){ 
$uid=intval($_POST['chpass']);
?>
<div class="col-md-12 popup_details_div changepass">
<div class="row">
<div id="server-results">
<input type="hidden" name="chagepass" readonly />    
<input type="hidden" name="userid" value="<?php echo $uid; ?>" readonly />    
</div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<div class="form-group">
<label>Password</label>
<div class="row">
<div class="form-group col-sm-12">
<div class="input-group">
<span class="input-group-addon">P</span>    
<input type="password" name="pass" class="form-control" id="pass" placeholder="Password" required="">
</div>
</div>
<div class="form-group col-sm-12">
<div class="input-group">
<span class="input-group-addon">CP</span>    
<input type="password" name="cpass" class="form-control" id="cpass" placeholder="Confirm">
</div>
</div>
</div>
</div>       
</div>    
<div class="col-md-1"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="chngpass" class="btn btn-flat bg-purple btn-sm" value="Change"/>
</div> 
</div>
<script type="text/javascript">
function chek_error(){
var pass=$('#pass').val();
var cpass=$('#cpass').val();
var result = true; 

$('.LV_invalid_field').removeClass('LV_invalid_field');     
$('.LV_validation_message').remove();     

if(pass.length<=7){
$('#pass').addClass('LV_invalid_field');   
$('#pass').after("<span class='LV_validation_message LV_invalid'>Must not be less than 8 characters long!</span>").addClass('has-error');
result=false;    
}else{
$('#pass').removeClass('LV_invalid_field');
result=true;    
}
    
if (pass != cpass){
$('#cpass').addClass('LV_invalid_field');   
$('#cpass').after("<span class='LV_validation_message LV_invalid'>Passwords do not match!</span>").addClass('has-error');
result=false;    
}else{
$('#cpass').removeClass('LV_invalid_field');
result=true;    
}
    
if(pass != cpass || !result){
return false;    
}else{
return true;     
}    
}

$(document).on('blur', '#pass,#cpass', function() {
chek_error();    
});    
</script>    
<?php } ?>