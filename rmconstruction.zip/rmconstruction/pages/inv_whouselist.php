<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='inv_whouselist.php';   
$cuPage='inv_whouselist.php';    
$aid=$_SESSION['uid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='inventor';
$menuh='Inventory';
$phead='wholist';
$page='Warehouse';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php 
if(isset($_POST['delwar'])){
$id=$_POST['delwar']; 
if(delete_check('tbl_traproduct','waid',$id)>0 || delete_check('tbl_serial','whid',$id)>0 || delete_check('tbl_trafrwho','fsourch',$id,'ftype','WH')>0 || delete_check('tbl_trafrwho','tsourch',$id,'ttype','WH')>0 || delete_check('tbl_trafrbra','fsourch',$id,'ftype','WH')>0 || delete_check('tbl_trafrbra','tsourch',$id,'ttype','WH')>0){
save_msg('w','Warehouse Depend On Other Table!!!');
echo "<script>window.location='inv_whouselist.php'</script>";
return;    
}
$name= get_fild_data('tbl_warehouse',$id,'name');   
$sql="DELETE FROM tbl_warehouse WHERE id='$id'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);    
if($efid>0){    
$act =remove_junk(escape('Warehouse name: '.$name));    
write_activity($aid,'WAR','Warehouse has been deleted',$act);       
save_msg('s','Warehouse Successfully Deleted!!!');
}else{
save_msg('w','Warehouse Fail to Delete!!!');    
}     
echo "<script>window.location='inv_whouselist.php'</script>";
}
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Warehouse List';}else{echo 'গুদাম ঘরের (ওয়্যারহাউজ) তালিকা';}?></h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead class="text-uppercase">
<tr>
<th style="width:40px;"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'SN';}else{echo 'নং';}?></th> 
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Name';}else{echo 'নাম';}?></th>
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Phone';}else{echo 'ফোন';}?></th>
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Email';}else{echo 'ইমেইল';}?></th>
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Address';}else{echo 'ঠিকানা';}?></th>    
<th style="width:40px; text-align:center;"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Action';}else{echo 'সিদ্ধান্ত';}?></th>     
</tr>
</thead>    
<tbody>
<?php
$sql="SELECT * FROM tbl_warehouse ORDER BY name ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$id=$row['id'];
?>
<tr>
<td class="center"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo count_id();}else{echo engToBn(count_id());}?></td> 
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo $row['name'];}else{echo $row['bname'];}?></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo $row['phone'];}else{echo engToBn($row['phone']);}?></td>
<td><?php echo $row['email'];?></td>    
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo $row['address'];}else{echo $row['baddress'];}?></td>
<td nowrap="">
<a class="btn btn-flat bg-purple" href="#" onclick="edit_item('ED_<?php echo $row['id'];?>')"><i class="fa fa-edit"></i></a>      
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
<form action="inv_whouselist.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delwar" value="<?php echo $row['id']; ?>" />
</form>
<form action="inv_whouseedit.php" id="ED_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="editwar" value="<?php echo $row['id']; ?>" />
</form>    
</td>    
</tr>    
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<?php if(get_limitpermision('tbl_warehouse')<get_fild_data('tbl_limitset','1','whlim')){?>     
<a href="inv_whousecreate.php" class="btn btn-flat bg-purple"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Add Warehouse';}else{echo 'গুদাম ঘর যোগ করুন';}?></a>
<?php } ?>     
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'History';}else{echo 'ইতিহাস';}?> </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'WAR','A');}else{echo read_activity($aid,'WAR','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>    

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
});
function edit_item(id) {
document.getElementById(id).submit(); 
}
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});
}
</script>    
<!-- /page script -->
</html>    