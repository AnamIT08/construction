<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='axe_setting.php';   
$cuPage='axe_setting.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];
$uty=$_SESSION['utype'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='company';
$menuh='Company';
$phead='seting';
$page='Local Setting';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php 
if(isset($_POST['save_setting'])){
$efr=0;    
if(isset($_POST['data']) && !empty($_POST['data'])){
$settings=$_POST['data'];
foreach($settings as $setup){
$id = remove_junk(escape($setup['id']));
if($id==6){
$sval = escape($setup['action']);	
}elseif($id==17){
$nval=$_POST["inv"];	
$sval=implode(",",$nval);
}elseif($id==18){
$nsval=$_POST["invs"];	
$sval=implode(",",$nsval);
}else{
$sval = remove_junk(escape($setup['action']));	
}
$sql="UPDATE tbl_setting SET sval='$sval' WHERE id='$id'";
mysqli_query($con,$sql)or die(mysqli_error($con));
$itid=mysqli_affected_rows($con);
if($itid>0){
$efr+=1;    
}else{
$efr+=0;     
}    
}   
}
if($efr>0){
$act= ' Update Local Setting';   
write_activity($aid,'SET','Local Setting Changes',$act);    
save_msg('s','Setting Successfully Saved!');
}else{
save_msg('w','Setting Fail to Saved!');   
}    	
echo "<script>window.location='axe_setting.php'</script>";
}
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Local Setting</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>
<form action="axe_setting.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped">
<tr>
<th hidden>ID</th>
<th>Key</th>
<th>Description</th>
<th>Action</th>
</tr>    
<tbody>
<?php if($uty==1){?>
<tr>
<td hidden><input type="hidden" maxlength="11" name="data[0][id]" id="id_1" value="1" class="form-control" autocomplete="off"></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Select Language';}else{echo 'ভাষা নির্বাচন';}?></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Show Operating Language For Software';}else{echo 'সফ্টওয়্যার পরিচালনার ভাষা নির্বাচন করুন।';}?></td>
<td>
<select class="form-control" name="data[0][action]">    
<option <?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'selected';} ?> value="0">English</option>
<option <?php if(get_fild_data('tbl_setting','1','sval')==1){echo 'selected';} ?> value="1">বাংলা</option>
</select>
</td>  
</tr>
<tr>
<td hidden><input type="hidden" maxlength="11" name="data[1][id]" id="id_2" value="2" class="form-control" autocomplete="off"></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Purchase Receive';}else{echo 'ক্রয় কৃত পণ্য গ্রহণ';}?></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Purchase Product Received With Purchase Time';}else{echo 'ক্রয় কৃত পণ্য ক্রয়ের সময় গ্রহণ করবো।';}?></td>
<td>
<select class="form-control" name="data[1][action]">    
<option <?php if(get_fild_data('tbl_setting','2','sval')==0){echo 'selected';} ?> value="0"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Yes';}else{echo 'হ্যাঁ';}?></option>
<option <?php if(get_fild_data('tbl_setting','2','sval')==1){echo 'selected';} ?> value="1"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'No';}else{echo 'না';}?></option>
</select>
</td>  
</tr>
<tr>
<td hidden><input type="hidden" maxlength="11" name="data[2][id]" id="id_3" value="3" class="form-control" autocomplete="off"></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Sales Delivery';}else{echo 'বিক্রয় পণ্য বিতরণ';}?></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Sales Product Deliver With Sales Time';}else{echo 'বিক্রয় কৃত পণ্য বিক্রয়ের সময় বিতরণ করবো।';}?></td>
<td>
<select class="form-control" name="data[2][action]">    
<option <?php if(get_fild_data('tbl_setting','3','sval')==0){echo 'selected';} ?> value="0"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Yes';}else{echo 'হ্যাঁ';}?></option>
<option <?php if(get_fild_data('tbl_setting','3','sval')==1){echo 'selected';} ?> value="1"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'No';}else{echo 'না';}?></option>
</select>
</td>  
</tr>
<tr>
<td hidden><input type="hidden" maxlength="11" name="data[3][id]" id="id_4" value="4" class="form-control" autocomplete="off"></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Sales Time Show Cost';}else{echo 'বিক্রয় পণ্য বিতরণ';}?></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Sales Time Show Product Cost';}else{echo 'বিক্রয় কৃত পণ্য বিক্রয়ের সময় বিতরণ করবো।';}?></td>
<td>
<select class="form-control" name="data[3][action]">    
<option <?php if(get_fild_data('tbl_setting','4','sval')==0){echo 'selected';} ?> value="0"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Yes';}else{echo 'হ্যাঁ';}?></option>
<option <?php if(get_fild_data('tbl_setting','4','sval')==1){echo 'selected';} ?> value="1"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'No';}else{echo 'না';}?></option>
</select>
</td>  
</tr>
<tr>
<td hidden><input type="hidden" maxlength="11" name="data[4][id]" id="id_5" value="5" class="form-control" autocomplete="off"></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Invoice Due Print';}else{echo 'বিক্রয় পণ্য বিতরণ';}?></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Sales Invoice Print Old Due';}else{echo 'বিক্রয় কৃত পণ্য বিক্রয়ের সময় বিতরণ করবো।';}?></td>
<td>
<select class="form-control" name="data[4][action]">    
<option <?php if(get_fild_data('tbl_setting','5','sval')==0){echo 'selected';} ?> value="0"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Yes';}else{echo 'হ্যাঁ';}?></option>
<option <?php if(get_fild_data('tbl_setting','5','sval')==1){echo 'selected';} ?> value="1"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'No';}else{echo 'না';}?></option>
</select>
</td>  
</tr>
<tr>
<td colspan="3" style="text-align:center">Invoice Note &amp; Terms</td>
</tr>
<tr>
<td hidden><input type="hidden" maxlength="11" name="data[5][id]" id="id_6" value="6" class="form-control" autocomplete="off"></td>
<td colspan="3">
<textarea class="form-control" id="editor_terms" maxlength="425" name="data[5][action]" placeholder="Terms & Conditions"><?php echo get_fild_data('tbl_setting','6','sval');?></textarea>
</td>
</tr>
<tr>
<td hidden><input type="hidden" maxlength="11" name="data[6][id]" id="id_7" value="7" class="form-control" autocomplete="off"></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Invoice Note Print';}else{echo 'বিক্রয় পণ্য বিতরণ';}?></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Sales Invoice Print With Terms &amp; Condition';}else{echo 'বিক্রয় কৃত পণ্য বিক্রয়ের সময় বিতরণ করবো।';}?></td>
<td>
<select class="form-control" name="data[6][action]">    
<option <?php if(get_fild_data('tbl_setting','7','sval')==0){echo 'selected';} ?> value="0"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Yes';}else{echo 'হ্যাঁ';}?></option>
<option <?php if(get_fild_data('tbl_setting','7','sval')==1){echo 'selected';} ?> value="1"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'No';}else{echo 'না';}?></option>
</select>
</td>  
</tr>
<tr>
<td hidden><input type="hidden" maxlength="11" name="data[7][id]" id="id_8" value="8" class="form-control" autocomplete="off"></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Enable Chat';}else{echo 'বিক্রয় পণ্য বিতরণ';}?></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Fro Internal Communication';}else{echo 'বিক্রয় কৃত পণ্য বিক্রয়ের সময় বিতরণ করবো।';}?></td>
<td>
<select class="form-control" name="data[7][action]">    
<option <?php if(get_fild_data('tbl_setting','8','sval')==0){echo 'selected';} ?> value="0"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Yes';}else{echo 'হ্যাঁ';}?></option>
<option <?php if(get_fild_data('tbl_setting','8','sval')==1){echo 'selected';} ?> value="1"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'No';}else{echo 'না';}?></option>
</select>
</td>  
</tr>
<tr>
<td hidden><input type="hidden" maxlength="11" name="data[8][id]" id="id_9" value="9" class="form-control" autocomplete="off"></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Show Cost';}else{echo 'বিক্রয় পণ্য বিতরণ';}?></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Sales Price Update Time Show Cost';}else{echo 'বিক্রয় কৃত পণ্য বিক্রয়ের সময় বিতরণ করবো।';}?></td>
<td>
<select class="form-control" name="data[8][action]">    
<option <?php if(get_fild_data('tbl_setting','9','sval')==0){echo 'selected';} ?> value="0"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Yes';}else{echo 'হ্যাঁ';}?></option>
<option <?php if(get_fild_data('tbl_setting','9','sval')==1){echo 'selected';} ?> value="1"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'No';}else{echo 'না';}?></option>
</select>
</td>  
</tr>    
<?php }else{?>
        
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="save_setting" id="submit" class="btn btn-flat bg-purple btn-sm " value="Save"/>
</div>
</div>    
</div>
</form>     
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'SET','A');}else{echo read_activity($aid,'SET','U');}?>
</div>
</div>
</div>
</div>
</div>
</div> 

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
var tinymce_init = {
language: 'en',
directionality: 'ltr',
plugins: [
'advlist autolink lists charmap preview hr anchor pagebreak',
'searchreplace wordcount visualblocks visualchars code insertdatetime nonbreaking',
'save directionality paste textcolor'
],
setup: function(ed) {
var maxlength = parseInt($("#" + (ed.id)).attr("maxlength"));
        
ed.on("keydown", function(e) {
if(e.keyCode == 8 || e.keyCode == 46){
}else{
if (CountCharacters() >= maxlength) {
return false;
}	
}
});
},
menubar:false,
statusbar:false,
toolbar: 'undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | preview code',
};

function CountCharacters() {
var body = tinymce.get("editor_terms").getBody();
var content = tinymce.trim(body.innerText || body.textContent);
return content.length;
};

tinymce.remove("#editor_terms");
tinymce.init(
Object.assign({}, tinymce_init, {
selector: '#editor_terms',
height: 100,
})
);    
</script>    
<!-- /page script -->
</html>    