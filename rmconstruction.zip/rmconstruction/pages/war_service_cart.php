<?php
session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;     
}
$dtnow = date("Y-m-d h:i:s", time());
?>

<?php if(isset($_POST['viewitem'])){
$sql="SELECT * FROM tbl_sercenter ORDER BY name ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){    
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td><?php echo $row['name'];?></td>      
<td><?php echo show_addres('',$row['mobile'],$row['email']);;?></td>
<td><?php echo $row['address'];?></td>       
<td><?php if($row['status']>0){echo 'Active';}else{echo 'De-Active';}?></td>    
<td nowrap="">
<a class="btn btn-flat bg-purple details-invoice" href="#" id="src_<?php echo $row['id']; ?>"><i class="fa fa-edit cat-child"></i></a>    
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
<form action="war_service.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delsel" value="<?php echo $row['id']; ?>" />
</form>
</td>    
</tr>    
<?php }} ?>

<?php 
if(isset($_POST['viewitemhis'])){
if($_SESSION['utype']=='1'){echo read_activity($aid,'SRC','A');}else{echo read_activity($aid,'SRC','U');}
}?>

<?php 
if(isset($_POST['addsitem'])){ 
$item=intval($_POST['item']);   
?>
<div class="col-md-12 popup_details_div addservice">
<div class="row">
<div id="server-results"><!-- For server results --></div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<?php if($item <=0){ ?>     
<div class="form-group">
<label>Name</label>
<input type="text" maxlength="35" value="" name="name" id="name" class="form-control" placeholder="e.g. Axes Service Center"/>
<input type="hidden" name="addseritem" readonly />    
</div>
<div class="form-group">
<label>Mobile</label>
<input type="text" maxlength="18" value="" name="mobile" id="mobile" class="form-control" placeholder="e.g. 0161617xx7x"/>
</div>
<div class="form-group">
<label>Email</label>
<input type="text" maxlength="45" value="" name="email" id="email" class="form-control" placeholder="e.g. info@axesgl.com"/>
</div>    
<div class="form-group">
<label>Address</label>
<textarea class="form-control" maxlength="150" rows="5" name="address" id="address" placeholder="Address"></textarea>
</div>
<div class="form-group">
<label>Status</label>
<select class="form-control select2" name="status" id="status">
<option value="1">Active</option>
<option value="0">De-Active</option>    
</select>
</div>     
<?php 
}else{ 
$sql="SELECT * FROM tbl_sercenter WHERE id='".$item."' ORDER BY id ASC LIMIT 1";    
$admin=mysqli_query($con,$sql) or die(mysqli_error($con));    
$adm=mysqli_fetch_array($admin);    
?>
<div class="form-group">
<label>Name</label>
<input type="text" maxlength="35" value="<?php echo $adm['name'];?>" name="name" id="name" class="form-control" placeholder="e.g. Axes Service Center"/>
<input type="hidden" maxlength="11" value="<?php echo $adm['id'];?>" class="form-control" name="itmid" autocomplete="off" readonly>
<input type="hidden" name="editseritem" readonly />     
</div>    
<div class="form-group">
<label>Mobile</label>
<input type="text" maxlength="18" value="<?php echo $adm['mobile'];?>" name="mobile" id="mobile" class="form-control" placeholder="e.g. 0161617xx7x"/>
</div>
<div class="form-group">
<label>Email</label>
<input type="text" maxlength="45" value="<?php echo $adm['email'];?>" name="email" id="email" class="form-control" placeholder="e.g. info@axesgl.com"/>
</div>
<div class="form-group">
<label>Address</label>
<textarea class="form-control" maxlength="150" rows="5" name="address" id="address" placeholder="Address"><?php echo $adm['address'];?></textarea>
</div>   
<div class="form-group">
<label>Status</label>
<select class="form-control select2" name="status" id="status">
<option <?php if($adm['status']==1){echo 'selected';}?> value="1">Active</option>
<option <?php if($adm['status']==0){echo 'selected';}?> value="0">De-Active</option>    
</select>
</div>
</div>        
<?php } ?>       
<div class="col-md-1"></div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="additem" class="btn btn-flat bg-purple btn-sm " value="<?php if($item <=0){echo 'Save';}else{echo 'Update';} ?>"/>
</div> 
</div>
<script type="text/javascript">
$(".select2").select2();
    
function chek_error(){
var result = true;
var name = $('#name').val();
var mobile = $('#mobile').val();
var address = $('#address').val();    

$('.LV_invalid_field').removeClass('LV_invalid_field');     
$('.LV_validation_message').remove();     

if(name.length<1){
$('#name').addClass('LV_invalid_field');   
$('#name').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#name').removeClass('LV_invalid_field');
result=true;    
}    

if(mobile.length<1){
$('#mobile').addClass('LV_invalid_field');   
$('#mobile').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#mobile').removeClass('LV_invalid_field');
result=true;    
} 
    
if(address.length<1){
$('#address').addClass('LV_invalid_field');   
$('#address').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#address').removeClass('LV_invalid_field');
result=true;    
}     

if(mobile.length<0 || address.length<0 || !result){
return false;    
}else{
return true;     
}        
}
    
$(document).on('blur', '#name, #mobile, #address', function() {
chek_error();    
});    
</script> 

<?php }
if(isset($_POST['addseritem'])){
$name = ucwords(remove_junk(escape($_POST['name'])));
$mobile = remove_junk(escape($_POST['mobile']));
$email = remove_junk(escape($_POST['email']));
$address = remove_junk(escape($_POST['address']));    
$status = remove_junk(escape($_POST['status']));   
 
if(isset($_POST['name'])){
$sql="SELECT * FROM tbl_sercenter WHERE name = '$name'";           
$ducode = mysqli_query($con,$sql);
}
    
if($ducode->num_rows > 0) {
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Service Item Already Exists!!'
));
return;
exit;
}else{ 
$sql="INSERT INTO tbl_sercenter (name,address,mobile,email,status,brid,uid,date) VALUES ('$name','$address','$mobile','$email','$status','$brid','$aid','$dtnow')";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$pid=$con->insert_id;    
$efid=mysqli_affected_rows($con);    
if($efid>0){    
$act =remove_junk(escape('Service center name: '.$name));    
write_activity($aid,'SRC','New service center has been created',$act);    
echo json_encode(array(
'status' => 'success',
'message'=> 'Data Save Successfully!!'   
));
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));    
} 
}   
}

if(isset($_POST['editseritem'])){
$name = ucwords(remove_junk(escape($_POST['name'])));
$itemid = remove_junk(escape($_POST['itmid']));
$mobile = remove_junk(escape($_POST['mobile']));
$email = remove_junk(escape($_POST['email']));
$address = remove_junk(escape($_POST['address']));    
$status = remove_junk(escape($_POST['status'])); 

if(isset($_POST['name'])){
$sql="SELECT * FROM tbl_sercenter WHERE name = '$name' AND id!='$itemid'";           
$ducode = mysqli_query($con,$sql);
}
    
if($ducode->num_rows > 0) {
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Service Center Already Exists!!'
));
return;
exit;
}else{ 
$sql="UPDATE tbl_sercenter SET name='$name',address='$address',mobile='$mobile',email='$email',status='$status' WHERE id='$itemid'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));   
$efid=mysqli_affected_rows($con);    
if($efid>0){    
$act =remove_junk(escape('Service center name: '.$name));    
write_activity($aid,'SRC','Service center has been Updated',$act);    
echo json_encode(array(
'status' => 'success',
'message'=> 'Data Update Successfully!!'   
));
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Update!!'
));    
} 
}   
}

function check_desercenter($id){
$flage=0;
global $con;
$sql="SELECT * FROM tbl_waranty WHERE src_id='$id'";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}

if($flage>0){
return $flage;
exit;    
}    
return $flage;    
}

if(isset($_POST['delsercent'])){
$id=intval($_POST['item']);
    
if(check_desercenter($id)){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Service Item Depend On Other Table!!'
));
exit;
return;    
}

$name=get_fild_data('tbl_sercenter',$id,'name');
$sql="DELETE FROM tbl_sercenter WHERE id='$id'";
$fdel=mysqli_query($con,$sql)or die(mysqli_error($con));    
$efid=mysqli_affected_rows($con);
if($efid>0){
$act =remove_junk(escape('Service center: '.$name));    
write_activity($aid,'SRC','Service center has been deleted',$act);        
echo json_encode(array(
'status' => 'success',
'message'=> 'Data Deleted Successfully!!'   
));
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Delete!!'
));    
}       
}
?>