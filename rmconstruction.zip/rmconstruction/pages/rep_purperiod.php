<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/invfunctions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='rep_purperiod.php';   
$cuPage='rep_purperiod.php';    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='report';
$menuh='Report';
$phead='report';
$page='Periodic Purchase Records';
$ractive='F';
$print='print';
$today = strftime("%Y-%m-%d", time());
$dtnow = date("Y-m-d h:i:s", time());
$oavno='REP'.date("dmy", strtotime($today)).'PPDR';
?>
<?php 
if(isset($_POST['tfdate'])){
$fdate=$_POST['tfdate'];    		
}else{
$fdate=date('Y-m-d', strtotime('-0 days', time()));	
}
if(isset($_POST['ttdate'])){
$tdate=$_POST['ttdate'];	
}else{
$tdate=$today;	
}

if(isset($_POST['ibrid']) && $_POST['ibrid']!=''){
$ibrid=$_POST['ibrid'];    
}else{
$ibrid=$brid;    
}

if(isset($_POST['category']) && $_POST['category']!=''){
$catid=$_POST['category'];	
}else{
$catid=0;	
}

if(isset($_POST['subcat']) && $_POST['subcat']!=''){
$subid=$_POST['subcat'];	
}else{
$subid=0;	
}

if(isset($_POST['brand']) && $_POST['brand']!=''){
$brandid=$_POST['brand'];	
}else{
$brandid=0;	
}

if(isset($_POST['itemid']) && $_POST['itemid']!=''){
$itemid=$_POST['itemid'];	
}else{
$itemid=0;	
}

$sear='';
$isear='';

if($catid!='0'){
$sear=" WHERE catid='$catid' AND ";
$isear=" AND tbl_item.catid='$catid'";    
}else{
$sear='';
$isear='';    
}

if($subid!='0'){
if($sear!=''){
$sear.="scatid='$subid' AND ";
$isear.=" AND tbl_item.scatid='$subid'";    
}else{
$sear=" WHERE scatid='$subid' AND ";
$isear=" AND  tbl_item.scatid='$subid'";    
}
}

if($brandid!='0'){
if($sear!=''){
$sear.="brid='$brandid' AND ";
$isear.=" AND tbl_item.brid='$brandid'";    
}else{
$sear=" WHERE brid='$brandid' AND "; 
$isear=" AND  tbl_item.brid='$brandid'";    
}
}

if($itemid!='0'){
if($sear!=''){
$sear.="pid='$itemid' AND ";   
}else{
$sear=" WHERE pid='$itemid' AND ";   
}
}

if($sear==''){
$sear=" WHERE ";    
}    
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
<div class="row">
<div class="col-md-12">
<div class="col-md-3">    
<div class="box box-solid">

<div class="box-body">
<div class="col-md-12">    
<div class="row">    
<div class="roles-menu">   
<ul class="nav">
<li <?php if($ractive=='A'){echo 'class="active"';}?>><a href="rep_purinvrec.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Purchase Record (Invoice)';}else{echo '  ক্রয়ের প্রতিবেদন';}?></a></li>
<li <?php if($ractive=='B'){echo 'class="active"';}?>><a href="rep_purretrec.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Retrun Record (Invoice)';}else{echo ' ক্রয় ফেরত প্রতিবেদন চালান অনুযায়ী';}?></a></li>
<li <?php if($ractive=='C'){echo 'class="active"';}?>><a href="rep_pursupwise.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Supplier Wise (Invoice)';}else{echo ' ক্রয়  প্রতিবেদন    বিক্রেতা  অনুযায়ী';}?></a></li>
<li <?php if($ractive=='D'){echo 'class="active"';}?>><a href="rep_puritm.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Item Wise';}else{echo ' ক্রয় প্রতিবেদন পদ অনুযায়ী';}?></a></li>
<li <?php if($ractive=='E'){echo 'class="active"';}?>><a href="rep_puritmst.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Item Statement';}else{echo ' ক্রয়  পদ বিবরণ ';}?></a></li>
<li <?php if($ractive=='F'){echo 'class="active"';}?>><a href="rep_purperiod.php"> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Periodic Purchase Record';}else{echo ' পর্যায়ক্রমিক ক্রয়ের বিবরণ ';}?></a></li>
<li <?php if($ractive=='G'){echo 'class="active"';}?>><a href="rep_purovrview.php"> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Overview';}else{echo ' সামগ্রিক অবস্থা (ওভারভিউ)';}?></a></li>    
</ul>
</div>
</div>
<hr>    
<form action="rep_purperiod.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<!--From Data-->
<div class="col-md-12">    
<div class="row">
<?php if($uty=='1'){?>   
<div class="form-group" >
<label>Branch</label>
<div class="input-group">
<span class="input-group-addon">BR</span>
<select class="form-control select2" name="ibrid" id="ibrid">
<option <?php if($ibrid=='A'){echo 'selected';}?> value="A">-All Branch-</option>
<option <?php if($ibrid=='0'){echo 'selected';}?> value="0">-Corporate Branch-</option>    
<?php									
$querymt=mysqli_query($con,"SELECT DISTINCT id,name FROM tbl_branch ORDER BY name ASC")or die(mysqli_error($con));
while ($rowmt=mysqli_fetch_array($querymt)){
?>
<?php if($rowmt['id']==$ibrid){?>
<option selected value="<?php echo $rowmt['id'];?>"><?php echo $rowmt['name'];?></option>
<?php }else{ ?>    
<option value="<?php echo $rowmt['id'];?>"><?php echo $rowmt['name'];?></option>
<?php } ?>    
<?php } ?>
</select>
</div>
</div>    
<?php } ?>    
</div>
</div>

<div class="row">
<div class="col-md-6">
<div class="form-group">
<label>Category</label>
<select class="form-control select2" name="category" onchange="getAllSubgroup(this.value)">
<option value="">-Select-</option> 
<?php
$sql="SELECT * FROM tbl_category ORDER BY name ASC";    
$querymt=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowmt=mysqli_fetch_array($querymt)){
?>
<?php if($rowmt['id']==$catid){?>
<option selected value="<?php echo $rowmt['id'];?>"><?php echo $rowmt['name'];?></option>
<?php }else{ ?>
<option value="<?php echo $rowmt['id'];?>"><?php echo $rowmt['name'];?></option>
<?php } ?>
<?php } ?>
</select>
</div>
</div>        
<div class="col-md-6">
<div class="form-group">
<label>Sub-Category</label>
<select class="form-control select2" id="scatid" name="subcat">
<?php if($catid>0){
echo '<option value="">-Select-</option>';
$sql="SELECT * FROM tbl_subcat WHERE catid='$catid'";
$subcat=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($scat=mysqli_fetch_array($subcat)){
?>
<?php if($scat['id']==$subid){?>
<option selected value="<?php echo $scat['id'];?>"><?php echo $scat['name'];?></option>
<?php }else{ ?>
<option value="<?php echo $scat['id'];?>"><?php echo $scat['name'];?></option>
<?php } ?>
<?php }}else{ ?>
<option value="">-Select-</option>
<?php } ?>
</select>
</div>	
</div>       
</div>    
<div class="row">
<div class="col-md-6">
<div class="form-group">
<label>Brand</label>
<select class="form-control select2" name="brand">
<option value="">-Select-</option> 
<?php
$sql="SELECT * FROM tbl_brand ORDER BY name ASC";    
$queryb=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowb=mysqli_fetch_array($queryb)){
?>
<?php if($rowb['id']==$brandid){?>
<option selected value="<?php echo $rowb['id'];?>"><?php echo $rowb['name'];?></option>
<?php }else{ ?>
<option value="<?php echo $rowb['id'];?>"><?php echo $rowb['name'];?></option>
<?php } ?>
<?php } ?>
</select>
</div>   
</div>
<div class="col-md-6">
<div class="form-group">
<label>Item</label>
<select class="form-control select2" name="itemid">
<option value="">-Select-</option> 
<?php
if($isear!=''){
$sql="SELECT DISTINCT tbl_traproduct.pid AS id,tbl_item.name FROM tbl_traproduct LEFT JOIN tbl_item ON tbl_item.id=tbl_traproduct.pid WHERE tbl_traproduct.mods='SE'$isear ORDER BY name ASC";    
}else{
$sql="SELECT DISTINCT tbl_traproduct.pid AS id,tbl_item.name FROM tbl_traproduct LEFT JOIN tbl_item ON tbl_item.id=tbl_traproduct.pid WHERE tbl_traproduct.mods='SE' ORDER BY name ASC";    
}    
$queryp=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowp=mysqli_fetch_array($queryp)){
?>
<?php if($rowp['id']==$itemid){?>
<option selected value="<?php echo $rowp['id'];?>"><?php echo $rowp['name'];?></option>
<?php }else{ ?>
<option value="<?php echo $rowp['id'];?>"><?php echo $rowp['name'];?></option>
<?php } ?>
<?php } ?>
</select>
</div>   
</div>    
</div>    
<div class="row"> 
<div class="col-md-6">    
<div class="form-group" >
<label>From</label>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><span class="fa fa-calendar"></span></span>
<input type="text" maxlength="18" class="form-control" name="tfdate" value="<?php echo $fdate; ?>" required autocomplete="off" required>
</div>
</div>
</div>
<div class="col-md-6">    
<div class="form-group" >
<label>To</label>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><span class="fa fa-calendar"></span></span>
<input type="text" maxlength="18" class="form-control" name="ttdate" value="<?php echo $tdate;?>" required autocomplete="off" required>
</div>
</div>
</div>    
</div>    
<!--End From Data-->    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-4"></div>
<div class="col-md-8 text-right" >
<input type="submit" name="filter_submit" id="submit" class="btn btn-flat bg-purple btn-sm " value="Submit"/> <a href="axe_report.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>  
</div>
<div class="col-md-9">
<div class="row">    
<div class="side-head"> 
<div class="col-md-12">    
<div class="col-md-4 text-left">
<button class="btn btn-flat bg-teal" id="print"><i class="fa fa-print"></i></button> 
<button class="btn btn-flat bg-blue"><i class="fa fa-envelope-o"></i></button> 
<button class="btn btn-flat bg-gray"><i class="fa fa-file-pdf-o"></i></button>     
</div>
<div class="col-md-7 text-center">
<select name="Page_resolution" id="resolution" onchange="setPrinterConfig()" style="width: 205px;height: 28px;border: 1px solid red;">
<option value="A4" selected="selected">A4 [210mm × 297mm]</option>   
<option value="A5">A5 [148mm × 210mm]</option>
<option value="Letter">US Letter [216mm × 279mm]</option>
<option value="Legal">US Legal [216mm × 356mm]</option>
</select>
<select name="Page_size" id="rotate" onchange="setPrinterConfig()" style="width: 120px;height: 28px;border: 1px solid red;">
<option value="portrait">Portrait</option>
<option value="landscape">Landscape</option>
</select>    
</div>    
<div class="col-md-1 text-right">

</div>
</div>
</div>    
</div>
<div class="row">
<div class="invhold scrol-y" id="invhold">
<div class="printableArea">
    
</div>    
    
</div>
</div>
</div>
    
</div>    
</div>

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(function(){
$('.invhold').css({ height: $(window).innerHeight()-190 });
$(window).resize(function(){
$('.invhold').css({ height: $(window).innerHeight()-190 });
});
});
    
function getAllSubgroup(id){
$.ajax({
url: 'axe_getsub.php',
type: 'post',
data: {subcat : id},
success:function(data) {
$('#scatid').html(data);
}
});
};    
</script>    
<!-- /page script -->
</html>    