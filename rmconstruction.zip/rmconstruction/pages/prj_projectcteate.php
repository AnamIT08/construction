<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='prj_projectcteate.php';   
$cuPage='prj_projectcteate.php';    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='project';
$menuh='Manage Project';
$phead='prjcreate';
$page='Add New Project';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php 
if(isset($_POST['save_project'])){
	$prjid = strtoupper(remove_junk(escape($_POST['prjid'])));
    $prjname = remove_junk(escape($_POST['prjname']));
    $pgid = remove_junk(escape($_POST['pgid']));
    $psgid = remove_junk(escape($_POST['psgid']));
    //$prjty = remove_junk(escape($_POST['prjty']));
    $status = remove_junk(escape($_POST['status']));

    $cname = remove_junk(escape($_POST['cname']));
    if($cname==''){$cname='NULL';}else{$cname="'".$cname."'";}
    $cnumber = remove_junk(escape($_POST['cnumber']));
    if($cnumber==''){$cnumber='NULL';}else{$cnumber="'".$cnumber."'";}
    $prjamo = remove_junk(escape($_POST['prjamo']));
    if($prjamo==''){$prjamo='0';}else{$prjamo="'".$prjamo."'";}
    $expamo = remove_junk(escape($_POST['expamo']));
    if($expamo==''){$expamo='0';}else{$expamo="'".$expamo."'";}
    $details = remove_junk(escape($_POST['details']));
    if($details==''){$details='NULL';}else{$details="'".$details."'";}
    $address = remove_junk(escape($_POST['address']));
    if($address==''){$address='NULL';}else{$address="'".$address."'";}
    
    $coid = remove_junk(escape($_POST['coid']));
    if($coid==''){$coid='NULL';}else{$coid="'".$coid."'";}
    $coamo = remove_junk(escape($_POST['coamo']));
    if($coamo==''){$coamo='0';}else{$coamo="'".$coamo."'";}
    
    $client = remove_junk(escape($_POST['client']));
    if($client==''){$client='NULL';}else{$client="'".$client."'";}
    
	if(isset($_POST['prjid'])){
    $sql="SELECT * FROM tbl_project WHERE name = '$prjid'";           
	$ducode = mysqli_query($con,$sql);
	}
	
	if($ducode->num_rows > 0) {
	save_msg('i','Prject ID alrady exists! Plz try another');
	echo "<script>window.location='prj_projectcteate.php'</script>";
	}else{    
    $sql="INSERT INTO tbl_project(pgid,psgid,prjid,name,address,cperson,cnumber,prjdetails,prjamount,prjexpamo,prjtype,coid,coamo,client,status,brid,uid,date) VALUES ('$pgid','$psgid','$prjid','$prjname',$address,$cname,$cnumber,$details,$prjamo,$expamo,NULL,$coid,$coamo,$client,'$status','$brid','$aid','$dtnow')";
    
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $pid=$con->insert_id;    
    $efid=mysqli_affected_rows($con);    
    if($efid>0){
    $act =remove_junk(escape('Project ID: '.$prjid));    
    write_activity($aid,'PRJ','New project has been created',$act);    
    save_msg('s','Data Successfully Saved!');
    }else{
    save_msg('w','Data Fail to Saved!');   
    }
    echo "<script>window.location='prj_projectcteate.php'</script>";     
	}  
}
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Add New Project</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="prj_projectcteate.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">

<div class="row ">
<div class="col-md-12">
<div class="col-md-2"></div>
<div class="col-md-8">
<div class="row">
<div class="col-md-4">    
<div class="form-group">
<label>Project ID</label>
<input type="text" name="prjid" maxlength="20" value="" id="prjid" class="form-control" placeholder="e. g. EDU487K" />
</div>
</div>
<div class="col-md-8">
<div class="form-group">
<label>Project Name</label>
<input type="text" name="prjname" maxlength="60" value="" id="prjname" class="form-control" placeholder="e.g Rapura Water Line"  />
</div>    
</div>
</div>
<div class="row">    
<div class="col-md-4">
<div class="form-group">
<label>Select Group</label>
<select class="form-control select2" name="pgid" id="pgid" onchange="getAllSubgroup(this.value)">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_progroup ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>    
</div>
</div>    
<div class="col-md-4">    
<div class="form-group">
<label>Sub-Group</label>      
<select class="form-control select2" name="psgid" id="psgid">
<option value="">-Select-</option>
    
</select> 
</div>    
</div>    
<div class="col-md-4">    
<div class="form-group">
<label>Project Status</label>   
<select class="form-control" name="status" id="status">
<option value="">-Select-</option>
<option value="0">Start</option>
<option value="1">On-Process</option>
<option value="2">Done</option>
<option value="3">Apply</option>    
</select>        
</div>
</div>    
</div>
<div class="row">
<div class="col-md-3">
<div class="form-group">
<label>Contact Person</label>
<input type="text" name="cname" maxlength="35" value="" class="form-control" placeholder="e.g Mr.Enamul Haque"  />
</div>    
</div>    
<div class="col-md-3">
<div class="form-group">
<label>Contact Number</label>
<input type="text" name="cnumber" maxlength="18" value="" class="form-control" placeholder="e.g +880161xxxxx70"  />
</div>    
</div>
<div class="col-md-3">
<div class="form-group">
<label>Project Value</label>
<input type="text" name="prjamo" maxlength="12" value="" onkeypress="return isNumberKey(event)" class="form-control" placeholder="e.g 3,50,00,000"  />
</div>    
</div>
<div class="col-md-3">
<div class="form-group">
<label>Target Expenses</label>
<input type="text" name="expamo" maxlength="12" value="" onkeypress="return isNumberKey(event)" class="form-control" placeholder="e.g 2,50,00,000"  />
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-4">
<div class="form-group">
<label>Select Contractor</label>
<select class="form-control select2" name="coid" id="coid">
<option value="">-Select-</option>
<?php									
$queryc=mysqli_query($con,"SELECT * FROM tbl_contractor WHERE status='1' ORDER BY id ASC")or die(mysqli_error($con));
while ($rowc=mysqli_fetch_array($queryc)){
?>
<option value="<?php echo $rowc['id'];?>"><?php echo $rowc['name'];?></option>
<?php } ?>
</select>    
</div>
</div>
<div class="col-md-4">
<div class="form-group">
<label>Contact Amount</label>
<input type="text" name="coamo" maxlength="12" value="" onkeypress="return isNumberKey(event)" class="form-control" placeholder="e.g 2,10,00,000"  />
</div>    
</div>
<div class="col-md-4">
<div class="form-group">
<label>Select Client</label>
<select class="form-control select2" name="client" id="client">
<option value="">-Select-</option>
<?php									
$queryc=mysqli_query($con,"SELECT * FROM tbl_customer WHERE status='1' ORDER BY id ASC")or die(mysqli_error($con));
while ($row=mysqli_fetch_array($queryc)){
?>
<option value="<?php echo $row['id'];?>"><?php echo $row['code'].' - '.$row['name'];?></option>
<?php } ?>
</select>    
</div>
</div>    
</div>    
<div class="row">
<div class="col-md-6">    
<div class="form-group">
<label>Project Details</label>
<textarea class="form-control" maxlength="250" rows="6" name="details" placeholder="e.g. Details"></textarea>
</div>
</div>
<div class="col-md-6">    
<div class="form-group">
<label>Address</label>
<textarea class="form-control" maxlength="150" rows="6" name="address" placeholder="e.g. Address"></textarea>
</div>
</div>
</div>    
</div>    
<div class="col-md-2"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="save_project" id="submit" class="btn btn-flat bg-purple btn-sm " value="Save"/> <a href="prj_projectlist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'PRJ','A');}else{echo read_activity($aid,'PRJ','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>
    
    
<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function (){ 
var prjid = new LiveValidation('prjid');
prjid.add(Validate.Presence);
var prjname = new LiveValidation('prjname');
prjname.add(Validate.Presence);    
var pgid = new LiveValidation('pgid');
pgid.add(Validate.Presence);
var psgid = new LiveValidation('psgid');
psgid.add(Validate.Presence);
var status = new LiveValidation('status');
status.add(Validate.Presence);    
});
    
function getAllSubgroup(id){
$.ajax({
url: 'axe_getsub.php',
type: 'post',
data: {psgid : id},
success:function(data) {
$('#psgid').html(data);
}
});
};
</script>    
<!-- /page script -->
</html>    