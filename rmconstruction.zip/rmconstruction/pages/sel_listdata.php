<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
include ('../inc/repfunctions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];    
$today = strftime("%Y-%m-%d", time());    
$dtnow = date("Y-m-d h:i:s", time());    
}else{
header('Location:../index.php');
exit;    
}

function check_desales($invno){
$flage=0;
global $con;
$sql="SELECT * FROM tbl_trarecord WHERE invno!='$invno' AND refinv='$invno'";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}

if($flage>0){
return $flage;
exit;    
}    

$sql="SELECT * FROM tbl_pdlirecord WHERE refinv='$invno'";    
$rquery=mysqli_query($con,$sql)or die(mysqli_error($con));
if($rquery->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}

if($flage>0){
return $flage;
exit;    
}    
    
$sql="SELECT * FROM tbl_waranty WHERE refinv='$invno'";    
$rquery=mysqli_query($con,$sql)or die(mysqli_error($con));
if($rquery->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}

if($flage>0){
return $flage;
exit;    
}    
    
$sql="SELECT * FROM tbl_sreturn WHERE refinv='$invno'";    
$rquery=mysqli_query($con,$sql)or die(mysqli_error($con));
if($rquery->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}

return $flage;    
}


$request=$_REQUEST;
if($uty=='1'){
$sql ="SELECT * FROM tbl_sales";
}else{
$sql ="SELECT * FROM tbl_sales WHERE brid='$brid'";    
}

$query=mysqli_query($con,$sql);

$totalData=mysqli_num_rows($query);

$totalFilter=$totalData;

//Search
$table='tbl_sales';
if($uty=='1'){
$sql_search = "SELECT * FROM ".$table." WHERE ";
}else{
$sql_search = "SELECT * FROM ".$table." WHERE brid='$brid' AND (";    
}
$sql_search_fields = Array();
$sql = "SHOW COLUMNS FROM ".$table;
$rs = mysqli_query($con,$sql);
while($r = mysqli_fetch_array($rs)){
$colum = $r[0];
$sql_search_fields[] = $colum." LIKE('%".$request['search']['value']."%')";
}
$sql_search .= implode(" OR ", $sql_search_fields);
if($uty=='1'){
$tsql = $sql_search;    
}else{
$tsql = $sql_search.')';    
}
$querys=mysqli_query($con,$tsql);
$totalData=mysqli_num_rows($querys);

//Order
//Order
if($uty=='1'){
$sql_search.=" ORDER BY apdate DESC,id DESC"."  LIMIT ".$request['start']."  ,".$request['length']."  ";    
}else{    
$sql_search.=") ORDER BY apdate DESC,id DESC"."  LIMIT ".$request['start']."  ,".$request['length']."  ";
}
$queryi=mysqli_query($con,$sql_search);

$data=array();
$s=0;
while($row=mysqli_fetch_array($queryi)){
    $ac='';
    $s+=1;
    $invno=$row['invno'];
    $subdata=array();
    $subdata[]=$s+$request['start'];//serial
    $subdata[]=date("d M Y", strtotime($row['apdate'])); //date
    if($uty=='1'){
    if($row['brid']==0){
    $subdata[]='Main Branch';    
    }else{
    $subdata[]=get_fild_data('tbl_branch',$row['brid'],'name');    
    }    
    }
    if($row['type']=='SU'){
 $subdata[]=show_addres(get_fild_data('tbl_supplier',$row['cusid'],'name'),get_fild_data('tbl_supplier',$row['cusid'],'cnumber'),get_fild_data('tbl_supplier',$row['cusid'],'cemail'),'',get_fild_data('tbl_supplier',$row['cusid'],'code'),$row['type'].'_'.$row['cusid']);    
    }else{
    if($row['cusid']==0){    
    if($row['name']!=''){$subdata[]=show_addres($row['name'],$row['mobile'],'','','',$row['type'].'_'.$row['cusid']);}else{$subdata[]=show_addres('Walk-in Customer','','','','',$row['type'].'_'.$row['cusid']);}
    }else{
    $subdata[]=show_addres(get_fild_data('tbl_customer',$row['cusid'],'name'),get_fild_data('tbl_customer',$row['cusid'],'cnumber'),get_fild_data('tbl_customer',$row['cusid'],'cemail'),'',get_fild_data('tbl_customer',$row['cusid'],'code'),$row['type'].'_'.$row['cusid']);     
    }}
    $subdata[]=$row['invno'];
    $subdata[]=numtolocal($row['total'],get_fild_data('tbl_currency','1','symbol'));
    $subdata[]=$row['note'];
    $ac.='<a class="btn btn-flat bg-purple details-invoice" style="margin: 3px;" href="#" id="inv_'.$row['id'].'_'.$row['cusid'].'_'.$row['type'].'"><i class="fa fa-eye cat-child"></i></a>';
    if(!check_desales($invno)){
    $ac.='<a class="btn btn-flat bg-purple" style="margin: 3px;" href="#"><i class="fa fa-edit" onclick="take_action(\'ED_'.$row['id'].'\')"></i></a>';    
    }
    $ac.='<a class="btn btn-flat bg-purple" style="margin: 3px;" href="#" onclick="take_action(\'RE_'.$row['id'].'\')"><i class="fa fa-reply"></i></a>';
    if(!check_desales($invno)){
    $ac.='<a class="btn btn-flat bg-purple" style="margin: 3px;" href="#" onclick="remove_item(\'DL_'.$row['id'].'\')"><i class="fa fa-trash"></i></a>';    
    }
    $ac.='<form action="sel_sreturncteate.php" id="RE_'.$row['id'].'" method="post" >';
    $ac.='<input type="hidden" name="selret" value="'.$row['id'].'" />';
    $ac.='</form>';
    if(!check_desales($invno)){
    $ac.='<form action="sel_sinvlist.php" id="DL_'.$row['id'].'" method="post" >';
    $ac.='<input type="hidden" name="delsel" value="'.$row['id'].'" />';
    $ac.='</form>';
    $ac.='<form action="sel_sinvedit.php" id="ED_'.$row['id'].'" method="post" >';
    $ac.='<input type="hidden" name="editsel" value="'.$row['invno'].'" />';
    $ac.='</form>';    
    }
    $subdata[]=$ac;
    $data[]=$subdata;
    $ac='';
}

$json_data=array(
    "draw"              =>  intval($request['draw']),
    "recordsTotal"      =>  intval($totalData),
    "recordsFiltered"   =>  intval($totalFilter),
    "data"              =>  $data
);

echo json_encode($json_data);

?>
