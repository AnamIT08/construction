<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('45','creates','R');      
$_SESSION['cuPages']='rol_usercreate.php';   
$cuPage='rol_usercreate.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];
if(get_limitpermision('tbl_user')>=get_fild_data('tbl_limitset','1','userlim')){
header('Location:rou_userlist.php');   
}    
}else{
header('Location:../index.php');
exit;    
}
$mhead='user';
$menuh='User &amp; Role';
$phead='usercre';
$page='User Create';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include ('../inc/imgpro.php');
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php
if(isset($_POST['save_user'])){
$email = remove_junk(escape($_POST['email']));
$name = remove_junk(escape($_POST['name']));
$bname = remove_junk(escape($_POST['bname']));    
$pass = remove_junk(escape($_POST['pass']));
$cpass = remove_junk(escape($_POST['cpass']));
$spass= sha1($pass);    
$acess = remove_junk(escape($_POST['acess']));
$ibrid = remove_junk(escape($_POST['ibrid']));    
$item = PATHINFO($_FILES["item"]["name"]);     
$status = remove_junk(escape($_POST['status'])); 

if(isset($_POST['email'])){
$ducode = mysqli_query($con,"SELECT * FROM tbl_user WHERE email = '$email'");
}
	
if($ducode->num_rows > 0) {
save_msg('w','Email Address alrady used! Plz try another');
echo "<script>window.location='rou_usercreate.php'</script>";
}else{       
$sql="INSERT INTO tbl_user(email,password,utype,acess,abrid,name,bname,status,brid,uid,date) VALUES ('$email','$spass','3','$acess','$ibrid','$name','$bname','$status','$brid','$aid','$dtnow')";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$eid=$con->insert_id;    
if($result){
if (!empty($_FILES["item"]["name"])){
get_upload($eid,$_FILES['item'],'U');    
}
$act =remove_junk(escape('New User Add: '.$name));    
write_activity($aid,'USR','User has been Added',$act);     
save_msg('s','User Added Successfully!!!');
echo "<script>window.location='rou_usercreate.php'</script>";	
}else{
save_msg('e','User insert fail!!!!');
echo "<script>window.location='rou_usercreate.php'</script>";		
}
}
}    
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Add New User</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="rou_usercreate.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">
<div class="col-md-2"></div>
<div class="col-md-8">
<div class="row">
<div class="col-md-12">
<div class="form-group">
<label>Email</label>
<div class="input-group">
<span class="input-group-addon">E</span>   
<input type="email" class="form-control" maxlength="45" name="email" id="email" placeholder="Email" autocomplete="off">
</div>    
</div>
</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="form-group" >
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Name (English)';}else{echo 'নাম (ইংরেজিতে)';}?></label>
<div class="input-group">
<span class="input-group-addon">N</span>
<input type="text" maxlength="35" class="form-control" name="name" id="name" placeholder="e. g Sumon" autocomplete="off">
</div>
</div>
<div class="form-group" >
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Name (বাংলায়)';}else{echo 'নাম (বাংলায়)';}?></label>
<div class="input-group">
<span class="input-group-addon">N</span>
<input type="text" maxlength="255" class="form-control" name="bname" id="bname" placeholder="e. g সুমন" autocomplete="off">
</div>
</div>    
</div>
</div>    
<div class="row">
<div class="col-md-6">
<div class="form-group">
<label>Password</label>
<div class="row">
<div class="form-group col-sm-12">
<div class="input-group">
<span class="input-group-addon">P</span>    
<input type="password" data-minlength="8" name="pass" class="form-control" id="pass" placeholder="Password" required="">
</div>
</div>
<div class="form-group col-sm-12">
<div class="input-group">
<span class="input-group-addon">CP</span>    
<input type="password" name="cpass" class="form-control" id="cpass" placeholder="Confirm">
</div>
</div>
</div>
</div>
<div class="form-group" >
<label class="control-label mb-10">Access Lavel</label>
<div class="input-group">
<span class="input-group-addon">AL</span>
<select class="form-control select2" name="acess" id="acess">
<option value="">-Select-</option>   
<?php									
$queryd=mysqli_query($con,"SELECT * FROM tbl_usergroup ORDER BY id ASC")or die(mysqli_error($con));
while ($rowd=mysqli_fetch_array($queryd)){
?>
<option value="<?php echo $rowd['id'];?>"><?php echo $rowd['name'];?></option>
<?php } ?>                                                                
</select>
</div>
</div>
<div class="form-group" >
<label>Branch</label>
<div class="input-group">
<span class="input-group-addon">BR</span>
<select class="form-control select2" name="ibrid" id="ibrid">
<option value="">-Select-</option>
<option value="0">No Branch</option>     
<?php									
$queryd=mysqli_query($con,"SELECT * FROM tbl_branch ORDER BY name ASC")or die(mysqli_error($con));
while ($rowd=mysqli_fetch_array($queryd)){
?>
<option value="<?php echo $rowd['id'];?>"><?php echo $rowd['name'];?></option>
<?php } ?>                                                                
</select>    
</div>
</div>    
<div class="form-group" >
<label>Status</label>
<div class="input-group">
<span class="input-group-addon">ST</span>    
<select class="form-control" name="status">
<option value="1">Active</option>
<option value="0">De-Active</option>
</select>    
</div>
</div>    
</div>
<div class="col-md-6">
<div class="form-group">
<label>Image</label>
<div style="width:200px; height:245px;">
<img src="../img/user/duser.jpg" id="profile-img-tag" style="width: 100%; height: 100%; object-fit: contain;">
</div>
<br>    

<input type="file" class="btn btn-flat bg-purple btn-sm" name="item" id="profile-img" accept=".png, .gif, .jpg, .jpeg">

</div>     
</div>    
</div>
</div>    
<div class="col-md-2"></div>
</div>
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="save_user" id="submit" class="btn btn-flat bg-purple btn-sm " value="Save"/> <a href="rou_userlist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'USR','A');}else{echo read_activity($aid,'USR','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function () {  
var email = new LiveValidation('email');
email.add(Validate.Presence);
email.add(Validate.Email);
<?php if(get_fild_data('tbl_setting','1','sval')==0){?>    
var name = new LiveValidation('name');
name.add(Validate.Presence);
<?php }else{ ?>
var bname = new LiveValidation('bname');
bname.add(Validate.Presence);    
<?php } ?> 
var pass = new LiveValidation('pass');
pass.add(Validate.Presence);
pass.add(Validate.Length, {minimum: 8, maximum: 15});
var cpass = new LiveValidation('cpass');
cpass.add(Validate.Confirmation, { match: 'pass' });
var acess = new LiveValidation('acess');
acess.add(Validate.Presence);
var ibrid = new LiveValidation('ibrid');
ibrid.add(Validate.Presence);    
});    
    
function readURL(input) {
if (input.files && input.files[0]) {
var reader = new FileReader();
            
reader.onload = function (e) {
$('#profile-img-tag').attr('src', e.target.result);
}
reader.readAsDataURL(input.files[0]);
}
}
$("#profile-img").change(function(){
readURL(this);
});
$("#profile-img-tag").click(function() {
$("#profile-img").click();
});    
</script>    
<!-- /page script -->
</html>    