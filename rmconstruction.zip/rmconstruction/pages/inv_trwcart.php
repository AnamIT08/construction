<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
$today = strftime("%Y-%m-%d", time());    
$dtnow = date("Y-m-d h:i:s", time());    
}else{
header('Location:../index.php');
exit;    
}

if(isset($_POST['additem'])){
$unqid=$_POST['additem'];
$whid=$_POST['whid'];    
addwhtransfer($whid,$unqid,1);    
}

if(isset($_POST['remove'])){
$ids = floatval($_POST['remove']);
$unqid=$_SESSION['axes_transwh'][$ids]['unqid'];    
remove_transwh($ids);
if(isset($_SESSION['axes_trwse'])){    
remove_trwhslimei($unqid);
}
$max=count($_SESSION['axes_transwh']);
if($max <= 0){
unset($_SESSION['axes_transwh']);
if(isset($_SESSION['axes_trwse'])){
unset($_SESSION['axes_trwse']);	
}	
}
if(isset($_SESSION['axes_trwse'])){
$smax=count($_SESSION['axes_trwse']);
if($smax <= 0){    
unset($_SESSION['axes_trwse']);
}
}    
}

if(isset($_POST['upqty'])){
$ids=intval($_POST['upqty']);
$qty=floatval($_POST['qty']);
if($qty<0 || $qty==''){
$redata=array($_SESSION['axes_transwh'][$ids]['qty']);
echo json_encode($redata);    
exit;
}
$unqid = $_SESSION['axes_transwh'][$ids]['unqid'];
$whid = $_SESSION['axes_transwh'][$ids]['whid'];    
$eqty=get_warestockinfo($whid,$unqid,'avqty');    
if($qty<=$eqty){
$_SESSION['axes_transwh'][$ids]['qty']=$qty;		
}elseif($qty>$eqty){
$_SESSION['axes_transwh'][$ids]['qty']=$eqty;		
}    
$redata=array($_SESSION['axes_transwh'][$ids]['qty']);
echo json_encode($redata);
}

if(isset($_POST['removeitmsl'])){
$id=intval($_POST['removeitmsl']);
$unqid=$_SESSION['axes_trwse'][$id]['unqid'];
$itid=get_transwhitmid($unqid);
$itmqty=$_SESSION['axes_transwh'][$itid]['qty'];

remove_transwhsl($id);    
if($itmqty<=1){
remove_transwh($itid);    
}else{
$_SESSION['axes_transwh'][$itid]['qty']=($itmqty-1);    
}   
$max=count($_SESSION['axes_transwh']);
if($max <= 0){
unset($_SESSION['axes_transwh']);
if(isset($_SESSION['axes_trwse'])){
unset($_SESSION['axes_trwse']);	
}	
}    
}

if(isset($_POST['upimei'])){
$ids=intval($_POST['upimei']);
$serialno=strtoupper(remove_junk(escape($_POST['imeidata'])));
$pid=intval($_SESSION['axes_trwse'][$ids]['pid']);
if($serialno!=''){
if(transwhserial_exists($pid,$serialno)){
$redata=array($_SESSION['axes_trwse'][$ids]['imei']);
echo json_encode($redata);    
return;
exit;    
}
$_SESSION['axes_trwse'][$ids]['imei']= $serialno;    
}else{
$_SESSION['axes_trwse'][$ids]['imei']='';    
}    
$redata=array($_SESSION['axes_trwse'][$ids]['imei']);
echo json_encode($redata); 
}

if(isset($_POST['audimei'])){
$id=$_POST['audimei'];
$iwhid=$_POST['iwhid'];    
$pid=intval($_SESSION['axes_trwse'][$id]['pid']);    
$search = $_POST['search'];
	
$sql="SELECT pid,serial FROM tbl_serial WHERE pid='$pid' AND serial LIKE '%$search%' AND whid='$iwhid' AND rci='Y' AND status='0' ORDER BY serial ASC LIMIT 30";		
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
while($row = mysqli_fetch_array($result) ){
$response[] = array("value"=>$row['pid'],"label"=>$row['serial']);
}

// encoding array to json format
echo json_encode($response);
exit;    
}

if(isset($_POST['clear'])){
if(isset($_SESSION['axes_transwh'])){
unset($_SESSION['axes_transwh']);   
}
if(isset($_SESSION['axes_trwse'])){
unset($_SESSION['axes_trwse']);	
}
}

if(isset($_POST['trbdata'])){
$edata=array(check_trwserial('S'));
echo json_encode($edata);
}

if(isset($_POST['addwhtrns'])){
    
$invno = gen_newinvno('tbl_trafrwho','TRW');
$stype='WH';    
$swhid = remove_junk(escape($_POST['swhid']));
$desid = explode('_',remove_junk(escape($_POST['desid'])));    
$ttype=$desid['0'];    
$toid = $desid['1'];
if($ttype=='BR'){$ibrid="'".$toid."'";$iwhid='NULL';}else{$ibrid='NULL';$iwhid="'".$toid."'";}    
$media = remove_junk(escape($_POST['media']));
if($media==0){$media='NULL';}else{$media="'".$media."'";}     
$note = remove_junk(escape($_POST['note']));    
$apdate = remove_junk(escape($_POST['trwdt']));
    
if(!isset($_SESSION['axes_transwh'])){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! No item found!!'
));
return;
exit;  
}
    
if(check_trwvalidqty($swhid)){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Quantity not available!!'
));
return;
exit;     
}
$sql="INSERT INTO tbl_trafrwho (invno,ftype,fsourch,ttype,tsourch,media,note,apdate,brid,uid,date) VALUES ('$invno','$stype','$swhid','$ttype','$toid',$media,'$note','$apdate','$brid','$aid','$dtnow')";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sid=$con->insert_id;    
$efid=mysqli_affected_rows($con);    

if($efid>0){
$max=count($_SESSION['axes_transwh']);
for($i=0;$i<$max;$i++){
$pid = $_SESSION['axes_transwh'][$i]['pid'];
$unqid= $_SESSION['axes_transwh'][$i]['unqid'];   
$col=$_SESSION['axes_transwh'][$i]['col'];
$siz=$_SESSION['axes_transwh'][$i]['siz'];
$cost=$_SESSION['axes_transwh'][$i]['cost'];
$puqty=0;    
$qtyin=$_SESSION['axes_transwh'][$i]['qty'];
$soqty=0;    
$qtyout=$_SESSION['axes_transwh'][$i]['qty'];
$taxp=0;
$taxamo=0;
$idisp=0;
$idisf=0;
$disamo=0;
$sdisp=0;
$sdisf=0;
$price=$_SESSION['axes_transwh'][$i]['price'];
$isubtot=0;
$wday=$_SESSION['axes_transwh'][$i]['wday'];
$pnote='';    
    
$sql="INSERT INTO tbl_traproduct (type,tid,invno,refinv,pid,unqid,colid,sizid,cost,price,p_qty,p_in,s_qty,p_out,taxp,taxamo,disp,disf,disamo,subtot,wday,mods,brid,waid,tramod,isinv,pnote,uid,apdate,date) VALUES (NULL,NULL,'$invno',NULL,'$pid','$unqid','$col','$siz','$cost','$price','$puqty','0','$soqty','$qtyout','$taxp','$taxamo','$idisp','$idisf','$disamo','$isubtot','$wday','TR',NULL,'$swhid',NULL,'Y',NULL,'$aid','$apdate','$dtnow'),(NULL,NULL,'$invno',NULL,'$pid','$unqid','$col','$siz','$cost','$price','$puqty','$qtyin','$soqty','0','$taxp','$taxamo','$idisp','$idisf','$disamo','$isubtot','$wday','TR',$ibrid,$iwhid,NULL,'Y',NULL,'$aid','$apdate','$dtnow')";
    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));    
}

if(isset($_SESSION['axes_trwse'])){
$max=count($_SESSION['axes_trwse']);
for($i=0;$i<$max;$i++){
$pid=$_SESSION['axes_trwse'][$i]['pid'];
$unqid=$_SESSION['axes_trwse'][$i]['unqid'];    
$serial=$_SESSION['axes_trwse'][$i]['imei'];    
$sql="INSERT INTO tbl_serialsale (invno,pid,unqid,serial,mods) VALUES ('$invno','$pid','$unqid','$serial','T')";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sql="UPDATE tbl_serial SET brid=$ibrid,whid=$iwhid WHERE serial='$serial'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));    
}    
}

unset($_SESSION['axes_transwh']);
if(isset($_SESSION['axes_trwse'])){
unset($_SESSION['axes_trwse']);
}    
        
$act =remove_junk(escape('Transfer No: '.$invno));    
write_activity($aid,'TRW','New Transfer has been Created',$act);
echo json_encode(array(
'status' => 'success',
'message'=> 'Transfer Save Successfully!!'   
));
exit;    
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));    
}        
}
?>

<?php 
if(isset($_POST['savetra'])){
$iwhid=$_POST['whid'];    
?>
<div class="col-md-12 popup_details_div addtransfer">
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<div class="form-group" >
<label>Transfer Date</label>
<input type="text" class="form-control datetimepicker" name="trwdt" id="trwdt" value="<?php echo $today;?>" placeholder="Transfer Date" autocomplete="off" readonly>
</div>    
<div class="form-group">
<label>Transfer To</label>    
<select class="form-control select2" name="desid" id="desid">
<option value="">-Select-</option>
<optgroup label="Branch">   
<option value="BR_0">No Branch</option>       
<?php
$sql="SELECT id,name FROM tbl_branch ORDER BY name ASC";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {    
while ($rows=mysqli_fetch_array($query)){
?>
<option value="<?php echo 'BR_'.$rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>   
<?php } ?>
</optgroup>
<optgroup label="Warehouse">     
<?php
$sql="SELECT id,name FROM tbl_warehouse WHERE id!='$iwhid' ORDER BY name ASC";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {    
while ($rows=mysqli_fetch_array($query)){
?>
<option value="<?php echo 'WH_'.$rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>   
<?php } ?>
</optgroup>    
</select>
<input type="hidden" name="addwhtrns" readonly />
<input type="hidden" name="swhid" value="<?php echo $iwhid; ?>" readonly />    
</div>

<div class="form-group">
<label>Transfer Type</label>
<select class="form-control select2" name="media" id="media">    
<option value="0">Direct</option>
<?php
$sql="SELECT id,name FROM tbl_shipline ORDER BY name ASC";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
?>
<optgroup label="Media">    
<?php    
while ($rows=mysqli_fetch_array($query)){
?>    
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>    
<?php } ?>
</optgroup>    
<?php } ?>    
</select>    
</div>    
    
<div class="form-group">
<label>Note</label>
<textarea class="form-control" maxlength="150" rows="3" name="note" placeholder="Note"></textarea>
</div>    
</div>    
<div class="col-md-1"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="fintrw" class="btn btn-flat bg-purple btn-sm " value="Save Transfer"/>
</div> 
</div>

<script type="text/javascript">
function chek_error(){
var trbdt = $('#trwdt').val();     
var desid = $('#desid').val();      
var result = true;    

$('.LV_invalid_field').removeClass('LV_invalid_field');     
$('.LV_validation_message').remove();    

if(trwdt.length<=0){
$('#trwdt').addClass('LV_invalid_field');   
$('#trwdt').after("<span class='LV_validation_message LV_invalid'>Enter Transfer Date!</span>").addClass('has-error');
result=false;    
}else{
$('#trwdt').removeClass('LV_invalid_field');
result=true;    
}    

if(desid == '-Select-' || desid == ''){
$('#desid').addClass('LV_invalid_field');   
$('#desid').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error');
result=false;    
}else{
$('#desid').removeClass('LV_invalid_field');     
}    
    
if(desid == '' || !result){
return false;    
}else{
return true;     
}    
   
}
        
$(document).on('blur', '#trwdt, #desid', function() {
chek_error();    
});

$('.datetimepicker').datepicker({format: "yyyy-mm-dd", autoclose: true, clearBtn: true, orientation: 'auto bottom'});    
</script>    
<?php } ?>