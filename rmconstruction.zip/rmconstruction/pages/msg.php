<?php session_start();
if(isset($_POST['shows'])){}
if(isset($_SESSION['gmsg'])){
	$_SESSION['gmsg'][0]['show']=1;
}
?>