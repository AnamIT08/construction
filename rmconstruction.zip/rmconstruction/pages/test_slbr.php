<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='blank_page.php';   
$cuPage='blank_page.php';    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='product';
$menuh='Product';
$phead='prcre';
$page='Parent Create';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
<div class="nav-tabs-custom">    
<ul class="nav nav-tabs">
  <li class="active"><a href="#1" data-toggle="tab" class="text-uppercase">Home</a></li>
  <li><a href="#2" data-toggle="tab" class="text-uppercase">Menu 1</a></li>
  <li><a href="#3" data-toggle="tab" class="text-uppercase">Menu 2</a></li>
  <li><a href="#4" data-toggle="tab" class="text-uppercase">Menu 3</a></li>
</ul>
<div class="tab-content">
<div class="active tab-pane" id="1"> </div>
<div class="tab-pane" id="2"> </div>
<div class="tab-pane" id="3"> </div>
<div class="tab-pane" id="4"> </div>    
</div>     
</div>    
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
    
    
});
    
</script>    
<!-- /page script -->
</html>    