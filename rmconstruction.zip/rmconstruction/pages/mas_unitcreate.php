<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('17','creates','R');    
$_SESSION['cuPages']='mas_unitcreate.php';   
$cuPage='mas_unitcreate.php';    
$aid=$_SESSION['uid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='master';
$menuh='Master Process';
$phead='unicre';
$page='Add Unit';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['save_unit'])){
	$name = remove_junk(escape($_POST['name']));
    $description = remove_junk(escape($_POST['description']));
	
	if(isset($_POST['name'])){
	$ducode = mysqli_query($con,"SELECT * FROM tbl_unit WHERE name = '$name'");
	}
	
	if($ducode->num_rows > 0) {
		save_msg('i','Unit name alrady used! Plz try another');
		echo "<script>window.location='mas_unitcreate.php'</script>";
	}else{
    $sql="INSERT INTO tbl_unit(name,description,uid,date) VALUES ('$name','$description','$aid','$dtnow')";    
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $efid=mysqli_affected_rows($con);    
    if($efid>0){
    $act =remove_junk(escape('Unit name: '.$name));    
    write_activity($aid,'UNI','New unit has been Added',$act);    
    save_msg('s','Data Successfully Saved!');
    echo "<script>window.location='mas_unitcreate.php'</script>";
    }else{
    save_msg('w','Data Fail to Saved!');
    echo "<script>window.location='mas_unitcreate.php'</script>";    
    }
	}  
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Add New Unit</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="mas_unitcreate.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">

<div class="row ">
<div class="col-md-12">
<div class="col-md-3"></div>
<div class="col-md-6">
<div class="form-group">
<label>Unit Name</label>
<input type="text" name="name" maxlength="35" value="" id="pname" class="form-control" placeholder="Unit Name"  />
</div>
<div class="form-group">
<label>Description</label>
<textarea class="form-control" maxlength="250" rows="6" name="description" placeholder="Description"></textarea>
</div>   
</div>    
<div class="col-md-3"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="save_unit" id="submit" class="btn btn-flat bg-purple btn-sm " value="Save"/> <a href="mas_unitlist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'UNI','A');}else{echo read_activity($aid,'UNI','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function () {  
var pname = new LiveValidation('pname');
pname.add(Validate.Presence);
});
</script>    
<!-- /page script -->
</html>    