<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
$body='';
$foot='';
$s=0;
$totamo=0;
if(isset($_SESSION['axes_traitem'])){
if(is_array($_SESSION['axes_traitem'])){
$max=count($_SESSION['axes_traitem']);
for($i=($max-1);$i>=0;$i=$i-1){
     
$dty = $_SESSION['axes_traitem'][$i]['dty'];
$did=$_SESSION['axes_traitem'][$i]['did'];
$dname = get_namebytype($dty,'N',$did);    
$amo=$_SESSION['axes_traitem'][$i]['amo'];
$cid=$_SESSION['axes_traitem'][$i]['cid'];
$cty=$_SESSION['axes_traitem'][$i]['cty'];
$cname = get_namebytype($cty,'N',$cid);    
$chkno=$_SESSION['axes_traitem'][$i]['chkno'];
$chkdt=$_SESSION['axes_traitem'][$i]['chkdt'];
$ref=$_SESSION['axes_traitem'][$i]['ref'];
    
$s+=1;
$body.='<tr>';
$body.='<td style="text-align:center">'.$s.'</td>';
$body.='<td>'.$cname.'</td>';
$body.='<td>'.$dname.'</td>';    
$body.='<th class="text-right">'.number_format($amo,2).'</th>';
$body.='<td>'.$chkno.'</td>'; 
$body.='<td>'.$chkdt.'</td>';     
$body.='<td>'.$ref.'</td>';
$body.='<td style="text-align:center"><a id="'.$i.'" class="remove"><span style="cursor: pointer;color:red;" class="fa fa-times"></span></a></td>';    
$body.='</tr>';     
}
$foot.='<tr>';
$foot.='<th colspan="3" class="text-right">TOTAL</th>';
$foot.='<th class="text-right">'.number_format(total_travalue(),2).'</th>';    
$foot.='<th colspan="6"></th>';    
$foot.='</tr>';    
}else{
$body.='<tr>';
$body.='<td colspan="8" class="text-center">There are no items in your transaction list!</td>';
$body.='</tr>'; 
} 
}else{
$body.='<tr>';
$body.='<td colspan="8" class="text-center">There are no items in your transaction list!</td>';
$body.='</tr>';
}
            
if(isset($_POST['body'])){
echo $body;
}elseif(isset($_POST['foot'])){
echo $foot;	
}
exit;    
?>    