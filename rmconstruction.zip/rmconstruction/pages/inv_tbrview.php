<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
$body='';
$foot='';
$buton='';
$s=0;
$totqty=0;

if(isset($_SESSION['axes_transbr'])){
if(is_array($_SESSION['axes_transbr'])){
$max=count($_SESSION['axes_transbr']);
for($i=($max-1);$i>=0;$i=$i-1){
$unqid=$_SESSION['axes_transbr'][$i]['unqid'];
$pid=$_SESSION['axes_transbr'][$i]['pid'];    
$code=$_SESSION['axes_transbr'][$i]['code'];
$name=$_SESSION['axes_transbr'][$i]['name'];
$unit=$_SESSION['axes_transbr'][$i]['unid'];
$col=$_SESSION['axes_transbr'][$i]['col'];
if($col==0){$col='';}    
$siz=$_SESSION['axes_transbr'][$i]['siz'];
if($siz==0){$siz='';}      
$qty=$_SESSION['axes_transbr'][$i]['qty'];

if($col=='' && $siz==''){
$name=$name;    
}elseif($col!='' && $siz==''){
$name= $name.' '.get_fild_data('tbl_color',$col,'name');    
}elseif($col=='' && $siz!=''){
$name= $name.' '.get_fild_data('tbl_size',$siz,'sval');    
}elseif($col!='' && $siz!=''){    
$name= $name.' '.get_fild_data('tbl_color',$col,'name').' '.get_fild_data('tbl_size',$siz,'sval');    
}    
$s+=1;
$totqty+=$qty;    

$body.='<tr>';
$body.='<td class="text-center" width="30px">'.$s.'</td>';    
$body.='<td width="326px">'.$name.'</td>';
$body.='<td width="144px"><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control quantity" id="qty_'.$i.'" value="'.$qty.'"  size="2" style="height: 24px;"/></td>';
$body.='<td class="text-center" width="25px"><a id="'.$i.'" class="remove"><span style="cursor: pointer;" class="fa fa-times"></span></a></td>';    
$body.='</tr>';    
}    

$foot.='<tr>';
$foot.='<td width="30px"></td>';
$foot.='<td width="326px"></td>';
$foot.='<td width="144px"></td>';
$foot.='<td width="25px"></td>';
$foot.='</tr>';    
$foot.='<tr>';
$foot.='<td colspan="2" class="text-center" width="356px"><strong>-Total-</strong></td>';
$foot.='<td width="169px" colspan="2"><strong>'.$totqty.'</strong></td>';
$foot.='</tr>';	
   
}else{
$body.='<tr>';
$body.='<td colspan="4" class="text-center">There are no Transfer Item!</td>';
$body.='</tr>'; 
} 
}else{
$body.='<tr>';
$body.='<td colspan="4" class="text-center">There are no Transfer Item!</td>';
$body.='</tr>';
}

if(isset($_SESSION['axes_transbr'])){
$buton.='<div class="col-md-6">';
$buton.='<input type="button" id="emptycart" class="btn btn-flat bg-red btn-sm" value="Empty"/></div>';
$buton.='<div class="col-md-6 text-right">';   
$buton.='<input type="button" id="save_transfer" class="btn btn-flat bg-purple btn-sm" value="Transfer"/>'; 
$buton.='</div>';
}

if(isset($_POST['body'])){
echo $body;
}elseif(isset($_POST['foot'])){
echo $foot;
}elseif(isset($_POST['buton'])){
echo $buton;    
}
exit; 