<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('4','creates','R');     
$_SESSION['cuPages']='dai_expadd.php';   
$cuPage='dai_expadd.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='daily';
$menuh='Daily Process';
$phead='expadd';
$page='Add Expenses Head';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['save_exphead'])){
	$name = ucwords(remove_junk(escape($_POST['name'])));
    //$bname = $_POST['bname'];
    $etype = remove_junk(escape($_POST['etype']));
    $description = remove_junk(escape($_POST['description']));
	if($etype==0){
    $grid=9;
    $sgrid=21;    
    }else{
    $grid=8;
    $sgrid=20;    
    }
    $code = get_ledgercode($grid);
	if(isset($_POST['name'])){
	//$ducode = mysqli_query($con,"SELECT * FROM tbl_acledger WHERE (name IS NOT NULL AND name = '$name') OR (bname IS NOT NULL AND bname='$bname')");
    $ducode = mysqli_query($con,"SELECT * FROM tbl_acledger WHERE name = '$name'");    
	}
	
	if($ducode->num_rows > 0) {
	save_msg('i','This expenses head already exists! Plz try another');
	echo "<script>window.location='dai_expadd.php'</script>";
	}else{   
    //$sql="INSERT INTO tbl_acledger(code,grid,sgrid,name,bname,description,uid,date) VALUES ('$code','$grid','$sgrid','$name','$bname','$description','$aid','$dtnow')";
    $sql="INSERT INTO tbl_acledger(code,grid,sgrid,name,description,uid,date) VALUES ('$code','$grid','$sgrid','$name','$description','$aid','$dtnow')";    
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $efid=mysqli_affected_rows($con);    
    if($efid>0){   
    $act =remove_junk(escape('Expenses Head name: '.$name));
    $bact =remove_junk('খরচ খাতের নামঃ '.$name);    
    write_activity($aid,'EXP','New Expenses Head has been created',$act,'নতুন খরচ খাত যোগ করেছেন',$bact);   
    save_msg('s','Data Successfully Saved!');
    }else{
    save_msg('w','Data Fail to Saved!');    
    }
    echo "<script>window.location='dai_expadd.php'</script>";  
	}  
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Add Expenses Head';}else{echo 'খরচের খাত যোগ করুন';}?></h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="dai_expadd.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">

<div class="row">
<div class="col-md-12">
<div class="col-md-3"></div>
<div class="col-md-6">
<div class="form-group">
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Name';}else{echo 'নাম (ইংলিশ)';}?></label>
<input type="text" name="name" maxlength="35" value="" id="name" class="form-control" placeholder="e.g. Electric Bill"  />
</div>
<!--<div class="form-group">
<label><?php //if(get_fild_data('tbl_setting','1','sval')==0){echo 'Name (Bangla)';}else{echo 'নাম (বাংলায়)';}?></label>
<input type="text" name="bname" maxlength="255" value="" id="bname" class="form-control" placeholder="e.g. বিদ্যুৎ বিল" />
</div>-->    
<div class="form-group">
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Expeses Type';}else{echo 'খরচের ধরন';}?></label>
<select class="form-control" name="etype" id="etype">
<option value="">-<?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Select';}else{echo 'নির্বাচন করুন';}?>-</option>
<option value="0"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Administrative Expenses';}else{echo 'প্রশাসনিক খরচ';}?></option>
<option value="1"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Operating Expenses';}else{echo 'পরিচালনা খরচ';}?></option>    
</select>    
</div>    
<div class="form-group">
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Description';}else{echo 'বর্ণনা';}?></label>
<textarea class="form-control" maxlength="250" rows="6" name="description" placeholder="<?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Description';}else{echo 'বর্ণনা';}?>"></textarea>
</div>   
</div>    
<div class="col-md-3"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="save_exphead" id="submit" class="btn btn-flat bg-purple btn-sm " value="<?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Save';}else{echo 'সংরক্ষণ';}?>"/> <a href="dai_explist.php" class="btn btn-flat bg-gray  "><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Close';}else{echo 'বন্দ';}?></a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'History';}else{echo 'ইতিহাস';}?> </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'EXP','A');}else{echo read_activity($aid,'EXP','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function () {  
<?php if(get_fild_data('tbl_setting','1','sval')==0){?>    
var name = new LiveValidation('name');
name.add(Validate.Presence);    
<?php }else{ ?>
var bname = new LiveValidation('bname');
bname.add(Validate.Presence);    
<?php } ?>
var etype = new LiveValidation('etype');
etype.add(Validate.Presence);    
});
</script>    
<!-- /page script -->
</html>    