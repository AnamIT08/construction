<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='rep_accovrview.php';   
$cuPage='rep_accovrview.php';    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='report';
$menuh='Report';
$phead='report';
$page='Accounts Overview';
$ractive='H';
$print='print';
$today = strftime("%Y-%m-%d", time());
$dtnow = date("Y-m-d h:i:s", time());
$oavno='REP'.date("dmy", strtotime($today)).'AOVW';
?>
<?php
$sql="SELECT CAST(apdate AS DATE) AS date,brid FROM (SELECT apdate,brid FROM tbl_traledger) cfs ORDER BY apdate DESC LIMIT 1";

$bgdate=mysqli_query($con,$sql)or die(mysqli_error($con));
$rowbd=mysqli_fetch_array($bgdate);

if(isset($_POST['ibrid'])){
$ibrid=$_POST['ibrid'];       
}else{
$ibrid=$brid;    
}

if(isset($_POST['tfdate'])){
if ($_POST['tfdate']<=$today){
$stdate=date('Y-m-d', strtotime('-0 days',strtotime($today)));	
$endate=date('Y-m-d', strtotime('-0 days',strtotime($today)));
}else{
$stdate=$today;	
$endate=date('Y-m-d', strtotime('-0 days',strtotime($_POST['tfdate'])));
}	
$fdate=$_POST['tfdate'];	
}else{
$fdate=date('Y-m-d', strtotime('-29 days', time()));	
$stdate=$today;
$endate=date('Y-m-d', strtotime('+29 days',strtotime($stdate)));
}
if(isset($_POST['ttdate'])){
$tdate=$_POST['ttdate'];	
}else{
$tdate=$today;	
}
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-12">
<div class="col-md-3">    
<div class="box box-solid">

<div class="box-body">
<div class="col-md-12">    
<div class="row">    
<div class="roles-menu">   
<ul class="nav">
<li <?php if($ractive=='A'){echo 'class="active"';}?>><a href="rep_accledgerst.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Ledger Statement';}else{echo ' খতিয়ান  বিবরণ ';}?></a></li>
<li <?php if($ractive=='C'){echo 'class="active"';}?>><a href="rep_acccashst.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Cash Statement';}else{echo ' নগদ  বিবরণ';}?></a></li>
<li <?php if($ractive=='D'){echo 'class="active"';}?>><a href="rep_accbankst.php"> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Bank Statement';}else{echo ' ব্যাংকের বিবরণ ';}?></a></li>
<li <?php if($ractive=='I'){echo 'class="active"';}?>><a href="rep_accmobist.php"> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Mobile Statement';}else{echo ' ব্যাংকের বিবরণ ';}?></a></li>    
<li <?php if($ractive=='B'){echo 'class="active"';}?>><a href="rep_accjourhis.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Journal History';}else{echo ' জার্নালের  বিবরণ ';}?></a></li>
<li <?php if($ractive=='G'){echo 'class="active"';}?>><a href="rep_accprolos.php"> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Profit &amp; Loss';}else{echo ' লাভ ও ক্ষতি  বিবরণ ';}?></a></li>    
<li <?php if($ractive=='E'){echo 'class="active"';}?>><a href="rep_acctrialbal.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Trial Balance';}else{echo ' ট্রায়াল ব্যালেন্স';}?></a></li>
<li <?php if($ractive=='F'){echo 'class="active"';}?>><a href="rep_accbalshet.php"> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Balance Sheet';}else{echo ' ব্যালেন্স শীট';}?></a></li> 
<li <?php if($ractive=='H'){echo 'class="active"';}?>><a href="rep_accovrview.php"> <?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Overview';}else{echo ' সামগ্রিক অবস্থা (ওভারভিউ) ';}?></a></li>    
</ul>
</div>
</div>
<hr>    
<form action="rep_accovrview.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<!--From Data--> 
<div class="col-md-12">    
<div class="row">
<?php if($uty=='1'){?>   
<div class="form-group" >
<label>Branch</label>
<div class="input-group">
<span class="input-group-addon">BR</span>
<select class="form-control select2" name="ibrid" id="ibrid">
<option value="A">-All Branch-</option>
<option value="0">-Corporate Branch-</option>    
<?php									
$querymt=mysqli_query($con,"SELECT DISTINCT id,name FROM tbl_branch ORDER BY name ASC")or die(mysqli_error($con));
while ($rowmt=mysqli_fetch_array($querymt)){
?>
<?php if($rowmt['id']==$ibrid){?>
<option selected value="<?php echo $rowmt['id'];?>"><?php echo $rowmt['name'];?></option>
<?php }else{ ?>    
<option value="<?php echo $rowmt['id'];?>"><?php echo $rowmt['name'];?></option>
<?php } ?>    
<?php } ?>
</select>
</div>
</div>    
<?php } ?>    
</div>
</div>
<div class="row"> 
<div class="col-md-6">    
<div class="form-group" >
<label>From</label>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><span class="fa fa-calendar"></span></span>
<input type="text" maxlength="18" class="form-control" name="tfdate" value="<?php if(isset($_POST['tfdate'])){echo $_POST['tfdate']; }else{echo date('Y-m-d', strtotime('-0 days', time()));} ?>" required autocomplete="off" required>
</div>
</div>
</div>
<div class="col-md-6">    
<div class="form-group" >
<label>To</label>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><span class="fa fa-calendar"></span></span>
<input type="text" maxlength="18" class="form-control" name="ttdate" value="<?php if(isset($_POST['ttdate'])){echo $_POST['ttdate']; }else{echo $today;} ?>" required autocomplete="off" required>
</div>
</div>
</div>    
</div>   
<!--End From Data-->    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-4"></div>
<div class="col-md-8 text-right" >
<input type="submit" name="filter_submit" id="submit" class="btn btn-flat bg-purple btn-sm " value="Submit"/> <a href="axe_report.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>  
</div>
<div class="col-md-9">
<div class="row">    
<div class="side-head"> 
<div class="col-md-12">    
<div class="col-md-4 text-left">
<button class="btn btn-flat bg-teal" id="print"><i class="fa fa-print"></i></button> 
<button class="btn btn-flat bg-blue"><i class="fa fa-envelope-o"></i></button> 
<button class="btn btn-flat bg-gray"><i class="fa fa-file-pdf-o"></i></button>     
</div>
<div class="col-md-7 text-center">
<select name="Page_resolution" id="resolution" onchange="setPrinterConfig()" style="width: 205px;height: 28px;border: 1px solid red;">
<option value="A4" selected="selected">A4 [210mm × 297mm]</option>   
<option value="A5">A5 [148mm × 210mm]</option>
<option value="Letter">US Letter [216mm × 279mm]</option>
<option value="Legal">US Legal [216mm × 356mm]</option>
</select>
<select name="Page_size" id="rotate" onchange="setPrinterConfig()" style="width: 120px;height: 28px;border: 1px solid red;">
<option value="portrait">Portrait</option>
<option value="landscape">Landscape</option>
</select>    
</div>    
<div class="col-md-1 text-right">

</div>
</div>
</div>    
</div>
<div class="row">
<div class="invhold scrol-y" id="invhold">
<div class="printableArea">
    
</div>    
    
</div>
</div>
</div>
    
</div>    
</div>

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
   
</script>    
<!-- /page script -->
</html>    