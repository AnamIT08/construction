<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
?>
<table class="table table-bordered table-striped">
<?php
if(isset($_SESSION['axes_returnse'])){
if(is_array($_SESSION['axes_returnse'])){
$s=0;
$max=count($_SESSION['axes_returnse']);?>
<tr>
<th style="width:35px; max-width:35px;" class="text-center">#</th>
<th style="width:475px; max-width:475px;">Name</th>
<th>IMEI/Serial</th>
<th width="25px" align="center"></th>
</tr>
<?php
for($i=($max-1);$i>=0;$i=$i-1){
$unqid=$_SESSION['axes_returnse'][$i]['unqid'];    
$name=$_SESSION['axes_returnse'][$i]['name'];
$serial=$_SESSION['axes_returnse'][$i]['serial'];
$check=$_SESSION['axes_returnse'][$i]['check'];    
$s=$s+1;    
?>
<tr>
<td align="center"><?php echo $s; ?></td>
<td><?php echo $name; ?></td>
<td><?php echo $serial; ?></td>
<?php if($check==1){ ?>
<td class="text-center" width="35px"><input type="checkbox" class="bscan" id="bscan_<?php echo $i; ?>" value="<?php echo $unqid;?>" name="radio-group" checked /></td>    
<?php }else{ ?>
<td class="text-center" width="35px"><input type="checkbox" class="bscan" id="bscan_<?php echo $i; ?>" value="<?php echo $unqid;?>" name="radio-group" /></td>   
<?php } ?>    
</tr>
<?php } ?>	
<?php }else{ ?>
<tr>
<td colspan="4" align="center">No IMEI or Product Serial!</td>
</tr> 
<?php } ?> 
<?php }else{ ?>
<tr><td colspan="4" align="center">No IMEI or Product Serial!</td>
</tr>
<?php } ?>
</table>
