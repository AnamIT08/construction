<style>
.kchatslide{
  position: fixed;
  bottom:37px;
  z-index: 98888;    
  background: #00305d;
  width: 300px; 
  right: -300px;
  height: 400px;
  transition: right 0.4s ease-in-out;
  -o-transition: right 0.4s ease-in-out;
  -ms-transition: right 0.4s ease-in-out;
  -moz-transition: right 0.4s ease-in-out;
  -webkit-transition: right 0.4s ease-in-out;
}
.kchattoggle{
  position: absolute;
  bottom: 14px;
  width: 60px;
  height: 32px;
  right: 287px;
  padding: 6px;
  background: #f39c12;
  border-color: #e08e0b;
  font-size: 15px;
  text-align: center;
  vertical-align: middle;    
  color: #fff;
  cursor: pointer;    
}
.kchatbox {
  padding: 10px;
  background: #00305d;
  border-color: #00305d;    
}
.kchatslide-open{
  right: 0px;
}
.chat_con{
height: 348px;
background: #222d32;
color: #fff;    
overflow: hidden;
overflow-y: auto;       
}
    
.subpanel_title {
    padding-top: 4px;
    line-height: 21px;
    padding-left: 10px;
    padding-right: 10px;
}
.subpanel_title {
    background: #1d4a88;
    color: #FFFFFF;
}
.subpanel_title {
    background: #00b0ff;
    color: #fff;
}
.subpanel_title {
    cursor: pointer;
    font-weight: bold;
    padding: 3px 4px 3px 8px;
    font-size: 17px;
    display: block;
    height: 30px;
    overflow: hidden;
}
.subpanel_title span.options {
    width: 12px;
    height: 12px;
    display: none;
}
.subpanel_title span {
    filter: alpha(opacity=100);
    opacity: 1;
    -moz-opacity: 1;
    font-size: 17px;
    font-weight: bold;
    float: right;
    line-height: 1.7em;
    padding: 2px 0 1px 1px;
}
.subpanel_title .minusicon:hover {
    color: #060;
}
.subpanel_title span.min {
    padding: 0;
}
    
.chat_options {
    background: #f9f9f9;
    border-bottom: 1px solid #eee;
}
.chat_options {
    height: 37px;
}
.chat_options {
    overflow: hidden;
    position: relative;
}
.chat_options .drupalchat-self-profile {
    display: inline-block;
    height: 37px;
    width: 78%;
}
.chat_options .drupalchat-self-profile .drupalchat-self-profile-div {
    display: inline-block;
    width: 32px;
}
.chat_options .drupalchat-self-profile .drupalchat-self-profile-div .drupalchat-self-profile-img img {
    margin: 3px 0 4px 10px;
    float: left;
    height: 28px;
    width: 28px;
    -webkit-border-radius: 28px;
    -moz-border-radius: 28px;
    border-radius: 28px;
}
.localhost-avatar-sprite-28.R_3 {
    background-position: -56px -476px;
    width: 28px;
    height: 28px;
}
.chat_options .drupalchat-self-profile .drupalchat-self-profile-namdiv {
    display: inline-block;
    width: 70%;
    padding: 0;
    margin: 0;
    height: 100%;
    padding-left: 3px;
}
.chat_options .drupalchat-self-profile .drupalchat-self-profile-namdiv .drupalchat-profile-un {
    display: inline;
    border: 0;
    padding: 0;
    margin-left: 7px;
    margin-top: 11px;
    position: absolute;
    float: left;
    width: 118px;
    font-size: 13px;
    overflow: hidden;
    cursor: pointer;
    font-weight: bold;
}
.chat_options a {
    border-left: 1px solid #999;
    color: #333;
}
.chat_options a {
    float: right;
    padding: 3px 8px 3px 3px;
    width: 18px;
    height: 18px;
}
.chat_options .drupalchat-usermenu {
    height: 37px;
    display: inline-block;
    cursor: pointer;
    width: 22%;
}
.chat_options .drupalchat-usermenu .drupalchat-usermenu-img {
    color: #333;
}
.chat_options .drupalchat-usermenu .drupalchat-usermenu-img {
    padding-top: 8px;
    padding-left: 0;
    float: left;
    font-size: 22px;
}
.chat_options .drupalchat-usermenu a {
    display: block;
    position: absolute;
    height: 37px;
    width: 10%;
    border: 0;
    padding: 0;
    margin-left: 26px;
}
.chat_options span.status-1 {
    background: url(../img/online.png) no-repeat left;
}
.chat_options a {
    border-left: 1px solid #999;
    color: #333;
}
.chat_options a {
    float: right;
    padding: 3px 8px 3px 3px;
    width: 18px;
    height: 18px;
}
    
.chat_options .drupalchat-self-profile .drupalchat-self-profile-div .drupalchat-self-profile-img img {
    margin: 3px 0 4px 10px;
    float: left;
    height: 28px;
    width: 28px;
    -webkit-border-radius: 28px;
    -moz-border-radius: 28px;
    border-radius: 28px;
}

.statuso {
    display: inline;
    width: 0px;
    height: 21px;
    float: right;
    padding-top: 10px;
}
.statuso.Online {
    color: green;
}
.statuso.Offline {
    color: gray;
}    
    
.drupalchat_search {
    background: #f9f9f9;
    border-bottom: 1px solid #eee;
}
.drupalchat_search {
    overflow: hidden;
    position: relative;
}
.drupalchat_search .drupalchat_searchinput {
    background: #f9f9f9;
}
.drupalchat_search .drupalchat_searchinput {
    height: 30px;
    outline: 0;
    vertical-align: middle;
    margin-left: 7px;
    border: 0;
    font-size: 12px;
}
.drupalchat_search .searchbutton {
    background: url(../chat/chatcss/img/searchb.png) no-repeat center;
    width: 14px;
    height: 14px;
    float: right;
    filter: none;
}
.contact-list {
    width: 348px;
    height: 303px;
    overflow-y: scroll;
    background-color: #eceff1;
}

.chatboxcontent{
    width: 100%;padding: 0;
}    

.chatboxcontent{
    overflow-y: auto;
    overflow-x: hidden;
    height: 303px;
}    
    
.chat_box. img {
    float: left;
    height: 28px;
    width: 28px;
    -webkit-border-radius: 28px;
    -moz-border-radius: 28px;
    border-radius: 28px;
}    
</style>    
<div class="kchatslide" id="kchatslide">
<div class="kchattoggle rotate" id="kchat">Chat</div>
<?php
$ses_username = $_SESSION['uid'];
$picname = $_SESSION['uimage'];
$ses_picname = ($picname == "")? "duser.jpg" : $picname;
?>
<!--Contact List end-->
<div class="chat_box">    
<div class="subpanel_title">Chat<span class="options"></span>
<div class="material-switch pull-right" style="margin-left: 10px;">
<input id="chaton" type="checkbox" <?php if(isset($_SESSION['chatmod']) && $_SESSION['chatmod']=='on'){echo 'checked=""';}else{echo '';}?>>
<label for="chaton" class="label-success"></label>
</div>    
<span class="min localhost-icon-minus-1" id="minmaxchatlist"><i class="fa fa-minus-circle minusicon text-20" aria-hidden="true"></i></span>
<span>&nbsp;&nbsp;</span>
<span class="min localhost-icon-minus-1" id="mute-sound"><i class="icon icon-volume-2"></i></span>
</div>
    
<div class="chat_options" style="background-color: #eceff1;" >
<div class="drupalchat-self-profile">
<div class="drupalchat-self-profile-div">
<div class="drupalchat-self-profile-img + localhost-avatar-sprite-28 <?php echo strtoupper($ses_username[0]); ?>_3">
<img src="../img/user/<?php echo $ses_picname; ?>"/>
</div>
</div>
<div class="drupalchat-self-profile-namdiv">
<a class="drupalchat-profile-un drupalchat_cng"><?php echo get_fild_data('tbl_user',$_SESSION['uid'],'name'); ?></a>
</div>

</div>

</div>
<div class="drupalchat_search_main chatboxinput" style="background:#f9f9f9">
<div class="drupalchat_search" style="height:30px;">
<input class="drupalchat_searchinput live-search-box" placeholder="Type here to search" value="" size="24" type="text">
<input class="searchbutton" value="" style="height:30px;border:none;margin:0px; padding-right:13px; vertical-align: middle;" type="submit"></div>
</div>

<div class="contact-list chatboxcontent" id="chat_list">
                                
</div>
</div>    
<!--Contact List end-->

<!--This div for modal light box chat box image-->
<table id="lightbox"  style="display: none;height: 100%">
<tr>
<td height="10px"><p><img src="../chat/images/close-icon-white.png" width="30px" style="cursor: pointer"/></p></td>
</tr>
<tr>
<td valign="middle"><div id="content"><img src="#"/></div></td>
</tr>
</table>
<!--This div for modal light box chat box image-->
</div>