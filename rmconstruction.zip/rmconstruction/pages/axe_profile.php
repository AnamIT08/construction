<?php session_start();
require_once '../inc/dbcon.php';
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='axe_profile.php';   
$cuPage='axe_profile.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='profile';
$menuh='Profile';
$phead='profile';
$page='Profile';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">

</script>    
<!-- /page script -->
</html>        