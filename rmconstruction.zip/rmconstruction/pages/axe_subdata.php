<?php
session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;     
}
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());

if(isset($_POST['exphead'])){
$name = ucwords(remove_junk(escape($_POST['name'])));
$etype = remove_junk(escape($_POST['etype']));
$description = remove_junk(escape($_POST['description']));
if($etype==0){
$grid=9;
$sgrid=21;    
}else{
$grid=8;
$sgrid=20;    
}
$code = get_ledgercode($grid);
if(isset($_POST['name'])){
$ducode = mysqli_query($con,"SELECT * FROM tbl_acledger WHERE name = '$name'");
}
	
if($ducode->num_rows > 0) {
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! This expenses head already exists!!'
));
return;
exit;    
}else{   
$sql="INSERT INTO tbl_acledger(code,grid,sgrid,name,description,uid,date) VALUES ('$code','$grid','$sgrid','$name','$description','$aid','$dtnow')";    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sid=$con->insert_id;    
$efid=mysqli_affected_rows($con);    
if($efid>0){
$act =remove_junk(escape('Expenses Head name: '.$name));    
write_activity($aid,'EXP','New Expenses Head has been created',$act);
echo json_encode(array(
'status' => 'success',
'id'=> $sid   
));
exit;     
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));       
}
}  
}

if(isset($_POST['addcus'])){
$name = ucwords(remove_junk(escape($_POST['name'])));
$code = get_genid('CU');
$cperson = remove_junk(escape($_POST['cperson']));
$cnumber = remove_junk(escape($_POST['cnumber']));
$cemail = remove_junk(escape($_POST['cemail']));    
$address = remove_junk(escape($_POST['address']));
if(isset($_POST['cnumber'])){
$ducode = mysqli_query($con,"SELECT * FROM tbl_customer WHERE cnumber = '$cnumber'");
}
	
if($ducode->num_rows > 0) {
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! This contact number already exists!!'
));
return;
exit;
}else{
$sql="INSERT INTO tbl_customer(code,name,cperson,cnumber,cemail,address,uid,date) VALUES ('$code','$name','$cperson','$cnumber','$cemail','$address','$aid','$dtnow')";    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sid=$con->insert_id;    
$efid=mysqli_affected_rows($con);    
if($efid>0){
$act =remove_junk(escape('Customer name: '.$name));    
write_activity($aid,'CUS','New customer has been Added',$act);
echo json_encode(array(
'status' => 'success',
'id'=> $sid   
));
exit;   
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));    
} 
}    
}

if(isset($_POST['addsup'])){
$name = ucwords(remove_junk(escape($_POST['name'])));
$code = get_genid('SU');
$cperson = remove_junk(escape($_POST['cperson']));
$cnumber = remove_junk(escape($_POST['cnumber']));
$cemail = remove_junk(escape($_POST['cemail']));    
$address = remove_junk(escape($_POST['address']));
if(isset($_POST['cnumber'])){
$ducode = mysqli_query($con,"SELECT * FROM tbl_supplier WHERE cnumber = '$cnumber'");
}
	
if($ducode->num_rows > 0) {
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! This contact number already exists!!'
));
return;
exit;
}else{
$sql="INSERT INTO tbl_supplier(code,name,cperson,cnumber,cemail,address,uid,date) VALUES ('$code','$name','$cperson','$cnumber','$cemail','$address','$aid','$dtnow')";    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sid=$con->insert_id;    
$efid=mysqli_affected_rows($con);    
if($efid>0){
$act =remove_junk(escape('Supplier name: '.$name));    
write_activity($aid,'SUP','New supplier has been Added',$act);
echo json_encode(array(
'status' => 'success',
'id'=> $sid   
));
exit;   
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));    
} 
}    
}

if(isset($_POST['addpro'])){
$name = ucwords(remove_junk(escape($_POST['name'])));
$code = get_genid('PU','ABA');
$preid = remove_junk(escape($_POST['preid']));
if($preid==''){$preid='NULL';}else{$preid="'".$preid."'";}
$catid = remove_junk(escape($_POST['catid']));
if($catid==''){$catid='NULL';}else{$catid="'".$catid."'";}
$scatid = remove_junk(escape($_POST['scatid']));
if($scatid==''){$scatid='NULL';}else{$scatid="'".$scatid."'";}
$braid = remove_junk(escape($_POST['braid']));
if($braid==''){$braid='NULL';}else{$braid="'".$braid."'";}
$manid = remove_junk(escape($_POST['manid']));
if($manid==''){$manid='NULL';}else{$manid="'".$manid."'";}
$unid = remove_junk(escape($_POST['unid']));
if($unid==''){$unid='NULL';}else{$unid="'".$unid."'";}
$colid = remove_junk(escape($_POST['colid']));
if($colid==''){$colid='NULL';}else{$colid="'".$colid."'";}
$couid = remove_junk(escape($_POST['couid']));
if($couid==''){$couid='NULL';}else{$couid="'".$couid."'";}
$status = remove_junk(escape($_POST['status']));   
$description = remove_junk(escape($_POST['description']));
	
if(isset($_POST['name'])){
if($colid!='NULL'){
$sql="SELECT * FROM tbl_item WHERE name = '$name' AND colid = '$colid'";    
}else{
$sql="SELECT * FROM tbl_item WHERE name = '$name'";    
}        
$ducode = mysqli_query($con,$sql);
}
	
if($ducode->num_rows > 0) {
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! This product already exists!!'
));
return;
exit;
}else{    
$sql="INSERT INTO tbl_item(code,name,description,prid,catid,scatid,brid,manid,unid,colid,couid,status,uid,date) VALUES ('$code','$name','$description',$preid,$catid,$scatid,$braid,$manid,$unid,$colid,$couid,'$status','$aid','$dtnow')";    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sid=$con->insert_id;    
$efid=mysqli_affected_rows($con);    
if($efid>0){ 
$act =remove_junk(escape('Product name: '.$name));    
write_activity($aid,'ITM','New product has been created',$act);    
echo json_encode(array(
'status' => 'success',
'id'=> $sid   
));
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));   
}
}    
}

if(isset($_POST['addcash'])){
$jouno = gen_newinvno('tbl_journal','JOU');
$note = remove_junk(escape($_POST['note']));
$did = '1';
$dty='LE';
$exdt = remove_junk(escape($_POST['cid']));    
$expo = explode('_',$exdt);
$cid=$expo['1'];
$cty=$expo['0'];    
$chkno = remove_junk(escape(strtoupper($_POST['chkno'])));
$chkdt = remove_junk(escape($_POST['chkdt']));
if($chkno=='' || strlen($chkno)<2){$chkdt='NULL';$chkno='NULL';}else{$chkdt="'".$chkdt."'";$chkno="'".$chkno."'";}    
$ref = remove_junk(escape($_POST['ref']));    
$total = remove_junk(escape($_POST['amo']));
$amo = remove_junk(escape($_POST['amo']));    

if(strlen($chkno)>1){
$sql="SELECT * FROM tbl_trarecord WHERE chkno=$chkno";    
$ducode = mysqli_query($con,$sql);      
if($ducode->num_rows > 0) {
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Check No already used!!'
));
exit;
return;    
}    
}    
    
$sql="INSERT INTO tbl_journal (invno,note,amount,apdate,brid,uid,date) VALUES ('$jouno','$note','$total','$today','$brid','$aid','$dtnow')";    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sid=$con->insert_id;    
$efid=mysqli_affected_rows($con);
if($efid>0){
    
$sql="INSERT INTO tbl_trarecord (invno,dty,did,amo,cid,cty,chkno,chkdt,ref,curid,xrate,apdate,brid,uid,date) VALUES ('$jouno','$dty','$did','$amo','$cid','$cty',$chkno,$chkdt,'$ref','0','0','$today','$brid','$aid','$dtnow')";
mysqli_query($con,$sql) or die(mysqli_error($con));

$act =remove_junk(escape('Journal No: '.$jouno));    
write_activity($aid,'JOU','Journal has been Added',$act);

$ldebit=get_ledgerval('LE1','D','N','','',$brid);
$lcredit=get_ledgerval('LE1','C','N','','',$brid);
$lnet=($ldebit-$lcredit);     
    
echo json_encode(array(
'status' => 'success',
'cash'=> $lnet   
));
exit;    
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Amount Fail to Transfer!!'
));   
}    
    
}
?>