<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='off_alloffer.php';   
$cuPage='off_alloffer.php';    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='offer';
$menuh='Set Offer &amp; Rebeat';
$phead='ofcre';
$page='Edit Coupon &amp; Offer';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php 
if(isset($_POST['update_offer'])){
$itmid = remove_junk(escape($_POST['itmid']));
$name = ucfirst(remove_junk(escape($_POST['name'])));
$percent = remove_junk(escape($_POST['percent']));
$fixed = remove_junk(escape($_POST['fixed']));
$stdate = remove_junk(escape($_POST['stdate']));
$endate = remove_junk(escape($_POST['endate']));
$efton = remove_junk(escape($_POST['efton']));
$status = remove_junk(escape($_POST['status']));    
$description = remove_junk(escape($_POST['description']));
	
if(isset($_POST['name'])){
$ducode = mysqli_query($con,"SELECT * FROM tbl_offer WHERE name = '$name' AND id!='$itmid'");
}
	
if($ducode->num_rows > 0) {
save_msg('i','Offer already exists! Plz try another');
echo "<script>window.location='off_alloffer.php'</script>";
}else{
$sql="UPDATE tbl_offer SET name='$name',description='$description',percent='$percent',fixed='$fixed',stdate='$stdate',endate='$endate',aft='$efton',status='$status' WHERE id='$itmid'";    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);    
if($efid>0){
$act =remove_junk(escape('Offer name: '.$name));    
write_activity($aid,'OFF','Offer has been Updated',$act);    
save_msg('s','Data Successfully Update!');
}else{
save_msg('w','Data Fail to Update!');    
}
}    
echo "<script>window.location='off_alloffer.php'</script>";   
}
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Edit Offer</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="off_offeredit.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">
<div class="col-md-1"></div>
<div class="col-md-10">
<?php    
if(isset($_POST['editoff'])){
$ids = $_POST['editoff'];
$sql="SELECT * FROM tbl_offer WHERE id='".$ids."' ORDER BY id ASC LIMIT 1";    
$admin=mysqli_query($con,$sql) or die(mysqli_error($con));    
$adm=mysqli_fetch_array($admin);
?>    
<div class="row">
<div class="col-md-6">
<div class="form-group">
<label>Name</label>
<div class="input-group">
<span class="input-group-addon">N</span>   
<input type="text" class="form-control" maxlength="45" name="name" id="name" value="<?php echo $adm['name'];?>" placeholder="e.g Summer Offer" required="" autocomplete="off">
<input type="hidden" maxlength="11" value="<?php echo $adm['id'];?>" class="form-control" name="itmid" autocomplete="off" readonly>    
</div>    
</div>
</div>
<div class="col-md-3">
<div class="form-group">
<label>Percent</label>
<div class="input-group">
<span class="input-group-addon">%</span>   
<input type="text" class="form-control" maxlength="5" min="0" name="percent" id="percent" value="<?php echo $adm['percent'];?>"  placeholder="e.g 5" onkeypress="return isNumberKey(event)" required="" autocomplete="off">
</div>    
</div>
</div>
<div class="col-md-3">
<div class="form-group">
<label>Fixed</label>
<div class="input-group">
<span class="input-group-addon">Tk</span>   
<input type="text" class="form-control" maxlength="6" min="0" name="fixed" id="fixed" value="<?php echo $adm['fixed'];?>"  placeholder="e.g 65" onkeypress="return isNumberKey(event)" required="" autocomplete="off">
</div>    
</div>
</div>    
</div>
<div class="row">
<div class="col-md-3">
<div class="form-group" >
<label>Offer Start</label>
<div class="input-group">
<span class="input-group-addon">
<span class="fa fa-calendar"></span>
</span>
<input type="text" class="form-control datetimepicker" name="stdate" id="stdate" value="<?php echo $adm['stdate'];?>" placeholder="e.g 2020-02-01" autocomplete="off" required="">
<span class="input-group-addon">SD</span>
</div>
</div>    
</div>
<div class="col-md-3">
<div class="form-group" >
<label>Offer End</label>
<div class="input-group">
<span class="input-group-addon">
<span class="fa fa-calendar"></span>
</span>
<input type="text" class="form-control datetimepicker" name="endate" id="endate" value="<?php echo $adm['endate'];?>" placeholder="e.g 2020-02-05" autocomplete="off" required="">
<span class="input-group-addon">ED</span>
</div>
</div>    
</div>
<div class="col-md-3">
<div class="form-group" >
<label>Effect On</label>
<div class="input-group">
<span class="input-group-addon">EF</span>    
<select class="form-control" name="efton">
<option <?php if($adm['aft']==0){echo 'selected';}?> value="0">Supplier</option>
<option <?php if($adm['aft']==1){echo 'selected';}?> value="1">Self</option>
</select>    
</div>
</div>    
</div>
<div class="col-md-3">
<div class="form-group" >
<label>Status</label>
<div class="input-group">
<span class="input-group-addon">ST</span>    
<select class="form-control" name="status">
<option <?php if($adm['status']==1){echo 'selected';}?> value="1">Active</option>
<option <?php if($adm['status']==0){echo 'selected';}?> value="0">De-Active</option>
</select>    
</div>
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group">
<label>Description</label>
<div class="input-group">
<span class="input-group-addon">DS</span>   
<textarea class="form-control" name="description" maxlength="350" rows="5" placeholder="Offer Details"><?php echo $adm['description'];?></textarea>
</div>    
</div>    
</div>
<div class="col-md-6">
    
</div>    
</div>    
<?php } ?>
</div>    
<div class="col-md-1"></div>
</div>
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="update_offer" class="btn btn-flat bg-purple btn-sm" value="Update"/> <a href="off_alloffer.php" class="btn btn-flat bg-gray">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'OFF','A');}else{echo read_activity($aid,'OFF','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>    
<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function (){ 
var name = new LiveValidation('name');
name.add(Validate.Presence);
var percent = new LiveValidation('percent');
percent.add(Validate.Presence);
percent.add(Validate.Numericality, { minimum: 0, maximum: 100});    
var fixed = new LiveValidation('fixed');
fixed.add(Validate.Presence);
fixed.add(Validate.Length, {minimum: 1, maximum: 6});    
var stdate = new LiveValidation('stdate');
stdate.add(Validate.Presence);
var endate = new LiveValidation('endate');
endate.add(Validate.Presence);    
});
    
$(document).on('keyup change', '#percent', function() {
$('#fixed').val('0');    
});
$(document).on('keyup change', '#fixed', function() {
$('#percent').val('0');    
});    
</script>    
<!-- /page script -->
</html>    