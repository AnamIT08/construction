<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='inv_prodispos.php';   
$cuPage='inv_prodispos.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];
$uty=$_SESSION['utype'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='inventor';
$menuh='Inventory';
$phead='prodis';
$page='Product Disposal';
$print='print';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php 
if(isset($_POST['delpdr'])){
$id=$_POST['delpdr'];

$sql="SELECT * FROM tbl_disposal WHERE id='$id' LIMIT 1";
$dsales=mysqli_query($con,$sql) or die(mysqli_error($con));    
$dsel=mysqli_fetch_array($dsales);     

$invno=$dsel['invno'];    

$sql="SELECT * FROM tbl_serial WHERE disno='$invno'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {  
$sql="UPDATE tbl_serial SET status='0',disno=NULL WHERE disno='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));      
}    

$sql="DELETE FROM tbl_traproduct WHERE invno='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));    

$sql="DELETE FROM tbl_disposal WHERE id='$id'";
$fdel=mysqli_query($con,$sql)or die(mysqli_error($con));    
$efid=mysqli_affected_rows($con);
if($efid>0){
$act =remove_junk(escape('Disposal No: '.$invno));
$bact =remove_junk('নিষ্পত্তি নং: '.$invno);    
write_activity($aid,'PDR','Disposal has been deleted',$act,'পণ্যের নিষ্পত্তি মুছে ফেলেছেন',$bact);        
save_msg('s','Disposal Successfully Deleted!!!');
}else{
save_msg('s','Disposal Fail to Delete!!!');    
}
echo "<script>window.location='inv_prodispos.php'</script>";    
}
?> 
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Disposal Record</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px; text-align:center;">SN</th>   
<th>Date</th>
<th>Disposal No</th>
<th>From</th>
<th>Dispos</th>    
<th>Recover</th>
<th>Note</th>    
<th style="width:40px; text-align:center;">Action</th>    
</tr>
</thead>    
<tbody>
<?php
$sql="SELECT * FROM tbl_disposal WHERE brid='$brid' ORDER BY apdate DESC,id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){    
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td><?php echo date("d M Y", strtotime($row['apdate']));?></td>
<td><?php echo $row['invno'];?></td>    
<td>
<?php 
if($row['brwh']=='B'){
if($row['ibrid']!=0){    
echo get_fild_data('tbl_branch',$row['ibrid'],'name');
}else{
echo 'No Branch';    
}
}else{
echo get_fild_data('tbl_warehouse',$row['ibrid'],'name');
}
?>
</td>
<td><?php echo numtolocal($row['dtotal'],get_fild_data('tbl_currency','1','symbol'));?></td>
<td><?php echo numtolocal($row['total'],get_fild_data('tbl_currency','1','symbol'));?></td>    
<td><?php echo $row['note'];?></td>   
<td nowrap="">
<a class="btn btn-flat bg-purple details-invoice" href="#" id="inv_<?php echo $row['id'].'_'.$row['ibrid'].'_'.$row['brwh']; ?>"><i class="fa fa-eye cat-child"></i></a>   
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>   
<form action="inv_prodispos.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delpdr" value="<?php echo $row['id']; ?>" />
</form>
</td>    
</tr>    
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<a href="inv_prodisposcre.php" class="btn btn-flat bg-purple">Create Disposal</a>
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'PDR','A');}else{echo read_activity($aid,'PDR','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content --> 
<?php include('../layout/print.php'); ?>    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
});
    
function take_action(id) {
document.getElementById(id).submit(); 
}
    
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});
}
    
$(document).on('click','.details-invoice',function(e) {      
id_arr = $(this).attr('id');
id = id_arr.split("_");

$.ajax({
url: 'inv_viewdis.php',
method: "POST",
data:{ 
invid: id[1],cusid: id[2],type:id[3]
},
success: function(data){
$('#listitem').html(data);
pagelist();    
}
});    
    
$.ajax({
url: 'inv_viewdisinv.php',
method: "POST",
data:{ 
print: id[1]
},
success: function(data){
$('#invhold').html(data);
sethead();    
}
});
    
$('.right-side').toggle('slide', { direction: 'right' }, 300);    

e.preventDefault();
});

$(document).on('click', '#closepop', function() {
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }   
});
    
$('#listitem').on('click','li', function(){
   $(this).addClass('active').siblings().removeClass('active');
});
    
$(document).on('click', '.invpiv', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
$.ajax({
url: 'inv_viewdisinv.php',
method: "POST",
data:{ 
print: ids
},
beforeSend: function() {
//$("#invhold").fadeOut('slow');
},    
success: function(data){    
$('#invhold').html(data);
$("#invhold").fadeIn('slow');    
sethead();    
}
});     
});    
</script>    
<!-- /page script -->
</html>    