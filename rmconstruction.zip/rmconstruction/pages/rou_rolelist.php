<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('44','views','R');     
$_SESSION['cuPages']='rou_rolelist.php';   
$cuPage='rou_rolelist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
$uty=$_SESSION['utype'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='user';
$menuh='User &amp; Role';
$phead='rollist';
$page='User Role';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['delrol'])){
$id=$_POST['delrol'];
if(delete_check('tbl_user','acess',$id)>0){
save_msg('w','Role Depend On Other Table!!!');
echo "<script>window.location='rou_rolelist.php'</script>";
return;    
}
$name= get_fild_data('tbl_usergroup',$id,'name');
$sql="DELETE FROM tbl_userpermision WHERE seid='$id'";
$queryes=mysqli_query($con,$sql)or die(mysqli_error($con));
$sql="DELETE FROM tbl_usergroup WHERE id='$id'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);     
if($efid>0){
$act =remove_junk(escape('Role name: '.$name));    
write_activity($aid,'ROL','User Role has been deleted',$act);        
save_msg('s','Role Successfully Deleted!!!');
}else{
save_msg('w','Role Fail to Deleted!!!');    
}    
echo "<script>window.location='rou_rolelist.php'</script>";
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">All Role</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px;">SN</th>   
<th>Access</th>
<th>Description</th>        
<th style="width:40px; text-align:center;">Action</th>    
</tr>
</thead>    
<tbody>
<?php
$sql="SELECT * FROM tbl_usergroup ORDER BY id ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$id=$row['id'];
?>
<tr>
<td class="center"><?php echo count_id();?></td>      
<td><?php echo $row['name'];?></td>
<td><?php echo $row['description'];?></td>     
<td nowrap="">   
<?php if($row['id']!='1'){ ?>
<a class="btn btn-flat bg-purple" href="#" onclick="edit_item('ED_<?php echo $row['id'];?>')"><i class="fa fa-edit"></i></a>    
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
<?php } ?>    
<form action="rou_roleedit.php" id="ED_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="editrol" value="<?php echo $row['id']; ?>" />
</form> 
<form action="rou_rolelist.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delrol" value="<?php echo $row['id']; ?>" />
</form>
</td>    
</tr>    
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >    
<a href="rou_rolecreate.php" class="btn btn-flat bg-purple">Add Role</a>   
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'ROL','A');}else{echo read_activity($aid,'ROL','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>
 
<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
});
function edit_item(id) {
document.getElementById(id).submit(); 
}
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});

}
</script>    
<!-- /page script -->
</html>    