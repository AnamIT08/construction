<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/imgpro.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('36','creates','R');    
$_SESSION['cuPages']='payr_empcreate.php';   
$cuPage='payr_empcreate.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='payroll';
$menuh='Payroll';
$phead='empcre';
$page='Employee Add';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php
if(isset($_POST['save_emp'])){
$name = remove_junk(escape($_POST['name']));
$fname = remove_junk(escape($_POST['fname']));
$mname = remove_junk(escape($_POST['mname']));
$dipid = remove_junk(escape($_POST['dipid']));    
$desid = remove_junk(escape($_POST['desid']));
$mobile = remove_junk(escape($_POST['mobile']));
$phone = remove_junk(escape($_POST['phone']));
$email = remove_junk(escape($_POST['email']));
$nidno = remove_junk(escape($_POST['nidno']));
$dob = remove_junk(escape($_POST['dob']));
$job = remove_junk(escape($_POST['job']));
$salary = remove_junk(escape($_POST['salary']));
$address = remove_junk(escape($_POST['address']));
$paddress = remove_junk(escape($_POST['paddress']));
$code = get_empcode($dipid);
$item = PATHINFO($_FILES["item"]["name"]);    
$status = remove_junk(escape($_POST['status']));
$wbrid = remove_junk(escape($_POST['wbrid']));    
    
if(isset($_POST['mobile'])){
$ducode = mysqli_query($con,"SELECT * FROM tbl_employe WHERE mobile = '$mobile'");
}
	
if($ducode->num_rows > 0) {
save_msg('w','Mobile number alrady used! Plz try another');
echo "<script>window.location='emp_empcreate.php'</script>";
}else{       
$sql="INSERT INTO tbl_employe(dipid,desid,name,fname,mname,dob,job,code,salary,address,paddress,mobile,phone,email,nidno,status,wbrid,brid,uid,date) VALUES ('$dipid','$desid','$name','$fname','$mname','$dob','$job','$code','$salary','$address','$paddress','$mobile','$phone','$email','$nidno','$status','$wbrid','$brid','$aid','$dtnow')";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$eid=$con->insert_id;
$efid=mysqli_affected_rows($con);   
if($efid>0){
if (!empty($_FILES["item"]["name"])){
get_upload($eid,$_FILES['item'],'E');    
}
$act =remove_junk(escape('Employee name: '.$name));    
write_activity($aid,'EMP','New employee has been Added',$act);    
save_msg('s','Employee Added Successfully!!!');
echo "<script>window.location='payr_empcreate.php'</script>";  
}else{
save_msg('e','Employee insert fail!!!!');
echo "<script>window.location='payr_empcreate.php'</script>";		
}
}
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Add New Employee</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="payr_empcreate.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">    
<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<div class="row">
<div class="col-md-6">
<div class="form-group" >
<label>Department</label>
<div class="input-group">
<span class="input-group-addon">DP</span>
<select class="form-control select2" name="dipid" id="dipid" required>
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_department ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>
</div>
</div>
</div>
<div class="col-md-6">
<div class="form-group" >
<label>Designation</label>
<div class="input-group">
<span class="input-group-addon">DS</span>
<select class="form-control select2" name="desid" id="desid" required>
<option value="">-Select-</option>
<?php									
$queryd=mysqli_query($con,"SELECT * FROM tbl_designation ORDER BY id ASC")or die(mysqli_error($con));
while ($rowd=mysqli_fetch_array($queryd)){
?>
<option value="<?php echo $rowd['id'];?>"><?php echo $rowd['name'];?></option>
<?php } ?>                                                                
</select>
</div>
</div>        
</div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="form-group" >
<label>Name</label>
<div class="input-group">
<span class="input-group-addon">N</span>
<input type="text" maxlength="45" class="form-control" name="name" id="name" placeholder="e.g. Sumon" autocomplete="off" required>
</div>
</div>
</div>
</div>    
<div class="row">
<div class="col-md-6">
<div class="form-group" >
<label>Father Name</label>
<div class="input-group">
<span class="input-group-addon">FN</span>
<input type="text" maxlength="45" class="form-control" name="fname" id="fname" placeholder="e.g. Abul Kalam" autocomplete="off" required>
</div>
</div>
<div class="form-group" >
<label>Mobile</label>
<div class="input-group">
<span class="input-group-addon">MO</span>
<input type="text" maxlength="18" class="form-control" name="mobile" id="mobile" placeholder="e. g. 0161xx700xx" autocomplete="off" required>
</div>
</div>
<div class="form-group" >
<label>Email</label>
<div class="input-group">
<span class="input-group-addon">EM</span>
<input type="email" maxlength="45" class="form-control" name="email" id="email" placeholder="e.g. info@axesgl.com" autocomplete="off">
</div>
</div>    
</div>
<div class="col-md-6">
<div class="form-group" >
<label>Mother Name</label>
<div class="input-group">
<span class="input-group-addon">MN</span>
<input type="text" maxlength="45" class="form-control" name="mname" id="mname" placeholder="e.g. Begum Feroza" autocomplete="off" required>
</div>
</div>
<div class="form-group" >
<label>Phone</label>
<div class="input-group">
<span class="input-group-addon">PH</span>
<input type="text" maxlength="14" class="form-control" name="phone" id="inputPhone" placeholder="Phone No:" autocomplete="off">
</div>
</div>
<div class="form-group" >
<label>NID No</label>
<div class="input-group">
<span class="input-group-addon">NI</span>
<input type="text" maxlength="17" class="form-control" name="nidno" id="nidno" onkeypress="return isNumberKey(event)" placeholder="NID No:" autocomplete="off">
</div>
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group" >
<label>Date of Birth</label>
<div class="input-group">
<span class="input-group-addon">
<span class="fa fa-calendar"></span>
</span>
<input type="text" class="form-control datetimepicker" name="dob" id="dob" placeholder="Date of Birth:" autocomplete="off" required>
<span class="input-group-addon">DOB</span>
</div>
</div>
<div class="form-group" >
<label>Joining Date</label>
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-calendar"></span></span>
<input type="text" maxlength="18" class="form-control datetimepicker" name="job" id="job" placeholder="Joining Date:" autocomplete="off" required>
<span class="input-group-addon">JOB</span>
</div>
</div>
<div class="form-group" >
<label>Salary</label>
<div class="input-group">
<span class="input-group-addon">SA</span>
<input type="text" maxlength="6" class="form-control" name="salary" id="salary"  onkeypress="return isNumberKey(event)" placeholder="Salary:" autocomplete="off" required>
</div>
</div>
<div class="form-group" >
<label>Status</label>
<div class="input-group">
<span class="input-group-addon">ST</span>    
<select class="form-control" name="status">
<option value="1">Active</option>
<option value="0">De-Active</option>
</select>    
</div>
</div>
<div class="form-group" >
<label>Branch</label>
<div class="input-group">
<span class="input-group-addon">BR</span>
<select class="form-control select2" name="wbrid" id="wbrid" required>
<option value="">-Select-</option>
<option value="0">-No Branch-</option>    
<?php									
$queryd=mysqli_query($con,"SELECT * FROM tbl_branch ORDER BY id ASC")or die(mysqli_error($con));
while ($rowd=mysqli_fetch_array($queryd)){
?>
<option value="<?php echo $rowd['id'];?>"><?php echo $rowd['name'];?></option>
<?php } ?>                                                                
</select>
</div>
</div>    
</div>
<div class="col-md-6">
<div class="form-group">
<label for="inputIMAGE" class="control-label mb-10">Image</label>
<div style="width:200px; height:245px;">
<img src="../img/emp/demp.jpg" id="profile-img-tag" style="width: 100%; height: 100%; object-fit: contain;">
</div>
<br>    
<input type="file" class="btn btn-flat bg-purple btn-sm" name="item" id="profile-img" accept=".png, .gif, .jpg, .jpeg">
    
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-6">    
<div class="form-group">
<label>Residential Address</label>
<div class="input-group">
<span class="input-group-addon">RA</span>
<textarea class="form-control" name="address" id="address" maxlength="250" rows="5" placeholder="Residential Address" required></textarea>
</div>    
</div>
</div>
<div class="col-md-6">    
<div class="form-group">
<label>Permanent Address</label>
<div class="input-group">
<span class="input-group-addon">PA</span>
<textarea class="form-control" name="paddress" id="paddress" maxlength="250" rows="5" placeholder="Permanent Address" required></textarea>
</div>    
</div>
</div>    
</div>
   
</div>    
<div class="col-md-1"></div>
</div>
</div>
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="save_emp" id="submit" class="btn btn-flat bg-purple btn-sm " value="Save"/> <a href="payr_emplist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'EMP','A');}else{echo read_activity($aid,'EMP','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function () {
var dipid = new LiveValidation('dipid');
dipid.add(Validate.Presence);    
var desid = new LiveValidation('desid');
desid.add(Validate.Presence);
var name = new LiveValidation('name');
name.add(Validate.Presence);
var fname = new LiveValidation('fname');
fname.add(Validate.Presence);
var mname = new LiveValidation('mname');
mname.add(Validate.Presence);    
var mobile = new LiveValidation('mobile');
mobile.add(Validate.Presence);
mobile.add(Validate.Length, {minimum: 11, maximum: 14});
var dob = new LiveValidation('dob');
dob.add(Validate.Presence); 
var job = new LiveValidation('job');
job.add(Validate.Presence); 
var salary = new LiveValidation('salary');
salary.add(Validate.Presence);     
var address = new LiveValidation('address');
address.add(Validate.Presence);
var paddress = new LiveValidation('paddress');
paddress.add(Validate.Presence);   
var email = new LiveValidation('email');
email.add(Validate.Email);
var nidno = new LiveValidation('nidno');
nidno.add(Validate.Length, {minimum: 10, maximum: 17});
var wbrid = new LiveValidation('wbrid');
wbrid.add(Validate.Presence);    
});
    
function readURL(input) {
if (input.files && input.files[0]) {
var reader = new FileReader();
            
reader.onload = function (e) {
$('#profile-img-tag').attr('src', e.target.result);
}
reader.readAsDataURL(input.files[0]);
}
}
$("#profile-img").change(function(){
readURL(this);
});
$("#profile-img-tag").click(function() {
$("#profile-img").click();
});
</script>    
<!-- /page script -->
</html>    