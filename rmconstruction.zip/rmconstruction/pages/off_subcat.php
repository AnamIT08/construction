<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$output='';
if(isset($_POST['catid'])){
   $id=$_POST['catid'];
    $sql="SELECT DISTINCT id,name FROM (SELECT tbl_subcat.catid,tbl_subcat.id,tbl_subcat.name,(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0))+(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0)) AS avqty FROM tbl_stock LEFT JOIN tbl_item ON tbl_item.id=tbl_stock.pid LEFT JOIN tbl_subcat ON tbl_subcat.id=tbl_item.scatid) ofitm WHERE avqty>0 AND catid='$id' ORDER BY name ASC";
    $query=mysqli_query($con,$sql)or die(mysqli_error($con));
    while ($rowc=mysqli_fetch_array($query)){
    $sid=$rowc['id'];
    $output.='<button id="subcat_'.$rowc['id'].'" type="button" title="'.$rowc['name'].'" class="btn-prni btn-outline-primary subcat" data-container="body"><img src="../img/product/';
    if(empty($rowc['image'])){$output.='no_image.png';}else{$output.=$rowc['image'];}
    $output.='" alt="'.$rowc['name'].'" class="img-rounded" /><span>'.$rowc['name'].'</span></button>';
    }
}
echo $output;
exit;