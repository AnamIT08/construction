<?php 

session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/repfunctions.php');
$today = strftime("%Y-%m-%d", time());

if(isset($_POST['tfdate'])){	
$fdate=$_POST['tfdate'];	
}else{
$fdate=date('Y-m-d', strtotime('-29 days', time()));	
}
if(isset($_POST['ttdate'])){
$tdate=$_POST['ttdate'];	
}else{
$tdate=$today;	
}

?>
<div class="col-md-12">
<div class="row">
<div class="col-md-6 text-left">
<h4>FROM: <?php echo date("d-M-Y", strtotime($fdate));?></h4>    
</div>
<div class="col-md-6 text-right">
<h4>To: <?php echo date("d-M-Y", strtotime($tdate));?></h4>    
</div>
</div>
</div>
<div class="clearfix" ></div>
<!-- ASSETS --> 
<table class="table table-bordered   table-hover">
<tbody>
<tr>
<td width="50%" class="bg-gray"><b>ASSETS</b></td>
<td width="16.16%" class="bg-gray"><b>Opening</b></td>
<td width="16.16%" class="bg-gray"><b>During Time</b></td>
<td width="16.16%" class="bg-gray"><b>Closing</b></td>    
</tr>
<?php     
$sql="SELECT DISTINCT grid,groups FROM tbl_ledger WHERE clsid='1' ORDER BY grid ASC";
$result=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowg=mysqli_fetch_array($result)){
$gopval=(get_goupval($rowg['grid'],'D','O','G',$fdate)-get_goupval($rowg['grid'],'C','O','G',$fdate));
$gdebit=get_goupval($rowg['grid'],'D','D','G',$fdate,$tdate);
$gcredit=get_goupval($rowg['grid'],'C','D','G',$fdate,$tdate);
$gnet=($gdebit-$gcredit);
$gcval=($gopval+$gnet);    
?>
<?php if(ABS($gcval)>0){?>     
<tr>
<td ><b><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;<?php echo $rowg['groups'];?></b></td>
<td></td>
<td></td>
<td></td>    
</tr>
<?php } ?>    
<?php     
$sql="SELECT DISTINCT sgrid,sgroup FROM tbl_ledger WHERE clsid='1' AND grid='".$rowg['grid']."' ORDER BY sgrid ASC";
$results=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowsg=mysqli_fetch_array($results)){
$sopval=(get_goupval($rowsg['sgrid'],'D','O','S',$fdate)-get_goupval($rowsg['sgrid'],'C','O','S',$fdate));
$sdebit=get_goupval($rowsg['sgrid'],'D','D','S',$fdate,$tdate);
$scredit=get_goupval($rowsg['sgrid'],'C','D','S',$fdate,$tdate);
$snet=($sdebit-$scredit);
$scval=($sopval+$snet);     
?>
<?php if(ABS($scval)>0){?>     
<tr>
<td style="padding-left: 15px;"><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;<?php echo $rowsg['sgroup'];?></td>
<td></td>
<td></td>
<td></td>    
</tr>
<?php } ?>   
<?php     
$sql="SELECT id,code,ledger FROM tbl_ledger WHERE clsid='1' AND sgrid='".$rowsg['sgrid']."' ORDER BY id ASC";
$resultl=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowl=mysqli_fetch_array($resultl)){
$lopval=(get_ledgerval($rowl['id'],'D','O',$fdate)-get_ledgerval($rowl['id'],'C','O',$fdate));
$ldebit=get_ledgerval($rowl['id'],'D','D',$fdate,$tdate);
$lcredit=get_ledgerval($rowl['id'],'C','D',$fdate,$tdate);
$lnet=($ldebit-$lcredit);
$lcval=($lopval+$lnet);    
?>
<?php if(ABS($lcval)>0){?>    
<tr>
<td style="padding-left:30px;"><?php echo $rowl['code'];?>: <?php echo $rowl['ledger'];?></td>
<td class="text-right"><?php echo number_format($lopval,2);?></td>
<td class="text-right"><?php echo number_format($lnet,2);?></td>
<td class="text-right"><?php echo number_format($lcval,2);?></td>    
</tr>
<?php } ?>   
<?php }} ?>
<?php if(ABS($gcval)>0){?>     
<tr>
<td style="text-align: right;padding-right:20px;"><strong>Total <?php echo $rowg['groups'];?></strong></td>
<td style="text-align: right; border-top: 1px double #000000;"><b><?php echo number_format($gopval,2);?></b>
</td>
<td style="text-align: right; border-top: 1px double #000000;"><b><?php echo number_format($gnet,2);?></b>
</td>
<td style="text-align: right; border-top: 1px double #000000;"><b><?php echo number_format($gcval,2);?></b>
</td>    
</tr>
<?php } ?>    
<?php } ?>
<?php 
$acopval=(get_goupval('1','D','O','C',$fdate)-get_goupval('1','C','O','C',$fdate));
$acdebit=get_goupval('1','D','D','C',$fdate,$tdate);
$accredit=get_goupval('1','C','D','C',$fdate,$tdate);
$acnet=($acdebit-$accredit);
$accval=($acopval+$acnet);    
?>
<?php if(ABS($accval)>0){?>    
<tr style="border-bottom:none;border-top:none;">
    <td colspan="4"></td>
</tr>     
<tr>    
<td ><b>&nbsp;Total Assets</b></td>
<td style="text-align: right; border-top: 1px double #000000; border-bottom: 4px double #000000;"><b><?php echo number_format(ABS($acopval),2);?></b></td>
<td style="text-align: right; border-top: 1px double #000000; border-bottom: 4px double #000000;"><b><?php echo number_format(ABS($acnet),2);?></b></td>
<td style="text-align: right; border-top: 1px double #000000; border-bottom: 4px double #000000;"><b><?php echo number_format(ABS($accval),2);?></b></td>    
</tr>
<?php } ?>
</tbody>    
</table>
<!--/ASSETS-->
<!--LIABILITIES--> 
<table class="table table-bordered   table-hover">
<tbody>
<tr>
<td width="50%" class="bg-gray"><b>LIABILITIES &amp; OWNER'S EQUITY</b></td>
<td width="16.16%" class="bg-gray"><b>Opening</b></td>
<td width="16.16%" class="bg-gray"><b>During Time</b></td>
<td width="16.16%" class="bg-gray"><b>Closing</b></td>    
</tr>
<?php     
$sql="SELECT DISTINCT grid,groups FROM tbl_ledger WHERE clsid='2'  ORDER BY clsid,grid ASC";
$result=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowg=mysqli_fetch_array($result)){
$gopval=(get_goupval($rowg['grid'],'C','O','G',$fdate)-get_goupval($rowg['grid'],'D','O','G',$fdate));
$gdebit=get_goupval($rowg['grid'],'D','D','G',$fdate,$tdate);
$gcredit=get_goupval($rowg['grid'],'C','D','G',$fdate,$tdate);
$gnet=($gcredit-$gdebit);
$gcval=($gopval+$gnet);    
?>
<?php if(ABS($gcval)>0){?>     
<tr>
<td ><b><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;<?php echo $rowg['groups'];?></b></td>
<td></td>
<td></td>
<td></td>    
</tr>
<?php } ?>    
<?php     
$sql="SELECT DISTINCT sgrid,sgroup FROM tbl_ledger WHERE clsid='2' AND grid='".$rowg['grid']."' ORDER BY sgrid ASC";
$results=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowsg=mysqli_fetch_array($results)){
$sopval=(get_goupval($rowsg['sgrid'],'C','O','S',$fdate)-get_goupval($rowsg['sgrid'],'D','O','S',$fdate));
$sdebit=get_goupval($rowsg['sgrid'],'D','D','S',$fdate,$tdate);
$scredit=get_goupval($rowsg['sgrid'],'C','D','S',$fdate,$tdate);
$snet=($scredit-$sdebit);
$scval=($sopval+$snet);     
?>
<?php if(ABS($scval)>0){?>     
<tr>
<td style="padding-left: 15px;"><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;<?php echo $rowsg['sgroup'];?></td>
<td></td>
<td></td>
<td></td>    
</tr>
<?php } ?>   
<?php     
$sql="SELECT id,code,ledger FROM tbl_ledger WHERE clsid='2' AND sgrid='".$rowsg['sgrid']."' ORDER BY id ASC";
$resultl=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowl=mysqli_fetch_array($resultl)){
$lopval=(get_ledgerval($rowl['id'],'C','O',$fdate)-get_ledgerval($rowl['id'],'D','O',$fdate));
$ldebit=get_ledgerval($rowl['id'],'D','D',$fdate,$tdate);
$lcredit=get_ledgerval($rowl['id'],'C','D',$fdate,$tdate);
$lnet=($lcredit-$ldebit);
$lcval=($lopval+$lnet);    
?>
<?php if(ABS($lcval)>0){?>    
<tr>
<td style="padding-left:30px;"><?php echo $rowl['code'];?>: <?php echo $rowl['ledger'];?></td>
<td class="text-right"><?php echo number_format($lopval,2);?></td>
<td class="text-right"><?php echo number_format($lnet,2);?></td>
<td class="text-right"><?php echo number_format($lcval,2);?></td>    
</tr>
<?php } ?>   
<?php }} ?>
<?php if(ABS($gcval)>0){?>     
<tr>
<td style="text-align: right;padding-right:20px;"><strong>Total <?php echo $rowg['groups'];?></strong></td>
<td style="text-align: right; border-top: 1px double #000000;"><b><?php echo number_format($gopval,2);?></b>
</td>
<td style="text-align: right; border-top: 1px double #000000;"><b><?php echo number_format($gnet,2);?></b>
</td>
<td style="text-align: right; border-top: 1px double #000000;"><b><?php echo number_format($gcval,2);?></b>
</td>    
</tr>
<?php } ?>    
<?php } ?>
<!--/LIABILITIES-->
<!--OWNER'S EQUITY-->    
<?php     
$sql="SELECT DISTINCT grid,groups FROM tbl_ledger WHERE clsid='3'  ORDER BY clsid,grid ASC";
$result=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowg=mysqli_fetch_array($result)){
$gopval=(get_goupval($rowg['grid'],'C','O','G',$fdate)-get_goupval($rowg['grid'],'D','O','G',$fdate));
$gdebit=get_goupval($rowg['grid'],'D','D','G',$fdate,$tdate);
$gcredit=get_goupval($rowg['grid'],'C','D','G',$fdate,$tdate);
$gnet=($gcredit-$gdebit);
$gcval=($gopval+$gnet);    
?>
<?php if(ABS($gcval)>0){?>     
<tr>
<td ><b><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;<?php echo $rowg['groups'];?></b></td>
<td></td>
<td></td>
<td></td>    
</tr>
<?php } ?>    
<?php     
$sql="SELECT DISTINCT sgrid,sgroup FROM tbl_ledger WHERE clsid='3' AND grid='".$rowg['grid']."' ORDER BY sgrid ASC";
$results=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowsg=mysqli_fetch_array($results)){
$sopval=(get_goupval($rowsg['sgrid'],'C','O','S',$fdate)-get_goupval($rowsg['sgrid'],'D','O','S',$fdate));
$sdebit=get_goupval($rowsg['sgrid'],'D','D','S',$fdate,$tdate);
$scredit=get_goupval($rowsg['sgrid'],'C','D','S',$fdate,$tdate);
$snet=($scredit-$sdebit);
$scval=($sopval+$snet);     
?>
<?php if(ABS($scval)>0){?>     
<tr>
<td style="padding-left: 15px;"><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;<?php echo $rowsg['sgroup'];?></td>
<td></td>
<td></td>
<td></td>    
</tr>
<?php } ?>   
<?php     
$sql="SELECT id,code,ledger FROM tbl_ledger WHERE clsid='3' AND sgrid='".$rowsg['sgrid']."' ORDER BY id ASC";
$resultl=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowl=mysqli_fetch_array($resultl)){
$lopval=(get_ledgerval($rowl['id'],'C','O',$fdate)-get_ledgerval($rowl['id'],'D','O',$fdate));
$ldebit=get_ledgerval($rowl['id'],'D','D',$fdate,$tdate);
$lcredit=get_ledgerval($rowl['id'],'C','D',$fdate,$tdate);
$lnet=($lcredit-$ldebit);
$lcval=($lopval+$lnet);    
?>
<?php if(ABS($lcval)>0){?>    
<tr>
<td style="padding-left:30px;"><?php echo $rowl['code'];?>: <?php echo $rowl['ledger'];?></td>
<td class="text-right"><?php echo number_format($lopval,2);?></td>
<td class="text-right"><?php echo number_format($lnet,2);?></td>
<td class="text-right"><?php echo number_format($lcval,2);?></td>    
</tr>
<?php } ?>   
<?php }} ?>
<?php if(ABS($gcval)>0){?>     
<tr>
<td style="text-align: right;padding-right:20px;"><strong>Total <?php echo $rowg['groups'];?></strong></td>
<td style="text-align: right; border-top: 1px double #000000;"><b><?php echo number_format($gopval,2);?></b>
</td>
<td style="text-align: right; border-top: 1px double #000000;"><b><?php echo number_format($gnet,2);?></b>
</td>
<td style="text-align: right; border-top: 1px double #000000;"><b><?php echo number_format($gcval,2);?></b>
</td>    
</tr>
<?php } ?>    
<?php } ?>    
<!--/OWNER'S EQUITY-->    
<?php 
$rcopval=(get_goupval('5','C','O','C',$fdate)-get_goupval('5','D','O','C',$fdate));
$rcdebit=get_goupval('5','D','D','C',$fdate,$tdate);
$rccredit=get_goupval('5','C','D','C',$fdate,$tdate);
$rcnet=($rccredit-$rcdebit);
$rccval=($rcopval+$rcnet);    

$ecopval=(get_goupval('4','D','O','C',$fdate)-get_goupval('4','C','O','C',$fdate));
$ecdebit=get_goupval('4','D','D','C',$fdate,$tdate);
$eccredit=get_goupval('4','C','D','C',$fdate,$tdate);
$ecnet=($ecdebit-$eccredit);
$eccval=($ecopval+$ecnet);

$reopval=($rcopval-$ecopval);
$reduval=($rcnet-$ecnet);
$reclval=($rccval-$eccval);    
?>    
<tr>
<td ><b><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;Retained earnings </b></td>
<td class="text-right"><?php echo number_format(($rcopval-$ecopval),2);?></td>
<td class="text-right"><?php echo number_format(($rcnet-$ecnet),2);?></td>
<td class="text-right"><?php echo number_format(($rccval-$eccval),2);?></td>     
</tr> 
    
<?php 
$lcopval=(get_goupval('2','C','O','C',$fdate)-get_goupval('2','D','O','C',$fdate));
$lcdebit=get_goupval('2','D','D','C',$fdate,$tdate);
$lccredit=get_goupval('2','C','D','C',$fdate,$tdate);
$lcnet=($lccredit-$lcdebit);
$lccval=($lcopval+$lcnet);
    
$wcopval=(get_goupval('3','C','O','C',$fdate)-get_goupval('3','D','O','C',$fdate));
$wcdebit=get_goupval('3','D','D','C',$fdate,$tdate);
$wccredit=get_goupval('3','C','D','C',$fdate,$tdate);
$wcnet=($wccredit-$wcdebit);
$wccval=($wcopval+$wcnet);    
?>
<?php if(ABS($lccval)>0){?>    
<tr style="border-bottom:none;border-top:none;">
    <td colspan="4"></td>
</tr>     
<tr>    
<td ><b>&nbsp;Total Liabilities and Owner's Equity</b></td>
<td style="text-align: right; border-top: 1px double #000000; border-bottom: 4px double #000000;"><b><?php echo number_format(($lcopval+$wcopval+$reopval),2);?></b></td>
<td style="text-align: right; border-top: 1px double #000000; border-bottom: 4px double #000000;"><b><?php echo number_format(($lcnet+$wcnet+$reduval),2);?></b></td>
<td style="text-align: right; border-top: 1px double #000000; border-bottom: 4px double #000000;"><b><?php echo number_format(($lccval+$wccval+$reclval),2);?></b></td>    
</tr>
<?php } ?>
</tbody>    
</table>
<!--/LIABILITIES and OWNER'S EQUITY-->
<table class="table table-bordered   table-hover">
<tbody>
<tr>
<td width="50%" class="bg-gray"><b>Common Financial Ratios</b></td>
<td width="16.16%" class="bg-gray"></td>
<td width="16.16%" class="bg-gray"></td>
<td width="16.16%" class="bg-gray"></td>    
</tr>
<tr>
<td width="50%" style="padding-left:15px;"><b>Debt Ratio</b> (Total Liabilities / Total Assets)</td>
<td width="16.16%" class="text-right"><?php if(ABS($acopval)>0 && ABS($lcopval)>0){echo number_format(ABS($acopval/$lcopval),2);}else{echo '0.00';}?></td>
<td width="16.16%" class="text-right"><?php if(ABS($acnet)>0 && ABS($lcnet)>0){echo number_format(ABS($acnet/$lcnet),2);}else{echo '0.00';}?></td>
<td width="16.16%" class="text-right"><?php if(ABS($accval)>0 && ABS($lccval)>0){echo number_format(ABS($accval/$lccval),2);}else{echo '0.00';}?></td>    
</tr>
<?php 
$caopval=(get_goupval('2','D','O','G',$fdate)-get_goupval('2','C','O','G',$fdate));
$cadebit=get_goupval('2','D','D','G',$fdate,$tdate);
$cacredit=get_goupval('2','C','D','G',$fdate,$tdate);
$canet=($cadebit-$cacredit);
$cacval=($caopval+$canet);

$clopval=(get_goupval('5','C','O','G',$fdate)-get_goupval('5','D','O','G',$fdate));
$cldebit=get_goupval('5','D','D','G',$fdate,$tdate);
$clcredit=get_goupval('5','C','D','G',$fdate,$tdate);
$clnet=($clcredit-$cldebit);
$clcval=($clopval+$clnet);     
?>    
<tr>
<td width="50%" style="padding-left:15px;"><b>Current Ratio</b> (Current Assets / Current Liabilities)</td>
<td width="16.16%" class="text-right"><?php if(ABS($caopval)>0 && ABS($clopval)>0){echo number_format(ABS($caopval/$clopval),2);}else{echo '0.00';}?></td>
<td width="16.16%" class="text-right"><?php if(ABS($canet)>0 && ABS($clnet)>0){echo number_format(ABS($canet/$clnet),2);}else{echo '0.00';}?></td>
<td width="16.16%" class="text-right"><?php if(ABS($cacval)>0 && ABS($clcval)>0){echo number_format(ABS($cacval/$clcval),2);}else{echo '0.00';}?></td>    
</tr>
<tr>
<td width="50%" style="padding-left:15px;"><b>Working Capital</b> (Current Assets - Current Liabilities)</td>
<td width="16.16%" class="text-right"><?php echo number_format(($caopval-$clopval),2);?></td>
<td width="16.16%" class="text-right"><?php echo number_format(($canet-$clnet),2);?></td>
<td width="16.16%" class="text-right"><?php echo number_format(($cacval-$clcval),2);?></td>    
</tr>
<tr>
<td width="50%" style="padding-left:15px;"><b>Assets-to-Equity Ratio</b> (Total Assets / Owner's Equity)</td>
<td width="16.16%" class="text-right"><?php if(ABS($caopval)>0 && ABS($wcopval)>0){echo number_format(ABS($caopval/$wcopval),2);}else{echo '0.00';}?></td>
<td width="16.16%" class="text-right"><?php if(ABS($canet)>0 && ABS($wcnet)>0){echo number_format(ABS($canet/$wcnet),2);}else{echo '0.00';}?></td>
<td width="16.16%" class="text-right"><?php if(ABS($cacval)>0 && ABS($wccval)>0){echo number_format(ABS($cacval/$wccval),2);}else{echo '0.00';}?></td>    
</tr>
<tr>
<td width="50%" style="padding-left:15px;"><b>Debt-to-Equity Ratio</b> (Total Liabilities / Owner's Equity)</td>
<td width="16.16%" class="text-right"><?php if(ABS($lcopval)>0 && ABS($wcopval)>0){echo number_format(ABS($lcopval/$wcopval),2);}else{echo '0.00';}?></td>
<td width="16.16%" class="text-right"><?php if(ABS($lcnet)>0 && ABS($wcnet)>0){echo number_format(ABS($lcnet/$wcnet),2);}else{echo '0.00';}?></td>
<td width="16.16%" class="text-right"><?php if(ABS($lccval)>0 && ABS($wccval)>0){echo number_format(ABS($lccval/$wccval),2);}else{echo '0.00';}?></td>   
</tr>    
</tbody>    
</table>    