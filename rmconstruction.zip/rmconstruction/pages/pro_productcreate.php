<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/imgpro.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('14','creates','R');    
$_SESSION['cuPages']='pro_productcreate.php';   
$cuPage='pro_productcreate.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='product';
$menuh='Product Process';
$phead='procre';
$page='Add Product';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['save_item'])){
	$name = ucwords(remove_junk(escape($_POST['name'])));
    $code = get_genid('PU','ABA');
    $preid = remove_junk(escape($_POST['preid']));
    if($preid==''){$preid='NULL';}else{$preid="'".$preid."'";}
    $catid = remove_junk(escape($_POST['catid']));
    if($catid==''){$catid='NULL';}else{$catid="'".$catid."'";}
    $scatid = remove_junk(escape($_POST['scatid']));
    if($scatid==''){$scatid='NULL';}else{$scatid="'".$scatid."'";}
    $braid = remove_junk(escape($_POST['braid']));
    if($braid==''){$braid='NULL';}else{$braid="'".$braid."'";}
    $manid = remove_junk(escape($_POST['manid']));
    if($manid==''){$manid='NULL';}else{$manid="'".$manid."'";}
    $unid = remove_junk(escape($_POST['unid']));
    if($unid==''){$unid='NULL';}else{$unid="'".$unid."'";}
    $couid = remove_junk(escape($_POST['couid']));
    if($couid==''){$couid='NULL';}else{$couid="'".$couid."'";}
    $cost = remove_junk(escape($_POST['cost']));
    $price = remove_junk(escape($_POST['price']));
    $wday = remove_junk(escape($_POST['wday']));
    $pmod = remove_junk(escape($_POST['pmode']));
    $modelno = remove_junk(escape($_POST['model']));
    $brandno = remove_junk(escape($_POST['brandno']));
    $minst = remove_junk(escape($_POST['minst']));
    $barcode = remove_junk(escape($_POST['barcode']));
    $certi = remove_junk(escape($_POST['certi']));    
    $item = PATHINFO($_FILES["item"]["name"]);
    $status = remove_junk(escape($_POST['status']));   
    $description = remove_junk(escape($_POST['description']));
	
	if(isset($_POST['name'])){
    $sql="SELECT * FROM tbl_item WHERE name = '$name'";           
	$ducode = mysqli_query($con,$sql);
	}
	
	if($ducode->num_rows > 0) {
	save_msg('i','Product name alrady exists! Plz try another');
	echo "<script>window.location='pro_productcreate.php'</script>";
	}else{    
    $sql="INSERT INTO tbl_item(code,name,description,prid,catid,scatid,brid,manid,unid,couid,minstock,barcode,certificate,modelno,brandno,cost,price,wday,pmod,status,uid,date) VALUES ('$code','$name','$description',$preid,$catid,$scatid,$braid,$manid,$unid,$couid,'$minst','$barcode','$certi','$modelno','$brandno','$cost','$price','$wday','$pmod','$status','$aid','$dtnow')";
    
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $pid=$con->insert_id;    
    $efid=mysqli_affected_rows($con);    
    if($efid>0){
    if (!empty($_FILES["item"]["name"])){
    get_upload($pid,$_FILES['item'],'P');
    }
    $act =remove_junk(escape('Product name: '.$name));    
    write_activity($aid,'ITM','New product has been created',$act);    
    save_msg('s','Data Successfully Saved!');
    }else{
    save_msg('w','Data Fail to Saved!');   
    }
    echo "<script>window.location='pro_productcreate.php'</script>";     
	}  
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Add Product</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="pro_productcreate.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">    
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">    

<div class="row">
<div class="col-md-9">    
<div class="form-group">
<label>Name</label>
<input type="text" name="name" maxlength="65" value="" id="name" class="form-control" placeholder="e.g. Denim"/>
</div>
</div>
<div class="col-md-3">    
<div class="form-group">
<label>Code</label>
<input type="text" name="code" maxlength="45" value="<?php echo get_genid('PU','ABA');?>" id="code" class="form-control" placeholder="e.g. Mr.Sumon" readonly/>
</div>
</div>    
</div>    

<div class="row">
<div class="col-md-4">    
<div class="form-group">
<label>Parent (Optional)</label>
<div class="input-group">    
<select class="form-control select2" name="preid" id="preid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_parent ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>
<span class="input-group-addon"><a href="pro_parentcreate.php"><span class="fa fa-plus"></span></a></span>     
</div>    
</div>
</div>
<div class="col-md-4">    
<div class="form-group">
<label>Category</label>
<div class="input-group">    
<select class="form-control select2" name="catid" id="catid" onchange="getAllSubgroup(this.value)">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_category ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>
<span class="input-group-addon"><a href="pro_categorycreate.php"><span class="fa fa-plus"></span></a></span>     
</div>    
</div>
</div>
<div class="col-md-4">    
<div class="form-group">
<label>Sub-Category</label>    
<div class="input-group">    
<select class="form-control select2" name="scatid" id="scatid">
<option value="">-Select-</option>
    
</select>
<span class="input-group-addon"><a href="pro_subcategorylist.php"><span class="fa fa-plus"></span></a></span> 
</div>    
</div>
</div>    
</div>     

<div class="row">
<div class="col-md-4">    
<div class="form-group">
<label>Brand</label>
<div class="input-group">    
<select class="form-control select2" name="braid" id="braid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_brand ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>
<span class="input-group-addon"><a href="mas_brandcreate.php"><span class="fa fa-plus"></span></a></span>    
</div>    
</div>
</div>
<div class="col-md-4">    
<div class="form-group">
<label>Manufacturer</label>
<div class="input-group">    
<select class="form-control select2" name="manid" id="manid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_manfacturer ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>    
</select>
<span class="input-group-addon"><a href="mas_mancreate.php"><span class="fa fa-plus"></span></a></span>    
</div>    
</div>
</div>
<div class="col-md-4">    
<div class="form-group">
<label>Unit</label>
<div class="input-group">     
<select class="form-control select2" name="unid" id="unid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_unit ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>    
</select>
<span class="input-group-addon"><a href="mas_unitcreate.php"><span class="fa fa-plus"></span></a></span>    
</div>    
</div>
</div>    
</div>    
    
<div class="row">
<div class="col-md-4">    
<div class="form-group">
<label>Purchase Scan</label>   
<select class="form-control" name="pmode" id="pmode">
<option value="">-Select-</option>
<option value="0">Barcode</option>
<option value="1">Serial</option>
<option value="2">IMEI</option>
</select>        
</div>
</div>
<div class="col-md-4">    
<div class="form-group">
<label>Country</label>
<div class="input-group">    
<select class="form-control select2" name="couid" id="couid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_country ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>    
</select>
<span class="input-group-addon"><a href="mas_countrycreate.php"><span class="fa fa-plus"></span></a></span>    
</div>    
</div>
</div>
<div class="col-md-4">    
<div class="form-group">
<label>Status</label>
<select class="form-control select2" name="status" id="status">
<option value="1">Active</option>
<option value="0">De-Active</option>    
</select>
</div>    
</div>
</div>
<div class="row">
<div class="col-md-8">
<div class="form-group">
<label>Certificate</label>
<input type="text" maxlength="100" value="" name="certi" id="certi" class="form-control" placeholder="e.g. ISO:9901"/>
</div>
</div>
<div class="col-md-4">
<div class="form-group">
<label>Minimum Stock</label>
<input type="text" maxlength="6" class="form-control" min="0" value="0" name="minst" id="minst" onkeypress="return isNumberKey(event)" autocomplete="off">
</div>    
</div>    
</div>    
<div class="row">
<div class="col-md-4">
<div class="form-group">
<label>Model No</label>
<input type="text" maxlength="25" class="form-control" name="model" id="model" autocomplete="off">
</div>
<div class="form-group">
<label>Cost</label>
<input type="text" maxlength="6" class="form-control" min="0" value="0" name="cost" id="cost" onkeypress="return isNumberKey(event)" autocomplete="off">
</div>
<div class="form-group">
<label>Warranty Days</label>
<input type="text" maxlength="4" class="form-control" min="0" value="0" name="wday" onkeypress="return isNumberKey(event)" autocomplete="off">
</div>        
</div>
<div class="col-md-4">
<div class="form-group">
<label>Brand No</label>
<input type="text" maxlength="25" class="form-control" name="brandno" id="brandno" autocomplete="off">   
</div>
<div class="form-group">
<label>Price</label>
<input type="text" maxlength="6" class="form-control" min="0" value="0" name="price" id="price" onkeypress="return isNumberKey(event)" autocomplete="off">
</div>
<div class="form-group">
<label>Barcode (Optional)</label>
<input type="text" maxlength="25" class="form-control" name="barcode" id="barcode" autocomplete="off">
</div>    
</div>    
<div class="col-md-4">
<div class="form-group">
<label>Image</label>
<div style="width:200px; height:245px;">
<img src="../img/product/no_image.png" id="profile-img-tag" style="width: 100%; height: 100%; object-fit: contain;">
</div>
<br>    
<input type="file" class="btn btn-file bg-purple btn-sm" name="item" id="profile-img" accept=".png, .gif, .jpg, .jpeg">
    
</div>         
</div>    
</div>    
<div class="row">
<div class="col-md-12">     
<div class="form-group">
<label>Description</label>
<textarea class="form-control" maxlength="250" rows="6" name="description" placeholder="Description"></textarea>
</div>
</div>    
</div>    
</div>    
    
<div class="col-md-1"></div>    
</div>    
</div>    
</div>
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="save_item" id="submit" class="btn btn-flat bg-purple btn-sm " value="Save"/> <a href="pro_productlist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'ITM','A');}else{echo read_activity($aid,'ITM','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function (){ 
var name = new LiveValidation('name');
name.add(Validate.Presence);
var pmode = new LiveValidation('pmode');
pmode.add(Validate.Presence);    
var unid = new LiveValidation('unid');
unid.add(Validate.Presence);    
});
    
function getAllSubgroup(id){
$.ajax({
url: 'axe_getsub.php',
type: 'post',
data: {subcat : id},
success:function(data) {
$('#scatid').html(data);
}
});
};
    
function readURL(input) {
if (input.files && input.files[0]) {
var reader = new FileReader();
            
reader.onload = function (e) {
$('#profile-img-tag').attr('src', e.target.result);
}
reader.readAsDataURL(input.files[0]);
}
}
$("#profile-img").change(function(){
readURL(this);
});
$("#profile-img-tag").click(function() {
$("#profile-img").click();
});    
</script>    
<!-- /page script -->
</html>    