<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
include ('../inc/repfunctions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
$today = strftime("%Y-%m-%d", time());    
$dtnow = date("Y-m-d h:i:s", time());    
}else{
header('Location:../index.php');
exit;    
}

if(isset($_POST['addoffer'])){
$unqid=$_POST['addoffer'];
$ofid=intval($_POST['ofid']);    
add_offer($unqid,$ofid);    
}

if(isset($_POST['remove'])){
$ids = floatval($_POST['remove']);
remove_offer($ids);
$max=count($_SESSION['axes_offer']);    
if($max <= 0){
unset($_SESSION['axes_offer']);    
}    
}

if(isset($_POST['clear'])){
if(isset($_SESSION['axes_offer'])){
unset($_SESSION['axes_offer']);   
}
}

if(isset($_POST['saveoff'])){
$efids=0;    
if(!isset($_SESSION['axes_offer'])){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! No offer item found!!'
));
return;
exit;  
}

$max=count($_SESSION['axes_offer']);
for($i=0;$i<$max;$i++){
$unqid=$_SESSION['axes_offer'][$i]['unqid'];
$ofid=$_SESSION['axes_offer'][$i]['ofid'];
$sql="UPDATE tbl_stock SET ofid='$ofid' WHERE unqid='$unqid'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);
if($efid>0){
$efids+=1;    
}    
}    
if($efids>0){
unset($_SESSION['axes_offer']);    
$act =remove_junk(escape('Offer set on item:-'));    
write_activity($aid,'OFF','Item Offer set Successfully',$act);
echo json_encode(array(
'status' => 'success',
'message'=> 'Offer Save Successfully!!'   
));
exit;     
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));    
}    
}