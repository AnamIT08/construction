<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];   
}else{
header('Location:../index.php');
exit;    
}
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php
if(isset($_POST['ibrid']) && $_POST['ibrid']!=''){
$ibrid=$_POST['ibrid'];    
}else{
$ibrid=$brid;    
}
?>
<style>
    .bussiness_insights .info-box-number{
        font-size: 15px;
        text-transform: uppercase;
    }

    .new_accounts_count_box .info-box{
        background-color: #eee;
        border: 1px solid #bbb;
        box-shadow: none;
        border-radius: 0px;
        border-left: 5px solid #a8cf46;
    }
    .deleted_count_box .info-box{
        background-color: #eee;
        border: 1px solid #bbb;
        box-shadow: none;
        border-radius: 0px;
        border-left: 5px solid darkorange;
    }
    .non_perform_count_box .info-box{
        background-color: #eee;
        border: 1px solid #bbb;
        box-shadow: none;
        border-radius: 0px;
        border-left: 5px solid #00a65a;
    }
    .sales_count_box .info-box{
        box-shadow: none;
        border-radius: 0px;
    }
    .new_accounts_count_box .info-box .info-box-number,
    .non_perform_count_box .info-box .info-box-number,
    .deleted_count_box .info-box .info-box-number{
        color: #333;
        font-size: 16px;
    }
    .new_accounts_count_box .info-box .progress-description,
    .non_perform_count_box .info-box .progress-description,
    .deleted_count_box .info-box .progress-description {
        color: #00a2e1;
        text-transform: uppercase;
        font-size: 13px;
    }
    .top_receivables_table td,.top_payables_table td{
        font-size: 12px;
    }
    .sales_count_box .info-box :hover{
        background: #00305d;
    }
    .new_accounts_count_box .info-box:hover,
    .non_perform_count_box .info-box:hover,
    .deleted_count_box .info-box:hover{
background: #ccc;
    }
</style>
<section class="col-lg-12 bussiness_insights">
    <div class="box ">
        <div class="box-header">
            <i class="fa fa-signal"></i>
            <h3 class="box-title">
                Business Insights
            </h3>
        </div>
        <div class="box-body">
            <div class="row">
                <form action="" id="bussiness_insight_form" onsubmit="return business_insights()" method="post" accept-charset="utf-8">
                <div class="col-md-12  table-responsive">
                    <table class="chart_filter">
                        <tr>
<td>
<select name="bussiness_insight_branch" id="bussiness_insight_branch" class="form-control text-uppercase" onchange="bussiness_insight_members()">
<option <?php if($ibrid=='A'){echo 'selected';}?> value="A">-All Branch-</option>
<option <?php if($ibrid=='0'){echo 'selected';}?> value="0">-Main Branch-</option>    
<?php    
$querybr=mysqli_query($con,"SELECT id,name FROM tbl_branch ORDER BY name ASC")or die(mysqli_error($con));
while ($rowbr=mysqli_fetch_array($querybr)){
?>
<?php if($rowbr['id']==$ibrid){?>
<option selected value="<?php echo $rowbr['id'];?>"><?php echo $rowbr['name'];?></option>
<?php }else{ ?>    
<option value="<?php echo $rowbr['id'];?>"><?php echo $rowbr['name'];?></option>
<?php } ?>    
<?php } ?>
</select>
</td>
<td style=""><select name="bussiness_insight_member" id="bussiness_insight_member" class="form-control text-uppercase">
<?php    
$query=mysqli_query($con,"SELECT id,name FROM tbl_user ORDER BY name ASC")or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
?>
<?php if($row['id']==$aid){?>
<option selected value="<?php echo $row['id'];?>"><?php echo $row['name'];?></option>
<?php }else{ ?>    
<option value="<?php echo $row['id'];?>"><?php echo $row['name'];?></option>
<?php } ?>    
<?php } ?>
</select>
</td>
                            <td style="width: 123px;">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                    <input type="text" value="01-02-2020" id="bussiness_insight_date_from" class="form-control filter_date" placeholder="FROM DATE" readonly="true"  />
                                </div>
                            </td>
                            <td style="width: 123px;">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                    <input type="text" value="11-02-2020" id="bussiness_insight_date_to" class="form-control filter_date" placeholder="TO DATE" readonly="true"  />
                                </div>
                            </td>
                            <td><input type="submit" value="Search" id="bussiness_insight_submit" class="btn btn-flat bg-purple "  />
</td>
                        </tr>
                    </table>
                    <hr>
                </div>
                </form>            </div>
            <div class="row" >
                <div class="col-md-4 sales_count_box">
                    <div class="row">
                        <div class="col-md-6">
                            <a href="javascript:" data-type="sales" data-fn="totals" class="box_link"> 
                                <div class="info-box bg-light-blue" style="min-height:inherit">
                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Sales</span>
                                        <span class="progress-description bussiness_insights_total_sales" ></span>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6">
                            <a href="javascript:" data-type="sales" data-fn="totals" class="box_link"> 
                                <div class="info-box bg-light-blue" style="min-height:inherit">
                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number"><i class="fa fa-money" aria-hidden="true"></i> Sales Margin</span>
                                        <span class="progress-description bussiness_insights_total_margin" ></span>
                                    </div>
                                </div>
                            </a>
                        </div>  
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="javascript:" data-type="sales"  data-fn="totals" class="box_link"> 
                                <div class="info-box bg-light-blue" style="min-height:inherit">
                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number"><i class="fa fa-money" aria-hidden="true"></i> Commission Received</span>
                                        <span class="progress-description bussiness_insights_commission_received" ></span>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6">
                            <a href="javascript:" data-type="sales"  data-fn="totals" class="box_link"> 
                                <div class="info-box bg-light-blue" style="min-height:inherit">
                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number"><i class="fa fa-money" aria-hidden="true"></i> Commission Paid</span>
                                        <span class="progress-description bussiness_insights_commission_paid" ></span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <a href="javascript:" data-type="receipt_total"  data-fn="totals" class="box_link"> 
                                <div class="info-box bg-light-blue" style="min-height:inherit">
                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number"><i class="fa fa-money" aria-hidden="true"></i> Receipts</span>
                                        <span class="progress-description bussiness_insights_total_receipts" ></span>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6">
                            <a href="javascript:" data-type="payment_total"  data-fn="totals" class="box_link"> 
                                <div class="info-box bg-light-blue" style="min-height:inherit" >
                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number"><i class="fa fa-credit-card" aria-hidden="true"></i> Payments</span>
                                        <span class="progress-description bussiness_insights_payments" ></span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 bussiness_insights_receivables"></div>
                <div class="col-md-4 bussiness_insights_payables"></div>
            </div>
            <div class="row" >
                <div class="col-md-12"><hr></div>
                <div class="col-md-4 new_accounts_count_box">
                    <div class="row">
                        <div class="col-md-6">
                            <a href="javascript:" data-type="customer" data-fn="new_acc" class="box_link"> 
                                <div class="info-box " style="min-height:inherit;">
                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number customer_new_count">0</span>
                                        <span class="progress-description" ><i class="fa fa-user" aria-hidden="true"></i> New Customers</span>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6">
                            <a href="javascript:" data-type="supplier" data-fn="new_acc" class="box_link"> 
                                <div class="info-box " style="min-height:inherit">
                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number supplier_new_count">0</span>
                                        <span class="progress-description" ><i class="fa fa-user" aria-hidden="true"></i> New Suppliers</span>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6">
                            <a href="javascript:" data-type="hotel" data-fn="new_acc" class="box_link"> 
                                <div class="info-box " style="min-height:inherit">
                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number hotel_new_count">0</span>
                                        <span class="progress-description" ><i class="fa fa-hotel" aria-hidden="true"></i> New Hotels</span>
                                    </div>

                                </div>
                            </a>
                        </div>
                        <div class="col-md-6">
                            <a href="javascript:" data-type="airline" data-fn="new_acc" class="box_link"> 
                                <div class="info-box " style="min-height:inherit">

                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number airline_new_count">0</span>
                                        <span class="progress-description" ><i class="fa fa-plane" aria-hidden="true"></i>  New Airlines</span>
                                    </div>

                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 non_perform_count_box">
                    <div class="row">
                        <div class="col-md-6">
                            <a href="javascript:" data-type="customer" data-fn="non_perf" class="box_link"> 
                                <div class="info-box " style="min-height:inherit">
                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number non_perform_cus">0</span>
                                        <span class="progress-description" ><i class="fa fa-user" aria-hidden="true"></i> Non Performing Customers</span>
                                    </div>

                                </div>
                            </a>
                        </div>
                        <div class="col-md-6">
                            <a href="javascript:" data-type="supplier" data-fn="non_perf" class="box_link"> 
                                <div class="info-box " style="min-height:inherit">
                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number non_perform_sup">0</span>
                                        <span class="progress-description" ><i class="fa fa-user" aria-hidden="true"></i> Non Performing Suppliers</span>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6">
                            <a href="javascript:" data-type="hotel" data-fn="non_perf" class="box_link"> 
                                <div class="info-box " style="min-height:inherit">
                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number non_perform_hotels">0</span>
                                        <span class="progress-description" ><i class="fa fa-hotel" aria-hidden="true"></i> Non Performing Hotels</span>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6">
                            <a href="javascript:" data-type="airline" data-fn="non_perf" class="box_link"> 
                                <div class="info-box " style="min-height:inherit">
                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number non_perform_airlines">0</span>
                                        <span class="progress-description" ><i class="fa fa-plane" aria-hidden="true"></i> Non Performing Airlines</span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 deleted_count_box">
                    <div class="row">
                        <div class="col-md-6">
                            <a href="javascript:" data-type="sales" data-fn="deleted" class="box_link"> 
                                <div class="info-box " style="min-height:inherit">
                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number deleted_sales">0</span>
                                        <span class="progress-description" ><i class="fa fa-trash" aria-hidden="true"></i> Deleted Sales</span>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6">
                            <a href="javascript:" data-type="refunds" data-fn="deleted" class="box_link"> 
                                <div class="info-box " style="min-height:inherit">
                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number deleted_refunds">0</span>
                                        <span class="progress-description" ><i class="fa fa-trash" aria-hidden="true"></i> Deleted Refunds</span>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-6">
                            <div class="info-box " style="min-height:inherit">
                                <div class="info-box-content" style="margin-left: 0px">
                                    <span class="info-box-number deleted_receipts">0</span>
                                    <span class="progress-description" ><i class="fa fa-trash" aria-hidden="true"></i> Deleted (<a style="font-size: 9px" href="javascript:" data-type="receipts" data-fn="deleted" class="box_link">Sales Receipts</a>, <a style="font-size: 9px" href="javascript:" title="Other Receipts" data-type="acc_receipts" data-fn="deleted" class="box_link">Other Receipts</a>)</span>
                                </div>
                            </div>

                        </div>
                        <div class="col-md-6">
                            <a href="javascript:" data-type="payments" data-fn="deleted" class="box_link"> 
                                <div class="info-box " style="min-height:inherit">
                                    <div class="info-box-content" style="margin-left: 0px">
                                        <span class="info-box-number deleted_payments">0</span>
                                        <span class="progress-description" ><i class="fa fa-trash" aria-hidden="true"></i> Deleted Payments</span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div> 
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    $(document).ready(function () {
        setTimeout(function () {
            business_insights();
        }, 500);
        $('.bussiness_insights .filter_date').datepicker({format: "dd-mm-yyyy", autoclose: true, clearBtn: true, orientation: 'auto bottom', });

        $('.box_link').click(function () {
            redirect_accounts($(this));
            return false;
        });

    })
    function business_insights() {
        $('#bussiness_insight_submit').val('Loading..');
        $('#bussiness_insight_submit').prop('disabled', true);
        var error = '';
        var branch = $('#bussiness_insight_form').find('#bussiness_insight_branch').val();
        var member = $('#bussiness_insight_form').find('#bussiness_insight_member').val();
        var date_from = $('#bussiness_insight_form').find('#bussiness_insight_date_from').val();
        var date_to = $('#bussiness_insight_form').find('#bussiness_insight_date_to').val();
        if (!checkValueExists(branch))
            error = error + 'Branch is required<br>';
        if (!checkValueExists(date_from))
            error = error + 'Date from is required<br>';
        if (!checkValueExists(date_to))
            error = error + 'Date to is required<br>';
        if (!error) {
            var total_sales = '0.00';
            var total_margin = '0.00';
            var commission_received = '0.00';
            var commission_paid = '0.00';
            var total_receipts = '0.00';
            var total_payments = '0.00';
            var receivables = '';
            var payables = '';
            $.ajax({
                type: "POST",
                url: "axe_businsight.php",
                cache: false,
                dataType: 'json',
                data: {'branch': branch, 'member': member, 'date_from': date_from, 'date_to': date_to},
                timeout: 15000,
                success: function (data)
                {

                    if (data) {
                        if (data['totals']) {
                            total_sales = data['totals']['cus_total'];
                            total_margin = data['totals']['cus_margin'];
                            commission_received = data['totals']['sup_commission_rvd'];
                            commission_paid = data['totals']['cus_commisson_paid'];
                            total_receipts = data['totals']['total_receipts'];
                            total_payments = data['totals']['total_payments'];


                        }
                        if (data['outstanding']) {
                            receivables = data['outstanding']['receivables'];
                            payables = data['outstanding']['payables'];
                        }
                    }
                    $('.bussiness_insights .bussiness_insights_total_sales').text(total_sales);
                    $('.bussiness_insights .bussiness_insights_total_margin').text(total_margin);
                    $('.bussiness_insights .bussiness_insights_commission_received').text(commission_received);
                    $('.bussiness_insights .bussiness_insights_commission_paid').text(commission_paid);
                    $('.bussiness_insights .bussiness_insights_total_receipts').text(total_receipts);
                    $('.bussiness_insights .bussiness_insights_payments').text(total_payments);

                    $('.bussiness_insights .bussiness_insights_receivables').html(receivables);
                    $('.bussiness_insights .bussiness_insights_payables').html(payables);

                    $('.bussiness_insights .customer_new_count').text(data['new_accounts']['customers']);
                    $('.bussiness_insights .supplier_new_count').text(data['new_accounts']['suppliers']);
                    $('.bussiness_insights .hotel_new_count').text(data['new_accounts']['hotels']);
                    $('.bussiness_insights .airline_new_count').text(data['new_accounts']['airlines']);

                    $('.bussiness_insights .non_perform_cus').text(data['non_perf_accounts']['customers']);
                    $('.bussiness_insights .non_perform_sup').text(data['non_perf_accounts']['suppliers']);
                    $('.bussiness_insights .non_perform_hotels').text(data['non_perf_accounts']['hotels']);
                    $('.bussiness_insights .non_perform_airlines').text(data['non_perf_accounts']['airlines']);

                    $('.bussiness_insights .deleted_sales').text(data['deleted_items']['sales']);
                    $('.bussiness_insights .deleted_receipts').text(data['deleted_items']['receipts']);
                    $('.bussiness_insights .deleted_payments').text(data['deleted_items']['payments']);
                    $('.bussiness_insights .deleted_refunds').text(data['deleted_items']['refunds']);

                    $('.bussiness_insights .supplier_new_count').html(0);

                    $('#bussiness_insight_submit').val('Search');
                    $('#bussiness_insight_submit').prop('disabled', false);
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log(textStatus);
                    $('.bussiness_insights .bussiness_insights_total_sales').text(total_sales);
                    $('.bussiness_insights .bussiness_insights_total_margin').text(total_margin);
                    $('.bussiness_insights .bussiness_insights_commission_received').text(commission_received);
                    $('.bussiness_insights .bussiness_insights_commission_paid').text(commission_paid);
                    $('.bussiness_insights .bussiness_insights_total_receipts').text(total_receipts);
                    $('.bussiness_insights .bussiness_insights_payments').text(total_payments);

                    $('.bussiness_insights .bussiness_insights_receivables').html('');
                    $('.bussiness_insights .bussiness_insights_payables').html('');

                    $('.bussiness_insights .customer_new_count').text(0);
                    $('.bussiness_insights .supplier_new_count').text(0);
                    $('.bussiness_insights .hotel_new_count').text(0);
                    $('.bussiness_insights .airline_new_count').text(0);

                    $('.bussiness_insights .non_perform_cus').text(0);
                    $('.bussiness_insights .non_perform_sup').text(0);
                    $('.bussiness_insights .non_perform_hotels').text(0);
                    $('.bussiness_insights .non_perform_airlines').text(0);

                    $('.bussiness_insights .deleted_sales').text(0);
                    $('.bussiness_insights .deleted_receipts').text(0);
                    $('.bussiness_insights .deleted_payments').text(0);
                    $('.bussiness_insights .deleted_refunds').text(0);

                    $('#bussiness_insight_submit').val('Search');
                    $('#bussiness_insight_submit').prop('disabled', false);
                }

            });
        } else {
            toaster(error);
            $('#bussiness_insight_submit').val('Search');
            $('#bussiness_insight_submit').prop('disabled', false);
        }
        return false;
    }
    function bussiness_insight_members()
    {
        var branch = $('#bussiness_insight_form').find('#bussiness_insight_branch').val();
        $('#bussiness_insight_member').html('<option value="">Loading..</option>');
        $.ajax({
            type: "POST",
            url: "get_members.php",
            cache: false,
            data: {'branch': branch},
            timeout: 15000,
            success: function (data)
            {
                $('#bussiness_insight_member').html(data);
            },
            error: function (jqXHR, textStatus, errorThrown) {
                $('#bussiness_insight_member').html('<option value="">Error</option>');
            }
        });
    }
    function redirect_sales_count_box(type) {
        var branch = $('#bussiness_insight_form').find('#bussiness_insight_branch').val();
        var member = $('#bussiness_insight_form').find('#bussiness_insight_member').val();
        var date_from = $('#bussiness_insight_form').find('#bussiness_insight_date_from').val();
        var date_to = $('#bussiness_insight_form').find('#bussiness_insight_date_to').val();

        if (type == 'sale_total' || type == 'sale_margin' || type == 'sale_commission_rvd' || type == 'sale_commission_paid') {
            var url = "load_from_dashboard.php" + '?branch=' + branch + '&member=' + member + '&date_from=' + date_from + '&date_to=' + date_to;
            var data = {'src': url, 'title': 'Sales List', 'callback': ''}

            popup_open(data);
        } else if (type == 'receipt_total' || type == 'payment_total') {

            var url = "load_from_dashboard.php" + '?branch=' + branch + '&member=' + member + '&date_from=' + date_from + '&date_to=' + date_to + '&trn_type=' + type;

            var data = {'src': url, 'title': 'Receipts & Payments', 'callback': ''}
            popup_open(data);
        }
    }
    function redirect_accounts(obj) {
        var fn = $(obj).data('fn');
        var type = $(obj).data('type');

        var branch = $('#bussiness_insight_form').find('#bussiness_insight_branch').val();
        var member = $('#bussiness_insight_form').find('#bussiness_insight_member').val();
        var date_from = $('#bussiness_insight_form').find('#bussiness_insight_date_from').val();
        var date_to = $('#bussiness_insight_form').find('#bussiness_insight_date_to').val();

        if (fn == 'totals') {
            if (type == 'sales') {
                var url = "load_from_dashboard.php" + '?branch=' + branch + '&member=' + member + '&date_from=' + date_from + '&date_to=' + date_to + '&show_type=1';
                ;
                var data = {'src': url, 'title': 'Sales List', 'callback': ''}

                popup_open(data);

            } else if (type == 'receipt_total' || type == 'payment_total') {
                var url = "load_from_dashboard.php" + '?branch=' + branch + '&member=' + member + '&date_from=' + date_from + '&date_to=' + date_to + '&trn_type=' + type;
                var data = {'src': url, 'title': 'Receipts & Payments', 'callback': ''}
                popup_open(data);
            }
        } else if (fn == 'new_acc') {

            var url = "acc_links.php" + '?branch=' + branch + '&member=' + member + '&date_from=' + date_from + '&date_to=' + date_to + '&trn_type=' + type + '&sub_type=' + fn;
            var data = {'src': url, 'title': 'List', 'callback': ''}
            popup_open(data);



        } else if (fn == 'non_perf') {
            var url = "acc_links.php" + '?branch=' + branch + '&member=' + member + '&date_from=' + date_from + '&date_to=' + date_to + '&trn_type=' + type + '&sub_type=' + fn;
            var data = {'src': url, 'title': 'List', 'callback': ''}
            popup_open(data);
        } else if (fn == 'deleted') {

            var url = "deleted_trns.php" + '?branch=' + branch + '&member=' + member + '&date_from=' + date_from + '&date_to=' + date_to + '&trn_type=' + type + '&sub_type=' + fn;
            var data = {'src': url, 'title': 'List', 'callback': ''}

            popup_open(data);

        }

    }


</script>
