<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('33','views','R');    
$_SESSION['cuPages']='fin_accanalysis.php';   
$cuPage='fin_accanalysis.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='financ';
$menuh='Financials';
$phead='finanal';
$page='Finace Analysis';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">

</script>    
<!-- /page script -->
</html>    