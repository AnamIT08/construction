<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
$body='';
$foot='';
$buton='';
$s=0;
$totqty=0;

if(isset($_SESSION['axes_edsales'])){
if(is_array($_SESSION['axes_edsales'])){
$max=count($_SESSION['axes_edsales']);
for($i=($max-1);$i>=0;$i=$i-1){
$unqid=$_SESSION['axes_edsales'][$i]['unqid'];
$pid=$_SESSION['axes_edsales'][$i]['pid'];    
$code=$_SESSION['axes_edsales'][$i]['code'];
$name=$_SESSION['axes_edsales'][$i]['name'];
$unit=$_SESSION['axes_edsales'][$i]['unid'];
$col=$_SESSION['axes_edsales'][$i]['col'];
if($col==0){$col='';}    
$siz=$_SESSION['axes_edsales'][$i]['siz'];
if($siz==0){$siz='';}    
$imei=$_SESSION['axes_edsales'][$i]['imei'];
$check=$_SESSION['axes_edsales'][$i]['check'];    
$cost=$_SESSION['axes_edsales'][$i]['cost']; 
$qty=$_SESSION['axes_edsales'][$i]['qty'];
$price=$_SESSION['axes_edsales'][$i]['price'];
$disp=$_SESSION['axes_edsales'][$i]['disp'];
$disf=$_SESSION['axes_edsales'][$i]['disf'];    
$disamo=$_SESSION['axes_edsales'][$i]['disamo'];
$wday=$_SESSION['axes_edsales'][$i]['wday'];
$pnote=$_SESSION['axes_edsales'][$i]['pnote'];    
$subtot=$_SESSION['axes_edsales'][$i]['subtot'];

if($col=='' && $siz==''){
$name=$name;    
}elseif($col!='' && $siz==''){
$name= $name.' '.get_fild_data('tbl_color',$col,'name');    
}elseif($col=='' && $siz!=''){
$name= $name.' '.get_fild_data('tbl_size',$siz,'sval');    
}elseif($col!='' && $siz!=''){    
$name= $name.' '.get_fild_data('tbl_color',$col,'name').' '.get_fild_data('tbl_size',$siz,'sval');    
}    
$s+=1;
$totqty+=$qty;    

$body.='<tr>';
$body.='<td class="text-center" width="30px">'.$s.'</td>';    
$body.='<td data-toggle="collapse" data-target="#sitem'.$i.'" class="accordion-toggle" style="cursor: pointer;" width="214px">'.$name.'</td>';
$body.='<td width="72px"><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control quantity" id="qty_'.$i.'" value="'.$qty.'"  size="2" style="height: 24px;"/></td>';
$body.='<td width="72px"><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control price" id="price_'.$i.'" value="'.$price.'"  size="2" style="height: 24px;"/></td>';
if($check==1){    
$body.='<td class="text-center" width="35px"><input type="checkbox" class="bscan" id="bscan_'.$i.'" value="'.$unqid.'" name="radio-group" checked /></td>';
}else{
$body.='<td class="text-center" width="35px"><input type="checkbox" class="bscan" id="bscan_'.$i.'" value="'.$unqid.'" name="radio-group" /></td>';    
}
$body.='<td width="77px" id="stotal_'.$i.'" class="text-right">'.getfloatval($subtot).'</td>';
$body.='<td class="text-center" width="25px"><a id="'.$i.'" class="remove"><span style="cursor: pointer;" class="fa fa-times"></span></a></td>';    
$body.='</tr>';
    
$body.='<tr>';
$body.='<td colspan="7" class="hiddenRow"><div class="accordian-body collapse" id="sitem'.$i.'">';
$body.='<table class="table table-bordered table-striped" style="margin-bottom: 0;">';
$body.='<thead>';
$body.='<tr>';
$body.='<th colspan="3" rowspan="2" class="text-center" width="316px">Product Note</th>';   
$body.='<th colspan="4" class="text-center" width="316px">Sales Discount</th>';    
$body.='</tr>';
$body.='<tr>';
$body.='<th class="text-center" width="72px">Percent(%)</th>';
$body.='<th class="text-center" width="72px">Fixed</th>';
$body.='<th colspan="2" class="text-center">Total</th>';    
$body.='</tr>';
$body.='</thead>';
$body.='<tbody>';
$body.='<tr>';
$body.='<td colspan="3"><input type="text" maxlength="45" class="form-control pnote" id="pnote_'.$i.'" value="'.$pnote.'"  size="2" style="height: 24px;"/></td>';    
$body.='<td><input type="text" min="0" onkeypress="return isNumberKey(event)" class="form-control disp" id="disp_'.$i.'" value="'.$disp.'"  size="2" style="height: 24px;"/></td>';
$body.='<td><input type="text" min="0" onkeypress="return isNumberKey(event)" class="form-control disf" id="disf_'.$i.'" value="'.$disf.'"  size="2" style="height: 24px;"/></td>';
$body.='<td id="disamo_'.$i.'" class="text-right">'.$disamo.'</td>';   
$body.='</tr>';    
$body.='</tbody></table></div></td></tr>';     
}    

if($max>0){
if (!isset($_SESSION['axes_edsalesde'])) {
$_SESSION['axes_edsalesde'] = array();
$_SESSION['axes_edsalesde'][0]['disp']=0;
$_SESSION['axes_edsalesde'][0]['disamo']=0;    
$_SESSION['axes_edsalesde'][0]['vatp']=0;
$_SESSION['axes_edsalesde'][0]['vatamo']=0;
$_SESSION['axes_edsalesde'][0]['aitp']=0;
$_SESSION['axes_edsalesde'][0]['aitamo']=0;
$_SESSION['axes_edsalesde'][0]['name']='Others';
$_SESSION['axes_edsalesde'][0]['others']=0;
$_SESSION['axes_edsalesde'][0]['less']=0;
$_SESSION['axes_edsalesde'][0]['freight']=0;
$_SESSION['axes_edsalesde'][0]['gtotal']=$subtot;    
}
}else{
if(isset($_SESSION['axes_edsalesde'])){
unset($_SESSION['axes_edsalesde']);    
}    
}
if(isset($_SESSION['axes_edsalesde'])){
if(is_array($_SESSION['axes_edsalesde'])){    
$disp=$_SESSION['axes_edsalesde'][0]['disp'];
$vatp=$_SESSION['axes_edsalesde'][0]['vatp'];
$vatamo=$_SESSION['axes_edsalesde'][0]['vatamo'];
$aitp=$_SESSION['axes_edsalesde'][0]['aitp'];
$aitamo=$_SESSION['axes_edsalesde'][0]['aitamo'];
$otname=$_SESSION['axes_edsalesde'][0]['name'];
$others=$_SESSION['axes_edsalesde'][0]['others'];
$less=$_SESSION['axes_edsalesde'][0]['less'];
$freight=$_SESSION['axes_edsalesde'][0]['freight'];
$gtotal=$_SESSION['axes_edsalesde'][0]['gtotal'];    
}else{
$disp=0;
$vatp=0;
$vatamo=0;
$otname='Others';
$others=0;
$less=0;
$freight=0;
$gtotal=0;    
}
}else{
$disp=0;
$vatp=0;
$vatamo=0;
$aitp=0;
$aitamo=0;
$otname='Others';
$others=0;
$less=0;
$freight=0;
$gtotal=0;    
}    

$foot.='<tr>';
$foot.='<td width="30px"></td>';
$foot.='<td width="214px"></td>';
$foot.='<td width="72px"></td>';
$foot.='<td width="72px"></td>';
$foot.='<td width="35px"></td>';
$foot.='<td width="77px"></td>';
$foot.='<td width="25px"></td>';
$foot.='</tr>';    
$foot.='<tr>';
$foot.='<td colspan="2" class="text-center" width="244px"><strong>-Total-</strong></td>';
$foot.='<td width="72px"><strong>'.$totqty.'</strong></td>';
$foot.='<td colspan="2" width="107px"></td>';
$foot.='<td width="77px" class="text-right"><strong>'.getfloatval(get_edsales_total()).'</strong></td>';
$foot.='<td></td>';
$foot.='</tr>';	

if(get_edseldiscount_total()>0){
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>Discount on Item:</strong></td>';
$foot.='<td align="center" colspan="2"></td>';    
$foot.='<td id="disitem" class="text-right"><strong>'.getfloatval(get_edseldiscount_total()).'</strong></td>';
$foot.='<td></td>';    
$foot.='</tr>';	
}
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>Discount (%)</strong></td>';
$foot.='<td colspan="2"><input type="text" maxlength="5" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="discount" value="'.getfloatval($disp).'"  size="2" style="height: 24px;"/></td>';    
$foot.='<td id="disitems" class="text-right"><strong>'.getfloatval(get_edseldiscount_total($disp)-get_edseldiscount_total()).'</strong></td>';
$foot.='<td></td>';
$foot.='</tr>';	
if(get_edseldiscount_total()>0){
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>Total Discount (%)</strong></td>';
$foot.='<td align="center" colspan="2"></td>';    
$foot.='<td id="totdisamo" class="text-right"><strong>'.getfloatval(get_edseldiscount_total($disp)).'</strong></td>';
$foot.='<td></td>';     
$foot.='</tr>';	
}    
if(get_edcbamo_total()>0){
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>Cash Back :</strong></td>';
$foot.='<td align="center" colspan="2"></td>';    
$foot.='<td id="totcbamo" class="text-right"><strong>'.getfloatval(get_edcbamo_total()).'</strong></td>';
$foot.='<td></td>';     
$foot.='</tr>';	
}
    
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>VAT (%)</strong></td>';
$foot.='<td colspan="2"><input type="text" maxlength="5" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="vatp" value="'.getfloatval($vatp).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="vatamo" class="text-right"><strong>'.getfloatval($vatamo).'</strong></td>';
$foot.='<td></td>';    
$foot.='</tr>';
$foot.='<tr>';     
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>AIT (%)</strong></td>';
$foot.='<td colspan="2"><input type="text" maxlength="5" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="aitp" value="'.getfloatval($aitp).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="aitamo" class="text-right"><strong>'.getfloatval($aitamo).'</strong></td>';
$foot.='<td></td>';    
$foot.='</tr>';
$foot.='<tr>';
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><div style="display: inline;"><i class="fa fa-angle-right cart-icon" id="icon"></i></div><span id="otdname"><strong>'.$otname.':</strong></span></td>';
$foot.='<td colspan="2"><input type="text" maxlength="7" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="others" value="'.getfloatval($others).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="othersamo" class="text-right"><strong>'.getfloatval($others).'</strong></td>';
$foot.='<td></td>';    
$foot.='</tr>';
$foot.='<tr class="dshow" style="display: none;">';   
$foot.='<td colspan="3" align="right"><strong>Others Name:</strong></td>';
$foot.='<td colspan="3"><input type="text" maxlength="20" min="0" class="form-control" id="otname" value="'.$otname.'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td></td>';    
$foot.='</tr>';
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>Freight:</strong></td>';
$foot.='<td colspan="2"><input type="text" maxlength="6" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="freight" value="'.getfloatval($freight).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="freightd" class="text-right"><strong>'.getfloatval($freight).'</strong></td>';
$foot.='<td></td>';    
$foot.='</tr>';
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>Fractional Discount:</strong></td>';
$foot.='<td colspan="2"><input type="text" maxlength="6" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="less" value="'.getfloatval($less).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="lessd" class="text-right"><strong>'.getfloatval($less).'</strong></td>';
$foot.='<td></td>';    
$foot.='</tr>';
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>Grand Total:</strong></td>';
$foot.='<td colspan="2"></td>'; 
$foot.='<td id="grtotal" class="text-right"><strong>'.getfloatval($gtotal).'</strong></td>';
$foot.='<td></td>';    
$foot.='</tr>';    
}else{
$body.='<tr>';
$body.='<td colspan="7" class="text-center">There are no Sales Item!</td>';
$body.='</tr>'; 
} 
}else{
$body.='<tr>';
$body.='<td colspan="7" class="text-center">There are no Sales Item!</td>';
$body.='</tr>';
}
    
$body.="<script>";
$body.="$('.accordian-body').on('show.bs.collapse', function () {";
$body.="$(this).closest('table')";
$body.=".find('.collapse.in')";
$body.=".not(this)";
$body.=".collapse('toggle')";
$body.="})";
$body.="</script>";

if(isset($_SESSION['axes_edsales'])){
$buton.='<div class="col-md-6">';
$buton.='<input type="button" id="emptycart" class="btn btn-flat bg-red btn-sm" value="Empty"/>';
$buton.='&nbsp;<input type="button" id="canceledit" class="btn btn-flat bg-red btn-sm" value="Cancel"/></div>';    
$buton.='<div class="col-md-6 text-right">';   
$buton.='<input type="button" id="save_sales" class="btn btn-flat bg-purple btn-sm" value="Checkout"/>'; 
$buton.='</div>';
}

if(isset($_POST['body'])){
echo $body;
}elseif(isset($_POST['foot'])){
echo $foot;
}elseif(isset($_POST['buton'])){
echo $buton;    
}
exit; 