<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='blank_page.php';   
$cuPage='blank_page.php';    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='product';
$menuh='Product';
$phead='prcre';
$page='Parent Create';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
<style>
.slimScrollBar {
    border-radius: 0 !important;
}

.navbar-header {
    position: relative;
}

.navbar-header > .btn {
    position: absolute;
    font-size: 1.3em;
    padding: 9px 16px;
    line-height: 30px;
    left: 0;
}

.navbar-header .navbar-brand + .btn {
    right: 0;
    top: 0;
    left: auto;
}

.navbar-brand {
    float: none;
    text-align: center;
    font-size: 20px;
    line-height: 50px;
    display: inline-block;
    padding: 0 15px;
    font-weight: bold;
}

.navbar-brand:hover {
    text-decoration: none;
}

.navbar-brand img {
    max-height: 20px;
    margin-top: -4px;
    vertical-align: middle;
}

.nav-primary {
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}
   
.bg-light .nav-primary {
    border-bottom: 1px solid #e9e9e9;
}

.nav-primary li {
    line-height: 1.5;
}

.nav-primary .bg-danger {
    background-color: #fb6b5b;
    color: #ffffff;
}    

.nav-primary .bg-warning {
    background-color: #ffc333;
    color: #fff8e6;
}    

.nav-primary .bg-success {
    background-color: #8ec165;
    color: #ebf4e4;
}    

.nav-primary .bg-info {
    background-color: #4cc0c1;
    color: #d1efef;
}    

.nav-primary .bg-primary {
    background-color: #65bd77;
    color: #e2f3e5;
}    

.nav-primary a {
    color: #d7ebf7;
}    
    
.nav-primary li > a > i {
    margin: -12px -15px;
    line-height: 44px;
    width: 44px;
    float: left;
    margin-right: 10px;
    font-size: 14px;
    border-right: 1px solid rgba(255, 255, 255, 0.05);
    text-align: center;
    position: relative;
    overflow: hidden;
}

.nav-primary li > a > i:before {
    position: relative;
    z-index: 2;
}

.nav-primary li > a > i > b {
    position: absolute;
    left: -42px;
    width: 100%;
    top: 0;
    bottom: 0;
    z-index: 0;
    -webkit-transition: left .25s;
    transition: left .25s;
}

.nav-primary ul.nav > li > a {
    padding: 11px 15px;
    position: relative;
    font-weight: bold;
    font-size: 12px;
    border-top: 1px solid transparent;
    border-color: rgba(255, 255, 255, 0.05);
    transition: color .3s ease-in-out 0s;
}

.no-borders .nav-primary ul.nav > li > a {
    border-width: 0 !important;
}

.nav-primary ul.nav > li > a > .badge {
    font-size: 11px;
    padding: 3px 6px;
    margin-top: 2px;
}

.bg-light .nav-primary ul.nav > li > a {
    color: #717171 !important;
    border-color: #ececec;
}

.bg-light .nav-primary ul.nav > li > a > i {
    color: #a4a4a4;
    border-right: 1px solid #ececec;
}

.nav-primary ul.nav > li > a.active .text {
    display: none;
}

.nav-primary ul.nav > li > a.active .text-active {
    display: inline-block !important;
}

.nav-primary ul.nav > li:hover > a,
.nav-primary ul.nav > li:focus > a,
.nav-primary ul.nav > li > a:hover,
.nav-primary ul.nav > li > a:focus,
.nav-primary ul.nav > li > a:active,
.nav-primary ul.nav > li.active > a {
    color: #fff;
    background-color: inherit;
    background-color: rgba(0, 0, 0, 0.05) !important;
    text-shadow: none;
}

.nav-primary ul.nav > li:hover > a > i.icon,
.nav-primary ul.nav > li:focus > a > i.icon,
.nav-primary ul.nav > li > a:hover > i.icon,
.nav-primary ul.nav > li > a:focus > i.icon,
.nav-primary ul.nav > li > a:active > i.icon,
.nav-primary ul.nav > li.active > a > i.icon {
    color: #fff;
}

.nav-primary ul.nav > li:hover > a > i > b,
.nav-primary ul.nav > li:focus > a > i > b,
.nav-primary ul.nav > li > a:hover > i > b,
.nav-primary ul.nav > li > a:focus > i > b,
.nav-primary ul.nav > li > a:active > i > b,
.nav-primary ul.nav > li.active > a > i > b {
    left: 0 !important;
}

.nav-primary ul.nav > li li a {
    font-weight: normal;
    text-transform: none;
    font-size: 13px;
}

.nav-primary ul.nav > li.active > ul {
    display: block;
}

.nav-primary ul.nav ul {
    display: none;
}

.text-active,
.active > .text {
    display: none !important;
}

.active > .text-active {
    display: inline-block !important;
}    
    

.bg-dark.lt, .bg-dark .lt {
    background-color: #00305d;
}

.nav-xs {
        width: 65px;
    }

    .nav-xs .slimScrollDiv,
    .nav-xs .slim-scroll {
        overflow: visible !important;
    }

    .nav-xs .slimScrollBar,
    .nav-xs .slimScrollRail {
        display: none !important;
    }

    .nav-xs .scrollable {
        overflow: visible;
    }

    .nav-xs .nav-primary > ul > li > a {
        position: relative;
        padding: 0;
        font-size: 11px;
        text-align: center;
        height: 60px;
        overflow-y: hidden;
        border: none;
    }

    .nav-xs .nav-primary > ul > li > a span {
        color: #fff !important;
        display: table-cell;
        vertical-align: middle;
        height: 60px;
        width: 60px;
        position: relative;
        z-index: 2;
    }

    .nav-xs .nav-primary > ul > li > a span.pull-right {
        display: none !important;
    }

    .nav-xs .nav-primary > ul > li > a i {
        width: auto;
        float: none;
        display: block;
        font-size: 18px;
        margin: 0;
        line-height: 60px;
        border: none !important;
        color: #fff !important;
        overflow: visible;
        -webkit-transition: margin-top 0.2s;
        transition: margin-top 0.2s;
    }

    .nav-xs .nav-primary > ul > li > a i b {
        left: 0 !important;
        -webkit-transition: top 0.2s;
        transition: top 0.2s;
    }

    .nav-xs .nav-primary > ul > li > a .badge {
        position: absolute;
        right: 6px;
        top: 4px;
        z-index: 3;
    }

    .nav-xs .nav-primary > ul > li:hover > a i,
    .nav-xs .nav-primary > ul > li:focus > a i,
    .nav-xs .nav-primary > ul > li:active > a i,
    .nav-xs .nav-primary > ul > li.active > a i {
        margin-top: -60px;
    }

    .nav-xs .nav-primary > ul > li:hover > a i b,
    .nav-xs .nav-primary > ul > li:focus > a i b,
    .nav-xs .nav-primary > ul > li:active > a i b,
    .nav-xs .nav-primary > ul > li.active > a i b {
        height: 60px;
        top: 60px;
    }

    .nav-xs .nav-primary > ul ul {
        display: none !important;
        background-color: #00305d;
        position: absolute;
        left: 100%;
        top: 0;
        z-index: 1050;
        width: 220px;
        -webkit-box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        border: 1px solid #ddd;
        border: 1px solid rgba(0, 0, 0, 0.1);
        background-clip: padding-box;
    }

    .nav-xs .nav-primary li:hover > ul,
    .nav-xs .nav-primary li:focus > ul,
    .nav-xs .nav-primary li:active > ul {
        display: block !important;
    }

    .nav-xs.nav-xs-right .nav-primary > ul ul {
        left: auto;
        right: 100%;
    }

    .nav-xs > .vbox > .header,
    .nav-xs > .vbox > .footer {
        padding: 0 15px;
    }

    .nav-xs .hidden-nav-xs {
        display: none;
    }

    .nav-xs .visible-nav-xs {
        display: inherit;
    }

    .nav-xs .nav-user {
        padding: 12px 0;
    }

    .nav-xs .nav-user .avatar {
        float: none !important;
        margin-right: 0;
    }

    .nav-xs .nav-user .dropdown > a {
        display: block;
        text-align: center;
    }

    .nav-xs .navbar-header {
        float: none;
    }

    .nav-xs .navbar-brand {
        display: block;
        padding: 0;
    }

    .nav-xs .navbar-brand img {
        margin-right: 0;
    }

    .nav-xs .navbar {
        padding: 0;
    }    
    
.main-menu {
    position: absolute;
    top: 100px;
    left: 240;
    min-height: 100%;
    padding-top: 50px;
    width: 250px;
    z-index: 810;
    background-color: #00305d;
    }    
</style>
<aside class="main-sidebar">
<section class="sidebar">    
<!-- nav -->   
<nav class="nav-primary">
<ul class="nav">
    
<li> <a href="home.php"> <i class="fa fa-dashboard icon"> <b class="bg-danger"></b> </i> <span>Dashboard</span> </a> </li>
    
<li class=""> <a href="#master" class=""> <i class="fa fa-gear icon"> <b class="bg-warning"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>Master Setup</span> </a>
<ul class="nav lt" style="display: none;">
<li> <a href="#whset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Warehouse Setup</span> </a>
<ul class="nav bg">
<li> <a href="mas_werhouse.php"> <i class="fa fa-angle-right"></i> <span>All Warehouse</span> </a> </li>
<li> <a href="mas_werhousecre.php"> <i class="fa fa-angle-right"></i> <span>Create New Warehouse</span> </a> </li>
</ul>
</li>
<li> <a href="#brset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Branch Setup</span> </a>
<ul class="nav bg">
<li> <a href="mas_branch.php"> <i class="fa fa-angle-right"></i> <span>All Branch</span> </a> </li>
<li> <a href="mas_branchcre.php"> <i class="fa fa-angle-right"></i> <span>Create New Branch</span> </a> </li>
</ul>
</li>
<li> <a href="#brnset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Brand Setup</span> </a>
<ul class="nav bg">
<li> <a href="mas_brand.php"> <i class="fa fa-angle-right"></i> <span>All Brand</span> </a> </li>
<li> <a href="mas_brandcre.php"> <i class="fa fa-angle-right"></i> <span>Create New Brand</span> </a> </li>
</ul>
</li>
<li> <a href="#catset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Category Setup</span> </a>
<ul class="nav bg">
<li> <a href="mas_catlist.php"> <i class="fa fa-angle-right"></i> <span>All Catagories</span> </a> </li>
<li> <a href="mas_catcre.php"> <i class="fa fa-angle-right"></i> <span>Create New Category</span> </a> </li>
</ul>
</li>
<li> <a href="#scatset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Sub Category Setup</span> </a>
<ul class="nav bg">
<li> <a href="mas_scatlist.php"> <i class="fa fa-angle-right"></i> <span>All Sub Catagories</span> </a> </li>
<li> <a href="mas_scatcre.php"> <i class="fa fa-angle-right"></i> <span>Create New Sub Category</span> </a> </li>
</ul>
</li>    
<li> <a href="#uniset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Unit Setup</span> </a>
<ul class="nav bg">
<li> <a href="mas_unitlist.php"> <i class="fa fa-angle-right"></i> <span>All Units</span> </a> </li>
<li> <a href="mas_unitcre.php"> <i class="fa fa-angle-right"></i> <span>Create New Units</span> </a> </li>
</ul>
</li>
<li> <a href="#colset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Color Setup</span> </a>
<ul class="nav bg">
<li> <a href="mas_colist.php"> <i class="fa fa-angle-right"></i> <span>All Colors</span> </a> </li>
<li> <a href="mas_colorcre.php"> <i class="fa fa-angle-right"></i> <span>Create New Color</span> </a> </li>
</ul>
</li>
<li class="active"> <a href="#taxvat" class="active"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>TAX &amp; VAT Setup</span> </a>
<ul class="nav bg">
<li class="active"> <a href="mas_taxlist.php" class="active"> <i class="fa fa-angle-right"></i> <span>TAX &amp; VAT List</span> </a> </li>
<li> <a href="mas_taxcre.php"> <i class="fa fa-angle-right"></i> <span>Add TAX &amp; VAT</span> </a> </li>
</ul>
</li>    
<li> <a href="#intset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Installment System</span> </a>
<ul class="nav bg">
<li> <a href="mas_instlist.php"> <i class="fa fa-angle-right"></i> <span>All Installment Policies</span> </a> </li>
<li> <a href="mas_instcre.php"> <i class="fa fa-angle-right"></i> <span>Create New Policy</span> </a> </li>
</ul>
</li>    
<li> <a href="#bposet"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Bussiness Promotional Offer</span> </a>
<ul class="nav bg">
<li> <a href="mas_bpolist.php"> <i class="fa fa-angle-right"></i> <span>All Offers List</span> </a> </li>
<li> <a href="mas_bpocre.php"> <i class="fa fa-angle-right"></i> <span>Create New Offers</span> </a> </li>
</ul>
</li>
<li> <a href="#toolset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Tools Management</span> </a>
<ul class="nav bg">
<li> <a href="mas_tolist.php"> <i class="fa fa-angle-right"></i> <span>Tools List</span> </a> </li>
<li> <a href="mas_toolcre.php"> <i class="fa fa-angle-right"></i> <span>Create New Tool</span> </a> </li>
<li> <a href="mas_toolman.php"> <i class="fa fa-angle-right"></i> <span>Manage Tools</span> </a> </li>    
</ul>
</li>    
</ul>
</li>

<li> <a href="#gneral"> <i class="fa fa-gears icon"> <b class="bg-warning"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>General Setup</span> </a>    
<ul class="nav lt">
<li> <a href="#cusset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Customers</span> </a>
<ul class="nav bg">
<li> <a href="gen_cuslist.php"> <i class="fa fa-angle-right"></i> <span>All Customer Recod</span> </a> </li>
<li> <a href="gen_cuscre.php"> <i class="fa fa-angle-right"></i> <span>Create New Customer</span> </a> </li>    
</ul>
</li>
<li> <a href="#supset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Suppliers</span> </a>
<ul class="nav bg">
<li> <a href="gen_suplist.php"> <i class="fa fa-angle-right"></i> <span>All Suppliers Record</span> </a> </li>
<li> <a href="gen_supcre.php"> <i class="fa fa-angle-right"></i> <span>Create New Supplier</span> </a> </li>    
</ul>
</li>
<li> <a href="#mnaset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Manufacturer</span> </a>
<ul class="nav bg">
<li> <a href="gen_manlist.php"> <i class="fa fa-angle-right"></i> <span>All Manufacturer</span> </a> </li>
<li> <a href="gen_mancre.php"> <i class="fa fa-angle-right"></i> <span>Create New Manufacturer</span> </a> </li>    
</ul>
</li>    
<li> <a href="gen_finyear.php"> <i class="fa fa-angle-right"></i> <span>Financial Year Setup</span> </a> </li>
<li> <a href="gen_localizer.php"> <i class="fa fa-angle-right"></i> <span>Print &amp; Localization</span> </a> </li>    
</ul>    
</li>    

<li> <a href="#finance"> <i class="fa fa-sun-o icon"> <b class="bg-warning"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>Financial Setup</span> </a>    
<ul class="nav lt">
<li> <a href="fin_aclass.php"> <i class="fa fa-angle-right"></i> <span>Account Class</span> </a> </li>
<li> <a href="#finacg"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Account Group / Control Accounts</span> </a> 
<ul class="nav bg">
<li> <a href="fin_acglist.php"> <i class="fa fa-angle-right"></i> <span>All Accounts Group</span> </a> </li>
<li> <a href="fin_acgcre.php"> <i class="fa fa-angle-right"></i> <span>Create New Group</span> </a> </li>    
</ul>
</li>
<li> <a href="#finsacg"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Account Sub / Subsidiary Accounts</span> </a> 
<ul class="nav bg">
<li> <a href="fin_sacglist.php"> <i class="fa fa-angle-right"></i> <span>All Accounts Sub Group</span> </a> </li>
<li> <a href="fin_sacgcre.php"> <i class="fa fa-angle-right"></i> <span>Create New Sub Group</span> </a> </li>    
</ul>   
</li>
<li> <a href="#finled"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Head Of Account / Ledger</span> </a> 
<ul class="nav bg">
<li> <a href="fin_ledlist.php"> <i class="fa fa-angle-right"></i> <span>All Accounts Ledger</span> </a> </li>
<li> <a href="fin_ledcre.php"> <i class="fa fa-angle-right"></i> <span>Create New Ledger</span> </a> </li>    
</ul>    
</li>
<li> <a href="#finbank"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Bank Accounts</span> </a>
<ul class="nav bg">
<li> <a href="fin_bnklist.php"> <i class="fa fa-angle-right"></i> <span>All Bank</span> </a> </li>    
<li> <a href="fin_balist.php"> <i class="fa fa-angle-right"></i> <span>Current Accounts</span> </a> </li>
<li> <a href="fin_bacre.php"> <i class="fa fa-angle-right"></i> <span>Loan &amp; Overdraft Accounts</span> </a> </li>    
</ul>
</li>
<li> <a href="#finmaset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Mobile Account</span> </a>
<ul class="nav bg">
<li> <a href="fin_malist.php"> <i class="fa fa-angle-right"></i> <span>All Mobile Accounts</span> </a> </li>   
</ul>
</li>
<li> <a href="#fintgset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Target Setup</span> </a>
<ul class="nav bg">
<li> <a href="fin_lglist.php"> <i class="fa fa-angle-right"></i> <span>Lifting Target</span> </a> </li>
<li> <a href="fin_stlist.php"> <i class="fa fa-angle-right"></i> <span>Sales Target</span> </a> </li>
<li> <a href="fin_bdmcre.php"> <i class="fa fa-angle-right"></i> <span>Budget Management</span> </a> </li>    
</ul>
</li>    
</ul>     
</li>    

<li> <a href="#proma"> <i class="fa fa-gift icon"> <b class="bg-success"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>Product Management</span> </a>    
<ul class="nav lt">
<li> <a href="#motbike"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Motor Bikes</span> </a>
<ul class="nav bg">
<li> <a href="pro_modlist.php"> <i class="fa fa-angle-right"></i> <span>All Models</span> </a> </li>
<li> <a href="pro_modcre.php"> <i class="fa fa-angle-right"></i> <span>Create New Model</span> </a> </li>    
</ul>
</li>
<li> <a href="#spapar"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Spare Parts</span> </a>
<ul class="nav bg">
<li> <a href="pro_spalist.php"> <i class="fa fa-angle-right"></i> <span>All Spare Parts</span> </a> </li>
<li> <a href="pro_spacre.php"> <i class="fa fa-angle-right"></i> <span> Create New Spare Parts</span> </a> </li>    
</ul>
</li>
<li> <a href="#access"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Accessories</span> </a>
<ul class="nav bg">
<li> <a href="pro_acclist.php"> <i class="fa fa-angle-right"></i> <span>All Accessoreis</span> </a> </li>
<li> <a href="pro_acccre.php"> <i class="fa fa-angle-right"></i> <span> Create New Accessories</span> </a> </li>    
</ul>
</li>
<li> <a href="#servic"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Services</span> </a>
<ul class="nav bg">
<li> <a href="pro_serlist.php"> <i class="fa fa-angle-right"></i> <span>All Services</span> </a> </li>
<li> <a href="pro_sercre.php"> <i class="fa fa-angle-right"></i> <span> Create New Service</span> </a> </li>    
</ul>
</li>   
</ul>    
</li>
    
 <li> <a href="#purman"> <i class="fa fa-shopping-cart icon"> <b class="bg-success"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>Purchase</span> </a>    
<ul class="nav lt">
<li> <a href="#purmot"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Motor Bike Purchase</span> </a>
<ul class="nav bg">
<li> <a href="pur_motlist.php"> <i class="fa fa-angle-right"></i> <span>All Purchase Record</span> </a> </li>
<li> <a href="pur_motcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Purchase</span> </a> </li>    
</ul>
</li>
<li> <a href="#purspac"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Spare Parts &amp; Accessories Purchase</span> </a>
<ul class="nav bg">
<li> <a href="pur_spaclist.php"> <i class="fa fa-angle-right"></i> <span>All Purchase Record</span> </a> </li>
<li> <a href="pur_spaccre.php"> <i class="fa fa-angle-right"></i> <span> Create New Purchase</span> </a> </li>    
</ul>
</li>
<li> <a href="#purret"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Purchase Return</span> </a>
<ul class="nav bg">
<li> <a href="pur_retlist.php"> <i class="fa fa-angle-right"></i> <span>All Purchase Return</span> </a> </li>
<li> <a href="pur_retcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Purchase Return</span> </a> </li>    
</ul>
</li>
<li> <a href="#purord"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Purchase Order</span> </a>
<ul class="nav bg">
<li> <a href="pur_ordlist.php"> <i class="fa fa-angle-right"></i> <span>All Purchase Order</span> </a> </li>
<li> <a href="pro_ordcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Purchase Order</span> </a> </li>    
</ul>
</li>    
</ul>
</li>
    
 <li> <a href="#salman"> <i class="fa fa-dollar icon"> <b class="bg-success"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>Sales</span> </a>    
<ul class="nav lt">
<li> <a href="#selmot"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Motorbike Sales</span> </a>
<ul class="nav bg">
<li> <a href="sel_motlist.php"> <i class="fa fa-angle-right"></i> <span>All Sales Record</span> </a> </li>
<li> <a href="sel_motcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Sales</span> </a> </li>    
</ul>
</li>
<li> <a href="#selspas"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Spare Parts &amp; Accessories Sales</span> </a>
<ul class="nav bg">
<li> <a href="sel_spaclist.php"> <i class="fa fa-angle-right"></i> <span>All Sales Record</span> </a> </li>
<li> <a href="sel_spaccre.php"> <i class="fa fa-angle-right"></i> <span> Create New Sales</span> </a> </li>    
</ul>
</li>
<li> <a href="#selreturn"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Sales Return</span> </a>
<ul class="nav bg">
<li> <a href="sel_retlist.php"> <i class="fa fa-angle-right"></i> <span>All Sales Returns</span> </a> </li>
<li> <a href="sel_retcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Return</span> </a> </li>    
</ul>
</li>
<li> <a href="#selquota"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Sales Quatation</span> </a>
<ul class="nav bg">
<li> <a href="sel_quolist.php"> <i class="fa fa-angle-right"></i> <span>All Sales Quotation</span> </a> </li>
<li> <a href="sel_quocre.php"> <i class="fa fa-angle-right"></i> <span> Create New Quotation</span> </a> </li>    
</ul>
</li>
<li> <a href="#selestm"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Service Estimate</span> </a>
<ul class="nav bg">
<li> <a href="sel_estlist.php"> <i class="fa fa-angle-right"></i> <span>All Estimate</span> </a> </li>
<li> <a href="sel_estcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Estimate</span> </a> </li>    
</ul>
</li>
<li> <a href="#selejob"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Job Cards</span> </a>
<ul class="nav bg">
<li> <a href="sel_joblist.php"> <i class="fa fa-angle-right"></i> <span>All Job Cards</span> </a> </li>
<li> <a href="sel_jobcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Job Card</span> </a> </li>    
</ul>
</li>    
</ul>
</li>
    
 <li> <a href="#vouent"> <i class="fa fa-file-text icon"> <b class="bg-success"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>Voucher Entry</span> </a>    
<ul class="nav lt">
<li> <a href="#payvou"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Payment Vouchers</span> </a>
<ul class="nav bg">
<li> <a href="vou_payvlist.php"> <i class="fa fa-angle-right"></i> <span>All Payments Record</span> </a> </li>
<li> <a href="vou_payvcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Payment</span> </a> </li>    
</ul>
</li>
<li> <a href="#recvou"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Receipt Vouchers</span> </a>
<ul class="nav bg">
<li> <a href="vou_reclist.php"> <i class="fa fa-angle-right"></i> <span>All Receipt Payment</span> </a> </li>
<li> <a href="vou_reccre.php"> <i class="fa fa-angle-right"></i> <span> Create New Receipt</span> </a> </li>    
</ul>
</li>
<li> <a href="#jouvou"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Journal Entry</span> </a>
<ul class="nav bg">
<li> <a href="vou_joulist.php"> <i class="fa fa-angle-right"></i> <span>All Journal Record</span> </a> </li>
<li> <a href="vou_joucre.php"> <i class="fa fa-angle-right"></i> <span> Create New Journal</span> </a> </li>    
</ul>
</li>
<li> <a href="#convou"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Contra Entry</span> </a>
<ul class="nav bg">
<li> <a href="vou_conlist.php"> <i class="fa fa-angle-right"></i> <span>All Contra Record</span> </a> </li>
<li> <a href="vou_concre.php"> <i class="fa fa-angle-right"></i> <span> Create New Contra Entry</span> </a> </li>    
</ul>
</li>    
</ul>
</li>
 
<li> <a href="#hrman"> <i class="fa fa-male icon"> <b class="bg-success"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>HR Management</span> </a>    
<ul class="nav lt">
<li> <a href="#employ"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Employee</span> </a>
<ul class="nav bg">
<li> <a href="hr_emplist.php"> <i class="fa fa-angle-right"></i> <span>All Employee List</span> </a> </li>
<li> <a href="hr_empcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Employee</span> </a> </li>    
</ul>
</li>
<li> <a href="#depart"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Department</span> </a>
<ul class="nav bg">
<li> <a href="hr_deplist.php"> <i class="fa fa-angle-right"></i> <span>All Department</span> </a> </li>
<li> <a href="hr_depcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Department</span> </a> </li>    
</ul>
</li>
<li> <a href="#design"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Designation</span> </a>
<ul class="nav bg">
<li> <a href="hr_deglist.php"> <i class="fa fa-angle-right"></i> <span>All Designation</span> </a> </li>
<li> <a href="hr_degcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Designation</span> </a> </li>    
</ul>
</li>
<li> <a href="#salset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Salary Sheet</span> </a>
<ul class="nav bg">
<li> <a href="hr_sallist.php"> <i class="fa fa-angle-right"></i> <span>All Salary Record</span> </a> </li>
<li> <a href="hr_salcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Salary Sheet</span> </a> </li>    
</ul>
</li>
<li> <a href="#salcom"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Sales Commission Setup</span> </a>
<ul class="nav bg">
<li> <a href="hr_salcomlist.php"> <i class="fa fa-angle-right"></i> <span>All Commission Policy</span> </a> </li>
<li> <a href="hr_salcomcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Policy</span> </a> </li>    
</ul>
</li>
<li> <a href="#attrec"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Attendance &amp; Leave</span> </a>
<ul class="nav bg">
<li> <a href="hr_leavelist.php"> <i class="fa fa-angle-right"></i> <span>All Leave</span> </a> </li>
<li> <a href="hr_leavcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Leave</span> </a> </li>
<li> <a href="hr_leavrec.php"> <i class="fa fa-angle-right"></i> <span> Add Leave Record</span> </a> </li>
<li> <a href="hr_attrec.php"> <i class="fa fa-angle-right"></i> <span> Add Attendance Record</span> </a> </li>    
</ul>
</li>    
</ul>
</li> 
    
<li> <a href="#brtadoc"> <i class="fa fa-files-o icon"> <b class="bg-success"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>BRTA Documentation &amp; VAT</span> </a>    
<ul class="nav lt">
<li> <a href="brta_brtsinv.php"> <i class="fa fa-angle-right"></i> <span> BRTA Sales Invoice</span> </a> </li>
<li> <a href="brta_brtvtinv.php"> <i class="fa fa-angle-right"></i> <span> VAT Invoice - 6.3</span> </a> </li>
<li> <a href="brta_brtslcer.php"> <i class="fa fa-angle-right"></i> <span> Sales Certificates</span> </a> </li>
<li> <a href="brta_cuspinf.php"> <i class="fa fa-angle-right"></i> <span> Customer's Personal Infromation Form</span> </a> </li>
<li> <a href="brta_brtreg.php"> <i class="fa fa-angle-right"></i> <span> BRTA Registration Form</span> </a> </li>
<li> <a href="brta_brtmvat.php"> <i class="fa fa-angle-right"></i> <span> VAT Manual</span> </a> </li>
<li> <a href="brta_pursum.php"> <i class="fa fa-angle-right"></i> <span> Purchase Summery</span> </a> </li>
<li> <a href="brta_selsum.php"> <i class="fa fa-angle-right"></i> <span> Sale Summery</span> </a> </li>
<li> <a href="brta_vatsum.php"> <i class="fa fa-angle-right"></i> <span> VAT Summery</span> </a> </li>    
<li> <a href="#trecha"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Treassury Challan</span> </a>
<ul class="nav bg">
<li> <a href="brta_chalanlist.php"> <i class="fa fa-angle-right"></i> <span>All Challans</span> </a> </li>
<li> <a href="brta_chalancre.php"> <i class="fa fa-angle-right"></i> <span> Create New Challan</span> </a> </li>    
</ul>
</li>
<li> <a href="#regexp"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Registration Expenses</span> </a>
<ul class="nav bg">
<li> <a href="brta_regrcplist.php"> <i class="fa fa-angle-right"></i> <span>All Registration Receipts</span> </a> </li>
<li> <a href="brta_regvoulist.php"> <i class="fa fa-angle-right"></i> <span> All Registration Vouchers</span> </a> </li>
<li> <a href="brta_regvoucre.php"> <i class="fa fa-angle-right"></i> <span> Create New Vouchers</span> </a> </li>    
</ul>
</li>    
</ul>
</li>
    
<li> <a href=""> <i class="fa fa-home icon"> <b class="bg-success"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>Warehouse Management</span> </a>    
<ul class="nav lt">
<li> <a href="#wrcvre"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Product Receiving</span> </a>
<ul class="nav bg">
<li> <a href="wer_recvlistlist.php"> <i class="fa fa-angle-right"></i> <span>All Received</span> </a> </li>
<li> <a href="wer_recvcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Receive</span> </a> </li>    
</ul>
</li>
<li> <a href="#delver"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Product Delivery</span> </a>
<ul class="nav bg">
<li> <a href="wer_delvlist.php"> <i class="fa fa-angle-right"></i> <span>All Delivered</span> </a> </li>
<li> <a href="wer_dlvcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Delivery</span> </a> </li>    
</ul>
</li>
<li> <a href="#transf"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Product Transfer</span> </a>
<ul class="nav bg">
<li> <a href="wer_trafwh.php"> <i class="fa fa-angle-right"></i> <span>Transfer From Warehouse</span> </a> </li>
<li> <a href="wer_trafbr.php"> <i class="fa fa-angle-right"></i> <span> Transfer From Branch</span> </a> </li>    
</ul>
</li>
<li> <a href="#dispos"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Product Disposal</span> </a>
<ul class="nav bg">
<li> <a href="wer_dspreclist.php"> <i class="fa fa-angle-right"></i> <span>All Disposal Record</span> </a> </li>
<li> <a href="wer_dspreccre.php"> <i class="fa fa-angle-right"></i> <span> Create New Disposal</span> </a> </li>    
</ul>
</li>
<li> <a href="#updpri"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Product Price Update</span> </a>
<ul class="nav bg">
<li> <a href="wer_prilist.php"> <i class="fa fa-angle-right"></i> <span>All Price List</span> </a> </li>    
</ul>
</li>    
<li> <a href="wer_engcha.php"> <i class="fa fa-angle-right"></i> <span> Engine &amp; Chassis Records</span> </a> </li> 
<li> <a href="#noninv"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Non Inventorical Item</span> </a>
<ul class="nav bg">
<li> <a href="wer_noninvlist.php"> <i class="fa fa-angle-right"></i> <span>All Non Inventorical Item</span> </a> </li>
<li> <a href="wer_noninvcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Item</span> </a> </li>    
</ul>
</li>    
</ul>
</li>
    
<li> <a href="#inventman"> <i class="fa fa-barcode icon"> <b class="bg-success"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>Inventory</span> </a>    
<ul class="nav lt">
<li> <a href="inv_motoinv.php"> <i class="fa fa-angle-right"></i> <span> Motor Bike Stock Status</span> </a> </li>
<li> <a href="inv_sprinv.php"> <i class="fa fa-angle-right"></i> <span> Spare Parts Stock Status</span> </a> </li>
<li> <a href="inv_acesor.php"> <i class="fa fa-angle-right"></i> <span> Accessories Stock Status</span> </a> </li>    
<li> <a href="#spaset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Stock Price Adjustment</span> </a>
<ul class="nav bg">
<li> <a href="inv_adjustlist.php"> <i class="fa fa-angle-right"></i> <span>All Adjustment Record</span> </a> </li>
<li> <a href="inv_adjustcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Adjustment Voucher</span> </a> </li>    
</ul>
</li>    
</ul>
</li>
    
<li> <a href="#wantman"> <i class="fa fa-wrench icon"> <b class="bg-success"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>Warranty Management</span> </a>    
<ul class="nav lt">
<li> <a href="want_clmlist.php"> <i class="fa fa-angle-right"></i> <span> All Claimed Warranties</span> </a> </li> 
<li> <a href="want_clmcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Claim</span> </a> </li>     
</ul>
</li>
    
<li class=""> <a href="#userman" class=""> <i class="fa fa-user icon"> <b class="bg-success"></b> </i> <span class="pull-right"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> </span> <span>User Management</span> </a>    
<ul class="nav lt" style="display: none;">
<li> <a href="#rolset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>Role Setup</span> </a>
<ul class="nav bg">
<li> <a href="rol_rollist.php"> <i class="fa fa-angle-right"></i> <span>All Role</span> </a> </li>
<li> <a href="rol_rolcre.php"> <i class="fa fa-angle-right"></i> <span> Create New Role</span> </a> </li>    
</ul>
</li>
<li> <a href="#usrset"> <i class="fa fa-angle-down text"></i> <i class="fa fa-angle-up text-active"></i> <span>User Setup</span> </a>
<ul class="nav bg">
<li> <a href="rol_userlist.php"> <i class="fa fa-angle-right"></i> <span>All User</span> </a> </li>
<li> <a href="rol_usercre.php"> <i class="fa fa-angle-right"></i> <span> Create New User</span> </a> </li>    
</ul>
</li>    
</ul>
</li>
    
<li> <a href="rep_master.php"> <i class="fa fa-bar-chart-o icon"> <b class="bg-info"></b> </i> <span>Master Reports</span> </a> </li>
    
<li> <a href="rep_finance.php"> <i class="fa fa-file-text-o icon"> <b class="bg-info"></b> </i> <span>Financial Reports</span> </a> </li>

<li> <a href="axe_company.php"> <i class="fa fa-sitemap icon"> <b class="bg-primary"></b> </i> <span>Company Setup</span> </a> </li>     
    
</ul>
</nav>    
<!-- /nav -->
</section>
</aside>    
<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {    
$(document).on('click', '.nav-primary a', function (e) {
var $this = $(e.target),
$active;
$this.is('a') || ($this = $this.closest('a'));
if ($('.nav-vertical').length) {
return;
}
$active = $this.parent().siblings(".active");
$active && $active.find('> a').toggleClass('active') && $active.toggleClass('active').find('> ul:visible').slideUp(200);
($this.hasClass('active') && $this.next().slideUp(200)) || $this.next().slideDown(200);
$this.toggleClass('active').parent().toggleClass('active');
$this.next().is('ul') && e.preventDefault();
setTimeout(function () {
$(document).trigger('updateNav');
}, 300);    
});

window.onresize = function(event) {
};    
    
});

$(document).on('click', '.sidebar-toggle', function() {
if($('.main-sidebar').hasClass('nav-xs')){
$('.main-sidebar').removeClass('nav-xs');    
}else{
$('.main-sidebar').addClass('nav-xs');     
}        
});        
</script>    
<!-- /page script -->
</html>    