<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
$today = strftime("%Y-%m-%d", time());    
$dtnow = date("Y-m-d h:i:s", time());    
}else{
header('Location:../index.php');
exit;    
}

if(isset($_POST['additem'])){
$unqid=$_POST['additem'];
$type=$_POST['type'];
$bwid=$_POST['bwid'];    
addtodispos($type,$bwid,$unqid,1);    
}

if(isset($_POST['remove'])){
$ids = floatval($_POST['remove']);
$unqid=$_SESSION['axes_dispos'][$ids]['unqid'];    
remove_dispos($ids);
if(isset($_SESSION['axes_dspse'])){    
remove_disposlimei($unqid);
}
$max=count($_SESSION['axes_dispos']);
if($max <= 0){
unset($_SESSION['axes_dispos']);
if(isset($_SESSION['axes_dspse'])){
unset($_SESSION['axes_dspse']);	
}	
}
if(isset($_SESSION['axes_dspse'])){
$smax=count($_SESSION['axes_dspse']);
if($smax <= 0){    
unset($_SESSION['axes_dspse']);
}
}    
}

if(isset($_POST['upqty'])){
$ids=intval($_POST['upqty']);
$qty=floatval($_POST['qty']);
if($qty<0 || $qty==''){
$redata=array($_SESSION['axes_dispos'][$ids]['qty'],$_SESSION['axes_dispos'][$ids]['subtot']);
echo json_encode($redata);    
exit;
}
$unqid = $_SESSION['axes_dispos'][$ids]['unqid'];
$type = $_SESSION['axes_dispos'][$ids]['type'];
$bwid = $_SESSION['axes_dispos'][$ids]['bwid'];
$price = $_SESSION['axes_dispos'][$ids]['price'];
if($type=='B'){    
$eqty=(get_selestockinfo($bwid,$unqid,'avqty')-get_selestockinfo($bwid,$unqid,'sloc'));
}else{
$eqty=get_warestockinfo($bwid,$unqid,'avqty');    
}
if($qty<=$eqty){
$_SESSION['axes_dispos'][$ids]['qty']=$qty;		
}elseif($qty>$eqty){
$_SESSION['axes_dispos'][$ids]['qty']=$eqty;		
}
$qty=$_SESSION['axes_dispos'][$ids]['qty'];    
$_SESSION['axes_dispos'][$ids]['subtot']=($price*$qty);    
$redata=array($_SESSION['axes_dispos'][$ids]['qty'],$_SESSION['axes_dispos'][$ids]['subtot']);
echo json_encode($redata);
}

if(isset($_POST['upprice'])){
$ids=intval($_POST['upprice']);
$price=$_POST['price'];
if($price<0 || $price==''){
$redata=array($_SESSION['axes_dispos'][$ids]['price'],$_SESSION['axes_dispos'][$ids]['subtot']);
echo json_encode($redata);    
exit;
}
$_SESSION['axes_dispos'][$ids]['price']=$price;
$qty=$_SESSION['axes_dispos'][$ids]['qty'];    
$_SESSION['axes_dispos'][$ids]['subtot']=($price*$qty);    
$redata=array($_SESSION['axes_dispos'][$ids]['price'],$_SESSION['axes_dispos'][$ids]['subtot']);
echo json_encode($redata);
}

if(isset($_POST['removeitmsl'])){
$id=intval($_POST['removeitmsl']);
$unqid=$_SESSION['axes_dspse'][$id]['unqid'];
$itid=get_dispositmid($unqid);
$itmqty=$_SESSION['axes_dispos'][$itid]['qty'];

remove_dispossl($id);    
if($itmqty<=1){
remove_dispos($itid);    
}else{
$_SESSION['axes_dispos'][$itid]['qty']=($itmqty-1);    
}   
$max=count($_SESSION['axes_dispos']);
if($max <= 0){
unset($_SESSION['axes_dispos']);
if(isset($_SESSION['axes_dspse'])){
unset($_SESSION['axes_dspse']);	
}	
}    
}

if(isset($_POST['upimei'])){
$ids=intval($_POST['upimei']);
$serialno=strtoupper(remove_junk(escape($_POST['imeidata'])));
$pid=intval($_SESSION['axes_dspse'][$ids]['pid']);
if($serialno!=''){
if(disposserial_exists($pid,$serialno)){
$redata=array($_SESSION['axes_dspse'][$ids]['imei']);
echo json_encode($redata);    
return;
exit;    
}
$_SESSION['axes_dspse'][$ids]['imei']= $serialno;    
}else{
$_SESSION['axes_dspse'][$ids]['imei']='';    
}    
$redata=array($_SESSION['axes_dspse'][$ids]['imei']);
echo json_encode($redata); 
}

if(isset($_POST['audimei'])){
$id=$_POST['audimei'];
$ibrid=$_POST['ibrid'];
$type=$_POST['type'];    
$pid=intval($_SESSION['axes_dspse'][$id]['pid']);    
$search = $_POST['search'];

if($type=='B'){
$sql="SELECT pid,serial FROM tbl_serial WHERE pid='$pid' AND serial LIKE '%$search%' AND brid='$ibrid' AND status='0' ORDER BY serial ASC LIMIT 30";    
}else{
$sql="SELECT pid,serial FROM tbl_serial WHERE pid='$pid' AND serial LIKE '%$search%' AND whid='$ibrid' AND status='0' ORDER BY serial ASC LIMIT 30";    
}
    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
while($row = mysqli_fetch_array($result) ){
$response[] = array("value"=>$row['pid'],"label"=>$row['serial']);
}

// encoding array to json format
echo json_encode($response);
exit;    
}

if(isset($_POST['clear'])){
if(isset($_SESSION['axes_dispos'])){
unset($_SESSION['axes_dispos']);   
}
if(isset($_SESSION['axes_dspse'])){
unset($_SESSION['axes_dspse']);	
}
}

if(isset($_POST['trbdata'])){
$edata=array(check_disserial('S'));
echo json_encode($edata);
}

if(isset($_POST['adddisposal'])){
    
$invno = gen_newinvno('tbl_disposal','PDR');
$stype = remove_junk(escape($_POST['stype']));;    
$sbrid = remove_junk(escape($_POST['sbrid']));      
$note = remove_junk(escape($_POST['note']));
$dtotal = get_dispos_total('C');
$total = get_dispos_total('P');     
$apdate = remove_junk(escape($_POST['trbdt']));   
if(!isset($_SESSION['axes_dispos'])){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! No item found!!'
));
return;
exit;  
}
    
if(check_dpbvalidqty($stype,$sbrid)){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Quantity not available!!'
));
return;
exit;     
}

if($total>0){
$cash = remove_junk(escape($_POST['cash']));    
$cdata=explode('_',remove_junk(escape($_POST['cusid'])));
$cty=$cdata['0'];    
$cid = $cdata['1'];    

if($cid!=0){
if($cty=='CU'){    
$cname=get_fild_data('tbl_customer',$cid,'name');
$cbname=get_fild_data('tbl_customer',$cid,'bname');    
$cmobile=get_fild_data('tbl_customer',$cid,'cnumber');    
}else{
$cname=get_fild_data('tbl_supplier',$cid,'name');
$cbname=get_fild_data('tbl_supplier',$cid,'bname');    
$cmobile=get_fild_data('tbl_supplier',$cid,'cnumber');     
}
}else{
$cname=remove_junk(escape($_POST['wname']));
$cbname = remove_junk(escape($_POST['bname']));    
$cmobile=remove_junk(escape($_POST['wmobile']));    
}    
}
    
if($total>0){
if($cbname=='0' || $cbname==''){$cbname='NULL';}else{$cbname="'".$cbname."'";}    
$sql="INSERT INTO tbl_disposal (invno,brwh,ibrid,type,cusid,name,bname,mobile,dtotal,total,amount,note,apdate,brid,uid,date) VALUES ('$invno','$stype','$sbrid','$cty','$cid','$cname',$cbname,'$cmobile','$dtotal','$total','$cash','$note','$apdate','$brid','$aid','$dtnow')";
}else{
$sql="INSERT INTO tbl_disposal (invno,brwh,ibrid,type,cusid,name,bname,mobile,dtotal,total,amount,note,apdate,brid,uid,date) VALUES ('$invno','$stype','$sbrid',NULL,NULL,NULL,NULL,NULL,'$dtotal','0','0','$note','$apdate','$brid','$aid','$dtnow')";    
}    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sid=$con->insert_id;    
$efid=mysqli_affected_rows($con);    
 
if($efid>0){
$max=count($_SESSION['axes_dispos']);
for($i=0;$i<$max;$i++){
$pid = $_SESSION['axes_dispos'][$i]['pid'];
$unqid= $_SESSION['axes_dispos'][$i]['unqid'];   
$col=$_SESSION['axes_dispos'][$i]['col'];
$siz=$_SESSION['axes_dispos'][$i]['siz'];
$cost=$_SESSION['axes_dispos'][$i]['cost'];
$puqty=0;    
$qtyin=$_SESSION['axes_dispos'][$i]['qty'];
$soqty=0;    
$qtyout=$_SESSION['axes_dispos'][$i]['qty'];
$taxp=0;
$taxamo=0;
$idisp=0;
$idisf=0;
$disamo=0;
$sdisp=0;
$sdisf=0;
$price=$_SESSION['axes_dispos'][$i]['price'];
$isubtot=$_SESSION['axes_dispos'][$i]['subtot'];
$wday=0;
$pnote='';    

if($stype=='B'){
$ibrid="'".$sbrid."'";
$iwhid='NULL';    
}else{
$ibrid='NULL';
$iwhid="'".$sbrid."'";    
}    

    
if($total>0){     
$sql="INSERT INTO tbl_traproduct (type,tid,invno,refinv,pid,unqid,colid,sizid,cost,price,p_qty,p_in,s_qty,p_out,taxp,taxamo,disp,disf,disamo,subtot,wday,mods,brid,waid,tramod,isinv,pnote,uid,apdate,date) VALUES ('$cty','$cid','$invno',NULL,'$pid','$unqid','$col','$siz','$cost','$price','$puqty','0','$soqty','$qtyout','$taxp','$taxamo','$idisp','$idisf','$disamo','$isubtot','$wday','DS',$ibrid,$iwhid,NULL,'Y',NULL,'$aid','$apdate','$dtnow')";
}else{
$sql="INSERT INTO tbl_traproduct (type,tid,invno,refinv,pid,unqid,colid,sizid,cost,price,p_qty,p_in,s_qty,p_out,taxp,taxamo,disp,disf,disamo,subtot,wday,mods,brid,waid,tramod,isinv,pnote,uid,apdate,date) VALUES (NULL,NULL,'$invno',NULL,'$pid','$unqid','$col','$siz','$cost','$price','$puqty','0','$soqty','$qtyout','$taxp','$taxamo','$idisp','$idisf','$disamo','$isubtot','$wday','DS',$ibrid,$iwhid,NULL,'Y',NULL,'$aid','$apdate','$dtnow')";    
}
$result = mysqli_query($con,$sql) or die(mysqli_error($con));    
}

if(isset($_SESSION['axes_dspse'])){
$max=count($_SESSION['axes_dspse']);
for($i=0;$i<$max;$i++){
$pid=$_SESSION['axes_dspse'][$i]['pid'];
$unqid=$_SESSION['axes_dspse'][$i]['unqid'];    
$serial=$_SESSION['axes_dspse'][$i]['imei'];    
$sql="UPDATE tbl_serial SET status='3',disno='$invno' WHERE serial='$serial'";   
$result = mysqli_query($con,$sql) or die(mysqli_error($con));    
}    
}

unset($_SESSION['axes_dispos']);
if(isset($_SESSION['axes_dspse'])){
unset($_SESSION['axes_dspse']);
}    
  
$act =remove_junk(escape('Disposal No: '.$invno));
$bact =remove_junk('নিষ্পত্তি নং: '.$invno);    
write_activity($aid,'PDR','New Disposal has been Created',$act,'নতুন নিষ্পত্তি (ডিস্পোজাল) যোগ করেছেন',$bact);
echo json_encode(array(
'status' => 'success',
'message'=> 'Disposal Save Successfully!!'   
));
exit;    
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));    
}        
}
?>

<?php 
if(isset($_POST['savetra'])){
$det=explode('_',$_POST['brid']);
$itype=$det[0];
$ibrid=$det[1];
$cash = get_dispos_total('P');    
?>
<div class="col-md-12 popup_details_div adddisposal">
<div class="row">
<div class="col-md-12">
<div class="form-group" >
<label>Disposal Date</label>
<input type="text" class="form-control datetimepicker" name="trbdt" id="trbdt" value="<?php echo $today;?>" placeholder="Disposal Date" autocomplete="off" readonly>
<input type="hidden" name="adddisposal" readonly />
<input type="hidden" name="stype" value="<?php echo $itype; ?>" readonly />
<input type="hidden" name="sbrid" value="<?php echo $ibrid; ?>" readonly /> 
</div>
<?php if($cash>0){ ?>    
<div class="form-group">
<label>Customer (Optional)</label>    
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-user-o"></span></span>
<span class="input-group-addon"><a data-toggle="collapse" data-target="#walkcus" class="accordion-toggle" id="walkin" style="cursor: pointer;">Walk-In</a></span>   
<input type="text" class="form-control" id="cusname" value="" placeholder="Type Customer Code, Name Or Mobile No..." autocomplete="off" />   
</div>
<input type="hidden" name="cusid" id="cusid" class="form-control" value="" readOnly />    
</div>
<div class="accordian-body collapse" id="walkcus">
<div class="col-md-6">    
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-id-card-o"></span></span>    
<input type="text" id="walkname" name="wname" maxlength="35" class="form-control" value="Walk-In Customer" placeholder="Customer Name" autocomplete="off">
</div>
</div>    
</div>
<div class="col-md-6">     
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-mobile"></span></span>    
<input type="text" id="walkmobile" name="wmobile" maxlength="18" class="form-control" value="" placeholder="e.g. 016167xx7x" autocomplete="off">
</div>
</div>    
</div>
</div>
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-id-card-o"></span></span>    
<input type="text" name="bname" maxlength="255" class="form-control" value="ভ্রাম্যমাণ ক্রেতা" placeholder="ক্রেতার নাম" autocomplete="off">
</div>
</div>    
<div class="form-group">
<label>Receivable Amount (<?php echo '<span style="color:red;">'.$cash.'</span>';?>)</label>
<input type="text" name="cash" id="cash" maxlength="12" class="form-control" value="0" onkeypress="return isNumberKey(event)" placeholder="e.g. 1250" autocomplete="off">
</div>
<?php } ?>   
<div class="form-group">
<label>Note</label>
<textarea class="form-control" maxlength="150" rows="3" name="note" id="note" placeholder="Note"></textarea>
</div>           
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-7"></div>
<div class="col-md-4 text-right" >
<input type="button" id="fintrb" class="btn btn-flat bg-purple btn-sm " value="Save Disposal"/>
<div class="col-md-1"></div>    
</div> 
</div>

<script type="text/javascript">
function chek_error(){
var trbdt = $('#trbdt').val();
var note = $('#note').val();
<?php if($cash>0){ ?>    
var cusid = $('#cusid').val();    
<?php } ?>    
var result = true;    

$('.LV_invalid_field').removeClass('LV_invalid_field');     
$('.LV_validation_message').remove();    

if(trbdt.length<=0){
$('#trbdt').addClass('LV_invalid_field');   
$('#trbdt').after("<span class='LV_validation_message LV_invalid'>Enter Disposal Date!</span>").addClass('has-error');
result=false;    
}else{
$('#trbdt').removeClass('LV_invalid_field');
result=true;    
}    
<?php if($cash>0){ ?> 
if(cusid.length < 1 || cusid == ''){ 
$('#cusname').addClass('LV_invalid_field');   
$('#cusname').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error');
result=false;    
}else{
$('#cusname').removeClass('LV_invalid_field');     
}    
<?php } ?>     
if(note.length<=0){
$('#note').addClass('LV_invalid_field');   
$('#note').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error');
result=false;    
}else{
$('#note').removeClass('LV_invalid_field');     
}    
    
if(note == '' || !result){
return false;    
}else{
return true;     
}    
   
}
        
$(document).on('blur', '#trbdt, #note', function() {
chek_error();    
});

$(document).on('click', '#walkin', function() {	
$('#cusname').val('Walk-In Customer');
$('#cusid').val('CU_0');
//$('#cusbal').html('0.00');	
});
    
$(document).on('keyup', '#cusname', function() { 
var bal = $(this).val();
if(bal.length<1){
$('#cusid').val('');
//$('#cusbal').html('0.00');	
}
});
    
$(document).on('keydown', '#cusname', function() {    
$('#cusname' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'sel_cart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term,getcus:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
$(this).val(ui.item.label);	
var cusid = ui.item.value; // selected id to input
$('#cusid').val(cusid);
$.ajax({
url: 'sel_cart.php',
type: 'post',
data: {checkbal:cusid},
success:function(data){
//$('#cusbal').html(data);
}
});

return false;
}
});
});    
    
$('.datetimepicker').datepicker({format: "yyyy-mm-dd", autoclose: true, clearBtn: true, orientation: 'auto bottom'});    
</script>    
<?php } ?>