<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='inv_deliverlist.php';   
$cuPage='inv_deliverlist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='inventor';
$menuh='Inventory';
$phead='dellist';
$page='Sales Delivery Create';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php
function get_proinfo($invno,$unqid,$key){
global $con;
$sql="SELECT ".$key." AS rdata FROM tbl_traproduct WHERE invno='$invno' AND unqid='$unqid' LIMIT 1";
$result = mysqli_query($con, $sql) or die(mysqli_error($con));    
$row=mysqli_fetch_array($result);
return $row['rdata'];    
}

if(isset($_POST['save_deliver'])){
$efr=0;
$dtot=0;    
$invno=remove_junk(escape($_POST['invno']));
$refinv=gen_newinvno('tbl_pdlirecord','DLI');
$apdate=remove_junk(escape($_POST['dlidt']));
$note=remove_junk(escape($_POST['note']));

if(isset($_POST['data']) && !empty($_POST['data'])){

$deitems=$_POST['data'];
foreach($deitems as $item){
$dnow = remove_junk(escape($item['dqty']));
if($dnow!='' || $dnow>0){
$dtot+=$dnow;    
}else{
$dtot+=0;    
}    
}    

if($dtot <= 0){
save_msg('w','Sorry! no item found for delivery!!!');
echo "<script>window.location='inv_delivercre.php'</script>";
exit;    
}    
    
$sql="INSERT INTO tbl_pdlirecord (invno,refinv,ibrid,note,apdate,brid,uid,date) VALUES ('$refinv','$invno','$brid','$note','$apdate','$brid','$aid','$dtnow')";

$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sid=$con->insert_id;    
$efid=mysqli_affected_rows($con);
   
if($efid>0){
$dlitem=$_POST['data'];
foreach($dlitem as $items){
$unqid = $items['unqid'];    
$cty = get_proinfo($invno,$unqid,'type');
$cid = get_proinfo($invno,$unqid,'tid');
$pid = get_proinfo($invno,$unqid,'pid');
$col = get_proinfo($invno,$unqid,'colid');  
$siz = get_proinfo($invno,$unqid,'sizid');
$ibrid = get_proinfo($invno,$unqid,'brid');    
$qtyout = floatval($items['dqty']);
$puloc = floatval($items['dqty']);
   
$sql="INSERT INTO tbl_traproduct (type,tid,invno,refinv,pid,unqid,colid,sizid,icdis,icinvdis,cost,price,p_qty,p_in,s_qty,p_out,p_loc,p_uloc,taxp,taxamo,disp,disf,disamo,subtot,wday,mods,brid,waid,tramod,isinv,pnote,uid,apdate,date) VALUES ('$cty','$cid','$refinv','$invno','$pid','$unqid','$col','$siz','0','0','0','0','0','0','0','$qtyout','0','$puloc','0','0','0','0','0','0','0','DL','$ibrid',NULL,NULL,'Y',NULL,'$aid','$apdate','$dtnow')";
if($qtyout>0){     
mysqli_query($con,$sql) or die(mysqli_error($con));
}
}

if(isset($_POST['serial']) && !empty($_POST['serial'])){
$serila = $_POST['serial'];
foreach($serila as $sld){
$upsl=strtoupper($sld['dlse']);
$sql="UPDATE tbl_serialsale SET dli='Y',dlno='$refinv' WHERE serial='$upsl'";
if(strlen($upsl)>0 && $upsl!=''){    
mysqli_query($con,$sql) or die(mysqli_error($con));
}
}    
}    
$act =remove_junk(escape('Delivery Challan No: '.$refinv));
$bact =remove_junk('ডেলিবার চালান নং: '.$refinv);    
write_activity($aid,'DLI','New delivery challan has been created',$act,'নতুন ডেলিবারী চালান যোগ করেছেন',$bact);   
save_msg('s','Data Successfully Saved!');
}else{
save_msg('w','Sorry! Data fail to save!!!');    
}       
}else{
save_msg('w','Sorry! no item found for delivery!!!');    
}
echo "<script>window.location='inv_delivercre.php'</script>";
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Sales Product Delivery</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="inv_delivercre.php" id="save_frdeliver" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12">    
<div class="row">
<div class="col-md-4">
<div class="form-group">
<label>Select Invoice</label>    
<select class="form-control select2" name="invno" id="invno">
<option value="">-Select Invoice-</option>    
<?php
$sql="SELECT DISTINCT type,tid,invno FROM (SELECT type,tid,invno,pid,unqid,colid,sizid,SUM(s_qty) AS sold,SUM(p_out) AS dliver,SUM(s_qty-p_out) AS resqty,brid FROM tbl_traproduct WHERE mods IN ('SE','DL') GROUP BY IF(mods='DL',refinv,invno),unqid) dli WHERE resqty>0 AND brid='$brid'";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
if($row['type']=='SU'){
$cusname=get_fild_data('tbl_supplier',$row['tid'],'name');    
}else{
if($row['tid']==0){
$sesql="invno='".$row['invno']."'";    
$cusname=get_fild_data('tbl_sales','','name',$sesql);    
}else{
$cusname=get_fild_data('tbl_customer',$row['tid'],'name');    
}    
}   
?>   
<option value="<?php echo $row['invno'];?>"><?php echo $row['invno'].'-'.$cusname;?></option>    
<?php } ?>    
</select>    
</div>
<div class="form-group">
<div class="input-group">
<span class="input-group-addon">CNo:</span>    
<input type="text" maxlength="15" class="form-control" value="<?php echo gen_newinvno('tbl_pdlirecord','DLI'); ?>" readonly> 
</div>
</div>
<div class="form-group" >
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-calendar"></span></span>    
<input type="text" class="form-control datetimepicker" name="dlidt" id="dlidt" value="<?php echo $today;?>" placeholder="Delivery Date" autocomplete="off" readonly>
</div>
</div>    
</div> 
<div class="col-md-8">
<div class="form-group">    
<label>Note</label>
<textarea class="form-control" name="note" id="note" maxlength="150" rows="5" placeholder="Challan Note"></textarea>    
</div>     
</div>     
</div>
<div class="row">
<div class="cart cart-sm">     
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<thead>
<th style="width:35px; text-align:center;">SN</th>
<th style="width:60px; text-align:center;">Image</th>
<th style="width:280px; text-align:left;">Product</th>
<th style="width:100px; text-align:center;">Code</th>
<th style="width:60px; text-align:center;">Sold</th>    
<th style="width:60px; text-align:center;">Delivered</th>
<th style="width:60px; text-align:center;">Rest Qty</th>
<th style="width:80px; text-align:center;">Now</th>    
</thead>
</table>
<div class="cart-tra style-3 item" style="padding:0px;">    
<table class="table table-bordered table-striped results" style="margin-bottom: 0;">    
<tbody id="traitem">

</tbody>    
</table>
</div>   
</div>    
</div>
<div class="row">
<div class="cart cart-sm" id="serialdata">

</div>
</div>    
    
</div>
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="hidden" name="save_deliver" class="form-control" value="0" readonly />   
<input type="button" id="save_deliver" class="btn btn-flat bg-purple btn-sm " value="Deliver"/> <a href="inv_deliverlist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'DLI','A');}else{echo read_activity($aid,'DLI','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>    

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->     
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
ReadItem();   
function ReadItem(){
$.ajax({
url: "inv_deliitem.php",
method: "POST",
data: {
invno:''
},    
success: function(data) {
$('#traitem').html(data);
}
})
}
    
$(document).on('change', '#invno', function() {
var ids = $(this).val();
$.ajax({
url: "inv_deliitem.php",
method: "POST",
data: {
invno:ids
},
success: function(data) {
$('#traitem').html(data);
}
});
    
$.ajax({
url: "inv_deliitem.php",
method: "POST",
data: {
serial:ids
},
success: function(data) {
$('#serialdata').html(data);
}
});    
});
    
$(document).on('keyup', '.dlqty', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var dlq = parseFloat($(this).val());
var resq = parseFloat($("#res_"+id[1]).val());
if(isNaN(dlq)){
dlq=0;    
}
if(dlq <= 0){
$("#dlq_"+id[1]).val('');
$("#sl_"+id[1]).val(0);    
}
if(dlq > resq){
$("#dlq_"+id[1]).val(resq);
$("#sl_"+id[1]).val(resq);    
}else{
$("#sl_"+id[1]).val(dlq);    
}   
});
    
$(document).on('change', '.bscan', function () {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var dlq = parseFloat($("#sl_"+id[2]).val());    
var cx = $("."+id[2]+":checked").length;
if(cx<=dlq){
    
}else{
document.getElementById(id_arr).checked = false;    
}
if(document.getElementById(id_arr).checked){
dsl=$("#seal_"+id[1]).val()    
$(this).val(dsl);    
}else{
$(this).val('');    
}     
});
    
function check_err(){
var sltot = 0;
var itsl = 0;    
$('.bscan').each(function() {
if($(this).prop('checked')){
sl=1;    
}else{
sl=0;    
}
sltot += sl;     
});
    
$('.serial').each(function() {
sel = parseFloat($(this).val());    
if(isNaN(sel)){
sel=0;    
}
itsl += sel;     
});
if (sltot!=itsl){
return true;    
}else{
return false;    
}       
}
    
$(document).on('click', '#save_deliver', function () {
if(check_err()){
return;    
}else{
document.getElementById('save_frdeliver').submit();    
}    
});    
</script>    
<!-- /page script -->
</html>    