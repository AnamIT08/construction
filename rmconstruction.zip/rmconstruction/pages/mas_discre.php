<?php
session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;     
}
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
if(isset($_POST['addseritem'])){
$name = remove_junk(escape($_POST['name']));
$cid = remove_junk(escape($_POST['cid']));

if(isset($_POST['name'])){
$sql="SELECT * FROM tbl_district WHERE cid='$cid' AND name = '$name'";           
$ducode = mysqli_query($con,$sql);
}
    
if($ducode->num_rows > 0) {
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! District Already Exists!!'
));
return;
exit;
}else{ 
$sql="INSERT INTO tbl_district (cid,name,uid,date) VALUES ('$cid','$name','$aid','$dtnow')";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$pid=$con->insert_id;    
$efid=mysqli_affected_rows($con);    
if($efid>0){    
$act =remove_junk(escape('District name: '.$name));    
write_activity($aid,'DIS','District name has been added',$act);    
echo json_encode(array(
'status' => 'success',
'message'=> 'Data Save Successfully!!'   
));
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));    
} 
}   
}

if(isset($_POST['editseritem'])){
$name = remove_junk(escape($_POST['name']));
$cid = remove_junk(escape($_POST['cid']));    
$itemid = remove_junk(escape($_POST['itmid']));;
 
if(isset($_POST['name'])){
$sql="SELECT * FROM tbl_district WHERE cid = '$cid' AND name='$name' AND id!='$itemid'";           
$ducode = mysqli_query($con,$sql);
}
    
if($ducode->num_rows > 0) {
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! District Already Exists!!'
));
return;
exit;
}else{ 
$sql="UPDATE tbl_district SET cid='$cid',name='$name' WHERE id='$itemid'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$pid=$con->insert_id;    
$efid=mysqli_affected_rows($con);    
if($efid>0){    
$act =remove_junk(escape('District name: '.$name));    
write_activity($aid,'DIS','District name has been Updated',$act);    
echo json_encode(array(
'status' => 'success',
'message'=> 'Data Update Successfully!!'   
));
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Update!!'
));    
} 
}   
}

if(isset($_POST['revsitem'])){
$id=intval($_POST['item']);

if(delete_check('tbl_zone','did',$id)>0 || delete_check('tbl_customer','did',$id)>0){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! District depend on other Table!!'
));
exit;    
}
$name= get_fild_data('tbl_district',$id,'name');    
$sql="DELETE FROM tbl_district WHERE id='$id'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);    
if($efid>0){
$act =remove_junk(escape('District name: '.$name));    
write_activity($aid,'DIS','District has been deleted',$act);        
echo json_encode(array(
'status' => 'success',
'message'=> 'District successfully deleted!!'   
));
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Deleted!!'
));   
}    
    
}
?> 
<?php 
if(isset($_POST['addsitem'])){ 
$item=intval($_POST['item']);   
?>
<div class="col-md-12 popup_details_div addservice">
<div class="row">
<div id="server-results"><!-- For server results --></div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<?php if($item <=0){ ?>
<div class="form-group">
<label>Select Country</label>
<select class="form-control select2" name="cid" id="cid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_country ORDER BY name ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>    
</div>    
<div class="form-group">
<label>Name</label>
<input type="text" maxlength="35" value="" name="name" id="name" class="form-control" placeholder="e.g. Dhaka"/>
<input type="hidden" name="addseritem" readonly /> 
</div>    
<?php 
}else{ 
$sql="SELECT * FROM tbl_district WHERE id='".$item."' ORDER BY name ASC LIMIT 1";    
$admin=mysqli_query($con,$sql) or die(mysqli_error($con));    
$adm=mysqli_fetch_array($admin);    
?>
<div class="form-group">
<label>Select Country</label>
<select class="form-control select2" name="cid" id="cid">
<option value="">-Select-</option>
<?php									
$queryd=mysqli_query($con,"SELECT * FROM tbl_country ORDER BY name ASC")or die(mysqli_error($con));
while ($rowd=mysqli_fetch_array($queryd)){
?>
<?php if($rowd['id']==$adm['cid']){ ?>
<option selected value="<?php echo $rowd['id'];?>"><?php echo $rowd['name'];?></option>
<?php }else{?>    
<option value="<?php echo $rowd['id'];?>"><?php echo $rowd['name'];?></option>
<?php } ?> 
<?php } ?>    
</select>    
</div>     
<div class="form-group">
<label>Name</label>
<input type="text" maxlength="35" value="<?php echo $adm['name'];?>" name="name" id="name" class="form-control" placeholder="e.g. bKash"/>
<input type="hidden" maxlength="11" value="<?php echo $adm['id'];?>" class="form-control" name="itmid" autocomplete="off" readonly>
<input type="hidden" name="editseritem" readonly />     
</div>   
<?php } ?>   
</div>    
<div class="col-md-1"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-2 text-right" >
<input type="button" id="additem" class="btn btn-flat bg-purple btn-sm " value="<?php if($item <=0){echo 'Save';}else{echo 'Update';} ?>"/>
</div>
<div class="col-md-2"></div>    
</div>
<script type="text/javascript">

function chek_error(){
var result = true;
var name = $('#name').val();
var cid = $('#cid').val();    


$('.LV_invalid_field').removeClass('LV_invalid_field');     
$('.LV_validation_message').remove();     

if(cid.length<1){
$('#cid').addClass('LV_invalid_field');   
$('#cid').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#cid').removeClass('LV_invalid_field');
result=true;    
}    
    
if(name.length<1){
$('#name').addClass('LV_invalid_field');   
$('#name').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#name').removeClass('LV_invalid_field');
result=true;    
}    
    
if(name.length<1 || cid.length<1 || !result){
return false;    
}else{
return true;     
}        
}
    
$(document).on('blur', '#name', function() {
chek_error();    
});
$(".select2").select2();    
</script> 

<?php } ?>

<?php if(isset($_POST['viewitem'])){
$sql="SELECT * FROM tbl_district ORDER BY name ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){    
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td><?php echo get_fild_data('tbl_country',$row['cid'],'name');?></td>      
<td><?php echo $row['name'];?></td>      
<td nowrap="">
<a class="btn btn-flat bg-purple details-invoice" href="#" id="DS_<?php echo $row['id']; ?>"><i class="fa fa-edit cat-child"></i></a>    
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
</td>    
</tr>    
<?php }} ?>

<?php 
if(isset($_POST['viewitemhis'])){
if($_SESSION['utype']=='1'){echo read_activity($aid,'DIS','A');}else{echo read_activity($aid,'DIS','U');}
}?>