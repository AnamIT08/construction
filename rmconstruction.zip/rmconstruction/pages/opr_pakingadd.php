<?php 
include ('../inc/dbcon.php');
include ('../inc/functions.php');
?>
<div class="col-md-12 form-group">
<form action="opr_invoice.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">    
<table class="table table-bordered table-striped">
<tr>
<td>#</td>
<td colspan="4">Product</td>
<td>Packages (CTNS)</td>
<td>Net Weight (KGS)</td>
<td>Gross Weight (KGS)</td>
<td></td>    
</tr>    
<?php if(isset($_POST['packid'])){
$s=0;    
$seid=$_POST['packid'];
echo '<tr class="hidden"><td colspan="9"><input type="hidden" maxlength="11" name="invid" value="'.$seid.'" autocomplete="off"></td></tr>';    
$sql="SELECT * FROM tbl_invoicede WHERE seid='$seid' ORDER BY id ASC";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){ 
$s+=1;    
?>    
<tr>
<td><?php echo $s; ?></td>
<td colspan="4"><?php echo get_name($row['itemid']); ?>   
<input type="hidden" maxlength="11" name="data[<?php echo $s; ?>][pid]" value="<?php echo $row['id']; ?>" autocomplete="off"> 
</td>
<td><input type="text" min="0" onkeypress="return isNumberKey(event)" id="pack_<?php echo $s; ?>" name="data[<?php echo $s; ?>][pack]" class="form-control package"  value="<?php echo $row['ctns'];?>" step="any" style="height: 24px; width:100%;" <?php if($row['ctns']>0){echo "readonly";}?>></td>
<td colspan="1"><input type="text" min="0" onkeypress="return isNumberKey(event)" id="net_<?php echo $s; ?>" name="data[<?php echo $s; ?>][net]" class="form-control netweight"  value="<?php echo $row['netw'];?>" step="any" style="height: 24px; width:100%;" <?php if($row['netw']>0){echo "readonly";}?>></td>
<td><input type="text" min="0" onkeypress="return isNumberKey(event)" id="gro_<?php echo $s; ?>" name="data[<?php echo $s; ?>][gross]" class="form-control grosweight"  value="<?php echo $row['grow'];?>" step="any" style="height: 24px; width:100%;" <?php if($row['grow']>0){echo "readonly";}?>></td>
<td><a class="btn btn-flat bg-purple editpac" id="et_<?php echo $s; ?>" href="#"><i class="fa fa-edit"></i></a></td>    
</tr>
<?php }} ?>
<tr>
<td colspan="5" style="text-align:center"><strong>-Total-</strong></td>
<td style="text-align:center" id="totpac"></td>
<td style="text-align:center" id="totnet"></td>
<td style="text-align:center" id="totgro"></td>
<td></td>    
</tr>
<tr>
<td colspan="9" style="text-align:right;">
<button class="btn btn-flat bg-red btn-sm" onclick="close_window(this)"><i class="fa fa-close"></i> Close</button>    
<input type="submit" name="save_pack" id="submit" class="btn btn-flat bg-purple btn-sm " value="Save"/>   
</td>    
</tr>    
</table>
</form>    
</div>    