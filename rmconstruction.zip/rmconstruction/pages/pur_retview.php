<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
include ('../inc/invfunctions.php');
$body='';
$foot='';
$buton='';
$s=0;
$totqty=0;


if(isset($_SESSION['axes_pureturn'])){
if(is_array($_SESSION['axes_pureturn'])){
$max=count($_SESSION['axes_pureturn']);
for($i=($max-1);$i>=0;$i=$i-1){
$pid=$_SESSION['axes_pureturn'][$i]['pid'];    
$code=$_SESSION['axes_pureturn'][$i]['code'];
$name=$_SESSION['axes_pureturn'][$i]['name'];
$unit=$_SESSION['axes_pureturn'][$i]['unid'];
$col=$_SESSION['axes_pureturn'][$i]['col'];
if($col==0){$col='';}    
$siz=$_SESSION['axes_pureturn'][$i]['siz'];
if($siz==0){$siz='';}        
$cost=$_SESSION['axes_pureturn'][$i]['cost']; 
$sold=$_SESSION['axes_pureturn'][$i]['qty'];
$prqty=$_SESSION['axes_pureturn'][$i]['prqty'];
$qty=$_SESSION['axes_pureturn'][$i]['rqty'];    
$price=$_SESSION['axes_pureturn'][$i]['price'];
$disp=$_SESSION['axes_pureturn'][$i]['disp'];
$disf=$_SESSION['axes_pureturn'][$i]['disf'];    
$disamo=$_SESSION['axes_pureturn'][$i]['disamo'];
$wday=$_SESSION['axes_pureturn'][$i]['wday'];
$pnote=$_SESSION['axes_pureturn'][$i]['pnote'];    
$subtot=$_SESSION['axes_pureturn'][$i]['subtot'];

if($col=='' && $siz==''){
$name=$name;    
}elseif($col!='' && $siz==''){
$name= $name.' '.get_fild_data('tbl_color',$col,'name');    
}elseif($col=='' && $siz!=''){
$name= $name.' '.get_fild_data('tbl_size',$siz,'sval');    
}elseif($col!='' && $siz!=''){    
$name= $name.' '.get_fild_data('tbl_color',$col,'name').' '.get_fild_data('tbl_size',$siz,'sval');    
}    
$s+=1;
$totqty+=$qty;

$body.='<tr>';
$body.='<td class="text-center" style="width:35px; max-width:35px;">'.$s.'</td>';
$body.='<td style="width:300px; max-width:300px;">'.$name.'</td>';
$body.='<td style="width:75px; max-width:75px;" class="text-center">'.$sold.'</td>';
$body.='<td style="width:75px; max-width:75px;" class="text-right">'.getfloatval($cost).'</td>';
$body.='<td style="width:60px; max-width:60px;" class="text-right">'.$disp.'</td>';    
$body.='<td style="width:60px; max-width:60px;" class="text-right">'.$disf.'</td>';
$body.='<td style="width:75px; max-width:75px;" class="text-center">'.$prqty.'</td>';    
$body.='<td style="width:75px; max-width:75px;" class="text-center"><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control quantity" id="qty_'.$i.'" value="'.$qty.'"  size="2" style="height: 24px;"/></td>';
$body.='<td id="stotal_'.$i.'" style="width:75px; max-width:75px;" class="text-right">'.getfloatval($subtot).'</td>';    
$body.='</tr>';    
}
    
$disp=$_SESSION['axes_pureturnde'][0]['disp'];
$disamo=$_SESSION['axes_pureturnde'][0]['disamo'];    
$vatp=$_SESSION['axes_pureturnde'][0]['vatp'];
$vatamo=$_SESSION['axes_pureturnde'][0]['vatamo'];
$taxp=$_SESSION['axes_pureturnde'][0]['taxp'];
$taxamo=$_SESSION['axes_pureturnde'][0]['taxamo'];
$invdue=$_SESSION['axes_pureturnde'][0]['invdue'];    
$less=$_SESSION['axes_pureturnde'][0]['less'];
$grtotal=$_SESSION['axes_pureturnde'][0]['gtotal'];     
    
$foot.='<tr>';
$foot.='<td style="width:35px; max-width:35px;"></td>';
$foot.='<td style="width:300px; max-width:300px;"></td>';
$foot.='<td style="width:75px; max-width:75px;"></td>';
$foot.='<td style="width:75px; max-width:75px;"></td>';
$foot.='<td style="width:60px; max-width:60px;"></td>';
$foot.='<td style="width:60px; max-width:60px;"></td>';
$foot.='<td style="width:75px; max-width:75px;"></td>';
$foot.='<td style="width:75px; max-width:75px;"></td>';
$foot.='<td style="width:75px; max-width:75px;"></td>';    
$foot.='</tr>';    

$foot.='<tr>';
$foot.='<td colspan="2" class="text-center" width="340px"><strong>-Total-</strong></td>';
$foot.='<td colspan="5"></td>';
$foot.='<td width="75px"><strong>'.$totqty.'</strong></td>';
$foot.='<td width="75px" class="text-right"><strong>'.getfloatval(get_pureturn_total()).'</strong></td>';
$foot.='</tr>';    

if(get_puretdiscount_total()>0){
$foot.='<tr>';
$foot.='<td colspan="7" class="text-right" width="340px"><strong>Discount on Item :</strong></td>';
$foot.='<td width="75px"></td>';
$foot.='<td width="75px" class="text-right"><strong>'.getfloatval(get_puretdiscount_total()).'</strong></td>';
$foot.='</tr>';    
}    
$foot.='<tr>';
$foot.='<td colspan="7" class="text-right" width="340px"><strong>Discount (%) :</strong></td>';
$foot.='<td width="75px" class="text-right">'.getfloatval($disp).'</td>';
$foot.='<td width="75px" class="text-right"><strong>'.getfloatval(get_puretdiscount_total($disp)-get_puretdiscount_total()).'</strong></td>';
$foot.='</tr>';
if(get_puretdiscount_total()>0){
$foot.='<tr>';
$foot.='<td colspan="7" class="text-right" width="340px"><strong>Total Discount :</strong></td>';
$foot.='<td width="75px"></td>';
$foot.='<td width="75px" class="text-right"><strong>'.getfloatval(get_puretdiscount_total($disp)).'</strong></td>';
$foot.='</tr>';    
}    
$foot.='<tr>';
$foot.='<td colspan="7" class="text-right" width="340px"><strong>VAT (%) :</strong></td>';
$foot.='<td width="75px" class="text-right">'.getfloatval($vatp).'</td>';
$foot.='<td width="75px" class="text-right"><strong>'.getfloatval($vatamo).'</strong></td>';
$foot.='</tr>';
$foot.='<tr>';
$foot.='<td colspan="7" class="text-right" width="340px"><strong>TAX (%) :</strong></td>';
$foot.='<td width="75px" class="text-right">'.getfloatval($taxp).'</td>';
$foot.='<td width="75px" class="text-right"><strong>'.getfloatval($taxamo).'</strong></td>';
$foot.='</tr>';
//$foot.='<tr>';
//$foot.='<td colspan="7" class="text-right" width="340px"><strong>Invoice Due :</strong></td>';
//$foot.='<td width="75px" class="text-right"></td>';
//$foot.='<td width="75px" class="text-right"><strong>'.getfloatval($invdue).'</strong></td>';
//$foot.='</tr>';    
$foot.='<tr>';
$foot.='<td colspan="7" class="text-right" width="340px"><strong>Fractional Discount:</strong></td>';
$foot.='<td width="75px" class="text-right"><input type="text" maxlength="6" min="0" onkeypress="return isNumberKey(event)" class="form-control text-right" id="less" value="'.getfloatval($less).'"  size="2" style="height: 24px;"/></td>';
$foot.='<td width="75px" class="text-right" id="lessd"><strong>'.getfloatval($less).'</strong></td>';
$foot.='</tr>';
$foot.='<tr>';
$foot.='<td colspan="7" class="text-right" width="340px"><strong>Return Total:</strong></td>';
$foot.='<td width="75px" class="text-right"></td>';
$foot.='<td width="75px" class="text-right"><strong>'.getfloatval($grtotal).'</strong></td>';
$foot.='</tr>';    
    
    
    
}else{
$body.='<tr>';
$body.='<td colspan="7" class="text-center">There are no Return Item!</td>';
$body.='</tr>'; 
} 
}else{
$body.='<tr>';
$body.='<td colspan="7" class="text-center">There are no Return Item!</td>';
$body.='</tr>';
}


if(isset($_SESSION['axes_pureturn'])){
$buton.='<div class="col-md-6">';
$buton.='<a href="pur_pinvlist.php" class="btn btn-flat bg-gray">Invoice</a><input type="button" id="retcancel" class="btn btn-flat bg-blue btn-sm" onclick="take_action('."'canpre'".')" value="Cancel"/></div>';
$buton.='<div class="col-md-6 text-right">';   
$buton.='<input type="button" id="save_return" class="btn btn-flat bg-purple btn-sm" value="Return"/>'; 
$buton.='</div>';
}

if(isset($_POST['body'])){
echo $body;
}elseif(isset($_POST['foot'])){
echo $foot;
}elseif(isset($_POST['buton'])){
echo $buton;    
}
?>

<?php if(isset($_SESSION['pureturninv']) && isset($_POST['invdata'])){
$inv = $_SESSION['pureturninv'];
$sql="SELECT * FROM tbl_purchase WHERE id='".$inv."' LIMIT 1";    
$pure=mysqli_query($con,$sql) or die(mysqli_error($con));    
$ret=mysqli_fetch_array($pure);
?>    
<div class="row-cols row">
<div class="col-6 col-xs-6">
<h4>Vendor</h4>    
<?php if(isset($_SESSION['pureturninv'])){ if($ret['type']=='CU'){echo get_csinfogen($ret['supid'],'tbl_customer');}else{echo get_csinfogen($ret['supid'],'tbl_supplier');}}?>    
</div>
<div class="col-6 col-xs-6">
<h4>Address</h4>
<?php if(isset($_SESSION['pureturninv'])){ if($ret['type']=='CU'){echo get_csinfogen($ret['supid'],'tbl_customer','address');}else{echo get_csinfogen($ret['supid'],'tbl_supplier','address');}}?>    
</div>
<div class="clearfix"></div>
</div>    
<div class="row-cols row">
<div class="col-6 col-xs-6">
<strong>Date:</strong> <?php if(isset($_SESSION['pureturninv'])){ echo date("d M Y", strtotime($ret['apdate']));}?>    
</div>
<div class="col-6 col-xs-6 text-right">
<strong>Invoice No:</strong> <?php if(isset($_SESSION['pureturninv'])){ echo $ret['invno'];}?>    
</div>
</div>
<?php } ?>