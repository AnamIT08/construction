<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('37','creates','R');     
$_SESSION['cuPages']='payr_levapcreate.php';   
$cuPage='payr_levapcreate.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];
$uty=$_SESSION['utype'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='payroll';
$menuh='Payroll';
$phead='levapcre';
$page='Leave Application';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php
if(isset($_POST['save_lar'])){
$empid = remove_junk(escape($_POST['empid']));
$lid = remove_junk(escape($_POST['lid'])); 
$apply = remove_junk(escape($_POST['apply']));
$fdate = remove_junk(escape($_POST['fdate'])); 
$tdate = remove_junk(escape($_POST['tdate']));
$status = remove_junk(escape($_POST['status'])); 
$reason = remove_junk(escape($_POST['reason']));
$note = remove_junk(escape($_POST['note'])); 

$date1=date_create($fdate);
$date2=date_create($tdate);
$diff=date_diff($date1,$date2);
$lday = intval(($diff->format("%R%a"))+1);    
    
if($fdate>$tdate){
save_msg('w','Please enter valid date!!');
echo "<script>window.location='payr_levapcreate.php'</script>";
exit;    
}    

$sql="INSERT INTO tbl_leaverequest(lid,empid,lfrom,lto,ldays,empremarks,adminremarks,status,apdate,brid,uid,date) VALUES ($lid,'$empid','$fdate','$tdate','$lday','$reason','$note','$status','$apply','$brid','$aid','$dtnow')";    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);   
if($efid>0){
$name = get_fild_data('tbl_employe',$empid,'name');    
$act =remove_junk(escape('Employee name: '.$name));    
write_activity($aid,'ALV','Apply new leave request',$act);    
save_msg('s','Leave request Added Successfully!!!');   
}else{
save_msg('e','Leave request insert fail!!!!');   
}
echo "<script>window.location='payr_levapcreate.php'</script>";     
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Add Leave Request</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="payr_levapcreate.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">    
<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<div class="row">
<div class="col-md-6">
<div class="form-group" >
<label>Employee</label>
<div class="input-group">
<span class="input-group-addon">EM</span>
<select class="form-control select2" name="empid" id="empid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_employe ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo '('.$rows['code'].') - '.$rows['name'];?></option>
<?php } ?>
</select>
</div>
</div>
</div>
<div class="col-md-3">
<div class="form-group" >
<label>Leave Type</label>
<select class="form-control select2" name="lid" id="lid">
<option value="">-Select-</option>
<?php									
$queryd=mysqli_query($con,"SELECT * FROM tbl_leave ORDER BY id ASC")or die(mysqli_error($con));
while ($rowd=mysqli_fetch_array($queryd)){
?>
<option value="<?php echo $rowd['id'];?>"><?php echo $rowd['name'];?></option>
<?php } ?>                                                                
</select>
</div>        
</div> 
<div class="col-md-3">
<div class="form-group" >
<label>Apply Date</label>
<div class="input-group">
<span class="input-group-addon">
<span class="fa fa-calendar"></span>
</span>
<input type="text" class="form-control datetimepicker" name="apply" id="apply" value="<?php echo date('Y-m-d');?>" placeholder="" autocomplete="off">
</div>
</div>
</div>    
</div>
<div class="row">
<div class="col-md-4">    
<div class="form-group" >
<label>Leave From</label>
<div class="input-group">
<span class="input-group-addon">
<span class="fa fa-calendar"></span>
</span>
<input type="text" class="form-control datetimepicker" name="fdate" id="fdate" placeholder="" autocomplete="off">
<span class="input-group-addon">LVF</span>
</div>
</div>
</div>
<div class="col-md-4">    
<div class="form-group" >
<label>Leave To</label>
<div class="input-group">
<span class="input-group-addon">
<span class="fa fa-calendar"></span>
</span>
<input type="text" class="form-control datetimepicker" name="tdate" id="tdate" placeholder="" autocomplete="off">
<span class="input-group-addon">LVT</span>
</div>
</div>
</div>
<div class="col-md-4">    
<div class="form-group" >
<label>Status</label>
<div class="input-group">
<span class="input-group-addon">ST</span>    
<select class="form-control" name="status" id="status" <?php if($uty!=1){echo 'disabled';}?>>
<option value="2">Pending</option>
<option value="1">Approve</option>
<option value="0">Disapprove</option>    
</select>    
</div>
</div>
</div>    
</div>
<div class="row">
<div class="col-md-6">    
<div class="form-group">
<label>Reason</label>
<div class="input-group">
<span class="input-group-addon">RE</span>
<textarea class="form-control" name="reason" id="reason" maxlength="250" rows="5" placeholder="Reason"></textarea>
</div>    
</div>
</div>
<div class="col-md-6">    
<div class="form-group">
<label>Note</label>
<div class="input-group">
<span class="input-group-addon">PA</span>
<textarea class="form-control" name="note" id="note" maxlength="250" rows="5" placeholder="Note"></textarea>
</div>    
</div>
</div>    
</div>
    
</div>    
<div class="col-md-1"></div>
</div>    
</div>
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="save_lar" id="submit" class="btn btn-flat bg-purple btn-sm " value="Save"/> <a href="payr_levaplist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'ALV','A');}else{echo read_activity($aid,'ALV','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function () {
var empid = new LiveValidation('empid');
empid.add(Validate.Presence);    
var lid = new LiveValidation('lid');
lid.add(Validate.Presence);
var apply = new LiveValidation('apply');
apply.add(Validate.Presence);    
var fdate = new LiveValidation('fdate');
fdate.add(Validate.Presence); 
var tdate = new LiveValidation('tdate');
tdate.add(Validate.Presence);
var reason = new LiveValidation('reason');
reason.add(Validate.Presence);    
var status = new LiveValidation('status');
status.add(Validate.Presence);     
});
</script>    
<!-- /page script -->
</html>    