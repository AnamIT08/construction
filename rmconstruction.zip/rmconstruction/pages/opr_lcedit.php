<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('6','edits','R');     
$_SESSION['cuPages']='opr_lclist.php';   
$cuPage='opr_lclist.php';    
$aid=$_SESSION['uid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='operation';
$menuh='Operation Process';
$phead='lcist';
$page='Edit LC';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['update_lcn'])){
	$lcid = remove_junk(escape($_POST['lcid']));
    $lcno = strtoupper(remove_junk(escape($_POST['lcno'])));
    $pino = strtoupper(remove_junk(escape($_POST['pino'])));
    $doi = remove_junk(escape($_POST['doi']));
    $expdate = remove_junk(escape($_POST['expdate']));
    $ldos = remove_junk(escape($_POST['ldos']));
    $apbank = ucwords(remove_junk(escape($_POST['apbank'])));
	$expdays = remove_junk(escape($_POST['expdays']));
    if($expdays!=''){$expdays=0;}
	if(isset($_POST['lcno'])){
	$ducode = mysqli_query($con,"SELECT * FROM tbl_lcopen WHERE lcno = '$lcno' AND id!='$lcid'");
	}
	if(isset($_POST['pino'])){
	$dupi = mysqli_query($con,"SELECT * FROM tbl_lcopen WHERE pino = '$pino' AND id!='$lcid'");
	}
    if($dupi->num_rows > 0) {
    save_msg('i','PI no alrady exists!');
	echo "<script>window.location='opr_lclist.php'</script>";
	}
    
	if($ducode->num_rows > 0) {
		save_msg('i','LC No alrady exists!');
		echo "<script>window.location='opr_lclist.php'</script>";
	}else{
    $sql="UPDATE tbl_lcopen SET lcno='$lcno',pino='$pino',doi='$doi',expdate='$expdate',expdays='$expdays',ldos='$ldos',apbank='$apbank' WHERE id='$lcid'";    
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $efid=mysqli_affected_rows($con);     
    if($efid>0){
    $act =remove_junk(escape('LC No: '.$lcno));    
    write_activity($aid,'LCN','LC No has been Update',$act);    
    save_msg('s','Data Successfully Updated!');
	}else{
    save_msg('w','Data Fail to Update!');    
    }
    echo "<script>window.location='opr_lclist.php'</script>";     
    }
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">EditLetter of Credit (LC)</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="opr_lcedit.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">    
<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<?php 
if(isset($_POST['editlc'])){
$ids = $_POST['editlc'];
$sql="SELECT * FROM tbl_lcopen WHERE id='".$ids."' ORDER BY id ASC LIMIT 1";    
$admin=mysqli_query($con,$sql) or die(mysqli_error($con));    
$adm=mysqli_fetch_array($admin);
?>     
<div class="row">
<div class="col-md-4">
<div class="form-group" >
<label>LC No</label>
<input type="text" maxlength="25" class="form-control" name="lcno" id="lcno" value="<?php echo $adm['lcno'];?>" placeholder="e.g. 1741192300167" autocomplete="off">
<input type="hidden" maxlength="11" value="<?php echo $adm['id'];?>" class="form-control" name="lcid" autocomplete="off" readonly>    
</div>    
</div>
<div class="col-md-4">
<div class="form-group" >
<label>PI No</label>
<input type="text" maxlength="25" class="form-control" name="pino" id="pino" value="<?php echo $adm['pino'];?>" placeholder="e.g. XHL20191203003" autocomplete="off">    
</div>
</div>
<div class="col-md-4">
<div class="form-group" >
<label>Date of Issue</label>
<div class="input-group">
<span class="input-group-addon">
<span class="fa fa-calendar"></span>
</span>
<input type="text" class="form-control datetimepicker" name="doi" id="doi" value="<?php echo $adm['doi'];?>" placeholder="Date of Issue" autocomplete="off" readonly>
</div>
</div>
</div>    
</div>
<div class="row">
<div class="col-md-4">
<div class="form-group" >
<label>Date of Expiry</label>
<div class="input-group">
<span class="input-group-addon">
<span class="fa fa-calendar"></span>
</span>
<input type="text" class="form-control datetimepicker" name="expdate" id="expdate" value="<?php echo $adm['expdate'];?>" placeholder="Date of Expiry" autocomplete="off" readonly>
</div>
</div>    
</div>
<div class="col-md-4">
<div class="form-group" >
<label>Expiry After Days</label>
<input type="text" maxlength="3" class="form-control" min="0" value="0" name="expdays" id="expdays" nkeypress="return isNumberKey(event)" value="<?php echo $adm['expdays'];?>" placeholder="e.g. 90" autocomplete="off">    
</div>    
</div>
<div class="col-md-4">
<div class="form-group" >
<label>Latest Date of Shipment</label>
<div class="input-group">
<span class="input-group-addon">
<span class="fa fa-calendar"></span>
</span>
<input type="text" class="form-control datetimepicker" name="ldos" id="ldos" value="<?php echo $adm['ldos'];?>" placeholder="Latest Date of Shipment" autocomplete="off" readonly>
</div>
</div>    
</div>    
</div>    
<div class="row">
<div class="col-md-6">
<div class="form-group" >
<label>Applicant Bank</label>
<textarea class="form-control" name="apbank" id="apbank" maxlength="150" rows="5" placeholder="e.g. Mercantile Bank Limited"><?php echo $adm['apbank'];?></textarea>   
</div>
</div>    
</div>
<?php } ?>   
</div>    
<div class="col-md-1"></div>
</div>
</div>
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="update_lcn" id="submit" class="btn btn-flat bg-purple btn-sm " value="Update"/> <a href="opr_lclist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'LCN','A');}else{echo read_activity($aid,'LCN','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function () {
var lcno = new LiveValidation('lcno');
lcno.add(Validate.Presence);
var pino = new LiveValidation('pino');
pino.add(Validate.Presence);
var doi = new LiveValidation('doi');
doi.add(Validate.Presence);
var expdate = new LiveValidation('expdate');
expdate.add(Validate.Presence);
var ldos = new LiveValidation('ldos');
ldos.add(Validate.Presence);
var apbank = new LiveValidation('apbank');
apbank.add(Validate.Presence);    
});
$(document).on('keydown', '#pino', function() {
$('#pino' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'axe_cart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term, getpi:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
var te=ui.item.label;
$(this).val(te); // display the selected text
return false;
}
});    
});    
</script>    
<!-- /page script -->
</html>    