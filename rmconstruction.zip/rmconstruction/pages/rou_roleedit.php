<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('44','edits','R');     
$_SESSION['cuPages']='rou_rolelist.php';   
$cuPage='rou_rolelist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
$uty=$_SESSION['utype'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='user';
$menuh='User &amp; Role';
$phead='rollist';
$page='User Role Edit';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['role_update'])){
$rid = remove_junk(escape($_POST['rid']));    
$name =remove_junk(escape($_POST['name']));     
$description =remove_junk(escape($_POST['description']));
$status =remove_junk(escape($_POST['status']));

if(isset($_POST['name'])){
$ducode = mysqli_query($con,"SELECT * FROM tbl_usergroup WHERE name = '$name' AND id!='$rid'");
}    
if($ducode->num_rows > 0) {
save_msg('w','Role name alrady used! Plz try another');
echo "<script>window.location='rou_rolelist.php'</script>";
}else{
    
$sql="UPDATE tbl_usergroup SET name='$name',description='$description',status='$status' WHERE id='$rid'";    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
if(isset($_POST['data']) && !empty($_POST['data'])){
$settings=$_POST['data'];
foreach($settings as $setup){
$pageid=remove_junk(escape($setup['id']));
if(!isset($setup['read'])){
$views=0;    
}else{
$views=remove_junk(escape($setup['read']));    
}
if(!isset($setup['write'])){
$creates=0;    
}else{
$creates=remove_junk(escape($setup['write']));    
}
if(!isset($setup['edit'])){
$edits=0;    
}else{
$edits=remove_junk(escape($setup['edit']));     
}
if(!isset($setup['delete'])){
$deletes=0;   
}else{
$deletes=remove_junk(escape($setup['delete']));    
}
if(!isset($setup['print'])){
$prints=0;    
}else{
$prints=remove_junk(escape($setup['print']));     
}    	
$section=remove_junk(escape($setup['sec']));
$sql="UPDATE tbl_userpermision SET views='$views',creates='$creates',edits='$edits',deletes='$deletes',prints='$prints' WHERE seid='$rid' AND pageid='$pageid'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));  
}
}
$act =remove_junk(escape('Role name: '.$name));    
write_activity($aid,'ROL','Role has been updated',$act);     
save_msg('s','Role Setting Successfully Update!');	
echo "<script>window.location='rou_rolelist.php'</script>";    
}
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Assigned Role Edit</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="rou_roleedit.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">

<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-5">
<?php 
if(isset($_POST['editrol'])){
$ids = $_POST['editrol'];
$sql="SELECT * FROM tbl_usergroup WHERE id='".$ids."' ORDER BY id ASC LIMIT 1";    
$admin=mysqli_query($con,$sql) or die(mysqli_error($con));    
while ($adm=mysqli_fetch_array($admin)){    
?>      
<div class="form-group">
<label>Name</label>
<input type="text" name="name" maxlength="25" value="<?php echo $adm['name'];?>" id="pname" class="form-control" placeholder="Role Name"  />
<input type="hidden" maxlength="11" value="<?php echo $adm['id'];?>" class="form-control" name="rid" autocomplete="off" readonly>    
</div>
<div class="form-group" >
<label>Status</label>  
<select class="form-control" name="status" id="status">
<option <?php if($adm['status']==1){echo 'selected';}?> value="1">Active</option>
<option <?php if($adm['status']==0){echo 'selected';}?> value="0">De-Active</option>
</select>    
</div>    
<div class="form-group">
<label>Description</label>
<textarea class="form-control" maxlength="150" rows="6" name="description" placeholder="Description"><?php echo $adm['description'];?></textarea>
</div>
<?php }} ?>    
</div>
<div class="col-md-5"> 
<div class="form-group">
<label>Module Access</label>    
<ul class="list-group">
<li class="list-groups-item">
Daily Process
<div class="material-switch pull-right">
<input id="daily" type="checkbox" class="access" checked="">
<label for="daily" class="label-success"></label>
</div>
</li>
<li class="list-groups-item">
Operation Process
<div class="material-switch pull-right">
<input id="operation" type="checkbox" class="access" checked="">
<label for="operation" class="label-success"></label>
</div>
</li>
<li class="list-groups-item">
Client
<div class="material-switch pull-right">
<input id="client" type="checkbox" class="access" checked="">
<label for="client" class="label-success"></label>
</div>
</li>
<li class="list-groups-item">
Product
<div class="material-switch pull-right">
<input id="product" type="checkbox" class="access" checked="">
<label for="product" class="label-success"></label>
</div>
</li>
<li class="list-groups-item">
Master
<div class="material-switch pull-right">
<input id="master" type="checkbox" class="access" checked="">
<label for="master" class="label-success"></label>
</div>
</li>
<li class="list-groups-item">
Accounts
<div class="material-switch pull-right">
<input id="account" type="checkbox" class="access" checked="">
<label for="account" class="label-success"></label>
</div>
</li>
<li class="list-groups-item">
Financials
<div class="material-switch pull-right">
<input id="financial" type="checkbox" class="access" checked="">
<label for="financial" class="label-success"></label>
</div>
</li>
<li class="list-groups-item">
Payroll
<div class="material-switch pull-right">
<input id="payrol" type="checkbox" class="access" checked="">
<label for="payrol" class="label-success"></label>
</div>
</li>
<li class="list-groups-item">
Bank
<div class="material-switch pull-right">
<input id="bank" type="checkbox" class="access" checked="">
<label for="bank" class="label-success"></label>
</div>
</li>
<li class="list-groups-item">
User &amp; Role
<div class="material-switch pull-right">
<input id="user" type="checkbox" class="access" checked="">
<label for="user" class="label-success"></label>
</div>
</li>
<li class="list-groups-item">
Report
<div class="material-switch pull-right">
<input id="report" type="checkbox" class="access" checked="">
<label for="report" class="label-success"></label>
</div>
</li>    
</ul>    
</div>
</div>    
<div class="col-md-1"></div>    
</div>    
</div>    

<div class="row" id="edaily">
<div class="col-md-12">
<table class="table">
<thead>
<tr>
<th style="width:285px;">Daily Process</th>
<th class="text-center">Read</th>
<th class="text-center">Write</th>
<th class="text-center">Edit</th>
<th class="text-center">Delete</th>
<th class="text-center">Print</th>
</tr>
</thead>
<tbody>
<tr>
<td>Price List
<input type="hidden" maxlength="11" name="data[2][id]" value="2" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[2][sec]" value="daily" class="form-control" autocomplete="off">    
</td>
<td class="text-center">
<input type="checkbox"  name="data[2][read]" class="role" <?php if(get_pageval($ids,'2','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'2','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[2][write]" class="role" <?php if(get_pageval($ids,'2','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'2','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[2][edit]" class="role" <?php if(get_pageval($ids,'2','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'2','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[2][delete]" class="role" <?php if(get_pageval($ids,'2','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'2','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[2][print]" class="role" <?php if(get_pageval($ids,'2','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'2','prints'); ?>">
</td>
</tr>
<tr>
<td>Expenses Record
<input type="hidden" maxlength="11" name="data[3][id]" value="3" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[3][sec]" value="daily" class="form-control" autocomplete="off"> 
</td>
<td class="text-center">
<input type="checkbox"  name="data[3][read]" class="role" <?php if(get_pageval($ids,'3','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'3','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[3][write]" class="role" <?php if(get_pageval($ids,'3','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'3','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[3][edit]" class="role" <?php if(get_pageval($ids,'3','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'3','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[3][delete]" class="role" <?php if(get_pageval($ids,'3','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'3','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[3][print]" class="role" <?php if(get_pageval($ids,'3','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'3','prints'); ?>">
</td>
</tr>
<tr>
<td>Expenses Head
<input type="hidden" maxlength="11" name="data[4][id]" value="4" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[4][sec]" value="daily" class="form-control" autocomplete="off"> 
</td>
<td class="text-center">
<input type="checkbox"  name="data[4][read]" class="role" <?php if(get_pageval($ids,'4','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'4','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[4][write]" class="role" <?php if(get_pageval($ids,'4','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'4','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[4][edit]" class="role" <?php if(get_pageval($ids,'4','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'4','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[4][delete]" class="role" <?php if(get_pageval($ids,'4','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'4','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[4][print]" class="role" <?php if(get_pageval($ids,'4','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'4','prints'); ?>">
</td>
</tr>
</tbody>
</table>        
</div>
</div>
    
<div class="row" id="eoperation">
<div class="col-md-12">
<table class="table">
<thead>
<tr>
<th style="width:285px;">Operation Process</th>
<th class="text-center">Read</th>
<th class="text-center">Write</th>
<th class="text-center">Edit</th>
<th class="text-center">Delete</th>
<th class="text-center">Print</th>
</tr>
</thead>
<tbody>
<tr>
<td>Proforma Invoice (PI)
<input type="hidden" maxlength="11" name="data[5][id]" value="5" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[5][sec]" value="operation" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[5][read]" class="role" <?php if(get_pageval($ids,'5','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'5','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[5][write]" class="role" <?php if(get_pageval($ids,'5','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'5','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[5][edit]" class="role" <?php if(get_pageval($ids,'5','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'5','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[5][delete]" class="role" <?php if(get_pageval($ids,'5','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'5','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[5][print]" class="role" <?php if(get_pageval($ids,'5','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'5','prints'); ?>">
</td>
</tr>
<tr>
<td>Letter of Credit (LC)
<input type="hidden" maxlength="11" name="data[6][id]" value="6" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[6][sec]" value="operation" class="form-control" autocomplete="off"> 
</td>
<td class="text-center">
<input type="checkbox"  name="data[6][read]" class="role" <?php if(get_pageval($ids,'6','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'6','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[6][write]" class="role" <?php if(get_pageval($ids,'6','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'6','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[6][edit]" class="role" <?php if(get_pageval($ids,'6','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'6','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[6][delete]" class="role" <?php if(get_pageval($ids,'6','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'6','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[6][print]" class="role" <?php if(get_pageval($ids,'6','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'6','prints'); ?>">
</td>
</tr>
<tr>
<td>Invoice
<input type="hidden" maxlength="11" name="data[7][id]" value="7" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[7][sec]" value="operation" class="form-control" autocomplete="off"> 
</td>
<td class="text-center">
<input type="checkbox"  name="data[7][read]" class="role" <?php if(get_pageval($ids,'7','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'7','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[7][write]" class="role" <?php if(get_pageval($ids,'7','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'7','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[7][edit]" class="role" <?php if(get_pageval($ids,'7','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'7','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[7][delete]" class="role" <?php if(get_pageval($ids,'7','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'7','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[7][print]" class="role" <?php if(get_pageval($ids,'7','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'7','prints'); ?>">
</td>
</tr>
<tr>
<td>Delivery Record
<input type="hidden" maxlength="11" name="data[8][id]" value="8" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[8][sec]" value="operation" class="form-control" autocomplete="off"> 
</td>
<td class="text-center">
<input type="checkbox"  name="data[8][read]" class="role" <?php if(get_pageval($ids,'8','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'8','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[8][write]" class="role" <?php if(get_pageval($ids,'8','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'8','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[8][edit]" class="role" <?php if(get_pageval($ids,'8','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'8','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[8][delete]" class="role" <?php if(get_pageval($ids,'8','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'8','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[8][print]" class="role" <?php if(get_pageval($ids,'8','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'8','prints'); ?>">
</td>
</tr>    
</tbody>
</table>        
</div>
</div>    

<div class="row" id="eclient">
<div class="col-md-12">
<table class="table">
<thead>
<tr>
<th style="width:285px;">Client</th>
<th class="text-center">Read</th>
<th class="text-center">Write</th>
<th class="text-center">Edit</th>
<th class="text-center">Delete</th>
<th class="text-center">Print</th>
</tr>
</thead>
<tbody>
<tr>
<td>Customer
<input type="hidden" maxlength="11" name="data[9][id]" value="9" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[9][sec]" value="client" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[9][read]" class="role" <?php if(get_pageval($ids,'9','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'9','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[9][write]" class="role" <?php if(get_pageval($ids,'9','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'9','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[9][edit]" class="role" <?php if(get_pageval($ids,'9','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'9','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[9][delete]" class="role" <?php if(get_pageval($ids,'9','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'9','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[9][print]" class="role" <?php if(get_pageval($ids,'9','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'9','prints'); ?>">
</td>
</tr>
<tr>
<td>Supplier
<input type="hidden" maxlength="11" name="data[10][id]" value="10" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[10][sec]" value="client" class="form-control" autocomplete="off"> 
</td>
<td class="text-center">
<input type="checkbox"  name="data[10][read]" class="role" <?php if(get_pageval($ids,'10','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'10','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[10][write]" class="role" <?php if(get_pageval($ids,'10','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'10','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[10][edit]" class="role" <?php if(get_pageval($ids,'10','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'10','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[10][delete]" class="role" <?php if(get_pageval($ids,'10','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'10','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[10][print]" class="role" <?php if(get_pageval($ids,'10','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'10','prints'); ?>">
</td>
</tr>
</tbody>
</table>        
</div>
</div>    
    
<div class="row" id="eproduct">
<div class="col-md-12">
<table class="table">
<thead>
<tr>
<th style="width:285px;">Product</th>
<th class="text-center">Read</th>
<th class="text-center">Write</th>
<th class="text-center">Edit</th>
<th class="text-center">Delete</th>
<th class="text-center">Print</th>
</tr>
</thead>
<tbody>
<tr>
<td>Parent
<input type="hidden" maxlength="11" name="data[11][id]" value="11" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[11][sec]" value="product" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[11][read]" class="role" <?php if(get_pageval($ids,'11','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'11','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[11][write]" class="role" <?php if(get_pageval($ids,'11','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'11','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[11][edit]" class="role" <?php if(get_pageval($ids,'11','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'11','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[11][delete]" class="role" <?php if(get_pageval($ids,'11','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'11','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[11][print]" class="role" <?php if(get_pageval($ids,'11','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'11','prints'); ?>">
</td>
</tr>
<tr>
<td>Category
<input type="hidden" maxlength="11" name="data[12][id]" value="12" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[12][sec]" value="product" class="form-control" autocomplete="off"> 
</td>
<td class="text-center">
<input type="checkbox"  name="data[12][read]" class="role" <?php if(get_pageval($ids,'12','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'12','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[12][write]" class="role" <?php if(get_pageval($ids,'12','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'12','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[12][edit]" class="role" <?php if(get_pageval($ids,'12','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'12','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[12][delete]" class="role" <?php if(get_pageval($ids,'12','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'12','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[12][print]" class="role" <?php if(get_pageval($ids,'12','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'12','prints'); ?>">
</td>
</tr>
<tr>
<td>Sub-Category
<input type="hidden" maxlength="11" name="data[13][id]" value="13" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[13][sec]" value="product" class="form-control" autocomplete="off"> 
</td>
<td class="text-center">
<input type="checkbox"  name="data[13][read]" class="role" <?php if(get_pageval($ids,'13','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'13','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[13][write]" class="role" <?php if(get_pageval($ids,'13','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'13','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[13][edit]" class="role" <?php if(get_pageval($ids,'13','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'13','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[13][delete]" class="role" <?php if(get_pageval($ids,'13','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'13','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[13][print]" class="role" <?php if(get_pageval($ids,'13','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'13','prints'); ?>">
</td>
</tr>
<tr>
<td>Product
<input type="hidden" maxlength="11" name="data[14][id]" value="14" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[14][sec]" value="product" class="form-control" autocomplete="off"> 
</td>
<td class="text-center">
<input type="checkbox"  name="data[14][read]" class="role" <?php if(get_pageval($ids,'14','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'14','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[14][write]" class="role" <?php if(get_pageval($ids,'14','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'14','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[14][edit]" class="role" <?php if(get_pageval($ids,'14','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'14','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[14][delete]" class="role" <?php if(get_pageval($ids,'14','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'14','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[14][print]" class="role" <?php if(get_pageval($ids,'14','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'14','prints'); ?>">
</td>
</tr>
</tbody>
</table>        
</div>
</div>    

<div class="row" id="emaster">
<div class="col-md-12">
<table class="table">
<thead>
<tr>
<th style="width:285px;">Master</th>
<th class="text-center">Read</th>
<th class="text-center">Write</th>
<th class="text-center">Edit</th>
<th class="text-center">Delete</th>
<th class="text-center">Print</th>
</tr>
</thead>
<tbody>
<tr>
<td>Brand
<input type="hidden" maxlength="11" name="data[15][id]" value="15" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[15][sec]" value="master" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[15][read]" class="role" <?php if(get_pageval($ids,'15','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'15','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[15][write]" class="role" <?php if(get_pageval($ids,'15','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'15','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[15][edit]" class="role" <?php if(get_pageval($ids,'15','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'15','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[15][delete]" class="role" <?php if(get_pageval($ids,'15','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'15','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[15][print]" class="role" <?php if(get_pageval($ids,'15','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'15','prints'); ?>">
</td>
</tr>
<tr>
<td>Manufacturer
<input type="hidden" maxlength="11" name="data[16][id]" value="16" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[16][sec]" value="master" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[16][read]" class="role" <?php if(get_pageval($ids,'16','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'16','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[16][write]" class="role" <?php if(get_pageval($ids,'16','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'16','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[16][edit]" class="role" <?php if(get_pageval($ids,'16','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'16','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[16][delete]" class="role" <?php if(get_pageval($ids,'16','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'16','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[16][print]" class="role" <?php if(get_pageval($ids,'16','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'16','prints'); ?>">
</td>
</tr>
<tr>
<td>Unit
<input type="hidden" maxlength="11" name="data[17][id]" value="17" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[17][sec]" value="master" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[17][read]" class="role" <?php if(get_pageval($ids,'17','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'17','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[17][write]" class="role" <?php if(get_pageval($ids,'17','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'17','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[17][edit]" class="role" <?php if(get_pageval($ids,'17','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'17','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[17][delete]" class="role" <?php if(get_pageval($ids,'17','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'17','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[17][print]" class="role" <?php if(get_pageval($ids,'17','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'17','prints'); ?>">
</td>
</tr>
<tr>
<td>Currency
<input type="hidden" maxlength="11" name="data[18][id]" value="18" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[18][sec]" value="master" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[18][read]" class="role" <?php if(get_pageval($ids,'18','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'18','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[18][write]" class="role" <?php if(get_pageval($ids,'18','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'18','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[18][edit]" class="role" <?php if(get_pageval($ids,'18','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'18','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[18][delete]" class="role" <?php if(get_pageval($ids,'18','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'18','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[18][print]" class="role" <?php if(get_pageval($ids,'18','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'18','prints'); ?>">
</td>
</tr>
<tr>
<td>Country
<input type="hidden" maxlength="11" name="data[19][id]" value="19" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[19][sec]" value="master" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[19][read]" class="role" <?php if(get_pageval($ids,'19','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'19','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[19][write]" class="role" <?php if(get_pageval($ids,'19','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'19','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[19][edit]" class="role" <?php if(get_pageval($ids,'19','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'19','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[19][delete]" class="role" <?php if(get_pageval($ids,'19','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'19','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[19][print]" class="role" <?php if(get_pageval($ids,'19','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'19','prints'); ?>">
</td>
</tr>
<tr>
<td>Shipping
<input type="hidden" maxlength="11" name="data[20][id]" value="20" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[20][sec]" value="master" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[20][read]" class="role" <?php if(get_pageval($ids,'20','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'20','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[20][write]" class="role" <?php if(get_pageval($ids,'20','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'20','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[20][edit]" class="role" <?php if(get_pageval($ids,'20','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'20','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[20][delete]" class="role" <?php if(get_pageval($ids,'20','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'20','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[20][print]" class="role" <?php if(get_pageval($ids,'20','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'20','prints'); ?>">
</td>
</tr>
<tr>
<td>Color
<input type="hidden" maxlength="11" name="data[21][id]" value="21" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[21][sec]" value="master" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[21][read]" class="role" <?php if(get_pageval($ids,'21','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'21','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[21][write]" class="role" <?php if(get_pageval($ids,'21','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'21','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[21][edit]" class="role" <?php if(get_pageval($ids,'21','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'21','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[21][delete]" class="role" <?php if(get_pageval($ids,'21','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'21','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[21][print]" class="role" <?php if(get_pageval($ids,'21','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'21','prints'); ?>">
</td>
</tr>    
</tbody>
</table>        
</div>
</div>    

<div class="row" id="eaccount">
<div class="col-md-12">
<table class="table">
<thead>
<tr>
<th style="width:285px;">Accounts</th>
<th class="text-center">Read</th>
<th class="text-center">Write</th>
<th class="text-center">Edit</th>
<th class="text-center">Delete</th>
<th class="text-center">Print</th>
</tr>
</thead>
<tbody>
<tr>
<td>Class
<input type="hidden" maxlength="11" name="data[22][id]" value="22" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[22][sec]" value="account" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[22][read]" class="role" <?php if(get_pageval($ids,'22','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'22','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[22][write]" class="role" <?php if(get_pageval($ids,'22','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'22','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[22][edit]" class="role" <?php if(get_pageval($ids,'22','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'22','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[22][delete]" class="role" <?php if(get_pageval($ids,'22','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'22','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[22][print]" class="role" <?php if(get_pageval($ids,'22','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'22','prints'); ?>">
</td>
</tr>
<tr>
<td>Account Group
<input type="hidden" maxlength="11" name="data[23][id]" value="23" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[23][sec]" value="account" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[23][read]" class="role" <?php if(get_pageval($ids,'23','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'23','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[23][write]" class="role" <?php if(get_pageval($ids,'23','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'23','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[23][edit]" class="role" <?php if(get_pageval($ids,'23','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'23','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[23][delete]" class="role" <?php if(get_pageval($ids,'23','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'23','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[23][print]" class="role" <?php if(get_pageval($ids,'23','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'23','prints'); ?>">
</td>
</tr>
<tr>
<td>Account Sub-Group
<input type="hidden" maxlength="11" name="data[24][id]" value="24" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[24][sec]" value="account" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[24][read]" class="role" <?php if(get_pageval($ids,'24','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'24','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[24][write]" class="role" <?php if(get_pageval($ids,'24','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'24','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[24][edit]" class="role" <?php if(get_pageval($ids,'24','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'24','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[24][delete]" class="role" <?php if(get_pageval($ids,'24','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'24','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[24][print]" class="role" <?php if(get_pageval($ids,'24','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'24','prints'); ?>">
</td>
</tr>
<tr>
<td>Account Ledger
<input type="hidden" maxlength="11" name="data[25][id]" value="25" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[25][sec]" value="account" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[25][read]" class="role" <?php if(get_pageval($ids,'25','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'25','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[25][write]" class="role" <?php if(get_pageval($ids,'25','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'25','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[25][edit]" class="role" <?php if(get_pageval($ids,'25','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'25','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[25][delete]" class="role" <?php if(get_pageval($ids,'25','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'25','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[25][print]" class="role" <?php if(get_pageval($ids,'25','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'25','prints'); ?>">
</td>
</tr>
<tr>
<td>Payment Voucher
<input type="hidden" maxlength="11" name="data[26][id]" value="26" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[26][sec]" value="account" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[26][read]" class="role" <?php if(get_pageval($ids,'26','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'26','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[26][write]" class="role" <?php if(get_pageval($ids,'26','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'26','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[26][edit]" class="role" <?php if(get_pageval($ids,'26','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'26','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[26][delete]" class="role" <?php if(get_pageval($ids,'26','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'26','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[26][print]" class="role" <?php if(get_pageval($ids,'26','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'26','prints'); ?>">
</td>
</tr>
<tr>
<td>Received Voucher
<input type="hidden" maxlength="11" name="data[27][id]" value="27" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[27][sec]" value="account" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[27][read]" class="role" <?php if(get_pageval($ids,'27','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'27','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[27][write]" class="role" <?php if(get_pageval($ids,'27','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'27','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[27][edit]" class="role" <?php if(get_pageval($ids,'27','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'27','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[27][delete]" class="role" <?php if(get_pageval($ids,'27','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'27','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[27][print]" class="role" <?php if(get_pageval($ids,'27','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'27','prints'); ?>">
</td>
</tr>
<tr>
<td>Journal Entry
<input type="hidden" maxlength="11" name="data[28][id]" value="28" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[28][sec]" value="account" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[28][read]" class="role" <?php if(get_pageval($ids,'28','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'28','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[28][write]" class="role" <?php if(get_pageval($ids,'28','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'28','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[28][edit]" class="role" <?php if(get_pageval($ids,'28','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'28','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[28][delete]" class="role" <?php if(get_pageval($ids,'28','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'28','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[28][print]" class="role" <?php if(get_pageval($ids,'28','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'28','prints'); ?>">
</td>
</tr>    
</tbody>
</table>        
</div>
</div>    

<div class="row" id="efinancial">
<div class="col-md-12">
<table class="table">
<thead>
<tr>
<th style="width:285px;">Financials</th>
<th class="text-center">Read</th>
<th class="text-center">Write</th>
<th class="text-center">Edit</th>
<th class="text-center">Delete</th>
<th class="text-center">Print</th>
</tr>
</thead>
<tbody>
<tr>
<td>Chart Of Account
<input type="hidden" maxlength="11" name="data[29][id]" value="29" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[29][sec]" value="financial" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[29][read]" class="role" <?php if(get_pageval($ids,'29','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'29','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[29][write]" class="role" <?php if(get_pageval($ids,'29','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'29','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[29][edit]" class="role" <?php if(get_pageval($ids,'29','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'29','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[29][delete]" class="role" <?php if(get_pageval($ids,'29','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'29','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[29][print]" class="role" <?php if(get_pageval($ids,'29','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'29','prints'); ?>">
</td>
</tr>
<tr>
<td>Profit &amp; Loss
<input type="hidden" maxlength="11" name="data[30][id]" value="30" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[30][sec]" value="financial" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[30][read]" class="role" <?php if(get_pageval($ids,'30','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'30','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[30][write]" class="role" <?php if(get_pageval($ids,'30','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'30','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[30][edit]" class="role" <?php if(get_pageval($ids,'30','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'30','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[30][delete]" class="role" <?php if(get_pageval($ids,'30','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'30','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[30][print]" class="role" <?php if(get_pageval($ids,'30','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'30','prints'); ?>">
</td>
</tr>
<tr>
<td>Trial Balance
<input type="hidden" maxlength="11" name="data[31][id]" value="31" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[31][sec]" value="financial" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[31][read]" class="role" <?php if(get_pageval($ids,'31','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'31','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[31][write]" class="role" <?php if(get_pageval($ids,'31','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'31','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[31][edit]" class="role" <?php if(get_pageval($ids,'31','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'31','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[31][delete]" class="role" <?php if(get_pageval($ids,'31','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'31','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[31][print]" class="role" <?php if(get_pageval($ids,'31','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'31','prints'); ?>">
</td>
</tr>
<tr>
<td>Balance Sheet
<input type="hidden" maxlength="11" name="data[32][id]" value="32" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[32][sec]" value="financial" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[32][read]" class="role" <?php if(get_pageval($ids,'32','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'32','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[32][write]" class="role" <?php if(get_pageval($ids,'32','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'32','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[32][edit]" class="role" <?php if(get_pageval($ids,'32','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'32','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[32][delete]" class="role" <?php if(get_pageval($ids,'32','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'32','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[32][print]" class="role" <?php if(get_pageval($ids,'32','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'32','prints'); ?>">
</td>
</tr>
<tr>
<td>Finance Analysis
<input type="hidden" maxlength="11" name="data[33][id]" value="33" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[33][sec]" value="financial" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[33][read]" class="role" <?php if(get_pageval($ids,'33','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'33','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[33][write]" class="role" <?php if(get_pageval($ids,'33','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'33','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[33][edit]" class="role" <?php if(get_pageval($ids,'33','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'33','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[33][delete]" class="role" <?php if(get_pageval($ids,'33','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'33','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[33][print]" class="role" <?php if(get_pageval($ids,'33','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'33','prints'); ?>">
</td>
</tr>
</tbody>
</table>        
</div>
</div>    

<div class="row" id="epayrol">
<div class="col-md-12">
<table class="table">
<thead>
<tr>
<th style="width:285px;">Payroll</th>
<th class="text-center">Read</th>
<th class="text-center">Write</th>
<th class="text-center">Edit</th>
<th class="text-center">Delete</th>
<th class="text-center">Print</th>
</tr>
</thead>
<tbody>
<tr>
<td>Department
<input type="hidden" maxlength="11" name="data[34][id]" value="34" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[34][sec]" value="payrol" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[34][read]" class="role" <?php if(get_pageval($ids,'34','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'34','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[34][write]" class="role" <?php if(get_pageval($ids,'34','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'34','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[34][edit]" class="role" <?php if(get_pageval($ids,'34','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'34','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[34][delete]" class="role" <?php if(get_pageval($ids,'34','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'34','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[34][print]" class="role" <?php if(get_pageval($ids,'34','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'34','prints'); ?>">
</td>
</tr>
<tr>
<td>Designation
<input type="hidden" maxlength="11" name="data[35][id]" value="35" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[35][sec]" value="payrol" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[35][read]" class="role" <?php if(get_pageval($ids,'35','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'35','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[35][write]" class="role" <?php if(get_pageval($ids,'35','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'35','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[35][edit]" class="role" <?php if(get_pageval($ids,'35','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'35','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[35][delete]" class="role" <?php if(get_pageval($ids,'35','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'35','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[35][print]" class="role" <?php if(get_pageval($ids,'35','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'35','prints'); ?>">
</td>
</tr>
<tr>
<td>Employee
<input type="hidden" maxlength="11" name="data[36][id]" value="36" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[36][sec]" value="payrol" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[36][read]" class="role" <?php if(get_pageval($ids,'36','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'36','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[36][write]" class="role" <?php if(get_pageval($ids,'36','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'36','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[36][edit]" class="role" <?php if(get_pageval($ids,'36','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'36','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[36][delete]" class="role" <?php if(get_pageval($ids,'36','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'36','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[36][print]" class="role" <?php if(get_pageval($ids,'36','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'36','prints'); ?>">
</td>
</tr>
<tr>
<td>Leave
<input type="hidden" maxlength="11" name="data[37][id]" value="37" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[37][sec]" value="payrol" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[37][read]" class="role" <?php if(get_pageval($ids,'37','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'37','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[37][write]" class="role" <?php if(get_pageval($ids,'37','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'37','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[37][edit]" class="role" <?php if(get_pageval($ids,'37','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'37','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[37][delete]" class="role" <?php if(get_pageval($ids,'37','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'37','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[37][print]" class="role" <?php if(get_pageval($ids,'37','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'37','prints'); ?>">
</td>
</tr>
<tr>
<td>Leave Record
<input type="hidden" maxlength="11" name="data[38][id]" value="38" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[38][sec]" value="payrol" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[38][read]" class="role" <?php if(get_pageval($ids,'38','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'38','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[38][write]" class="role" <?php if(get_pageval($ids,'38','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'38','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[38][edit]" class="role" <?php if(get_pageval($ids,'38','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'38','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[38][delete]" class="role" <?php if(get_pageval($ids,'38','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'38','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[38][print]" class="role" <?php if(get_pageval($ids,'38','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'38','prints'); ?>">
</td>
</tr>
<tr>
<td>Leave Application
<input type="hidden" maxlength="11" name="data[39][id]" value="39" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[39][sec]" value="payrol" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[39][read]" class="role" <?php if(get_pageval($ids,'39','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'39','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[39][write]" class="role" <?php if(get_pageval($ids,'39','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'39','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[39][edit]" class="role" <?php if(get_pageval($ids,'39','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'39','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[39][delete]" class="role" <?php if(get_pageval($ids,'39','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'39','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[39][print]" class="role" <?php if(get_pageval($ids,'39','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'39','prints'); ?>">
</td>
</tr>
<tr>
<td>Attendance &amp; Payslip
<input type="hidden" maxlength="11" name="data[40][id]" value="40" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[40][sec]" value="payrol" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[40][read]" class="role" <?php if(get_pageval($ids,'40','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'40','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[40][write]" class="role" <?php if(get_pageval($ids,'40','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'40','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[40][edit]" class="role" <?php if(get_pageval($ids,'40','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'40','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[40][delete]" class="role" <?php if(get_pageval($ids,'40','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'40','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[40][print]" class="role" <?php if(get_pageval($ids,'40','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'40','prints'); ?>">
</td>
</tr>    
</tbody>
</table>        
</div>
</div>    

<div class="row" id="ebank">
<div class="col-md-12">
<table class="table">
<thead>
<tr>
<th style="width:285px;">Bank</th>
<th class="text-center">Read</th>
<th class="text-center">Write</th>
<th class="text-center">Edit</th>
<th class="text-center">Delete</th>
<th class="text-center">Print</th>
</tr>
</thead>
<tbody>
<tr>
<td>Bank
<input type="hidden" maxlength="11" name="data[41][id]" value="41" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[41][sec]" value="bank" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[41][read]" class="role" <?php if(get_pageval($ids,'41','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'41','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[41][write]" class="role" <?php if(get_pageval($ids,'41','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'41','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[41][edit]" class="role" <?php if(get_pageval($ids,'41','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'41','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[41][delete]" class="role" <?php if(get_pageval($ids,'41','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'41','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[41][print]" class="role" <?php if(get_pageval($ids,'41','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'41','prints'); ?>">
</td>
</tr>
<tr>
<td>Account
<input type="hidden" maxlength="11" name="data[42][id]" value="42" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[42][sec]" value="bank" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[42][read]" class="role" <?php if(get_pageval($ids,'42','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'42','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[42][write]" class="role" <?php if(get_pageval($ids,'42','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'42','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[42][edit]" class="role" <?php if(get_pageval($ids,'42','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'42','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[42][delete]" class="role" <?php if(get_pageval($ids,'42','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'42','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[42][print]" class="role" <?php if(get_pageval($ids,'42','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'42','prints'); ?>">
</td>
</tr>
<tr>
<td>Transaction
<input type="hidden" maxlength="11" name="data[43][id]" value="43" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[43][sec]" value="bank" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[43][read]" class="role" <?php if(get_pageval($ids,'43','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'43','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[43][write]" class="role" <?php if(get_pageval($ids,'43','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'43','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[43][edit]" class="role" <?php if(get_pageval($ids,'43','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'43','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[43][delete]" class="role" <?php if(get_pageval($ids,'43','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'43','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[43][print]" class="role" <?php if(get_pageval($ids,'43','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'43','prints'); ?>">
</td>
</tr>
</tbody>
</table>        
</div>
</div>    

<div class="row" id="euser">
<div class="col-md-12">
<table class="table">
<thead>
<tr>
<th style="width:285px;">User &amp; Role</th>
<th class="text-center">Read</th>
<th class="text-center">Write</th>
<th class="text-center">Edit</th>
<th class="text-center">Delete</th>
<th class="text-center">Print</th>
</tr>
</thead>
<tbody>
<tr>
<td>User Role
<input type="hidden" maxlength="11" name="data[44][id]" value="44" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[44][sec]" value="user" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[44][read]" class="role" <?php if(get_pageval($ids,'44','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'44','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[44][write]" class="role" <?php if(get_pageval($ids,'44','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'44','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[44][edit]" class="role" <?php if(get_pageval($ids,'44','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'44','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[44][delete]" class="role" <?php if(get_pageval($ids,'44','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'44','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[44][print]" class="role" <?php if(get_pageval($ids,'44','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'44','prints'); ?>">
</td>
</tr>
<tr>
<td>User
<input type="hidden" maxlength="11" name="data[45][id]" value="45" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[45][sec]" value="user" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[45][read]" class="role" <?php if(get_pageval($ids,'45','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'45','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[45][write]" class="role" <?php if(get_pageval($ids,'45','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'45','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[45][edit]" class="role" <?php if(get_pageval($ids,'45','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'45','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[45][delete]" class="role" <?php if(get_pageval($ids,'45','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'45','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[45][print]" class="role" <?php if(get_pageval($ids,'45','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'45','prints'); ?>">
</td>
</tr>
</tbody>
</table>        
</div>
</div>        
    
<div class="row" id="ereport">
<div class="col-md-12">
<table class="table">
<thead>
<tr>
<th style="width:285px;">Report</th>
<th class="text-center">Read</th>
<th class="text-center">Write</th>
<th class="text-center">Edit</th>
<th class="text-center">Delete</th>
<th class="text-center">Print</th>
</tr>
</thead>
<tbody>
<tr>
<td>Report
<input type="hidden" maxlength="11" name="data[46][id]" value="46" class="form-control" autocomplete="off">
<input type="hidden" maxlength="11" name="data[46][sec]" value="report" class="form-control" autocomplete="off">  </td>
<td class="text-center">
<input type="checkbox"  name="data[46][read]" class="role" <?php if(get_pageval($ids,'46','views')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'46','views'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[46][write]" class="role" <?php if(get_pageval($ids,'46','creates')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'46','creates'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[46][edit]" class="role" <?php if(get_pageval($ids,'46','edits')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'46','edits'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[46][delete]" class="role" <?php if(get_pageval($ids,'46','deletes')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'46','deletes'); ?>">
</td>
<td class="text-center">
<input type="checkbox" name="data[46][print]" class="role" <?php if(get_pageval($ids,'46','prints')){echo 'checked=""';}?> value="<?php echo get_pageval($ids,'46','prints'); ?>">
</td>
</tr>
</tbody>
</table>        
</div>
</div>    
    
</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="role_update" id="submit" class="btn btn-flat bg-purple btn-sm " value="Update"/> <a href="rou_rolelist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'ROL','A');}else{echo read_activity($aid,'ROL','U');}?>
</div>
</div>
</div>
</div>
</div>
</div> 

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function () {  
var pname = new LiveValidation('pname');
pname.add(Validate.Presence);
});
    
$(document).on('change', '.role', function () {
if ($(this).is(":checked")){
$(this).val('1');
}else{
$(this).val('0');	
}    
});
    
$(document).on('change', '.access', function() {
ids = $(this).attr('id');    
if (this.checked){
$('#e'+ids).fadeIn('slow');   
}else{
$('#e'+ids).fadeOut('slow');    
}	
});    
</script>    
<!-- /page script -->
</html>    