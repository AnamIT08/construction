<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='pur_pinvlist.php';   
$cuPage='pur_pinvlist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];
$uty=$_SESSION['utype'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='purchase';
$menuh='Purchase';
$phead='pinvlist';
$page='Purchase Invoice';
$print='print';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php

if(isset($_POST['tfdate'])){
$fdate=$_POST['tfdate'];	
}else{
$fdate=date('Y-m-d', strtotime('-15 days', time()));	
}
if(isset($_POST['ttdate'])){
$tdate=$_POST['ttdate'];	
}else{
$tdate=$today;	
}

function check_purinvdel($invno){
$flage=0;
global $con;

$sql="SELECT * FROM tbl_traproduct WHERE invno='$invno'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$unqid=$row['unqid'];
$sql="SELECT * FROM tbl_traproduct WHERE mods IN ('SE','TR','WR') AND unqid='$unqid'";
$que=mysqli_query($con,$sql)or die(mysqli_error($con));    
if($que->num_rows > 0) {
$flage=1;
break;    
}else{
$flage=0;    
}    
}    

if($flage>0){
return $flage;
exit;    
}    
    
$sql="SELECT * FROM tbl_trarecord WHERE invno!='$invno' AND refinv='$invno'";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}

if($flage>0){
return $flage;
exit;    
}
    
$sql="SELECT * FROM tbl_preturn WHERE refinv='$invno'";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}

if($flage>0){
return $flage;
exit;    
}       
}

if(isset($_POST['delpur'])){
$id=$_POST['delpur'];

$sql="SELECT * FROM tbl_purchase WHERE id='$id' LIMIT 1";
$dsales=mysqli_query($con,$sql) or die(mysqli_error($con));    
$dsel=mysqli_fetch_array($dsales);     

$invno=$dsel['invno'];    
    
if(check_purinvdel($invno)){
save_msg('w','Purchase Depend on others data!!!');
echo "<script>window.location='pur_pinvlist.php'</script>";
return;    
}

$sql="SELECT * FROM tbl_serial WHERE purinv='$invno'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
$sql="DELETE FROM tbl_serial WHERE purinv='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));    
}    
    
$sql="DELETE FROM tbl_trarecord WHERE invno='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));

$sql="DELETE FROM tbl_traproduct WHERE invno='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));    

$sql="DELETE FROM tbl_stock WHERE invno='$invno'";    
mysqli_query($con,$sql)or die(mysqli_error($con));
    
$sql="DELETE FROM tbl_purchase WHERE id='$id'";
$fdel=mysqli_query($con,$sql)or die(mysqli_error($con));    
$efid=mysqli_affected_rows($con);
if($efid>0){
$act =remove_junk(escape('Purchase invoice: '.$invno));    
write_activity($aid,'PUR','Purchase has been deleted',$act);        
save_msg('s','Purchase Successfully Deleted!!!');
}else{
save_msg('w','Purchase Fail to Delete!!!');    
}
echo "<script>window.location='pur_pinvlist.php'</script>";    
}
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-9">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Purchase Record';}else{echo 'ক্রয়ের তালিকা';}?></h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px; text-align:center;">SN</th>   
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Date';}else{echo 'তারিখ';}?></th>
<?php if($uty=='1'){ ?>
<th>Branch</th>    
<?php } ?>    
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Supplier';}else{echo 'সরবরাহকারী';}?></th>
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Invoice';}else{echo 'রসিদ';}?></th>
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Total';}else{echo 'মোট';}?></th>    
<!--<th>Paid</th>
<th>Due</th>-->
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Note';}else{echo 'মন্তব্য';}?></th>    
<!--<th>Status</th>-->    
<th style="width:40px; text-align:center;"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Action';}else{echo 'অ্যাকশন';}?></th>    
</tr>
</thead>    
<tbody>
   
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<a href="pur_pinvcteate.php" class="btn btn-flat bg-purple"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Create Purchase';}else{echo 'ক্রয় করুন';}?></a>
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'PUR','A');}else{echo read_activity($aid,'PUR','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->
<?php include('../layout/print.php'); ?>
<?php include('../layout/details.php'); ?>    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
var dataTable=$('#datarec').DataTable({
"processing": true,
"serverSide":true,
"stateSave": true,    
"aoColumns": [
    { "sWidth": "40px", "sClass": "text-center" },
    <?php if($uty=='1'){ ?>
    null,
    <?php } ?>
    null,
    null,
    null,
    null,
    null,
    { "sWidth": "120px", "sClass": "text-center" }
],    
"ajax":{
url:"pur_listdata.php",
type:"post"
}
}); 
});
    
function take_action(id) {
document.getElementById(id).submit(); 
}
    
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});
}

$(document).on('click','.details-invoice',function(e) {
id_arr = $(this).attr('id');
id = id_arr.split("_");

$.ajax({
url: 'pur_viewlist.php',
method: "POST",
data:{ 
invid: id[1],supid: id[2]
},
success: function(data){
$('#listitem').html(data);
pagelist();    
}
});    
    
$.ajax({
url: 'pur_viewinv.php',
method: "POST",
data:{ 
print: id[1]
},
success: function(data){
$('#invhold').html(data);
sethead();    
}
});
    
$('.right-side').toggle('slide', { direction: 'right' }, 300);    

e.preventDefault();
});

$(document).on('click','.detailsrec',function(e) {    
id_arr = $(this).attr('id');
id = id_arr.split("_");
if(id[1]==0)return;

$.ajax({
url: 'axe_details.php',
method: "POST",
data:{ 
cusdet: 1,cusid: id[1],type:id[0]
},
success: function(data){
$('#profile').html(data);    
}
});    
    
$.ajax({
url: 'axe_details.php',
method: "POST",
data:{ 
tradet: 1,cusid: id[1],type:id[0]
},
success: function(data){
$('#details').html(data);   
}
});    
  
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);       
e.preventDefault();    
});    
    
$(document).on('click', '#closedet', function() {
$('#profile').html('');
$('#details').html('');
if($('.right-side-details').is(':visible')) {
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);
}    
});    
    
$(document).on('click', '#closepop', function() {
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }   
});    

$('#listitem').on('click','li', function(){
   $(this).addClass('active').siblings().removeClass('active');
});
    
$(document).on('click', '.invpiv', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
$.ajax({
url: 'pur_viewinv.php',
method: "POST",
data:{ 
print: ids
},
beforeSend: function() {
//$("#invhold").fadeOut('slow');
},    
success: function(data){    
$('#invhold').html(data);
$("#invhold").fadeIn('slow');    
sethead();    
}
});     
});    
</script>    
<!-- /page script -->
</html>    