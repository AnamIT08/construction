<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('5','prints','R');     
$_SESSION['cuPages']='opr_pilist.php';   
$cuPage='opr_pilist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
?>
<?php 
if(isset($_POST['invid'])){
$piid=$_POST['invid'];
$sql="SELECT * FROM tbl_proinv ORDER BY date,id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
?>
<li <?php if($row['id']==$piid){echo 'class="invpiv active"';}else{echo 'class="invpiv"';}?> id="pi_<?php echo $row['id'];?>"><p><strong class="pino"><?php echo $row['pino'];?></strong><br><strong class="name"><?php echo $row['cusname'];?></strong></p>
    <div class="sname" style="margin-top: -52px;float: right; position: relative;top: 6px;"><strong><?php echo 'T: '.numtolocal($row['total'],get_fild_data('tbl_currency',$row['curid'],'symbol')); ?></strong><br><strong><?php echo 'C: '.numtolocal($row['totcom'],get_fild_data('tbl_currency',$row['curid'],'symbol')); ?></strong></div>
</li>
<?php }} ?>