<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
include ('../inc/repfunctions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
$today = strftime("%Y-%m-%d", time());    
$dtnow = date("Y-m-d h:i:s", time());    
}else{
header('Location:../index.php');
exit;    
}

if(isset($_POST['additem'])){
$unqid=$_POST['additem'];   
addtouse($brid,$unqid,1);    
}

if(isset($_POST['itmsear'])){
$search = $_POST['search'];
$sql = "SELECT tbl_brstock.unqid,tbl_brstock.code,tbl_brstock.name,tbl_stock.cost,tbl_stock.price,tbl_brstock.avqty FROM tbl_brstock LEFT JOIN tbl_stock ON tbl_stock.unqid=tbl_brstock.unqid WHERE tbl_brstock.brid='$brid' AND tbl_brstock.status='1' AND (tbl_brstock.name LIKE '%$search%' OR tbl_brstock.code LIKE '%$search%') AND tbl_brstock.avqty>0 LIMIT 20";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
while($row = mysqli_fetch_array($result) ){
$response[] = array("value"=>$row['unqid'],"label"=>$row['code'].' | '.$row['name'].' | Qty:'.$row['avqty'].' | '.$row['cost']);
}

echo json_encode($response);
exit;    
}

if(isset($_POST['itmsear'])){
$search = $_POST['search'];
$sql = "SELECT tbl_brstock.unqid,tbl_brstock.code,tbl_brstock.name,tbl_stock.cost,tbl_stock.price FROM tbl_brstock LEFT JOIN tbl_stock ON tbl_stock.unqid=tbl_brstock.unqid WHERE tbl_brstock.brid='$brid' AND tbl_brstock.status='1' AND (tbl_brstock.name LIKE '%$search%' OR tbl_brstock.code LIKE '%$search%') LIMIT 20";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
while($row = mysqli_fetch_array($result) ){
$response[] = array("value"=>$row['unqid'],"label"=>$row['code'].' | '.$row['name'].' | '.$row['cost']);
}

echo json_encode($response);
exit;    
}

if(isset($_POST['remove'])){
$ids = floatval($_POST['remove']);
$unqid=$_SESSION['axes_rawmat'][$ids]['unqid'];    
remove_rawmat($ids);
$max=count($_SESSION['axes_rawmat']);
if($max <= 0){
unset($_SESSION['axes_rawmat']);
unset($_SESSION['axes_usede']);	
}    
}

if(isset($_POST['upqty'])){
$ids=intval($_POST['upqty']);
$qty=floatval($_POST['qty']);
if($qty<0 || $qty==''){
$redata=array($_SESSION['axes_rawmat'][$ids]['qty'],$_SESSION['axes_rawmat'][$ids]['price'],$_SESSION['axes_rawmat'][$ids]['subtot'],$_SESSION['axes_rawmat'][$ids]['pnote']);
echo json_encode($redata);    
exit;
}
$unqid = $_SESSION['axes_rawmat'][$ids]['unqid'];
$eqty=(get_selestockinfo($brid,$unqid,'avqty')-get_selestockinfo($brid,$unqid,'sloc'));    
if($qty<=$eqty){
$_SESSION['axes_rawmat'][$ids]['qty']=$qty;    
}elseif($qty>$eqty){
$_SESSION['axes_rawmat'][$ids]['qty']=$eqty;    
}    
$price = $_SESSION['axes_rawmat'][$ids]['price'];    
$sqty = $_SESSION['axes_rawmat'][$ids]['qty'];
$stot = ($price*$sqty);   
$_SESSION['axes_rawmat'][$ids]['subtot'] = getfloatval($stot);
$redata=array($_SESSION['axes_rawmat'][$ids]['qty'],$_SESSION['axes_rawmat'][$ids]['price'],$_SESSION['axes_rawmat'][$ids]['subtot'],$_SESSION['axes_rawmat'][$ids]['pnote']);
echo json_encode($redata);
}

if(isset($_POST['upnote'])){
$ids=intval($_POST['upnote']);
$note=ucwords(remove_junk(escape($_POST['note'])));
$_SESSION['axes_sales'][$ids]['pnote']=$note;    
$redata=array($_SESSION['axes_rawmat'][$ids]['qty'],$_SESSION['axes_rawmat'][$ids]['price'],$_SESSION['axes_rawmat'][$ids]['subtot'],$_SESSION['axes_rawmat'][$ids]['pnote']);
echo json_encode($redata);    
}


if(isset($_POST['foot'])){
$redata=array($_SESSION['axes_usede'][0]['freight'],$_SESSION['axes_usede'][0]['gtotal']);
echo json_encode($redata);	
exit;
}

if(isset($_POST['freight'])){
$fre=floatval($_POST['freight']);
if(isset($_SESSION['axes_usede'])){
$_SESSION['axes_usede'][0]['freight']=getfloatval($fre);	
}
}

if(isset($_SESSION['axes_usede'])){
if(is_array($_SESSION['axes_usede'])){    

$freight=$_SESSION['axes_usede'][0]['freight'];   
}else{
$freight=0;    
}
$_SESSION['axes_usede'][0]['gtotal']=(get_rawmat_total()+$freight);
}

if(isset($_POST['clear'])){
if(isset($_SESSION['axes_rawmat'])){
unset($_SESSION['axes_rawmat']);
unset($_SESSION['axes_usede']);    
}
}

if(isset($_POST['getcus'])){
$search = $_POST['search'];
$sql="SELECT * FROM tbl_project WHERE prjid LIKE '%$search%' OR name LIKE '%$search%' ORDER BY prjid ASC,name ASC LIMIT 30";		
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
while($row = mysqli_fetch_array($result) ){
$response[] = array("value"=>'PJ_'.$row['id'],"label"=>$row['prjid'].' | '.$row['name']);
}

// encoding array to json format
echo json_encode($response);
exit;
}

if(isset($_POST['checkbal'])){
if(strlen($_POST['checkbal'])>0){    
$id=str_replace('_','',$_POST['checkbal']);
$ldebit=get_ledgerval($id,'D','N');
$lcredit=get_ledgerval($id,'C','N');
$lnet=($ldebit-$lcredit);
echo number_format($lnet,2);
}else{
echo '0.00';    
}    
}

if(isset($_POST['expcsv'])){
$fdate=$_POST['fdate'];
$tdate=$_POST['tdate'];
$output='';
$sql="SELECT Package_Description,Receiver_Name,IF(endata.type='CU' AND endata.cusid=0,(SELECT waddress FROM tbl_sales WHERE invno=endata.invno),(SELECT address FROM tbl_customer WHERE id=endata.cusid)) AS Receiver_Address,(SELECT mobile FROM tbl_sales WHERE invno=endata.invno) AS Receiver_Number,IF(endata.city!='',(SELECT name FROM tbl_district WHERE id=endata.city),'') AS Receiver_City,IF(endata.zone!='',(SELECT name FROM tbl_zone WHERE id=endata.zone),'') AS Receiver_Zone,IF(endata.type='CU' AND endata.cusid=0,(SELECT wemail FROM tbl_sales WHERE invno=endata.invno),(SELECT cemail FROM tbl_customer WHERE id=endata.cusid)) AS Recipient_Email,Price,'' AS Instructions,qty,date FROM (SELECT GROUP_CONCAT(tbl_item.name) AS Package_Description,SUM(tbl_traproduct.s_qty) AS qty,type,tid AS cusid,(SELECT did FROM tbl_sales WHERE invno=tbl_traproduct.invno) AS city,(SELECT zid FROM tbl_sales WHERE invno=tbl_traproduct.invno) AS zone,(SELECT name FROM tbl_sales WHERE invno=tbl_traproduct.invno) AS Receiver_Name,(SELECT total FROM tbl_sales WHERE invno=tbl_traproduct.invno) AS Price,(SELECT apdate FROM tbl_sales WHERE invno=tbl_traproduct.invno) AS date,invno
FROM tbl_traproduct LEFT JOIN tbl_item ON tbl_item.id=tbl_traproduct.pid WHERE mods='SE' GROUP BY invno) AS endata WHERE date BETWEEN '$fdate' AND '$tdate'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$output.='<tr><th>Package_Description</th><th>Receiver_Name</th><th>Receiver_Address</th><th>Receiver_Number</th><th>Receiver_City</th><th>Receiver_Zone</th><th>Recipient_Email</th><th>Price</th><th>Instructions</th><th>Qty</th><th>Date</th></tr>';
while($row = mysqli_fetch_array($result) ){
$output.='<tr><td>'.$row['Package_Description'].'</td><td>'.$row['Receiver_Name'].'</td><td>'.$row['Receiver_Address'].'</td><td>'.$row['Receiver_Number'].'</td><td>'.$row['Receiver_City'].'</td><td>'.$row['Receiver_Zone'].'</td><td>'.$row['Recipient_Email'].'</td><td>'.$row['Price'].'</td><td>'.$row['Instructions'].'</td><td>'.$row['qty'].'</td><td>'.$row['date'].'</td></tr>';	
}
// encoding array to json format
echo $output;
}

if(isset($_POST['addchalan'])){
$invno = gen_newinvno('tbl_procha','CHA');
$apdate = remove_junk(escape($_POST['seldt']));

    
$cdata=explode('_',remove_junk(escape($_POST['customer'])));
$cty=$cdata['0'];    
$cid = $cdata['1'];    

$prjid=get_fild_data('tbl_project',$cid,'prjid');
if(strlen($prjid)>0){$prjid="'".$prjid."'";}else{$prjid='NULL';}    
$prjname=get_fild_data('tbl_project',$cid,'name');    
if(strlen($prjname)>0){$prjname="'".$prjname."'";}else{$prjname='NULL';}
    
$ref = remove_junk(escape($_POST['ref']));
if(strlen($ref)>0){$ref="'".$ref."'";}else{$ref='NULL';}    
$note = remove_junk(escape($_POST['note']));
if(strlen($note)>0){$note="'".$note."'";}else{$note='NULL';}    
$selp = remove_junk(escape($_POST['selp']));
if($selp=='' || $selp=='-Select-'){$selp='NULL';}else{$selp="'".$selp."'";} 

$freight=remove_junk(escape($_SESSION['axes_usede'][0]['freight']));
$subtot=get_rawmat_total();    
$gtotal=remove_junk(escape($_SESSION['axes_usede'][0]['gtotal']));
        
if(!isset($_SESSION['axes_rawmat'])){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! No item found!!'
));
return;
exit;  
}   

if(check_rawvalidqty($brid)){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Quantity not available!!'
));
return;
exit;     
}    
    
$sql="INSERT INTO tbl_procha (invno,pjid,prjid,name,amount,total,senderid,note,ref,apdate,brid,uid,date) VALUES ('$invno','$cid',$prjid,$prjname,'$subtot','$gtotal',$selp,$note,$ref,'$apdate','$brid','$aid','$dtnow')";
   
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sid=$con->insert_id;    
$efid=mysqli_affected_rows($con);     

if($efid>0){
$max=count($_SESSION['axes_rawmat']);
for($i=0;$i<$max;$i++){
$pid = $_SESSION['axes_rawmat'][$i]['pid'];
$unqid= $_SESSION['axes_rawmat'][$i]['unqid'];   
$col=0;
$siz=0;
$icdis=0;
$icinvdis=0;    
$cost=$_SESSION['axes_rawmat'][$i]['cost'];
$puqty=0;    
$qtyin=0;   
$soqty=$_SESSION['axes_rawmat'][$i]['qty'];
    
if(get_fild_data('tbl_setting','3','sval')==0){    
$qtyout=$_SESSION['axes_rawmat'][$i]['qty'];
$ploc=0;     
}else{
if(isset($_POST['sercv']) && $_POST['sercv']==0){
$qtyout=$_SESSION['axes_rawmat'][$i]['qty'];
$ploc=0;     
//}elseif(isset($_POST['sercv']) && $_POST['sercv']==1){
//$qtyout=0;
//$ploc=0;    
}else{
$qtyout=0;
$ploc=$_SESSION['axes_rawmat'][$i]['qty'];    
}       
}
    
$taxp=0;
$taxamo=0;
$idisp=0;
$idisf=0;
$disamo=0;
$sdisp=0;
$sdisf=0;    
$rbp=0;
$rbf=0;    
$cbamo=0;    
$price=$_SESSION['axes_rawmat'][$i]['price'];
$isubtot=$_SESSION['axes_rawmat'][$i]['subtot'];
$wday=0;
$pnote=$_SESSION['axes_rawmat'][$i]['pnote'];    

if($rbp>0 || $rbf>0){
$qty=$_SESSION['axes_rawmat'][$i]['qty'];    
$rebamo=getfloatval($rbf*$qty);    
}else{
$rebamo=0;    
}    
    
if($cbamo>0){
$cbamo=getfloatval($cbamo);    
$ofid = get_offerinfo($unqid,'ID');
$oft = get_offerinfo('','AF',$ofid);    
if($oft==0){
$afid = get_offerinfo($unqid,'SU');   
}else{
$afid = '52';   
}         
}else{
$cbamo=0;    
$ofid = 'NULL';
$oft = 'NULL';    
$afid = 'NULL';    
}    
    
$sql="INSERT INTO tbl_traproduct (type,tid,invno,refinv,pid,unqid,colid,sizid,icdis,icinvdis,cost,price,p_qty,p_in,s_qty,p_out,p_loc,taxp,taxamo,disp,disf,disamo,subtot,wday,mods,brid,waid,tramod,isinv,pnote,rbp,rbf,rbamo,ofid,ofamo,oft,aft,uid,apdate,date) VALUES ('$cty','$cid','$invno',NULL,'$pid','$unqid','$col','$siz','$icdis','$icinvdis','$cost','$price','$puqty','$qtyin','$soqty','$qtyout','$ploc','$taxp','$taxamo','$idisp','$idisf','$disamo','$isubtot','$wday','SE','$brid',NULL,NULL,'Y','$pnote','$rbp','$rbf','$rebamo',$ofid,'$cbamo',$oft,$afid,'$aid','$apdate','$dtnow')";    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));    
}

//sales_update($sid,'tbl_sales',$dtnow);   
unset($_SESSION['axes_rawmat']);
unset($_SESSION['axes_usede']);
    
$act =remove_junk(escape('Challan No: '.$invno));    
write_activity($aid,'CHA','New Challan has been Created',$act);
echo json_encode(array(
'status' => 'success',
'message'=> 'Challan Save Successfully!!',
'invid'=> $sid    
));
exit;    
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));    
}    
    
}


if(isset($_POST['savecus'])){
$name = ucwords(remove_junk(escape($_POST['name'])));
$code = get_genid('CU');
$cperson = remove_junk(escape($_POST['cperson']));
$cnumber = remove_junk(escape($_POST['cnumber']));
$cemail = remove_junk(escape($_POST['cemail']));    
$address = remove_junk(escape($_POST['address']));
$did = remove_junk(escape($_POST['did']));
if($did!=''){$did="'".$did."'";}else{$did='NULL';}
$zid = remove_junk(escape($_POST['zid']));
if($zid!=''){$zid="'".$zid."'";}else{$zid='NULL';}    
if(isset($_POST['cnumber'])){
$ducode = mysqli_query($con,"SELECT * FROM tbl_customer WHERE cnumber = '$cnumber'");
}
	
if($ducode->num_rows > 0) {
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! This contact number already exists!!'
));
return;
exit;
}else{
$sql="INSERT INTO tbl_customer(code,name,cperson,cnumber,cemail,address,did,zid,uid,date) VALUES ('$code','$name','$cperson','$cnumber','$cemail','$address',$did,$zid,'$aid','$dtnow')";    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sid=$con->insert_id;    
$efid=mysqli_affected_rows($con);    
if($efid>0){
$act =remove_junk(escape('Customer name: '.$name));    
write_activity($aid,'CUS','New customer has been Added',$act);
echo json_encode(array(
'status' => 'success',
'cbal'=> '0.00',
'cudata'=> $code.'|'.$name.'|'.$cnumber,
'cuid'=> 'CU_'.$sid    
));
exit;   
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Customer Fail to Saved!!'
));    
} 
}    
}
?>

<?php if(isset($_POST['addcus'])){ ?>
<div class="col-md-12 popup_details_div addcustomer">
<div class="row">
<div id="server-results"><!-- For server results --></div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<div class="form-group">
<label>Name</label>
<input type="text" name="name" maxlength="45" value="" id="name" class="form-control" placeholder="e.g. Md.Sumon Rahman"/>
<input type="hidden" name="savecus" readonly />    
</div>    
<div class="form-group">
<label>Contact Name</label>    
<input type="text" name="cperson" maxlength="45" value="" id="cperson" class="form-control" placeholder="e.g. Md.Rahman Sumon(CEO)"/>
</div>
<div class="form-group">
<label>Contact Number</label>    
<input type="text" name="cnumber" maxlength="18" value="" id="cnumber" class="form-control" placeholder="e.g. +88016161xxxxx70"/>
</div>
<div class="form-group">
<label>Contact Email</label>    
<input type="text" name="cemail" maxlength="45" value="" id="cemail" class="form-control" placeholder="e.g. info@axesgl.com"/>
</div>
<div class="form-group">    
<label>Address</label>
<textarea class="form-control" name="address" id="address" maxlength="250" rows="5" placeholder="Address"></textarea>    
</div>
<div class="row">
<div class="col-md-6">    
<div class="form-group">
<label>Select District</label>
<select class="form-control select2" name="did" id="did" onchange="getAllSubgroup(this.value)">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_district ORDER BY name ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>    
</div>
</div>
<div class="col-md-6">    
<div class="form-group">
<label>Select Zone</label>
<select class="form-control select2" name="zid" id="zid">
<option value="">-Select-</option>    
</select>     
</div>
</div>    
</div>    
</div>
<div class="col-md-1"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-2 text-right" >
<input type="button" id="adcus" class="btn btn-flat bg-purple btn-sm " value="Save"/>
</div>
<div class="col-md-2"></div>    
</div>

<script type="text/javascript">
function chek_error(){
var name = $('#name').val();
var cnumber = $('#cnumber').val();
var address = $('#address').val();    
var cemail = $('#cemail').val();    
var result = true;
    
var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,8}|[0-9]{1,3})(\]?)$/;
    
$('.LV_validation_message').remove();
    
if(name.length<=0){
$('#name').addClass('LV_invalid_field');   
$('#name').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); } else {
$('#name').removeClass('LV_invalid_field'); 
}    
    
if(cnumber.length<=0){
$('#cnumber').addClass('LV_invalid_field');   
$('#cnumber').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); } else {
$('#cnumber').removeClass('LV_invalid_field'); 
}    

if(address.length<=0){
$('#address').addClass('LV_invalid_field');   
$('#address').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); } else {
$('#address').removeClass('LV_invalid_field'); 
}    
    
if(cemail.length >0){
result = expr.test(cemail);
if(result){
$('#cemail').removeClass('LV_invalid_field');        
}else{
$('#cemail').addClass('LV_invalid_field');
$('#cemail').after("<span class='LV_validation_message LV_invalid'>Not a valid email address!</span>").addClass('has-error');    
}    
}    
    
if(name.length<=0 || address.length<=0 || cnumber.length<=0 || !result){
return false;    
}else{
return true;     
}    
}

function getAllSubgroup(id){
$.ajax({
url: 'axe_getsub.php',
type: 'post',
data: {zone : id},
success:function(data) {
$('#zid').html(data);
}
});
};     
    
$(document).on('blur', '#name, #cnumber, #cemail', function() {
chek_error();    
});        
</script>    
<?php } ?>

<?php 
if(isset($_POST['checkview'])){
$cusd=explode('_',$_POST['cusid']);
$typ=$cusd[0];    
$cusid=$cusd[1];    
if(isset($_SESSION['axes_usede'])){    
$gtotal=$_SESSION['axes_usede'][0]['gtotal'];
}else{
$gtotal=0;    
}
$id=str_replace('_','',$_POST['cusid']);
$ldebit=get_ledgerval($id,'D','N');
$lcredit=get_ledgerval($id,'C','N');
if($cusid!=0){
$lnet=($ldebit-$lcredit);     
}else{
$lnet=0;    
}        
?>
<div class="addsersales">
<div class="row">
<div class="col-md-3 col-xs-6">
<div class="small-box">
<div class="inner">
<h3 id="pabamo"><?php echo $gtotal;?></h3>
<p>Total Send</p>
</div>

</div>
<input type="hidden" value="<?php echo $_POST['cusid']; ?>" id="customer" name="customer" readonly />
<input type="hidden" value="<?php if($lnet<0){echo ABS($lnet);}else{echo 0;} ?>" id="balance" name="balance" readonly />     
<input type="hidden" name="addchalan" readonly />
<input type="hidden" name="scusid" id="scusid" value="<?php echo $cusid; ?>" readonly />    
</div>
<div class="col-md-3 col-xs-6">

</div>
<div class="col-md-3 col-xs-6">

</div>
<div class="col-md-3 col-xs-6">

</div>    
</div>
<div class="row">
<br>   
<div class="col-md-4">
<div class="form-group" >
<label>Challan Date</label>
<input type="text" class="form-control datetimepicker" name="seldt" id="seldt" value="<?php echo $today;?>" placeholder="Sales Date" autocomplete="off" readonly>
</div>   
<div class="form-group">
<label>Ref</label>
<input type="text" maxlength="25" class="form-control" name="ref" id="ref" placeholder="e.g. #ORD8976453" autocomplete="off">    
</div>
<div class="form-group">
<label>Send Person</label>    
<select class="form-control select2" name="selp" id="selp">
<option value="">-Select-</option>    
<?php
$sql="SELECT id,name FROM tbl_employe ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>    
</div>    
</div>
<div class="col-md-8">    
<div class="form-group">    
<label>Note</label>
<textarea class="form-control" name="note" id="note" maxlength="150" rows="9" placeholder="Challan Note"></textarea>    
</div>    
</div>    
</div>
<div class="row">
<?php if(get_fild_data('tbl_setting','3','sval')==1){ ?>   
<div class="col-md-12">
<div class="col-md-4">
<div class="form-group">
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Send Now';}else{echo 'বিক্রয় কৃত পণ্য বিতরণ এখনি';}?></label>    
<select class="form-control select2" name="sercv" id="sercv">    
<option <?php if(get_fild_data('tbl_setting','3','sval')==0){echo 'selected';} ?> value="0"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Yes';}else{echo 'হ্যাঁ';}?></option>
<option <?php if(get_fild_data('tbl_setting','3','sval')==1){echo 'selected';} ?> value="1"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'No';}else{echo 'না';}?></option>
<!--<option value="2"><?php //if(get_fild_data('tbl_setting','1','sval')==0){echo 'Lock';}else{echo 'লক';}?></option>-->    
</select>    
</div>
</div>    
<div class="col-md-8">    
<div class="secdiv" style="margin-bottom: 10px;"><span>Other Billing Name (Optional)</span></div>    
<div class="col-md-6">
<div class="form-group">
<label>Name</label>
<input type="text" name="otclient" maxlength="35" class="form-control" placeholder="e.g Sumon">
</div>    
</div>
<div class="col-md-6">    
<div class="form-group">
<label>Mobile</label>
<input type="text" name="otmobile" maxlength="18" class="form-control" placeholder="e.g 016161700">
</div>
</div>
</div>   
</div>
<?php }else{ ?>
<?php } ?>    
</div>    
</div>    
<div class="row">
<div class="col-md-12 text-center side-checkhead">
<button class="btn btn-flat bg-blue saveseinv" id="saveinv"><i class="fa fa-floppy-o"></i>&nbsp;&nbsp;Save</button>    
<button class="btn btn-flat bg-gray saveseinv" id="sinvprint"><i class="fa fa-floppy-o"></i>&nbsp;&nbsp; Challan &nbsp;&nbsp;<i class="fa fa-print"></i></button>   
</div>    
</div>
<script type="text/javascript">    
$(".select2").select2();    
$('.datetimepicker').datepicker({format: "yyyy-mm-dd", autoclose: true, clearBtn: true, orientation: 'auto bottom'});    
</script>    
<?php } ?>

<?php 
if(isset($_POST['checkout'])){
$cusd=explode('_',$_POST['cusid']);
$typ=$cusd[0];    
$cusid=$cusd[1];    
?>
<div class="col-md-12 cart-border-left text-center">
<div class="horizontal-scroll">
<h5 class="text-center" style="font-size: 20px;">Challan Details</h5> 
<div>
<div class="text-center header-line-height">
<small class="text-center" style="font-size: 15px;"><?php echo get_cominfo('1','name');?></small>
<br> <small class="text-center"><?php echo date("d M Y", strtotime($today));?></small>
<br> <small class="text-center" style="font-size: 12px;"><strong>Challan</strong></small>
<!--<br> <small class="text-left">Sold By: John Doe</small>--> 
<br> <small><span>Send To: <?php echo get_fild_data('tbl_project',$cusid,'prjid').' - '.get_fild_data('tbl_project',$cusid,'name');?></span></small> 
<small class="text-left invoice-show" style="display: none;">Invoice ID:</small>
</div> 
<div class="invoice-table">
<table class="table product-card-font" style="font-weight: 500;">
<thead class="border-top-0">    
<tr>
<th class="cart-summary-table text-left">Items</th> 
<th class="cart-summary-table text-left">Qty</th> 
<th class="cart-summary-table text-right">Price</th>
<th class="cart-summary-table text-right">Total</th>
</tr>   
</thead> 
<tbody>
<?php 
$s=0;    
if(isset($_SESSION['axes_rawmat'])){
$max=count($_SESSION['axes_rawmat']);
for($i=($max-1);$i>=0;$i=$i-1){
$name=$_SESSION['axes_rawmat'][$i]['name'];   
$qty=$_SESSION['axes_rawmat'][$i]['qty'];
$price=$_SESSION['axes_rawmat'][$i]['price'];   
$subtot=$_SESSION['axes_rawmat'][$i]['subtot'];
$pnote=$_SESSION['axes_rawmat'][$i]['pnote'];     
$s+=1;    
?>    
<tr>
<td class="cart-summary-table text-left"><?php echo $name;?><br></td>
<td class="cart-summary-table"><?php echo $qty;?></td> 
<td class="text-right cart-summary-table"><?php echo numtolocal($price,''); ?></td>  
<td class="text-right cart-summary-table"><?php echo numtolocal($subtot,''); ?></td>
<?php }} ?>     
</tbody> 
<tfoot>
<?php 
$freight=$_SESSION['axes_usede'][0]['freight'];
$gtotal=$_SESSION['axes_usede'][0]['gtotal'];    
?>    
<tr>
<td class="cart-summary-table font-weight-bold text-left">Sub Total</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table"><?php echo numtolocal(get_rawmat_total(),'Tk');?></td>
</tr>
<?php if($freight>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">Freight</td>  
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($freight,'Tk');?></td>
</tr>    
<?php } ?>      
<tr>
<td class="cart-summary-table font-weight-bold text-left">Total</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($gtotal,'Tk');?></td>
</tr> 
</tfoot>
</table>
</div>
</div>
</div>
</div>   
<?php } ?>
