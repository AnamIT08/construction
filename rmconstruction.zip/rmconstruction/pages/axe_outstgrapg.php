<?php
echo '{"ticketing_baggage":{"total_sales":1504900,"total_receipt":2980,"outstanding":1501920},"visa_visa_message":{"total_sales":220110,"total_receipt":6260,"outstanding":213850},"hotel":{"total_sales":0,"total_receipt":0,"outstanding":0},"ins_otheres":{"total_sales":270,"total_receipt":0,"outstanding":270},"interval":"11-01-2020 to 11-02-2020"}';
?>