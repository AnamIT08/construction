<?php 
echo '<div class="col-md-12 nopadding chat_header">
    <div class="col-md-2 col-xs-2 text-center nopadding" style="padding:3px"><img src="https://rishona.xobills.ae/image?source=assets/images/members/profile_photo.jpg&width=30" width="30" class="img-circle" /></div><div class="col-md-8 col-xs-8 nopadding" style="padding:3px"><span class="member_name"></span><span class="online_status">Last seen: 11 Feb 2020 10:46 pm</span></div><div class="col-md-2 col-xs-2  text-center nopadding" style="padding:3px"><div class="dropdown">
    <a style="font-size: 20px;color: #fff;" data-toggle="dropdown" ><i class="fa fa-cog" aria-hidden="true"></i></a>
    <ul class="dropdown-menu dropdown-menu-right chat_window_drop_down">
      
      <li><a onclick="clear_chat_history()">Clear All</a></li>
      <li><a  onclick="clear_chat_window()" >Close</a></li>
    </ul>
  </div></div> <input type="hidden" id="chat_header_type" name="chat_header_type" value=""/><input type="hidden" id="chat_header_id" name="chat_header_id" value=""/>    <div class="clearfix"></div>
</div>
<div class="direct-chat-messages">
    <p class="text-center" data-msgid="0"> Start Conversation</p></div >';
?>    