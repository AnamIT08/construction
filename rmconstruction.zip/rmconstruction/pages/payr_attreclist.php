<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='payr_attreclist.php';   
$cuPage='payr_attreclist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];
$uty=$_SESSION['utype'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='payroll';
$menuh='Payroll';
$phead='attlist';
$page='Attendance Record';
$today = strftime("%Y-%m-%d", time());
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 

function payslip_no($year,$month,$empid){
$empcode = str_pad($empid, 5, '0', STR_PAD_LEFT);
$yearcode = substr($year,2,2);
$moncode = str_pad($month, 2, '0', STR_PAD_LEFT);
$code = 'EMP'.$moncode.$yearcode.$empcode;
return $code;
}

function payslip_del($invno){
global $con;
$flag = 0;
$sql="DELETE FROM tbl_trarecord WHERE invno='$invno'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);    
if($efid>0){
$flag = 1;	
}else{
$flag = 0;	
}
return $flag;	
}

if(isset($_POST['save_attnl'])){
 $year = remove_junk(escape($_POST['year']));
 $month = remove_junk(escape($_POST['month']));
    
if(isset($_POST['data']) && !empty($_POST['data'])){
$deitems=$_POST['data'];
foreach($deitems as $item){
$empid = remove_junk(escape($item['empid']));
$joindate = remove_junk(escape($item['joindate']));
$gsalary = remove_junk(escape($item['salary'])); 
$absent = remove_junk(escape($item['absent']));
$late = remove_junk(escape($item['late']));
$leave = remove_junk(escape($item['leave']));
$pday = remove_junk(escape($item['pday']));
$pamo = remove_junk(escape($item['pamo']));
$invno = payslip_no($year,$month,$empid);
if($month == (int)date("m",strtotime($joindate)) && $year == (int)date("Y",strtotime($joindate))){
$jamo = round(($gsalary/30)*((date("d",strtotime($joindate)))-1));
}else{
$jamo = 0;   
}
    
$home = round(($gsalary/100)*28.57);
$medic = 250;
$trans = 200;
$food = 650;
$basic = ($gsalary-($medic+$trans+$food+$home));
         
if ($absent > 0){
$absamo = round(($basic/30)*$absent);
}else{
$absamo = 0;  
}
         
if ($late > 0){
list($whole, $decimal) = sscanf($late/3, '%d.%d'); 
$letamo = round(($basic/30)*$whole);
}else{
$letamo = 0;  
}
         
if ($leave > 0){
$levamo = round(($basic/30)*$leave);
}else{
$levamo = 0;  
}
         
if ($pday > 0){
$pdayamo = round(($basic/30)*$pday);
}else{
$pdayamo = 0;  
}
         
$netpay = (($gsalary-($absamo+$letamo+$pdayamo+$jamo+$pamo))+$levamo);
    
$ducode = mysqli_query($con,"SELECT * FROM tbl_salarysheet WHERE empid = '$empid' AND month = '$month' AND year='$year'");
	
	
if($ducode->num_rows > 0) {
$sql="UPDATE tbl_salarysheet SET absent='$absent',late='$late',leaves='$leave',pday='$pday',pamo='$pamo',absamo='$absamo',lateamo='$letamo',levamo='$levamo',pdayamo='$pdayamo',jdamo='$jamo',tsalary='$netpay' WHERE empid = '$empid' AND month = '$month' AND year='$year'";	
mysqli_query($con,$sql) or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);    
}else{
$sql="INSERT INTO tbl_salarysheet(empid,absent,late,leaves,pday,pamo,basic,homeamo,medical,food,comuni,absamo,lateamo,levamo,pdayamo,jdamo,bonus,tsalary,month,year,pstatus,payslip,apdate,brid,uid,date) 
VALUES ('$empid','$absent','$late','$leave','$pday','$pamo','$basic','$home','$medic','$food','$trans','$absamo','$letamo','$levamo','$pdayamo','$jamo','0','$netpay','$month','$year','0','$invno','$today','$brid','$aid','$dtnow')";    
mysqli_query($con,$sql) or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);    
}
}
}
if($efid>0){
$act= getMonthName($month).', '.$year;   
write_activity($aid,'SAL','Generate salary sheet for the month of ',$act);    
save_msg('s','Data Successfully Saved!');
}else{
save_msg('w','Data Fail to Saved!');   
}    
echo "<script>window.location='payr_attreclist.php'</script>";    
}    

?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-9">    
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Attendance &amp; Leave Entry</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="payr_attreclist.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">    
<div class="row">
<input type="hidden" id="syear" name="year" value="" readonly> 
<input type="hidden" id="smonth" name="month" value="" readonly>     
<div class="table-responsive">
<table class="table table-bordered table-striped">
<thead>
<tr>
<th width="3%">#</th>
<th width="23%">Name</th>
<th width="16%">Designation</th>
<th width="13%">G.Salary</th>
<th width="9%">Absent</th>
<th width="9%">Late</th>
<th width="9%">Leave</th>
<th width="9%">P.Day</th>
<th width="9%">P.Amo</th>
</tr>
</thead>
<tbody id="dataemploye">
		
</tbody>    
</table>    
</div>    
</div>
</div>
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="save_attnl" id="submit" class="btn btn-flat bg-purple btn-sm " value="Save"/> <input type="button" id="sreset" class="btn btn-flat bg-red btn-sm " value="Reset"/>
</div> 
</div>     
</form>    
</div>
</div>    
</div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">Salary Month</h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<div class="col-md-12 popup_details_div">
<div class="col-md-1"></div>
<div class="col-md-10">    

<div class="row">
<div class="col-md-6">
<label>Year</label>
<select class="form-control" id="year" name="year">
<?php 
for ($x = (date('Y')-4); $x <= (date('Y')+5); $x++) {
if ($x==date('Y')){
echo "<option selected value='$x'>$x</option>"; 
}else{
echo "<option value='$x'>$x</option>";
}    
}
?>
</select>
</div>
<div class="col-md-6">
<label>Salary Month</label>
<select class="form-control" id="month" name="month" onchange="getAllEmploye(this.value)">
<?php 
for ($x = 01; $x <= 12; $x++) {
if ($x== (date('m')-1)){
if ($x== 0){$x == 12;}    
echo "<option selected value='$x'>".getMonthName($x)."</option>"; 
}else{
echo "<option value='$x'>".getMonthName($x)."</option>";
}    
}
?>
</select>
</div>
</div>
<div class="row">
<div class="col-md-6">
<label>Branch</label>
<select class="form-control" name="pono" id="brid" onchange="getAllEmploye(this.value)">
<option value=" ">-Select Branch-</option>
<option value="0">-No Branch-</option>
<?php									
$queryd=mysqli_query($con,"SELECT * FROM tbl_branch ORDER BY id ASC")or die(mysqli_error($con));
while ($rowd=mysqli_fetch_array($queryd)){
?>
<option value="<?php echo $rowd['id'];?>"><?php echo $rowd['name'];?></option>
<?php } ?>
</select>
</div>    
</div>
    
</div>    
<div class="col-md-1"></div>    
</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-6"></div>
<div class="col-md-6 text-right" >
<input type="button" id="reset" class="btn btn-flat bg-red btn-sm " value="Reset"/>    
<input type="button" id="triview" class="btn btn-flat bg-purple btn-sm" value="Submit"/>
</div> 
</div>    
</div>
</div>
</div>
</div>    
</div>
</div>    

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
function getAllEmploye(id){
var month = $('#month').val();
var year = $('#year').val();
var brid = $('#brid').val();

$.ajax({
url: 'payr_ecart.php',
type: 'post',
data: {employe : '',branch : brid, month: month, year: year},
//dataType: 'json',
success:function(data) {
$('#dataemploye').html(data);
$('#syear').val(year);
$('#smonth').val(month);    
}
});
} 
</script>    
<!-- /page script -->
</html>    