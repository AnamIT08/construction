<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='war_manbadstock.php';   
$cuPage='war_manbadstock.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];
$uty=$_SESSION['utype'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='waaranty';
$menuh='Warranty Management';
$phead='badsman';
$print='print';
$page='Supplier Bad Stock Claim';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Bad Stock Claim</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px; text-align:center;">SN</th>   
<th>Date</th>
<th>Claim No</th>
<th>Supplier</th>
<th>Amount</th>    
<th>Note</th>    
<th style="width:40px; text-align:center;">Action</th>    
</tr>
</thead>    
<tbody>
<?php
$sql="SELECT * FROM tbl_badstockclaim WHERE brid='$brid' ORDER BY apdate DESC,id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){    
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td><?php echo date("d M Y", strtotime($row['apdate']));?></td>
<td><?php echo $row['invno'];?></td>    
<td>
<?php if($row['type']=='SU'){
echo show_addres(get_fild_data('tbl_supplier',$row['supid'],'name'),get_fild_data('tbl_supplier',$row['supid'],'cnumber'),get_fild_data('tbl_supplier',$row['supid'],'cemail'),'',get_fild_data('tbl_supplier',$row['supid'],'code'),$row['type'].'_'.$row['supid']);    
}else{
if($row['supid']==0){
if($row['name']!=''){echo show_addres($row['name'],$row['mobile'],'','','',$row['type'].'_'.$row['supid']);}else{echo show_addres('From Local Market','','','','',$row['type'].'_'.$row['supid']);}        
}else{
echo show_addres(get_fild_data('tbl_customer',$row['supid'],'name'),get_fild_data('tbl_customer',$row['supid'],'cnumber'),get_fild_data('tbl_customer',$row['supid'],'cemail'),'',get_fild_data('tbl_customer',$row['supid'],'code'),$row['type'].'_'.$row['supid']);    
}}?>
</td>
<td><?php echo numtolocal($row['amount'],get_fild_data('tbl_currency','1','symbol'));?></td>    
<td><?php echo $row['note'];?></td>   
<td nowrap="">
<a class="btn btn-flat bg-purple details-invoice" href="#" id="inv_<?php echo $row['id'].'_'.$row['supid']; ?>"><i class="fa fa-eye cat-child"></i></a>
<a class="btn btn-flat bg-purple receiv" href="#" id="rcv_<?php echo $row['id'].'_'.$row['invno']; ?>"><i class="fa fa-truck"></i></a>     
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>   
<form action="war_manbadstock.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delbsc" value="<?php echo $row['id']; ?>" />
</form>
</td>    
</tr>    
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<a href="war_badstcreate.php" class="btn btn-flat bg-purple">Bad Stock Claim</a>
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'BSC','A');}else{echo read_activity($aid,'BSC','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>    

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->
<?php include('../layout/rside.php'); ?>   
<?php include('../layout/details.php'); ?>     
<?php include('../layout/print.php'); ?>     
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
});
    
function take_action(id) {
document.getElementById(id).submit(); 
}
    
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});
}
    
$(document).on('click','.details-invoice',function(e) {      
id_arr = $(this).attr('id');
id = id_arr.split("_");

$.ajax({
url: 'war_viewbdlist.php',
method: "POST",
data:{ 
invid: id[1],cusid: id[2]
},
success: function(data){
$('#listitem').html(data);
pagelist();    
}
});    
    
$.ajax({
url: 'war_viewbdinv.php',
method: "POST",
data:{ 
print: id[1]
},
success: function(data){
$('#invhold').html(data);
sethead();    
}
});
    
$('.right-side').toggle('slide', { direction: 'right' }, 300);    

e.preventDefault();
});

$(document).on('click','.receiv',function(e) {
id_arr = $(this).attr('id');
id = id_arr.split("_");
$.ajax({
url: 'war_badcart.php',
method: "POST",
data:{ 
rcvdet: 1,invid: id[1],invno:id[2]
},
success: function(data){
$('#datacon').html(data);    
}
});    
    
$('.right-side-free').toggle('slide', { direction: 'right' }, 300);    
e.preventDefault();    
});    

   
    
$(document).on('click', '#closepop', function() {
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }   
});    

$(document).on('click', '.detailsrec', function(e) { 
id_arr = $(this).attr('id');
id = id_arr.split("_");
if(id[1]==0)return;

$.ajax({
url: 'axe_details.php',
method: "POST",
data:{ 
cusdet: 1,cusid: id[1],type:id[0]
},
success: function(data){
$('#profile').html(data);    
}
});    
    
$.ajax({
url: 'axe_details.php',
method: "POST",
data:{ 
tradet: 1,cusid: id[1],type:id[0]
},
success: function(data){
$('#details').html(data);   
}
});    
    
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);    
e.preventDefault();    
});
    
$(document).on('click', '#closedet', function() {
$('#profile').html('');
$('#details').html('');    
if($('.right-side-details').is(':visible')) {
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);
}    
});    
    
$('#listitem').on('click','li', function(){
   $(this).addClass('active').siblings().removeClass('active');
});
    
$(document).on('click', '.invpiv', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
$.ajax({
url: 'war_viewbdinv.php',
method: "POST",
data:{ 
print: ids
},
beforeSend: function() {
//$("#invhold").fadeOut('slow');
},    
success: function(data){    
$('#invhold').html(data);
$("#invhold").fadeIn('slow');    
sethead();    
}
});     
});    
</script>    
<!-- /page script -->
</html>    