<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}

$output=''; 

if(isset($_POST['catid'])){
$catid=intval($_POST['catid']);
if($catid>0){
$sql = "SELECT * FROM (SELECT tbl_item.name,tbl_item.brid,tbl_brand.name AS brand,tbl_item.catid,tbl_category.name AS category,tbl_item.scatid,tbl_stock.code,tbl_stock.unqid,tbl_stock.cost,tbl_stock.price,(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0))+(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0)) AS avqty FROM tbl_stock LEFT JOIN tbl_item ON tbl_item.id=tbl_stock.pid LEFT JOIN tbl_brand ON tbl_brand.id=tbl_item.brid LEFT JOIN tbl_category ON tbl_category.id=tbl_item.catid) ofitm WHERE avqty>0 AND catid='$catid' ORDER BY name ASC";    
}else{
$sql = "SELECT * FROM (SELECT tbl_item.name,tbl_item.brid,tbl_brand.name AS brand,tbl_item.catid,tbl_category.name AS category,tbl_item.scatid,tbl_stock.code,tbl_stock.unqid,tbl_stock.cost,tbl_stock.price,(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0))+(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0)) AS avqty FROM tbl_stock LEFT JOIN tbl_item ON tbl_item.id=tbl_stock.pid LEFT JOIN tbl_brand ON tbl_brand.id=tbl_item.brid LEFT JOIN tbl_category ON tbl_category.id=tbl_item.catid) ofitm WHERE avqty>0 ORDER BY name ASC";    
}        
}elseif(isset($_POST['subcatid'])){
$scatid=intval($_POST['subcatid']);
$sql = "SELECT * FROM (SELECT tbl_item.name,tbl_item.brid,tbl_brand.name AS brand,tbl_item.catid,tbl_category.name AS category,tbl_item.scatid,tbl_stock.code,tbl_stock.unqid,tbl_stock.cost,tbl_stock.price,(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0))+(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0)) AS avqty FROM tbl_stock LEFT JOIN tbl_item ON tbl_item.id=tbl_stock.pid LEFT JOIN tbl_brand ON tbl_brand.id=tbl_item.brid LEFT JOIN tbl_category ON tbl_category.id=tbl_item.catid) ofitm WHERE avqty>0 AND scatid='$scatid' ORDER BY name ASC";     
}elseif(isset($_POST['brandid'])){    
$brid=intval($_POST['brandid']);
if($brid>0){
$sql = "SELECT * FROM (SELECT tbl_item.name,tbl_item.brid,tbl_brand.name AS brand,tbl_item.catid,tbl_category.name AS category,tbl_item.scatid,tbl_stock.code,tbl_stock.unqid,tbl_stock.cost,tbl_stock.price,(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0))+(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0)) AS avqty FROM tbl_stock LEFT JOIN tbl_item ON tbl_item.id=tbl_stock.pid LEFT JOIN tbl_brand ON tbl_brand.id=tbl_item.brid LEFT JOIN tbl_category ON tbl_category.id=tbl_item.catid) ofitm WHERE avqty>0 AND brid='$brid' ORDER BY name ASC";     
}else{
$sql = "SELECT * FROM (SELECT tbl_item.name,tbl_item.brid,tbl_brand.name AS brand,tbl_item.catid,tbl_category.name AS category,tbl_item.scatid,tbl_stock.code,tbl_stock.unqid,tbl_stock.cost,tbl_stock.price,(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0))+(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0)) AS avqty FROM tbl_stock LEFT JOIN tbl_item ON tbl_item.id=tbl_stock.pid LEFT JOIN tbl_brand ON tbl_brand.id=tbl_item.brid LEFT JOIN tbl_category ON tbl_category.id=tbl_item.catid) ofitm WHERE avqty>0 ORDER BY name ASC";    
}    
}else{
$sql = "SELECT * FROM (SELECT tbl_item.name,tbl_item.brid,tbl_brand.name AS brand,tbl_item.catid,tbl_category.name AS category,tbl_item.scatid,tbl_stock.code,tbl_stock.unqid,tbl_stock.cost,tbl_stock.price,(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0))+(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0)) AS avqty FROM tbl_stock LEFT JOIN tbl_item ON tbl_item.id=tbl_stock.pid LEFT JOIN tbl_brand ON tbl_brand.id=tbl_item.brid LEFT JOIN tbl_category ON tbl_category.id=tbl_item.catid) ofitm WHERE avqty>0 ORDER BY name ASC";
}
$result = mysqli_query($con, $sql);
while ($row=mysqli_fetch_array($result)){
$unqid=$row['unqid'];
$output.='<div class="product-content product-select selitem" id="AX_'.$row['unqid'].'" title="'.$row['name'].'"><img src="../img/product/';
if(empty($row['image'])){$output.='no_image.png';}else{$output.=$row['image'];} 
$output.='" class="product-image"><div class="info"><h3>'.get_prostinfo($row['unqid'],'price').'</h3><p>Qty: '.$row['avqty'];
if(get_fild_data('tbl_setting','5','sval')==0){
$output.='<br>Cost: '.numtolocal(get_fild_data('tbl_stock','','cost',"unqid='$unqid'"),'');    
}   
$output.='</p></div><div class="product-detail"><b class="name">'.$row['name'].'</b></div><div class="product-code"><b class="sku">'.$row['code'].'</b><b class="indexg" style="display:none;">'.strtoupper(substr($row['name'],0,1)).'</b></div></div>';	
}   
echo $output;
exit;