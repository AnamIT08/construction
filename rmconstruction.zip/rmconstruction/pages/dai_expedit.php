<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('4','edits','R');     
$_SESSION['cuPages']='dai_explist.php';   
$cuPage='dai_explist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='daily';
$menuh='Daily Process';
$phead='expitm';
$page='Expenses Head';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['update_exphead'])){
    $expid = remove_junk(escape($_POST['expid']));
	$name = ucwords(remove_junk(escape($_POST['name'])));
    //$bname = $_POST['bname'];
    $etype = remove_junk(escape($_POST['etype']));
    $description = remove_junk(escape($_POST['description']));
	if($etype==0){
    $grid=9;
    $sgrid=21;    
    }else{
    $grid=8;
    $sgrid=20;    
    }
    $code = get_ledgercode($grid);
    
	if(isset($_POST['name'])){
	//$ducode = mysqli_query($con,"SELECT * FROM tbl_acledger WHERE ((name IS NOT NULL AND name = '$name') OR (bname IS NOT NULL AND bname='$bname')) AND id!='$expid'");
    $ducode = mysqli_query($con,"SELECT * FROM tbl_acledger WHERE name = '$name' AND id!='$expid'");    
	}

	if($ducode->num_rows > 0) {
	save_msg('i','This expenses head already exists! Plz try another');
	echo "<script>window.location='dai_explist.php'</script>";
	}else{   
    //$sql="UPDATE tbl_acledger SET code='$code',grid='$grid',sgrid=$sgrid,name='$name',bname='$bname',description='$description' WHERE id='$expid'"; 
    $sql="UPDATE tbl_acledger SET code='$code',grid='$grid',sgrid=$sgrid,name='$name',description='$description' WHERE id='$expid'";     
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $efid=mysqli_affected_rows($con);    
    if($efid>0){
    $act =remove_junk(escape('Expenses Head name: '.$name));
    $bact =remove_junk('খরচ খাতের নামঃ '.$name);    
    write_activity($aid,'EXP','New Expenses Head has been updated',$act,'খরচের খাত হালনাগাদ করেছেন',$bact);    
    save_msg('s','Data Successfully Updated!');
    }else{
    save_msg('w','Data Fail to Update!');    
    }
    echo "<script>window.location='dai_explist.php'</script>";  
	}  
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Edit Expenses Head';}else{echo 'খরচের খাত হালনাগাদ করুন';}?></h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="dai_expedit.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">

<div class="row">
<div class="col-md-12">
<div class="col-md-3"></div>
<div class="col-md-6">
<?php 
if(isset($_POST['editexh'])){
$ids = $_POST['editexh'];
$sql="SELECT * FROM tbl_acledger WHERE id='".$ids."' ORDER BY id ASC LIMIT 1";    
$admin=mysqli_query($con,$sql) or die(mysqli_error($con));    
$adm=mysqli_fetch_array($admin); 
?>     
<div class="form-group">
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Name';}else{echo 'নাম (ইংলিশ)';}?></label>
<input type="text" name="name" maxlength="35" value="<?php echo $adm['name'];?>" id="name" class="form-control" placeholder="e.g. Electric Bill"/>
<input type="hidden" maxlength="11" value="<?php echo $adm['id'];?>" class="form-control" name="expid" autocomplete="off" readonly>     
</div>
<!--<div class="form-group">
<label><?php //if(get_fild_data('tbl_setting','1','sval')==0){echo 'Name (Bangla)';}else{echo 'নাম (বাংলায়)';}?></label>
<input type="text" name="bname" maxlength="255" value="<?php echo $adm['bname'];?>" id="bname" class="form-control" placeholder="e.g. বিদ্যুৎ বিল" />
</div>-->    
<div class="form-group">
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Expeses Type';}else{echo 'খরচের ধরন';}?></label>
<select class="form-control" name="etype" id="etype">
<option value="">-<?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Select';}else{echo 'নির্বাচন করুন';}?>-</option>
<option <?php if($adm['sgrid']==21){echo 'selected';}?> value="0"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Administrative Expenses';}else{echo 'প্রশাসনিক খরচ';}?></option>
<option <?php if($adm['sgrid']==20){echo 'selected';}?> value="1"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Operating Expenses';}else{echo 'পরিচালনা খরচ';}?></option>    
</select>    
</div>    
<div class="form-group">
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Description';}else{echo 'বর্ণনা';}?></label>
<textarea class="form-control" maxlength="250" rows="6" name="description" placeholder="<?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Description';}else{echo 'বর্ণনা';}?>"><?php echo $adm['description'];?></textarea>
</div>
<?php } ?>   
</div>    
<div class="col-md-3"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="update_exphead" id="submit" class="btn btn-flat bg-purple btn-sm " value="<?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Update';}else{echo 'হালনাগাদ';}?>"/> <a href="dai_explist.php" class="btn btn-flat bg-gray"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Close';}else{echo 'বন্দ';}?></a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'History';}else{echo 'ইতিহাস';}?> </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'EXP','A');}else{echo read_activity($aid,'EXP','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function () {  
<?php if(get_fild_data('tbl_setting','1','sval')==0){?>    
var name = new LiveValidation('name');
name.add(Validate.Presence);    
<?php }else{ ?>
var bname = new LiveValidation('bname');
bname.add(Validate.Presence);    
<?php } ?>
var etype = new LiveValidation('etype');
etype.add(Validate.Presence);    
});
</script>    
<!-- /page script -->
</html>    