<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
$body='';
$foot='';
$s=0;
$totamo=0;
if(isset($_SESSION['axes_recitem'])){
if(is_array($_SESSION['axes_recitem'])){
$max=count($_SESSION['axes_recitem']);
for($i=($max-1);$i>=0;$i=$i-1){
     
$dty = $_SESSION['axes_recitem'][$i]['dty'];
$did=$_SESSION['axes_recitem'][$i]['did'];
$dname = get_namebytype($dty,'N',$did);    
$amo=$_SESSION['axes_recitem'][$i]['amo'];
$cid=$_SESSION['axes_recitem'][$i]['cid'];
$cty=$_SESSION['axes_recitem'][$i]['cty'];
$cname = get_namebytype($cty,'N',$cid);    
$chkno=$_SESSION['axes_recitem'][$i]['chkno'];
$chkdt=$_SESSION['axes_recitem'][$i]['chkdt'];
$ref=$_SESSION['axes_recitem'][$i]['ref'];
$mtype=$_SESSION['axes_recitem'][$i]['mtype'];    
if($mtype=='1'){
$etype='Civil Work';    
}elseif($mtype=='2'){
$etype='Power Work';    
}else{
$etype='';    
}    
$s+=1;
$body.='<tr>';
$body.='<td style="text-align:center">'.$s.'</td>';
$body.='<td>'.$dname.'</td>';
$body.='<td>'.$cname.'</td>';
$body.='<td>'.$etype.'</td>';    
$body.='<th class="text-right">'.number_format($amo,2).'</th>';
$body.='<td>'.$chkno.'</td>'; 
$body.='<td>'.$chkdt.'</td>';     
$body.='<td>'.$ref.'</td>';
$body.='<td style="text-align:center"><a id="'.$i.'" class="remove"><span style="cursor: pointer;color:red;" class="fa fa-times"></span></a></td>';    
$body.='</tr>';     
}
$foot.='<tr>';
$foot.='<th colspan="4" class="text-right">TOTAL</th>';
$foot.='<th class="text-right">'.number_format(total_recvalue(),2).'</th>';    
$foot.='<th colspan="6"></th>';    
$foot.='</tr>';    
}else{
$body.='<tr>';
$body.='<td colspan="8" class="text-center">There are no items in your received list!</td>';
$body.='</tr>'; 
} 
}else{
$body.='<tr>';
$body.='<td colspan="8" class="text-center">There are no items in your received list!</td>';
$body.='</tr>';
}
            
if(isset($_POST['body'])){
echo $body;
}elseif(isset($_POST['foot'])){
echo $foot;	
}
exit;    
?>    