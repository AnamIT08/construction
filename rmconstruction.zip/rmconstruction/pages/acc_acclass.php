<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='acc_acclass.php';   
$cuPage='acc_acclass.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='account';
$menuh='Account';
$phead='acclass';
$page='Account Class';
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
$dtnow = date("Y-m-d h:i:s", time());
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-12">    
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Account Class</h3>
</div>
<div class="box-body">
<div class="row">
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped table-hover">
<thead>
<tr>    
<th style="width:40px; text-align:center;">SN</th>
<th>Name</th>
<th>Description</th>    
</tr>
</thead>
<tbody>
<?php
$inc=2;
$sql="SELECT * FROM  tbl_aclass ORDER BY id ASC";	
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$id=$row['id'];
$inc = ($inc == 2) ? 1 : $inc+1;    
?>    
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td style="font-style: italic; font-weight: 600;"><?php echo $row['name'];?></td>
<td><?php echo $row['description'];?></td>
</tr>
<?php } ?>    
</tbody>
</table>    
</div>    
</div>     
</div>    
</div>    
</div>
</div>
    
<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">

</script>    
<!-- /page script -->
</html>