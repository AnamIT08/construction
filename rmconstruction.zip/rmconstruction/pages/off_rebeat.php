<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='off_rebeat.php';   
$cuPage='off_rebeat.php';    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='offer';
$menuh='Set Offer &amp; Rebeat';
$phead='rbclist';
$page='Rebeat Claim List';
$print='print';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Claim Rebeat Record</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px;">SN</th>   
<th>Date</th>
<th>Supplier</th>
<th>From</th>
<th>To</th>
<th>Amount</th>    
<th style="width:40px; text-align:center;">Action</th>    
</tr>
</thead>    
<tbody>
<?php
$sql="SELECT * FROM tbl_rebeat ORDER BY id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$id=$row['id'];
?>
<tr>
<td class="center"><?php echo count_id();?></td>
<td><?php echo date("d M Y", strtotime($row['apdate']));?></td>
<td><?php echo get_fild_data('tbl_supplier',$row['supid'],'name') ?></td>
<td><?php echo date("d M Y", strtotime($row['fdate']));?></td>
<td><?php echo date("d M Y", strtotime($row['tdate']));?></td>
<td><?php echo numtolocal($row['amount'],'');?></td>
<td nowrap="">
<a class="btn btn-flat bg-purple details-invoice" href="#" id="inv_<?php echo $row['id']; ?>"><i class="fa fa-eye cat-child"></i></a>
<?php if(delete_check('tbl_traproduct','ofid',$row['id'])<=0){ ?>   
<a class="btn btn-flat bg-purple" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
<form action="off_rebeat.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delrbt" value="<?php echo $row['id']; ?>" />
</form>
<?php } ?>    
</td>    
</tr>    
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<a href="off_rebeatcl.php" class="btn btn-flat bg-purple">Claim Rebeat</a>
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'RBT','A');}else{echo read_activity($aid,'RBT','U');}?>
</div>
</div>
</div>
</div>
</div>
</div> 
        
<?php include('../layout/quick.php');?>    
</section>
<?php include('../layout/print.php'); ?>    
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function(){
$('#datarec').DataTable({stateSave: true});
});
    
function edit_item(id) {
document.getElementById(id).submit(); 
}
    
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});
} 
</script>    
<!-- /page script -->
</html>    