<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='ser_serinvcre.php';   
$cuPage='ser_serinvcre.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='sevice';
$menuh='Service';
$phead='sercreate';
$page='Service Sales Create';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-7">
<div class="box box-solid">
<div class="box-body">
<div class="col-md-12">
<div class="row">
<div class="col-md-2"></div>
<div class="col-md-7">
<div class="form-group">  
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>
<input type="text" class="form-control" name="search" id="search" placeholder="e.g. Service Code or Name" autocomplete="off">    
</div>
</div>    
</div>
<div class="col-md-1">
<div class="form-group">  
<input type="text" class="form-control text-center" maxlength="1" id="searchi" placeholder="" autocomplete="off">    
</div>
</div>
<div class="col-md-2"></div>    
</div>
<div class="row">
<div class="product-panel style-2" id="purchaseitem">

</div>
</div>
</div>    
</div>
</div>
</div>
<div class="col-md-5">
<div class="box box-solid">
<div class="box-body">

<div class="col-md-12">
<div class="row">
<div class="col-md-9">
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-user-o"></span></span>
<span class="input-group-addon"><a data-toggle="collapse" data-target="#walkcus" class="accordion-toggle" id="walkin" style="cursor: pointer;">Walk-In</a></span>   
<input type="text" class="form-control" id="cusname" value="" placeholder="Type Customer Code, Name Or Mobile No..." autocomplete="off" />
<span class="input-group-addon"><a id="addcus" style="cursor: pointer;"><span class="fa fa-plus"></span></a></span>    
</div>
<input type="hidden" name="cusid" id="cusid" class="form-control" value="" readOnly />    
</div>    
</div>
<div class="col-md-3"><span style="font-size: 18px;color: red;font-weight: bold;">Bal.: </span><span style="font-size: 18px;color: blue;font-weight: bold;" id="cusbal">0.00</span></div>    
</div>
<div class="row">   
<div class="accordian-body collapse" id="walkcus">
<div class="col-md-6">    
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-id-card-o"></span></span>    
<input type="text" id="walkname" maxlength="35" class="form-control" value="Walk-In Customer" placeholder="Customer Name" autocomplete="off">
</div>
</div>
</div>
<div class="col-md-6">     
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-mobile"></span></span>    
<input type="text" id="walkmobile" maxlength="18" class="form-control" value="" placeholder="e.g. 016167xx7x" autocomplete="off">
</div>
</div>    
</div>
</div>     
</div>     
<div class="row">
<div class="col-md-12">
<div class="form-group">  
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>
<input type="text" class="form-control" id="pcode" placeholder="e.g. Service Code or Name" autocomplete="off">
<span class="input-group-addon"><a id="addexpro" style="cursor: pointer;"><span class="fa fa-plus" style="color:red"></span></a></span>    
</div>
</div>       
</div>       
</div>
    
<div class="row">
<div class="cart cart-sm">     
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<thead>
<th width="30px">SN</th>
<th width="249px">Services</th>
<th width="72px">Qty</th>
<th width="72px">Price</th>   
<th width="77px">SubTotal</th>
<th width="25px"><a class="empty" style="cursor: pointer;"><i class="fa fa-trash"></i></a></th>    
</thead>
</table>
<div class="cart-msg style-3 item" style="padding:0px;">    
<table class="table table-bordered table-striped" style="margin-bottom: 0;">    
<tbody id="itemdata">

</tbody>    
</table>
</div>
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<tfoot id="itemfoot">

</tfoot>
</table>    
</div>    
</div>
    
<div class="row" id="serialpro">
    
    
</div>    
  
<div class="row" id="extra">
 
</div>     
    
</div> 
    
</div>
</div>
</div>
</div>
    
<div class="rotate btn-cat-con">
<button type="button" id="open-subcategory" class="btn btn-warning open-subcategory" tabindex="-1">Sub Categories</button>
<button type="button" id="open-category" class="btn btn-primary open-category" tabindex="-1">Categories</button>
</div>

<div id="category-slider">
<div class="row">
<div class="col-md-2"></div>
<div class="col-md-8">
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>     
<input type="text" class="form-control form-control-lg" id="searchcategory" placeholder="Search by Name" autocomplete="off">
</div>
</div>
</div>   
<div class="col-md-2"></div>
</div>
<div id="category-list" class="ps-container style-2">
<button id="category_0" type="button" value="0" class="btn-prni category" tabindex="-1"><img src="../img/product/<?php if(empty($rowc['image']) || $rowc['image']==''){echo 'no_image.png';}else{echo $rowc['image'];}?>" class="img-rounded img-thumbnail"><span>All Categories</span></button>
<?php
$sql="SELECT tbl_seritem.catid AS id,tbl_category.name FROM tbl_seritem  LEFT JOIN tbl_category ON tbl_category.id=tbl_seritem.catid WHERE tbl_seritem.catid IS NOT NULL GROUP BY tbl_seritem.catid ORDER BY tbl_category.name ASC";	

$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowc=mysqli_fetch_array($query)){
$id=$rowc['id'];
?>
<button id="category_<?php echo $rowc['id']?>" type="button" value="<?php echo $rowc['id']?>" class="btn-prni category" tabindex="-1"><img src="../img/product/<?php if(empty($rowc['image']) || $rowc['image']==''){echo 'no_image.png';}else{echo $rowc['image'];}?>" class="img-rounded img-thumbnail"><span class="cname"><?php echo $rowc['name']?></span></button>    
<?php } ?>
<div class="ps-scrollbar-x-rail" style="width: 0px; display: none; left: 0px; bottom: 3px;"><div class="ps-scrollbar-x" style="left: 0px; width: 0px;"></div></div><div class="ps-scrollbar-y-rail" style="top: 0px; height: 0px; display: none; right: 3px;"><div class="ps-scrollbar-y" style="top: 0px; height: 0px;"></div></div>
</div>
</div>

<div id="subcategory-slider">
<div class="row">
<div class="col-md-2"></div>
<div class="col-md-8">
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>     
<input type="text" class="form-control form-control-lg" id="searchsubcategory" placeholder="Search by Name" autocomplete="off">
</div>
</div>   
</div>
<div class="col-md-2"></div>
</div>
<div id="subcategory" class="ps-container style-2">
    
</div>
</div>

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->
<?php include('../layout/rside.php'); ?> 
<?php include('../layout/checkout.php'); ?>
<div id="invdata" style="display: none;"></div>    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
ReadItem();
    
function ReadItem() {
$.ajax({
url: "ser_item.php",
method: "POST",
success: function(data) {
$('#purchaseitem').html(data);
}
})
}

ReadData();
function ReadData(){
$.ajax({
url: "ser_invview.php",
method: "POST",
data:{ 
body:1
},
success: function(data){
$('#itemdata').html(data);
}
})

$.ajax({
url: "ser_invview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})
ReadButon();       
};    

function ReadFoot(){
$.ajax({
url: "ser_invview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})	
}    

function ReadButon(){
$.ajax({
url: "ser_invview.php",
method: "POST",
data:{ 
buton:1
},
success: function(data){
$('#extra').html(data);
}
})	
}
    
var search = $("#search").on('input',function(){
var matcher = new RegExp($(this).val(), 'i');

$('.selitem').show().not(function(){
return matcher.test($(this).find('.name, .sku').text())
}).hide();
}) 

var search = $("#searchi").on('input',function(){
var matcher = new RegExp($(this).val(), 'i');

$('.selitem').show().not(function(){
return matcher.test($(this).find('.indexg').text())
}).hide();
})

$(document).on('keyup', '#searchcategory', function () {
var search = $("#searchcategory").on('input',function(){
var matcher = new RegExp($(this).val(), 'i');

$('.category').show().not(function(){
return matcher.test($(this).find('.cname').text())
}).hide();
})
})

$(document).on('keyup', '#searchsubcategory', function () {
var search = $("#searchsubcategory").on('input',function(){
var matcher = new RegExp($(this).val(), 'i');

$('.subcat').show().not(function(){
return matcher.test($(this).find('.sname').text())
}).hide();
})
})
    
$(".open-brands").click(function () {
$('#brands-slider').toggle('slide', { direction: 'right' }, 700);
});
$(".open-category").click(function () {
$('#category-slider').toggle('slide', { direction: 'right' }, 700);
});
$(".open-subcategory").click(function () {
$('#subcategory-slider').toggle('slide', { direction: 'right' }, 700);
});
    
$(document).on('click', function(e){
if (!$(e.target).is(".open-category, .cat-child") && !$(e.target).parents("#category-slider").length && $('#category-slider').is(':visible')) {
$('#category-slider').toggle('slide', { direction: 'right' }, 700);
}
if (!$(e.target).is(".open-subcategory, .cat-child") && !$(e.target).parents("#subcategory-slider").length && $('#subcategory-slider').is(':visible')) {
$('#subcategory-slider').toggle('slide', { direction: 'right' }, 700);
}
if (!$(e.target).is(".right-side-add, .side-cont") && !$(e.target).parents(".right-side-add").length && $('.right-side-add').hasClass('open-right-add')) {
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');
}    
});

$(document).on('click', '.category', function () {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
$.ajax({
url: 'ser_item.php',
method: "POST",
data:{ 
catid: ids
},
success: function(data){
$('#purchaseitem').html(data);
}
});
    
$.ajax({
url: 'ser_subcat.php',
method: "POST",
data:{ 
catid: ids
},
success: function(data){
$('#subcategory').html(data);
}
});    
});
    
$(document).on('click', '.subcat', function () {
sid_arr = $(this).attr('id');
sid = sid_arr.split("_");    
var scid = sid[1];
$.ajax({
url: 'ser_item.php',
method: "POST",
data:{ 
subcatid: scid
},
success: function(data){
$('#purchaseitem').html(data);
}
});    
});
    
$(document).on('click', '#icon', function() {
if(!$("#icon").hasClass('cart-icon-rotate')){
$("#icon").addClass('cart-icon-rotate');
$(".cart tr.dshow").toggle();
}else{
$("#icon").removeClass('cart-icon-rotate');	
$(".cart tr.dshow").hide();
}	
});

$(document).on('click', '.selitem', function () {    
var id = $(this).attr('id');
pid_arr = $(this).attr('id');
unid = pid_arr.split("_");    
var code = unid[1];    
$.ajax({
url: 'ser_cart.php',
method: "POST",
data:{ 
additem: code
},
success: function(data){
ReadData();
}
});    
});

$(document).on('keydown', '#pcode', function () {
$('#pcode' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'ser_cart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term,itmsear:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
var te='';
$(this).val(te); // display the selected text
var code = ui.item.value; // selected id to input

$.ajax({
url: 'ser_cart.php',
type: 'post',
data: {additem:code},
success:function(response){
ReadData();
}
});
return false;
}
});        
});    
    
$(document).on('click', '.remove', function () {
var id = $(this).attr('id');
$.ajax({
url: 'ser_cart.php',
method: "POST",
data:{ 
remove: id
},
success: function(data){
ReadData();
}
});    
});
    
$(document).on('blur', '.quantity', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var qty = parseFloat($('#qty_'+id[1]).val());
$.ajax({
url: 'ser_cart.php',
method: "POST",
data:{ 
upqty: ids, qty: qty
},
dataType: 'json',
success: function(data){
$('#qty_'+id[1]).val(data[0]);
$('#price_'+id[1]).val(data[1]);    
$('#stotal_'+id[1]).html(data[2]);
$('#snote_'+id[1]).val(data[3]);    
$('#disp_'+id[1]).val(data[4]);
$('#disf_'+id[1]).val(data[5]);
$('#disamo_'+id[1]).html(data[6]);        
ReadFoot();   
}
});     
});

$(document).on('blur', '.price', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var amo = parseFloat($('#price_'+id[1]).val());
$.ajax({
url: 'ser_cart.php',
method: "POST",
data:{ 
upprice: ids, amo: amo
},
dataType: 'json',
success: function(data){
$('#qty_'+id[1]).val(data[0]);
$('#price_'+id[1]).val(data[1]);    
$('#stotal_'+id[1]).html(data[2]);
$('#snote_'+id[1]).val(data[3]);    
$('#disp_'+id[1]).val(data[4]);
$('#disf_'+id[1]).val(data[5]);
$('#disamo_'+id[1]).html(data[6]); 
ReadFoot();
}
});     
});

$(document).on('blur', '.pnote', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var ref = $('#snote_'+id[1]).val();  
$.ajax({
url: 'ser_cart.php',
method: "POST",
data:{ 
upnote: ids, note: ref
},
dataType: 'json',
success: function(data){
$('#qty_'+id[1]).val(data[0]);
$('#price_'+id[1]).val(data[1]);    
$('#stotal_'+id[1]).html(data[2]);
$('#snote_'+id[1]).val(data[3]);    
$('#disp_'+id[1]).val(data[4]);
$('#disf_'+id[1]).val(data[5]);
$('#disamo_'+id[1]).html(data[6]); 
ReadFoot();
}
});     
});
    
$(document).on('blur', '.disp', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var dic = parseFloat($('#disp_' + id[1]).val());
$.ajax({
url: 'ser_cart.php',
method: "POST",
data: {
itemdisp: ids,
disp: dic
},
dataType: 'json',
success: function(data) {
$('#qty_'+id[1]).val(data[0]);
$('#price_'+id[1]).val(data[1]);    
$('#stotal_'+id[1]).html(data[2]);
$('#snote_'+id[1]).val(data[3]);    
$('#disp_'+id[1]).val(data[4]);
$('#disf_'+id[1]).val(data[5]);
$('#disamo_'+id[1]).html(data[6]);
ReadFoot();
}
});
});
    
$(document).on('blur', '.disf', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var dica = parseFloat($('#disf_' + id[1]).val());
$.ajax({
url: 'ser_cart.php',
method: "POST",
data: {
itemdisf: ids,
disf: dica
},
dataType: 'json',
success: function(data) {
$('#qty_'+id[1]).val(data[0]);
$('#price_'+id[1]).val(data[1]);    
$('#stotal_'+id[1]).html(data[2]);
$('#snote_'+id[1]).val(data[3]);    
$('#disp_'+id[1]).val(data[4]);
$('#disf_'+id[1]).val(data[5]);
$('#disamo_'+id[1]).html(data[6]);
ReadFoot();
}
});
});
    
function get_foot(){
$.ajax({
url: 'ser_cart.php',
method: "POST",
data: {
foot: 1
},
dataType: 'json',
success: function(data) {	
$('#discount').val(data[0]);
$('#disitems').html('<strong>'+data[1].toFixed(2)+'</strong>');
if(parseFloat(data[2])>0){
$('#totdisamo').html('<strong>'+data[2].toFixed(2)+'</strong>');
}
    
$('#vatp').val(data[3]);
$('#vatamo').html('<strong>'+data[4].toFixed(2)+'</strong>');

$('#aitp').val(data[5]);
$('#aitamo').html('<strong>'+data[6].toFixed(2)+'</strong>');
        
$('#otdname').html('<strong>'+data[7]+'</strong>');
$('#others').val(data[8]);
$('#othersamo').html('<strong>'+data[8].toFixed(2)+'</strong>');
    
$('#otame').html(data[7]);

$('#freight').val(data[9]);
$('#freightd').html('<strong>'+data[9].toFixed(2)+'</strong>');
$('#less').val(data[10]);
$('#lessd').html('<strong>'+data[10].toFixed(2)+'</strong>');
$('#grtotal').html('<strong>'+data[11].toFixed(2)+'</strong>');
}
});	
}
    
$(document).on('blur', '#discount', function() {
var disp = parseFloat($('#discount').val());
$.ajax({
url: 'ser_cart.php',
method: "POST",
data: {
seldis: disp
},
success: function(data) {
get_foot();
}
});
});
    
$(document).on('blur', '#vatp', function() {
var vatp = parseFloat($('#vatp').val());
$.ajax({
url: 'ser_cart.php',
method: "POST",
data: {
selvat: vatp
},
success: function(data) {
get_foot();
}
});
});
    
$(document).on('blur', '#aitp', function() {
var aitp = parseFloat($('#aitp').val());
$.ajax({
url: 'ser_cart.php',
method: "POST",
data: {
seltax: aitp
},
success: function(data) {
get_foot();
}
});
});
    
$(document).on('blur', '#others', function() {
var others = parseFloat($('#others').val());
$.ajax({
url: 'ser_cart.php',
method: "POST",
data: {
others: others
},
success: function(data) {
get_foot();
}
});
});

$(document).on('blur', '#otname', function() {
var otname = $('#otname').val();
$.ajax({
url: 'ser_cart.php',
method: "POST",
data: {
otname: otname
},
success: function(data) {
get_foot();
}
});
});
    
$(document).on('blur', '#freight', function() {
var frei = parseFloat($('#freight').val());
$.ajax({
url: 'ser_cart.php',
method: "POST",
data: {
freight: frei
},
success: function(data) {
get_foot();
}
});
});				
				
$(document).on('blur', '#less', function() {
var less = parseFloat($('#less').val());
$.ajax({
url: 'ser_cart.php',
method: "POST",
data: {
less: less
},
success: function(data) {
get_foot();
}
});
});
    
$(document).on('click', '#addexpro', function(e) {
$.ajax({
url: "ser_cart.php",
method: "POST",
data:{addseritem:1},
success: function(data){
$('#addsitem').html(data);
$('.right-side-add').toggle('slide', { direction: 'right' }, 300);     
}
})    
e.preventDefault();    
});    
    
$(document).on('click', '#closepop', function() {
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
});
    
$(document).on('click', '#addmseri', function() { 
var cash_data = $('.addourseritem input, .addourseritem select, .addourseritem textarea');
toastr.options = {'positionClass': 'toast-top-center'};    
if(!chek_error()){   
return;   
}
    
$.ajax({
url: "ser_cart.php",
data: cash_data,
type: 'post',
dataType: 'json',    
beforeSend: function () {
chek_error();    
},    
success: function(data){
if(data.status === "success"){    
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
ReadData();
}
}
})    
});
    
$(document).on('click', '#emptycart', function () {
var id = $(this).attr('id');    
$.ajax({
url: 'ser_cart.php',
method: "POST",
data:{ 
clear: id
},
success: function(data){
ReadData();
}
});    
});
    
$(document).on('click', '#walkin', function() {	
$('#cusname').val('Walk-In Customer');
$('#cusid').val('CU_0');
$('#cusbal').html('0.00');	
});
    
$(document).on('keyup', '#cusname', function() { 
var bal = $(this).val();
if(bal.length<1){
$('#cusid').val('');
$('#cusbal').html('0.00');	
}
});
    
$(document).on('keydown', '#cusname', function() {    
$('#cusname' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'ser_cart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term,getcus:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
$(this).val(ui.item.label);	
var cusid = ui.item.value; // selected id to input
$('#cusid').val(cusid);
$.ajax({
url: 'ser_cart.php',
type: 'post',
data: {checkbal:cusid},
success:function(data){
$('#cusbal').html(data);
}
});

return false;
}
});
});
    
$(document).on('click', '#addcus', function() {
$('#addsitem').html('');    
$.ajax({
url: "ser_cart.php",
method: "POST",
data:{addcus:1},
success: function(data){
$('#addsitem').html(data);
$('.right-side-add').toggle('slide', { direction: 'right' }, 300);     
}
})       
});
    
$(document).on('click', '#adcus', function() { 
var customer_data = $('.addcustomer input, .addcustomer textarea');
if(!chek_error()){
return;   
}
$.ajax({
url: "ser_cart.php",
data: customer_data,
type: 'post',
dataType: 'json',    
beforeSend: function () {
chek_error();    
},    
success: function(data){
if(data.status === "success"){
$('#cusname').val(data.cudata);
$('#cusbal').val(data.cbal);
$('#cusid').val(data.cuid);    
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
}else{
$('#cusname').val('');
$('#cusbal').val('0.00');
$('#cusid').val('');    
toastr.error(data.message);    
}         
}
})    
});
    
$(document).on('click', '#save_service', function() {
var cusid = $('#cusid').val();
var wname = $('#walkname').val();
var wmobil = $('#walkmobile').val();    
toastr.options = {'positionClass': 'toast-top-center'};    

if(cusid.length < 1 || cusid == ''){
toastr.info('Please Select Customer!');
return;
}

$.ajax({
url: "ser_cart.php",
method: "POST",
data:{checkview:1,cusid:cusid,wname:wname,wmobil:wmobil},
success: function(data){
$('#checkview').html('');
$('#checkview').html(data); 
}
})    
    
$.ajax({
url: "ser_cart.php",
method: "POST",
data:{checkout:1,cusid:cusid},
success: function(data){
$('#invhold').html('');
$('#invhold').html(data);       
}
})
$('.right-side-checkout').addClass('open-right-checkout');    
});    

$(document).on('click', '#closechk', function() {
$('.right-side-checkout').removeClass('open-right-checkout');
$('#addsitem').html('');    
});
    
$(document).on('click', '.saveseinv', function() {
var cusid = parseFloat($('#scusid').val());
var due = parseFloat($('#dueamo').html());
var stype = $(this).attr('id');
var cash_data = $('.addsersales input, .addsersales select, .addsersales textarea');    
toastr.options = {'positionClass': 'toast-top-center'};    
    
if(cusid<=0 && due > 0){
toastr.warning('Due Not Permitted for Walking Customer!');
return;
}

if(!chek_error()){return;}
    
$.ajax({
url: "ser_cart.php",
data: cash_data,
type: 'post',
dataType: 'json',    
success: function(data){
if(data.status === "success"){
$('.right-side-checkout').removeClass('open-right-checkout');
$('#addsitem').html('');
$('#cusname').val('');    
$("#cusid").val('');
$("#cusbal").html('0.00');
ReadItem();    
ReadData();    
toastr.success(data.message);
if(stype!='saveinv'){
print_inv(data.invid,stype);       
}    
}else{
toastr.error(data.message);    
}         
}
})    
    
});

function print_inv(id,key){
var mode = 'iframe'; //popup
var close = mode == "popup";
var options = {
mode: mode,
popClose: close
};    
$.ajax({
url: "ser_print.php",
data:{print:id,key:key}, 
type: 'post',    
success: function(data){
$("#invdata").html(data);    
$("div.printableArea").printArea(options);
$("#invdata").html('');    
}
})    
};    
    
</script>    
<!-- /page script -->
</html>    