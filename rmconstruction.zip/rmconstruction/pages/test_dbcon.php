<?php
$dbuse = $_SESSION["impdbuse"];
$dbpass = $_SESSION["impdbpass"];
$dbname = $_SESSION["impdbname"];
$icon = mysqli_connect("localhost","$dbuse","$dbpass","$dbname");
// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>