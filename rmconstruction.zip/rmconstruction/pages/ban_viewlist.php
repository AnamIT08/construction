<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/invfunctions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$_SESSION['cuPages']='sel_sinvlist.php';   
$cuPage='sel_sinvlist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
?>
<?php 
if(isset($_POST['acid'])){
$piid=$_POST['acid'];    
$sql="SELECT * FROM tbl_bacount ORDER BY id ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$bnid='BA'.$row['id'];
$ldebit=get_ledgerval($bnid,'D','N');
$lcredit=get_ledgerval($bnid,'C','N');
$lnet=($ldebit-$lcredit);    
?>
<li <?php if($row['id']==$piid){echo 'class="invpiv active"';}else{echo 'class="invpiv"';}?> id="pi_<?php echo $row['id'];?>"><p><strong class="pino"><?php echo $row['acno'];?></strong><br><strong><?php echo get_fild_data('tbl_bank',$row['bid'],'name');?></strong></p>
<div class="sname" style="margin-top: -52px;float: right; position: relative;top: 6px;"><strong><?php echo 'Debit: '.numtolocal($ldebit,get_fild_data('tbl_currency','1','symbol')); ?></strong><br><strong><?php echo 'Credit: '.numtolocal($lcredit,get_fild_data('tbl_currency','1','symbol')); ?></strong></div>
</li>
<?php }} ?>