<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('7','views','R');     
$_SESSION['cuPages']='opr_invoice.php';   
$cuPage='opr_invoice.php';    
$aid=$_SESSION['uid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='operation';
$menuh='Operation Process';
$phead='invist';
$page='Invoice List';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['save_pack'])){
$efr=0;
$invid= remove_junk(escape($_POST['invid']));    
$invno = remove_junk(escape(get_fild_data('tbl_invoice',$invid,'invno')));    
if(isset($_POST['data']) && !empty($_POST['data'])){
$deitems=$_POST['data'];
foreach($deitems as $item){
$pid = remove_junk(escape($item['pid']));
$ctns = remove_junk(escape($item['pack']));
if($ctns==''){$ctns=0;}    
$net = remove_junk(escape($item['net']));
if($net==''){$net=0;}     
$gross = remove_junk(escape($item['gross']));
if($gross ==''){$gross =0;} 
    
$sql="UPDATE tbl_invoicede SET ctns=$ctns,netw=$net,grow=$gross WHERE id='$pid'";    
$update = mysqli_query($con,$sql) or die(mysqli_error($con));
$itid=mysqli_affected_rows($con);
if($itid>0){
$efr+=1;    
}else{
$efr+=0;     
}    
}
if($efr>0){
$act =remove_junk(escape('Invoice No: '.$invno));    
write_activity($aid,'INV','Invoice packing list has been Update',$act);    
save_msg('s','Data Successfully Saved!');    
}else{
save_msg('w','Data Fail to Saved!');    
}    
}else{
save_msg('i','No data found!!! Data Fail to Save');    
}    
echo "<script>window.location='opr_invoice.php'</script>"; 
}

function restore_qty($pino,$invid){
global $con;
$piid=get_fild_data('tbl_proinv',$id='','id',"pino='$pino'");    
$sql="SELECT itemid,qty FROM tbl_invoicede WHERE seid='$invid'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while($row = mysqli_fetch_array($query)){
$pid=$row['itemid'];
$qty=$row['qty'];
$sql="UPDATE tbl_proinvde SET rcvqty=rcvqty-'$qty' WHERE seid='$piid' AND itemid='$pid'";
mysqli_query($con,$sql)or die(mysqli_error($con));    
}    
}

if(isset($_POST['delinv'])){
$id=$_POST['delinv'];
if(delete_check('tbl_delivery','invno',$id)>0){
save_msg('w','Invoice Depend On Other Table!!!');
echo "<script>window.location='opr_invoice.php'</script>";
return;    
}
$name= get_fild_data('tbl_invoice',$id,'invno');
$pino = get_fild_data('tbl_invoice',$id,'pino');
restore_qty($pino,$id);    
$sql="DELETE FROM tbl_invoicede WHERE seid='$id'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));   
$sql="DELETE FROM tbl_invoice WHERE id='$id'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);    
if($efid>0){    
$act =remove_junk(escape('Invoice No: '.$name));    
write_activity($aid,'INV','Invoice No has been deleted',$act);        
save_msg('s','Invoice Successfully Deleted!!!');
}else{
save_msg('w','Invoice Fail to Delete!!!');   
}
echo "<script>window.location='opr_invoice.php'</script>";     
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Price List</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px; text-align:center;" rowspan="2">SN</th>   
<th rowspan="2">Date</th>
<th rowspan="2">Invoice No</th>
<th rowspan="2">P.I. No</th>
<th rowspan="2" style="text-align:right;">Total</th>
<th colspan="3" style="text-align:center;">Commission Details</th>    
<th style="width:50px; text-align:center;" rowspan="2">Action</th>    
</tr>
<tr>
<th style="text-align:right;">Total</th> 
<th style="text-align:right;">Received</th>
<th style="text-align:right;">Due</th>    
</tr>    
</thead>    
<tbody>
<?php
$sql="SELECT * FROM  tbl_invoice ORDER BY apdate,id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$id=$row['id'];
$invno=$row['invno'];
?>
<tr>
<td class="center"><?php echo count_id();?></td>
<td><?php echo date("d M Y", strtotime($row['apdate']));?></td>       
<td><?php echo $row['invno'];?></td>
<td><?php echo $row['pino'];?></td>    
<td style="text-align:right;"><?php echo numtolocal($row['total'],get_fild_data('tbl_currency',$row['curid'],'symbol'));?></td>
<td style="text-align:right;"><?php echo numtolocal($row['totcom'],get_fild_data('tbl_currency',$row['curid'],'symbol'));?></td>
<td style="text-align:right;"><?php echo numtolocal(get_invcash($invno,'R'),get_fild_data('tbl_currency',$row['curid'],'symbol'));?></td>    
<td style="text-align:right;"><?php echo numtolocal(($row['totcom']-get_invcash($invno,'R')),get_fild_data('tbl_currency',$row['curid'],'symbol'));?></td>    
<td nowrap="">
<a class="btn btn-flat bg-purple details-invoice" href="#" id="inv_<?php echo $row['id']; ?>"><i class="fa fa-eye cat-child"></i></a>
<?php if($row['packst']==0){ ?>
<a class="btn btn-flat bg-purple" href="#" onclick="paking_add(<?php echo $row['id']; ?>,this)"><i class="fa fa-gift"></i></a>    
<?php }else{?>
<a class="btn btn-flat bg-purple" href="#" onclick="paking_view(<?php echo $row['id']; ?>,this)"><i class="fa-eye-slash"></i></a> 
<?php } ?>    
<a class="btn btn-flat bg-purple" href="#" onclick="edit_item('ED_<?php echo $row['id'];?>')"><i class="fa fa-edit"></i></a> 
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
<form action="opr_invoice.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delinv" value="<?php echo $row['id']; ?>" />
</form>
<form action="" id="ED_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="editinv" value="<?php echo $row['id']; ?>" />
</form>    
</td>    
</tr>    
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<a href="opr_geninvo.php" class="btn btn-flat bg-purple">Add Invoice</a>
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'INV','A');}else{echo read_activity($aid,'INV','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable();
});
    
function edit_item(id) {
document.getElementById(id).submit(); 
}
    
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});

}
    
function paking_add(id,obj) {
$('.details_tr').remove();
$.ajax({
type: "POST",
url: "opr_pakingadd.php",
cache: false,
data: {packid: id},
timeout: 15000,
success: function (data){
var html='<tr class="details_tr" style="background: #ddd;display:none"><td colspan="9"><p class="text-right" style="color: #337ab7;text-decoration: none;padding-r: 10px;padding-right: 16px;cursor: pointer;"></p>'+data+'</td></tr>';
$(html).insertAfter($(obj).closest('tr'));
$('.details_tr').fadeIn('slow');
},
error: function (jqXHR, textStatus, errorThrown) {

}

});

}
function close_window(obj){
$('.details_tr').fadeOut('slow');
$(obj).closest('tr').remove();
}

$(document).on('change keyup blur','.package,.netweight,.grosweight',function(){
calculateTotal();    
});
    
function calculateTotal(){
    var totpac = 0;
    var totnet = 0;
    var totgro = 0;

$('.package').each(function(){
if($(this).val() != '' )totpac += parseFloat( $(this).val() );
});
$('#totpac').html(totpac.toFixed(2));
    
$('.netweight').each(function(){
if($(this).val() != '' )totnet += parseFloat( $(this).val() );
});
$('#totnet').html(totnet.toFixed(2));
    
$('.grosweight').each(function(){
if($(this).val() != '' )totgro += parseFloat( $(this).val() );
});
$('#totgro').html(totgro.toFixed(2));    
}
    
$(document).on('click', '.editpac', function(e) {
id_arr = $(this).attr('id');
id = id_arr.split("_");    
var ids = id[1];
document.getElementById('pack_'+ids).readOnly = false; 
document.getElementById('net_'+ids).readOnly = false; 
document.getElementById('gro_'+ids).readOnly = false;
e.preventDefault();    
});    
</script>    
<!-- /page script -->
</html>    