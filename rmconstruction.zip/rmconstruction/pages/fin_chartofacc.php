<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('29','views','R');     
$_SESSION['cuPages']='fin_chartofacc.php';   
$cuPage='fin_chartofacc.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='financ';
$menuh='Financials';
$phead='finchart';
$page='Chart of Account';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">    
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Trial Balanch</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<div class="row">    
<center>
<h3 class="page-title">CHART OF ACCOUNT</h3>
</center>
</div>
<div class="row">     
<table class="table table-bordered table-hover treetable" id="itemdata">
<thead>
<th width="50%">Account Head</th>
<th width="16.16%">Debit</th>
<th width="16.16%">Credit</th>
<th width="16.16%">Balance</th>    
</thead>
<tbody>
<?php
$totd=0; $totc=0; $totb=0;    
$sql="SELECT id,name FROM tbl_aclass ORDER BY id ASC";
$class=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowc=mysqli_fetch_array($class)){
$cdebit=get_goupval($rowc['id'],'D','N','G');
$ccredit=get_goupval($rowc['id'],'C','N','G');
$cnet=($cdebit-$ccredit);
$totd+=$cdebit; $totc+=$ccredit; $totb+=$cnet;     
?>
<tr data-tt-id="<?php echo $rowc['id'];?>" class="branch collapsed" style="background-color:#e0f7fa">
<td><b>&nbsp;<?php echo $rowc['name'];?></b></td>
<td style="text-align:right;"><?php echo number_format($cdebit,2);?></td>
<td style="text-align:right;"><?php echo number_format($ccredit,2);?></td>
<td style="text-align:right;"><?php echo number_format($cnet,2);?></td>    
</tr>
<?php    
$sql="SELECT id,name FROM tbl_acgroup WHERE clsid='".$rowc['id']."' ORDER BY id ASC";
$group=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowg=mysqli_fetch_array($group)){
$gdebit=get_goupval($rowg['id'],'D','N','G');
$gcredit=get_goupval($rowg['id'],'C','N','G');
$gnet=($gdebit-$gcredit); 
?>
<tr data-tt-id="<?php echo $rowc['id'].$rowg['id'];?>" data-tt-parent-id="<?php echo $rowc['id'];?>" class="branch collapsed" style="display: none;">
<td><b>&nbsp;&nbsp;<?php echo $rowg['name'];?></b></td>
<td style="text-align:right;"><?php echo number_format($gdebit,2);?></td>
<td style="text-align:right;"><?php echo number_format($gcredit,2);?></td>
<td style="text-align:right;"><?php echo number_format($gnet,2);?></td>
</tr>
<?php    
$sql="SELECT id,name FROM tbl_acsubgroup WHERE grid='".$rowg['id']."' ORDER BY id ASC";
$sgroup=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowsg=mysqli_fetch_array($sgroup)){
$sdebit=get_goupval($rowsg['id'],'D','N','S');
$scredit=get_goupval($rowsg['id'],'C','N','S');
$snet=($sdebit-$scredit);   
?>
<tr data-tt-id="<?php echo $rowc['id'].$rowg['id'].$rowsg['id'];?>" data-tt-parent-id="<?php echo $rowc['id'].$rowg['id'];?>" class="branch collapsed" style="display: none;">
<td><b>&nbsp;&nbsp;&nbsp;<?php echo $rowsg['name'];?></b></td>
<td style="text-align:right;"><?php echo number_format($sdebit,2);?></td>
<td style="text-align:right;"><?php echo number_format($scredit,2);?></td>
<td style="text-align:right;"><?php echo number_format($snet,2);?></td>
</tr>
<?php    
$sql="SELECT id,ledger FROM tbl_ledger WHERE sgrid='".$rowsg['id']."' ORDER BY id ASC";
$ledger=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowl=mysqli_fetch_array($ledger)){
$ldebit=get_ledgerval($rowl['id'],'D','N');
$lcredit=get_ledgerval($rowl['id'],'C','N');
$lnet=($ldebit-$lcredit);    
?>
<tr data-tt-id="<?php echo $rowc['id'].$rowg['id'].$rowsg['id'].$rowl['id'];?>" data-tt-parent-id="<?php echo $rowc['id'].$rowg['id'].$rowsg['id'];?>" class="branch collapsed" style="display: none;">
<td><b>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rowl['ledger'];?></b></td>
<td style="text-align:right;"><?php echo number_format($ldebit,2);?></td>
<td style="text-align:right;"><?php echo number_format($lcredit,2);?></td>
<td style="text-align:right;"><?php echo number_format($lnet,2);?></td>
</tr>    
<?php }}}} ?> 
<tr>
<td style="text-align:center;"><b>-Total-</b></td>
<td style="text-align:right;"><?php echo number_format($totd,2);?></td>
<td style="text-align:right;"><?php echo number_format($totb,2);?></td>
<td style="text-align:right;"><?php echo number_format($totc,2);?></td>    
</tr>    
</tbody>    
</table>
</div>    
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<a class="btn btn-flat bg-purple" id="expand">Expand All</a>
<a class="btn btn-flat bg-purple" id="colaps">Collapsed All</a>    
</div>
</div>    
</div>   
</div>
</div>    
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">Account Summery</h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<div class="col-md-12 table-responsive">
    
</div>    
</div>
</div>
</div>
</div>    
</div>
</div>    

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$("#itemdata").treetable({expandable: true});
    
$(document).on('click', '#expand', function(e) {
$("#itemdata").treetable('expandAll');  
});
    
$(document).on('click', '#colaps', function(e) {
$("#itemdata").treetable('collapseAll');  
});    
</script>    
<!-- /page script -->
</html>    