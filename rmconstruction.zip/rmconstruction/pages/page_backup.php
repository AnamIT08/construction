Page Purchase List
=======================
<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='pur_pinvlist.php';   
$cuPage='pur_pinvlist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='purchase';
$menuh='Purchase';
$phead='pinvlist';
$page='Purchase Invoice';
$print='print';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php

if(isset($_POST['tfdate'])){
$fdate=$_POST['tfdate'];	
}else{
$fdate=date('Y-m-d', strtotime('-15 days', time()));	
}
if(isset($_POST['ttdate'])){
$tdate=$_POST['ttdate'];	
}else{
$tdate=$today;	
}

function check_purinvdel($invno){
$flage=0;
global $con;

$sql="SELECT * FROM tbl_traproduct WHERE invno='$invno'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$unqid=$row['unqid'];
$sql="SELECT * FROM tbl_traproduct WHERE mods IN ('SE','TR','WR') AND unqid='$unqid'";
$que=mysqli_query($con,$sql)or die(mysqli_error($con));    
if($que->num_rows > 0) {
$flage=1;
break;    
}else{
$flage=0;    
}    
}    

if($flage>0){
return $flage;
exit;    
}    
    
$sql="SELECT * FROM tbl_trarecord WHERE invno!='$invno' AND refinv='$invno'";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}

if($flage>0){
return $flage;
exit;    
}
    
$sql="SELECT * FROM tbl_preturn WHERE refinv='$invno'";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}

if($flage>0){
return $flage;
exit;    
}       
}

if(isset($_POST['delpur'])){
$id=$_POST['delpur'];

$sql="SELECT * FROM tbl_purchase WHERE id='$id' LIMIT 1";
$dsales=mysqli_query($con,$sql) or die(mysqli_error($con));    
$dsel=mysqli_fetch_array($dsales);     

$invno=$dsel['invno'];    
    
if(check_purinvdel($invno)){
save_msg('w','Purchase Depend on others data!!!');
echo "<script>window.location='pur_pinvlist.php'</script>";
return;    
}

$sql="SELECT * FROM tbl_serial WHERE purinv='$invno'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
$sql="DELETE FROM tbl_serial WHERE purinv='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));    
}    
    
$sql="DELETE FROM tbl_trarecord WHERE invno='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));

$sql="DELETE FROM tbl_traproduct WHERE invno='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));    

$sql="DELETE FROM tbl_stock WHERE invno='$invno'";    
mysqli_query($con,$sql)or die(mysqli_error($con));
    
$sql="DELETE FROM tbl_purchase WHERE id='$id'";
$fdel=mysqli_query($con,$sql)or die(mysqli_error($con));    
$efid=mysqli_affected_rows($con);
if($efid>0){
$act =remove_junk(escape('Purchase invoice: '.$invno));    
write_activity($aid,'PUR','Purchase has been deleted',$act);        
save_msg('s','Purchase Successfully Deleted!!!');
}else{
save_msg('w','Purchase Fail to Delete!!!');    
}
echo "<script>window.location='pur_pinvlist.php'</script>";    
}
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-9">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Purchase Record';}else{echo 'ক্রয়ের তালিকা';}?></h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px; text-align:center;">SN</th>   
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Date';}else{echo 'তারিখ';}?></th>
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Supplier';}else{echo 'সরবরাহকারী';}?></th>
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Invoice';}else{echo 'রসিদ';}?></th>
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Total';}else{echo 'মোট';}?></th>    
<!--<th>Paid</th>
<th>Due</th>-->
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Note';}else{echo 'মন্তব্য';}?></th>    
<!--<th>Status</th>-->    
<th style="width:40px; text-align:center;"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Action';}else{echo 'অ্যাকশন';}?></th>    
</tr>
</thead>    
<tbody>
<?php
$sql="SELECT * FROM tbl_purchase WHERE apdate BETWEEN '$fdate' AND '$tdate' AND brid='$brid' ORDER BY apdate DESC,id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$invno=$row['invno'];
$due=($row['total']-($row['adamo']+get_invcash($invno,'P')));    
$rcash=get_reamo($invno,'tbl_preturn');
if($due>$rcash){
$adj=$rcash;    
}else{
$adj=$due;    
}    
$cashst=($row['total']-($row['adamo']+get_invcash($invno,'P')+$adj));    
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td><?php echo date("d M Y", strtotime($row['apdate']));?></td>      
<td>
<?php 
if($row['type']=='SU'){
echo show_addres(get_fild_data('tbl_supplier',$row['supid'],'name'),get_fild_data('tbl_supplier',$row['supid'],'cnumber'),get_fild_data('tbl_supplier',$row['supid'],'cemail'),'',get_fild_data('tbl_supplier',$row['supid'],'code'),$row['type'].'_'.$row['supid']);
}else{
echo show_addres(get_fild_data('tbl_customer',$row['supid'],'name'),get_fild_data('tbl_customer',$row['supid'],'cnumber'),get_fild_data('tbl_customer',$row['supid'],'cemail'),'',get_fild_data('tbl_customer',$row['supid'],'code'),$row['type'].'_'.$row['supid']);
}
?></td>
<td><?php echo $row['invno'];?></td>    
<td><?php echo numtolocal($row['total'],get_fild_data('tbl_currency','1','symbol'));?></td>
<!--<td style="text-align:right;"><?php //echo numtolocal(($row['adamo']+get_invcash($invno,'P')),get_fild_data('tbl_currency','1','symbol'));?><?php //if($adj>0){echo '<br>+'.numtolocal($adj,'');}?></td>
<td style="text-align:right;"><?php //echo numtolocal(($row['total']-($row['adamo']+get_invcash($invno,'P')+$adj)),get_fild_data('tbl_currency','1','symbol'));?></td>-->
<td><?php echo $row['note'];?></td>
<!--<td class="text-center">
<?php //if($cashst<=0){ ?>
<span class="label label-success label-block">Paid</span>
<?php //}elseif($cashst>0 && $cashst<$row['total']){?>
<span class="label label-info label-block">Partially Paid</span>
<?php //}elseif($cashst>=$row['total']){?>
<span class="label label-danger label-block">Due</span>    
<?php //} ?>   
</td>-->    
<td nowrap="">
<a class="btn btn-flat bg-purple details-invoice" href="#" id="inv_<?php echo $row['id'].'_'.$row['supid']; ?>"><i class="fa fa-eye cat-child"></i></a>
<?php if(!check_purinvdel($invno)){ ?>
<?php if(substr($row['refinv'],0,3)=='POR'){?>        
<?php }else{ ?>
<a class="btn btn-flat bg-purple" href="#" onclick="take_action('ED_<?php echo $row['id'];?>')"><i class="fa fa-edit"></i></a>    
<?php }} ?>    
<a class="btn btn-flat bg-purple" href="#" onclick="take_action('RE_<?php echo $row['id'];?>')"><i class="fa fa-reply"></i></a>
<?php if(!check_purinvdel($invno)){ ?>     
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
<?php } ?>     
<?php if(!check_purinvdel($invno)){ ?>     
<form action="pur_pinvedit.php" id="ED_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="pured" value="<?php echo $row['invno']; ?>" />
</form>
<?php } ?>    
<form action="pur_preturncteate.php" id="RE_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="puret" value="<?php echo $row['id']; ?>" />
</form>    
<form action="pur_pinvlist.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delpur" value="<?php echo $row['id']; ?>" />
</form>
</td>    
</tr>    
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<a href="pur_pinvcteate.php" class="btn btn-flat bg-purple"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Create Purchase';}else{echo 'ক্রয় করুন';}?></a>
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<!-- tools box -->
<div class="pull-right box-tools">
<a class=" pull-right" data-widget="collapse" style="margin-right: 5px;">
<i class="fa fa-minus"></i></a>
</div>
<!-- /. tools -->
<i class="fa fa-filter" aria-hidden="true"></i>    
<h3 class="box-title">Date Range Filter</h3>
</div>
<!-- /.box-header -->
<div class="box-body" >

<form action="#" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">    
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">    

<div class="row">
<div class="col-md-6">
<div class="form-group">
<label>Date From</label>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
<input type="text" name="tfdate" value="<?php if(isset($_POST['tfdate'])){echo $_POST['tfdate']; }else{echo date('Y-m-d', strtotime('-15 days', time()));} ?>"  class="form-control" placeholder="Date From" readonly="true">
</div>
</div>        
</div>
<div class="col-md-6">
<div class="form-group" >
<label>Date To</label>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
<input type="text" name="ttdate" value="<?php if(isset($_POST['ttdate'])){echo $_POST['ttdate']; }else{echo $today;} ?>"  class="form-control" placeholder="Date To" readonly="true">
</div>    
</div>    
</div>    
</div>     
    
</div>   
<div class="col-md-1"></div>    
</div>    
</div>    
</div>
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="date_filter" id="submit" class="btn btn-flat bg-purple btn-sm " value="Submit"/>
</div> 
</div>     
</form>    
    
</div>
</div>
</div>

</div>        
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'PUR','A');}else{echo read_activity($aid,'PUR','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->
<?php include('../layout/print.php'); ?>
<?php include('../layout/details.php'); ?>    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
});
    
function take_action(id) {
document.getElementById(id).submit(); 
}
    
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});
}
    
$(".details-invoice").click(function (e) {
id_arr = $(this).attr('id');
id = id_arr.split("_");

$.ajax({
url: 'pur_viewlist.php',
method: "POST",
data:{ 
invid: id[1],supid: id[2]
},
success: function(data){
$('#listitem').html(data);
pagelist();    
}
});    
    
$.ajax({
url: 'pur_viewinv.php',
method: "POST",
data:{ 
print: id[1]
},
success: function(data){
$('#invhold').html(data);
sethead();    
}
});
    
$('.right-side').toggle('slide', { direction: 'right' }, 300);    

e.preventDefault();
});

$(".detailsrec").click(function (e) {
id_arr = $(this).attr('id');
id = id_arr.split("_");
if(id[1]==0)return;

$.ajax({
url: 'axe_details.php',
method: "POST",
data:{ 
cusdet: 1,cusid: id[1],type:id[0]
},
success: function(data){
$('#profile').html(data);    
}
});    
    
$.ajax({
url: 'axe_details.php',
method: "POST",
data:{ 
tradet: 1,cusid: id[1],type:id[0]
},
success: function(data){
$('#details').html(data);   
}
});    
    
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);    
e.preventDefault();    
});    
    
$(document).on('click', '#closedet', function() {
$('#profile').html('');
$('#details').html('');    
if($('.right-side-details').is(':visible')) {
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);
}   
});    
    
$(document).on('click', '#closepop', function() {
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }   
});    

$('#listitem').on('click','li', function(){
   $(this).addClass('active').siblings().removeClass('active');
});
    
$(document).on('click', '.invpiv', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
$.ajax({
url: 'pur_viewinv.php',
method: "POST",
data:{ 
print: ids
},
beforeSend: function() {
//$("#invhold").fadeOut('slow');
},    
success: function(data){    
$('#invhold').html(data);
$("#invhold").fadeIn('slow');    
sethead();    
}
});     
});    
</script>    
<!-- /page script -->
</html>

Page Sales List
===============
<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='sel_sinvlist.php';   
$cuPage='sel_sinvlist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];
$uty=$_SESSION['utype'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='sales';
$menuh='Sales';
$phead='sinvlist';
$page='Sales Invoice';
$print='print';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php

if(isset($_POST['tfdate'])){
$fdate=$_POST['tfdate'];	
}else{
$fdate=date('Y-m-d', strtotime('-15 days', time()));	
}
if(isset($_POST['ttdate'])){
$tdate=$_POST['ttdate'];	
}else{
$tdate=$today;	
}

function check_desales($invno){
$flage=0;
global $con;
$sql="SELECT * FROM tbl_trarecord WHERE invno!='$invno' AND refinv='$invno'";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}

if($flage>0){
return $flage;
exit;    
}    

$sql="SELECT * FROM tbl_pdlirecord WHERE refinv='$invno'";    
$rquery=mysqli_query($con,$sql)or die(mysqli_error($con));
if($rquery->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}

if($flage>0){
return $flage;
exit;    
}    
    
$sql="SELECT * FROM tbl_waranty WHERE refinv='$invno'";    
$rquery=mysqli_query($con,$sql)or die(mysqli_error($con));
if($rquery->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}

if($flage>0){
return $flage;
exit;    
}    
    
$sql="SELECT * FROM tbl_sreturn WHERE refinv='$invno'";    
$rquery=mysqli_query($con,$sql)or die(mysqli_error($con));
if($rquery->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}

return $flage;    
}

if(isset($_POST['delsel'])){
$id=$_POST['delsel'];

$sql="SELECT * FROM tbl_sales WHERE id='$id' LIMIT 1";
$dsales=mysqli_query($con,$sql) or die(mysqli_error($con));    
$dsel=mysqli_fetch_array($dsales);     

$invno=$dsel['invno'];    
    
if(check_desales($invno)){
save_msg('w','Sales Depend on others data!!!');
echo "<script>window.location='sel_sinvlist.php'</script>";
return;    
}    

$sql="SELECT * FROM tbl_serialsale WHERE invno='$invno'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
while ($row=mysqli_fetch_array($query)){
$serial=$row['serial'];    
$sql="UPDATE tbl_serial SET status='0' WHERE serial='$serial'";
mysqli_query($con,$sql)or die(mysqli_error($con));    
}
$sql="DELETE FROM tbl_serialsale WHERE invno='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));    
}    
    
$sql="DELETE FROM tbl_trarecord WHERE invno='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));

$sql="DELETE FROM tbl_traproduct WHERE invno='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));    

$sql="DELETE FROM tbl_sales WHERE id='$id'";
$fdel=mysqli_query($con,$sql)or die(mysqli_error($con));    
$efid=mysqli_affected_rows($con);
if($efid>0){
$act =remove_junk(escape('Sales invoice: '.$invno));    
write_activity($aid,'SEL','Sales has been deleted',$act);        
save_msg('s','Sales Successfully Deleted!!!');
}else{
save_msg('s','Sales Fail to Delete!!!');    
}
echo "<script>window.location='sel_sinvlist.php'</script>";    
}
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-9">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Sales Record</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px; text-align:center;">SN</th>   
<th>Date</th>
<th>Customer</th>
<th>Invoice</th>
<th>Total</th>    
<!--<th>Received</th>
<th>Due</th>-->
<th>Note</th>    
<!--<th>Status</th>-->    
<th style="width:40px; text-align:center;">Action</th>    
</tr>
</thead>    
<tbody>
<?php //if($uty==1){ ?>
    
<?php //}else{ ?>    
<?php
$sql="SELECT * FROM tbl_sales WHERE apdate BETWEEN '$fdate' AND '$tdate' AND brid='$brid' ORDER BY apdate DESC,id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$invno=$row['invno'];
$due=($row['total']-($row['adamo']+get_invcash($invno,'S')));    
$rcash=get_reamo($invno,'tbl_preturn');
if($due>$rcash){
$adj=$rcash;    
}else{
$adj=$due;    
}     
$cashst=($row['total']-($row['adamo']+get_invcash($invno,'S')+$adj));    
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td><?php echo date("d M Y", strtotime($row['apdate']));?></td>      
<td><?php if($row['type']=='SU'){
echo show_addres(get_fild_data('tbl_supplier',$row['cusid'],'name'),get_fild_data('tbl_supplier',$row['cusid'],'cnumber'),get_fild_data('tbl_supplier',$row['cusid'],'cemail'),'',get_fild_data('tbl_supplier',$row['cusid'],'code'),$row['type'].'_'.$row['cusid']);    
}else{
if($row['cusid']==0){
if($row['name']!=''){echo show_addres($row['name'],$row['mobile'],'','','',$row['type'].'_'.$row['cusid']);}else{echo show_addres('Walk-in Customer','','','','',$row['type'].'_'.$row['cusid']);}        
}else{
echo show_addres(get_fild_data('tbl_customer',$row['cusid'],'name'),get_fild_data('tbl_customer',$row['cusid'],'cnumber'),get_fild_data('tbl_customer',$row['cusid'],'cemail'),'',get_fild_data('tbl_customer',$row['cusid'],'code'),$row['type'].'_'.$row['cusid']);    
}}?>  
</td>
<td><?php echo $row['invno'];?></td>    
<td><?php echo numtolocal($row['total'],get_fild_data('tbl_currency','1','symbol'));?></td>
<!--<td style="text-align:right;"><?php //echo numtolocal(($row['adamo']+get_invcash($invno,'S')),get_fild_data('tbl_currency','1','symbol'));?><?php //if($adj>0){echo '<br>+'.numtolocal($adj,'');}?></td>
<td style="text-align:right;"><?php //echo numtolocal(($row['total']-($row['adamo']+get_invcash($invno,'S')+$adj)),get_fild_data('tbl_currency','1','symbol'));?></td>-->
<td><?php echo $row['note'];?></td>
<!--<td class="text-center">
<?php //if($cashst<=0){ ?>
<span class="label label-success label-block">Paid</span>
<?php //}elseif($cashst>0 && $cashst<$row['total']){?>
<span class="label label-info label-block">Partially Paid</span>
<?php //}elseif($cashst>=$row['total']){?>
<span class="label label-danger label-block">Due</span>    
<?php //} ?>   
</td>-->    
<td nowrap="">
<a class="btn btn-flat bg-purple details-invoice" href="#" id="inv_<?php echo $row['id'].'_'.$row['cusid'].'_'.$row['type']; ?>"><i class="fa fa-eye cat-child"></i></a>
<?php if(!check_desales($invno)){ ?>   
<a class="btn btn-flat bg-purple" href="#"><i class="fa fa-edit" onclick="take_action('ED_<?php echo $row['id'];?>')"></i></a>
<?php } ?>    
<a class="btn btn-flat bg-purple" href="#" onclick="take_action('RE_<?php echo $row['id'];?>')"><i class="fa fa-reply"></i></a>
<?php if(!check_desales($invno)){ ?>    
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
<?php } ?>     
<form action="sel_sreturncteate.php" id="RE_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="selret" value="<?php echo $row['id']; ?>" />
</form>
<?php if(!check_desales($invno)){ ?>      
<form action="sel_sinvlist.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delsel" value="<?php echo $row['id']; ?>" />
</form>
<form action="sel_sinvedit.php" id="ED_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="editsel" value="<?php echo $row['invno']; ?>" />
</form>    
<?php } ?>    
</td>    
</tr>    
<?php } ?>
<?php //} ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<a href="sel_sinvcteate.php" class="btn btn-flat bg-purple">Create Sales</a>
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<!-- tools box -->
<div class="pull-right box-tools">
<a class=" pull-right" data-widget="collapse" style="margin-right: 5px;">
<i class="fa fa-minus"></i></a>
</div>
<!-- /. tools -->
<i class="fa fa-filter" aria-hidden="true"></i>    
<h3 class="box-title">Date Range Filter</h3>
</div>
<!-- /.box-header -->
<div class="box-body" >

<form action="#" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">    
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">    

<div class="row">
<div class="col-md-6">
<div class="form-group">
<label>Date From</label>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
<input type="text" name="tfdate" id="tfdate" value="<?php if(isset($_POST['tfdate'])){echo $_POST['tfdate']; }else{echo date('Y-m-d', strtotime('-15 days', time()));} ?>"  class="form-control" placeholder="Date From" readonly="true">
</div>
</div>        
</div>
<div class="col-md-6">
<div class="form-group" >
<label>Date To</label>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
<input type="text" name="ttdate" id="tdate" value="<?php if(isset($_POST['ttdate'])){echo $_POST['ttdate']; }else{echo $today;} ?>"  class="form-control" placeholder="Date To" readonly="true">
</div>    
</div>    
</div>    
</div>     
    
</div>   
<div class="col-md-1"></div>    
</div>    
</div>    
</div>
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-2" >
<input type="button" id="csvexp" class="btn btn-flat bg-purple btn-sm " value="Exp->CSV"/>    
</div>       
<div class="col-md-10 text-right" >    
<input type="submit" name="date_filter" id="submit" class="btn btn-flat bg-purple btn-sm " value="Submit"/>    
</div> 
</div>     
</form>    
    
</div>
</div>
</div>

</div>    
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'SEL','A');}else{echo read_activity($aid,'SEL','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>    

<?php include('../layout/quick.php');?>
<div style="display: none;">
<table id="expcsv"></table>
</div>    
</section>
<!-- /.main content -->
<?php include('../layout/print.php'); ?>
<?php include('../layout/details.php'); ?>    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
});
    
function take_action(id) {
document.getElementById(id).submit(); 
}
    
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});
}

$(document).on('click','.details-invoice',function(e) {      
id_arr = $(this).attr('id');
id = id_arr.split("_");

$.ajax({
url: 'sel_viewlist.php',
method: "POST",
data:{ 
invid: id[1],cusid: id[2],type:id[3]
},
success: function(data){
$('#listitem').html(data);
pagelist();    
}
});    
    
$.ajax({
url: 'sel_viewinv.php',
method: "POST",
data:{ 
print: id[1]
},
success: function(data){
$('#invhold').html(data);
sethead();    
}
});
    
$('.right-side').toggle('slide', { direction: 'right' }, 300);    

e.preventDefault();
});

$(document).on('click', '#closepop', function() {
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }   
});    

$(document).on('click', '.detailsrec', function(e) { 
id_arr = $(this).attr('id');
id = id_arr.split("_");
if(id[1]==0)return;

$.ajax({
url: 'axe_details.php',
method: "POST",
data:{ 
cusdet: 1,cusid: id[1],type:id[0]
},
success: function(data){
$('#profile').html(data);    
}
});    
    
$.ajax({
url: 'axe_details.php',
method: "POST",
data:{ 
tradet: 1,cusid: id[1],type:id[0]
},
success: function(data){
$('#details').html(data);   
}
});    
    
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);   
e.preventDefault();    
});
    
$(document).on('click', '#closedet', function() {
$('#profile').html('');
$('#details').html('');    
if($('.right-side-details').is(':visible')) {
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);
}    
});    
    
$('#listitem').on('click','li', function(){
   $(this).addClass('active').siblings().removeClass('active');
});
    
$(document).on('click', '.invpiv', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
$.ajax({
url: 'sel_viewinv.php',
method: "POST",
data:{ 
print: ids
},
beforeSend: function() {
//$("#invhold").fadeOut('slow');
},    
success: function(data){    
$('#invhold').html(data);
$("#invhold").fadeIn('slow');    
sethead();    
}
});     
});
    
$(document).on('click', '#csvexp', function() {
var tfdate=$('#tfdate').val();
var tdate=$('#tdate').val();	
$.ajax({
url: 'sel_cart.php',
method: "POST",
data:{ 
expcsv: 1, fdate: tfdate, tdate: tdate
},
success: function(data){
$('#expcsv').html(data);
const dataTable = document.getElementById("expcsv");
const exporter = new TableCSVExporter(dataTable);
const csvOutput = exporter.convertToCSV();
const csvBlob = new Blob([csvOutput], { type: "text/csv" });
const blobUrl = URL.createObjectURL(csvBlob);
const anchorElement = document.createElement("a");

anchorElement.href = blobUrl;
anchorElement.download = "Axes_sold_invoice.csv";
anchorElement.click();

setTimeout(() => {
URL.revokeObjectURL(blobUrl);
}, 500);
}
});
$('#expcsv').html('');	
});
     
class TableCSVExporter {
constructor (table, includeHeaders = true) {
this.table = table;
this.rows = Array.from(table.querySelectorAll("tr"));

if (!includeHeaders && this.rows[0].querySelectorAll("th").length) {
this.rows.shift();
}
}

convertToCSV () {
const lines = [];
const numCols = this._findLongestRowLength();

for (const row of this.rows) {
let line = "";

for (let i = 0; i < numCols; i++) {
if (row.children[i] !== undefined) {
line += TableCSVExporter.parseCell(row.children[i]);
}

line += (i !== (numCols - 1)) ? "," : "";
}

lines.push(line);
}

return lines.join("\n");
}

_findLongestRowLength () {
return this.rows.reduce((l, row) => row.childElementCount > l ? row.childElementCount : l, 0);
}

static parseCell (tableCell) {
let parsedValue = tableCell.textContent;

// Replace all double quotes with two double quotes
parsedValue = parsedValue.replace(/"/g, `""`);

// If value contains comma, new-line or double-quote, enclose in double quotes
parsedValue = /[",\n]/.test(parsedValue) ? `"${parsedValue}"` : parsedValue;

return parsedValue;
}
}    
</script>    
<!-- /page script -->
</html>    