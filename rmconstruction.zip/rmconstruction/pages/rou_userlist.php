<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('45','views','R');     
$_SESSION['cuPages']='rou_userlist.php';   
$cuPage='rou_userlist.php';    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='user';
$menuh='User &amp; Role';
$phead='userlist';
$page='All User';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include ('../inc/imgpro.php');
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['delusr'])){
$id=$_POST['delusr'];
/*if(delete_check('tbl_category','pid',$id)>0 || delete_check('tbl_subcat','pid',$id)>0 || delete_check('tbl_item','prid',$id)>0){
save_msg('w','Paren Depend On Other Table!!!');
echo "<script>window.location='rou_userlist.php'</script>";
return;    
}*/
$name= get_fild_data('tbl_user',$id,'name');
get_destroy($id,'U');    
$sql="DELETE FROM tbl_user WHERE id='$id'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query){    
$act =remove_junk(escape('User name: '.$name));    
write_activity($aid,'USR','User has been deleted',$act);    
}    
save_msg('s','User Successfully Deleted!!!');
echo "<script>window.location='rou_userlist.php'</script>";
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">User List</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px;"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'SN';}else{echo 'নং';}?></th>   
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Image';}else{echo 'ছবি';}?></th>
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Name';}else{echo 'নাম';}?></th>
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Email';}else{echo 'ইমেল';}?></th>
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Access';}else{echo 'ভূমিকা';}?></th>
<th><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Status';}else{echo 'অবস্থা';}?></th>    
<th style="width:40px; text-align:center;"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Action';}else{echo 'কার্যকারিতা';}?></th>    
</tr>
</thead>    
<tbody>
<?php
$sql="SELECT * FROM tbl_user ORDER BY id ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$id=$row['id'];    
?>
<tr>
<td class="center"><?php echo count_id();?></td>
<td><img class="user-img img-circle" src="../img/user/<?php if(empty($row['image'])) {echo "duser.jpg";}else{echo $row['image'];} ?>" height="45px" width="45px"></td>    
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo $row['name'];}else{echo $row['bname'];}?></td>
<td><?php echo $row['email'];?></td>
<td><?php if(get_fild_data('tbl_setting','1','sval')==0){echo get_fild_data('tbl_usergroup',$row['acess'],'name');}else{echo get_fild_data('tbl_usergroup',$row['acess'],'bname');}?></td>
<td><?php if($row['status']==1){if(get_fild_data('tbl_setting','1','sval')==0){echo '<span class="label label-primary">Active</span>';}else{echo '<span class="label label-primary">সক্রিয়</span>';}}else{if(get_fild_data('tbl_setting','1','sval')==0){echo '<span class="label label-danger">De-Active</span>';}else{echo '<span class="label label-danger">নিসক্রিয়</span>';}}?></td>   
<td nowrap="">
<?php if($row['id']=='1'){?>
<?php if($uty=='1'){?>    
<a class="btn btn-flat bg-purple" href="#" onclick="edit_item('ED_<?php echo $row['id'];?>')"><i class="fa fa-edit"></i></a>    
<?php } ?>
<a class="btn btn-flat bg-purple chpass" href="#" id="<?php echo $row['id'];?>')"><i class="fa fa-key"></i></a> <?php }else{ ?>
<a class="btn btn-flat bg-purple" href="#" onclick="edit_item('ED_<?php echo $row['id'];?>')"><i class="fa fa-edit"></i></a>    
<?php if($row['utype']!='1'){ ?>
<a class="btn btn-flat bg-purple chpass" href="#" id="<?php echo $row['id'];?>')"><i class="fa fa-key"></i></a> <?php } ?>     
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>   
<?php } ?>    
<form action="rou_userlist.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delusr" value="<?php echo $row['id']; ?>" />
</form>
<form action="rou_useredit.php" id="ED_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="editusr" value="<?php echo $row['id']; ?>" />
</form>    
</td>    
</tr>    
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<?php if(get_limitpermision('tbl_user')<get_fild_data('tbl_limitset','1','userlim')){?>    
<a href="rou_usercreate.php" class="btn btn-flat bg-purple"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Create User';}else{echo 'ব্যবহারকারী যোগ করুন';}?></a>
<?php } ?>    
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'USR','A');}else{echo read_activity($aid,'USR','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->
<?php include('../layout/rside.php'); ?>    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
    $('#datarec').DataTable({stateSave: true});
} );

function edit_item(id) {
document.getElementById(id).submit(); 
}    
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});

}
    
$(document).on('click', '.chpass', function() {
$('#addsitem').html('');
var id=$(this).attr('id');    
$.ajax({
url: "axe_chpass.php",
method: "POST",
data:{chpass:id},
success: function(data){
$('#addsitem').html(data);
$('.right-side-add').toggle('slide', { direction: 'right' }, 300);     
}
})       
});

$(document).on('click', function(e){    
if (!$(e.target).is(".right-side-add, .side-cont") && !$(e.target).parents(".right-side-add").length && $('.right-side-add').hasClass('open-right-add')) {
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');
}    
});    
    
$(document).on('click', '#closepop', function() {    
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
});
    
$(document).on('click', '#chngpass', function() {   
var cash_data = $('.changepass input');
toastr.options = {'positionClass': 'toast-top-center'};    
if(!chek_error()){   
return;   
}

$.ajax({
url: "axe_chpass.php",
data: cash_data,
type: 'post',
dataType: 'json',    
beforeSend: function () {
chek_error();    
},    
success: function(data){
if(data.status === "success"){
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');   
toastr.success(data.message);    
}else{
toastr.error(data.message);    
}         
}
})     
    
});
</script>    
<!-- /page script -->
</html>    