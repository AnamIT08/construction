<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
$body='';
$foot='';
$buton='';
$s=0;
$totqty=0;

if(isset($_SESSION['axes_badstclaim'])){
if(is_array($_SESSION['axes_badstclaim'])){
$max=count($_SESSION['axes_badstclaim']);
for($i=($max-1);$i>=0;$i=$i-1){
$id=$_SESSION['axes_badstclaim'][$i]['id'];
$pid=$_SESSION['axes_badstclaim'][$i]['pid'];    
$name=$_SESSION['axes_badstclaim'][$i]['name'];
$serial=$_SESSION['axes_badstclaim'][$i]['serial'];
$col=$_SESSION['axes_badstclaim'][$i]['colid'];
if($col==0){$col='';}    
$siz=$_SESSION['axes_badstclaim'][$i]['sizid'];
if($siz==0){$siz='';}      

if($col=='' && $siz==''){
$name=$name;    
}elseif($col!='' && $siz==''){
$name= $name.' '.get_fild_data('tbl_color',$col,'name');    
}elseif($col=='' && $siz!=''){
$name= $name.' '.get_fild_data('tbl_size',$siz,'sval');    
}elseif($col!='' && $siz!=''){    
$name= $name.' '.get_fild_data('tbl_color',$col,'name').' '.get_fild_data('tbl_size',$siz,'sval');    
}    
$s+=1;
$totqty+=1;    

$body.='<tr>';
$body.='<td class="text-center" width="30px">'.$s.'</td>';    
$body.='<td width="326px">'.$name.'</td>';
$body.='<td width="144px">'.$serial.'</td>';
$body.='<td class="text-center" width="25px"><a id="'.$i.'" class="remove"><span style="cursor: pointer;" class="fa fa-times"></span></a></td>';    
$body.='</tr>';    
}    

$foot.='<tr>';
$foot.='<td width="30px"></td>';
$foot.='<td width="326px"></td>';
$foot.='<td width="144px"></td>';
$foot.='<td width="25px"></td>';
$foot.='</tr>';    
$foot.='<tr>';
$foot.='<td colspan="2" class="text-center" width="356px"><strong>-Total-</strong></td>';
$foot.='<td width="169px" colspan="2"><strong>'.$totqty.'</strong></td>';
$foot.='</tr>';	
   
}else{
$body.='<tr>';
$body.='<td colspan="4" class="text-center">There are no Bad Stock Item!</td>';
$body.='</tr>'; 
} 
}else{
$body.='<tr>';
$body.='<td colspan="4" class="text-center">There are no Bad Stock  Item!</td>';
$body.='</tr>';
}

if(isset($_SESSION['axes_badstclaim'])){
$buton.='<div class="col-md-6">';
$buton.='<input type="button" id="emptycart" class="btn btn-flat bg-red btn-sm" value="Empty"/></div>';
$buton.='<div class="col-md-6 text-right">';   
$buton.='<input type="button" id="save_claim" class="btn btn-flat bg-purple btn-sm" value="Claim"/>'; 
$buton.='</div>';
}

if(isset($_POST['body'])){
echo $body;
}elseif(isset($_POST['foot'])){
echo $foot;
}elseif(isset($_POST['buton'])){
echo $buton;    
}
exit; 