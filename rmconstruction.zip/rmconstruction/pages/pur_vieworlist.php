<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$_SESSION['cuPages']='pur_porderlist.php';   
$cuPage='pur_porderlist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$today = strftime("%Y-%m-%d", time());
?>
<?php 
if(isset($_POST['invid'])){
$piid=$_POST['invid'];
$supid=$_POST['supid'];    
$sql="SELECT * FROM tbl_purorder WHERE supid='$supid' ORDER BY apdate DESC,id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$invno=$row['invno'];    
$cashst=($row['total']-get_invcash($invno,'P'));    
?>
<li <?php if($row['id']==$piid){echo 'class="invpiv active"';}else{echo 'class="invpiv"';}?> id="pi_<?php echo $row['id'];?>"><p><strong class="pino"><?php echo $row['invno'];?></strong><br><strong class="name"><?php if($row['type']=='SU'){echo get_fild_data('tbl_supplier',$row['supid'],'name');}else{echo get_fild_data('tbl_customer',$row['supid'],'name');}?></strong><br><strong><?php echo date("d M Y", strtotime($row['apdate']));?></strong></p>
<div class="sname" style="margin-top: -52px;float: right; position: relative;top: 6px;"><strong><?php echo 'T: '.numtolocal($row['total'],get_fild_data('tbl_currency','1','symbol')); ?></strong><br><strong><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Approve: ';}else{echo 'অনুমোদিত: ';}?><?php if($row['ap']=='Y'){if(get_fild_data('tbl_setting','1','sval')==0){echo 'Yes';}else{echo 'হ্যাঁ';}}else{if($today<=$row['expdate']){if(get_fild_data('tbl_setting','1','sval')==0){echo 'No';}else{echo ' না';}}else{if(get_fild_data('tbl_setting','1','sval')==0){echo 'ST: Expired';}else{echo 'মেয়াদ উত্তীর্ণ';}}} ?></strong></div>
</li>
<?php }} ?>