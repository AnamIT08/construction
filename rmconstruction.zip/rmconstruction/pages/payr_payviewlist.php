<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$_SESSION['cuPages']='payr_payslip.php';   
$cuPage='payr_payslip.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
?>
<?php 
if(isset($_POST['invid'])){
$piid=$_POST['invid'];
$supid=$_POST['supid'];    
$sql="SELECT * FROM tbl_salarysheet WHERE empid='$supid' ORDER BY apdate DESC,id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$invno=$row['payslip'];        
?>
<li <?php if($row['id']==$piid){echo 'class="invpiv active"';}else{echo 'class="invpiv"';}?> id="pi_<?php echo $row['id'];?>"><p><strong class="pino"><?php echo $row['payslip'];?></strong><br><strong class="name"><?php echo get_fild_data('tbl_employe',$row['empid'],'name');?></strong></p>
<div class="sname" style="margin-top: -52px;float: right; position: relative;top: 6px;"><strong><?php echo 'T: '.numtolocal($row['tsalary'],get_fild_data('tbl_currency','1','symbol')); ?></strong><br><strong><?php echo date("d M Y", strtotime($row['apdate']));?></strong></div>
</li>
<?php }} ?>