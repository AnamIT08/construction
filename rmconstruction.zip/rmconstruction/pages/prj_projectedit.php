<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='prj_projectlist.php';   
$cuPage='prj_projectlist.php';    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='project';
$menuh='Manage Project';
$phead='prjlist';
$page='Project Record Edit';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php 
if(isset($_POST['update_project'])){
	$edid = remove_junk(escape($_POST['editid']));
    $prjid = strtoupper(remove_junk(escape($_POST['prjid'])));
    $prjname = remove_junk(escape($_POST['prjname']));
    $pgid = remove_junk(escape($_POST['pgid']));
    $psgid = remove_junk(escape($_POST['psgid']));
    
    $status = remove_junk(escape($_POST['status']));

    $cname = remove_junk(escape($_POST['cname']));
    if($cname==''){$cname='NULL';}else{$cname="'".$cname."'";}
    $cnumber = remove_junk(escape($_POST['cnumber']));
    if($cnumber==''){$cnumber='NULL';}else{$cnumber="'".$cnumber."'";}
    $prjamo = remove_junk(escape($_POST['prjamo']));
    if($prjamo==''){$prjamo='0';}else{$prjamo="'".$prjamo."'";}
    $expamo = remove_junk(escape($_POST['expamo']));
    if($expamo==''){$expamo='0';}else{$expamo="'".$expamo."'";}
    $details = remove_junk(escape($_POST['details']));
    if($details==''){$details='NULL';}else{$details="'".$details."'";}
    $address = remove_junk(escape($_POST['address']));
    if($address==''){$address='NULL';}else{$address="'".$address."'";}
    
    $coid = remove_junk(escape($_POST['coid']));
    if($coid==''){$coid='NULL';}else{$coid="'".$coid."'";}
    $coamo = remove_junk(escape($_POST['coamo']));
    if($coamo==''){$coamo='0';}else{$coamo="'".$coamo."'";}
    
    $client = remove_junk(escape($_POST['client']));
    if($client==''){$client='NULL';}else{$client="'".$client."'";}
    
	if(isset($_POST['prjid'])){
    $sql="SELECT * FROM tbl_project WHERE name = '$prjid' AND id!='$edid'";           
	$ducode = mysqli_query($con,$sql);
	}
	
	if($ducode->num_rows > 0) {
	save_msg('i','Prject ID alrady exists! Plz try another');
	echo "<script>window.location='prj_projectlist.php'</script>";
	}else{    
    $sql="UPDATE tbl_project SET pgid='$pgid',psgid='$psgid',prjid='$prjid',name='$prjname',address=$address,cperson=$cname,cnumber=$cnumber,prjdetails=$details,prjamount=$prjamo,prjexpamo=$expamo,coid=$coid,coamo=$coamo,client=$client,status='$status' WHERE id='$edid'";
    
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $pid=$con->insert_id;    
    $efid=mysqli_affected_rows($con);    
    if($efid>0){
    $act =remove_junk(escape('Project ID: '.$prjid));    
    write_activity($aid,'PRJ','Project has been updated',$act);    
    save_msg('s','Data Successfully Update!');
    }else{
    save_msg('w','Data Fail to Update!');   
    }
    echo "<script>window.location='prj_projectlist.php'</script>";     
	}  
}
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Edit Project</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="prj_projectedit.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">

<div class="row ">
<div class="col-md-12">
<div class="col-md-2"></div>
<div class="col-md-8">
<?php 
if(isset($_POST['editprj'])){
$ids = $_POST['editprj'];
$sql="SELECT * FROM tbl_project WHERE id='".$ids."' ORDER BY id ASC LIMIT 1";    
$admin=mysqli_query($con,$sql) or die(mysqli_error($con));    
$adm=mysqli_fetch_array($admin);
?>    
<div class="row">
<div class="col-md-4">    
<div class="form-group">
<label>Project ID</label>
<input type="text" name="prjid" maxlength="20" value="<?php echo $adm['prjid'];?>" id="prjid" class="form-control" placeholder="e. g. EDU487K" />
<input type="hidden" maxlength="11" value="<?php echo $adm['id'];?>" class="form-control" name="editid" autocomplete="off" readonly>    
</div>
</div>
<div class="col-md-8">
<div class="form-group">
<label>Project Name</label>
<input type="text" name="prjname" maxlength="60" value="<?php echo $adm['name'];?>" id="prjname" class="form-control" placeholder="e.g Rapura Water Line"  />
</div>    
</div>
</div>
<div class="row">    
<div class="col-md-4">
<div class="form-group">
<label>Select Group</label>
<select class="form-control select2" name="pgid" id="pgid" onchange="getAllSubgroup(this.value)">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_progroup ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option<?php if($rows['id']==$adm['pgid']){echo ' selected';} ?> value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>    
</div>
</div>    
<div class="col-md-4">    
<div class="form-group">
<label>Sub-Group</label>      
<select class="form-control select2" name="psgid" id="psgid">
<option value="">-Select-</option>
<?php if($adm['psgid']!=''){?>
<?php
$sql="SELECT * FROM tbl_prosubgroup WHERE pgid='".$adm['pgid']."' ORDER BY id ASC";           
$querysc=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowsc=mysqli_fetch_array($querysc)){
?>
<option<?php if($rowsc['id']==$adm['psgid']){echo ' selected';} ?> value="<?php echo $rowsc['id'];?>"><?php echo $rowsc['name'];?></option>
<?php } ?>    
<?php } ?>     
</select> 
</div>    
</div>    
<div class="col-md-4">    
<div class="form-group">
<label>Project Status</label>   
<select class="form-control" name="status" id="status">
<option value="">-Select-</option>
<option<?php if($adm['status']==0){echo ' selected';} ?> value="0">Start</option>
<option<?php if($adm['status']==1){echo ' selected';} ?> value="1">On-Process</option>
<option<?php if($adm['status']==2){echo ' selected';} ?> value="2">Done</option>
<option<?php if($adm['status']==3){echo ' selected';} ?> value="3">Apply</option>
<option<?php if($adm['status']==4){echo ' selected';} ?> value="4">Reject</option>    
</select>        
</div>
</div>    
</div>
<div class="row">
<div class="col-md-3">
<div class="form-group">
<label>Contact Person</label>
<input type="text" name="cname" maxlength="35" value="<?php echo $adm['cperson'];?>" class="form-control" placeholder="e.g Mr.Enamul Haque"  />
</div>    
</div>    
<div class="col-md-3">
<div class="form-group">
<label>Contact Number</label>
<input type="text" name="cnumber" maxlength="18" value="<?php echo $adm['cnumber'];?>" class="form-control" placeholder="e.g +880161xxxxx70"  />
</div>    
</div>
<div class="col-md-3">
<div class="form-group">
<label>Project Value</label>
<input type="text" name="prjamo" maxlength="12" value="<?php echo $adm['prjamount'];?>" onkeypress="return isNumberKey(event)" class="form-control" placeholder="e.g 3,50,00,000"  />
</div>    
</div>
<div class="col-md-3">
<div class="form-group">
<label>Target Expenses</label>
<input type="text" name="expamo" maxlength="12" value="<?php echo $adm['prjexpamo'];?>" onkeypress="return isNumberKey(event)" class="form-control" placeholder="e.g 2,50,00,000"  />
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-4">
<div class="form-group">
<label>Select Contractor</label>
<select class="form-control select2" name="coid" id="coid">
<option value="">-Select-</option>
<?php									
$queryc=mysqli_query($con,"SELECT * FROM tbl_contractor WHERE status='1' ORDER BY id ASC")or die(mysqli_error($con));
while ($rowc=mysqli_fetch_array($queryc)){
?>
<option<?php if($rowc['id']==$adm['coid']){echo ' selected';} ?> value="<?php echo $rowc['id'];?>"><?php echo $rowc['name'];?></option>
<?php } ?>
</select>    
</div>
</div>
<div class="col-md-4">
<div class="form-group">
<label>Contact Amount</label>
<input type="text" name="coamo" maxlength="12" value="<?php echo $adm['coamo'];?>" onkeypress="return isNumberKey(event)" class="form-control" placeholder="e.g 2,10,00,000"  />
</div>    
</div>
<div class="col-md-4">
<div class="form-group">
<label>Select Client</label>
<select class="form-control select2" name="client" id="client">
<option value="">-Select-</option>
<?php									
$queryc=mysqli_query($con,"SELECT * FROM tbl_customer WHERE status='1' ORDER BY id ASC")or die(mysqli_error($con));
while ($row=mysqli_fetch_array($queryc)){
?>
<option<?php if($row['id']==$adm['client']){echo ' selected';} ?> value="<?php echo $row['id'];?>"><?php echo $row['code'].' - '.$row['name'];?></option>
<?php } ?>
</select>    
</div>
</div>    
</div>    
<div class="row">
<div class="col-md-6">    
<div class="form-group">
<label>Project Details</label>
<textarea class="form-control" maxlength="250" rows="6" name="details" placeholder="e.g. Details"><?php echo $adm['prjdetails'];?></textarea>
</div>
</div>
<div class="col-md-6">    
<div class="form-group">
<label>Address</label>
<textarea class="form-control" maxlength="150" rows="6" name="address" placeholder="e.g. Address"><?php echo $adm['address'];?></textarea>
</div>
</div>
</div>
<?php } ?>    
</div>    
<div class="col-md-2"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="update_project" id="submit" class="btn btn-flat bg-purple btn-sm " value="Update"/> <a href="prj_projectlist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'PRJ','A');}else{echo read_activity($aid,'PRJ','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>
    
<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function (){ 
var prjid = new LiveValidation('prjid');
prjid.add(Validate.Presence);
var prjname = new LiveValidation('prjname');
prjname.add(Validate.Presence);    
var pgid = new LiveValidation('pgid');
pgid.add(Validate.Presence);
var psgid = new LiveValidation('psgid');
psgid.add(Validate.Presence);
var status = new LiveValidation('status');
status.add(Validate.Presence);    
});
    
function getAllSubgroup(id){
$.ajax({
url: 'axe_getsub.php',
type: 'post',
data: {psgid : id},
success:function(data) {
$('#psgid').html(data);
}
});
}; 
</script>    
<!-- /page script -->
</html>    