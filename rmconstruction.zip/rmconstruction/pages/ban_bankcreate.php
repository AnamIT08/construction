<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('41','creates','R');    
$_SESSION['cuPages']='ban_bankcreate.php';   
$cuPage='ban_bankcreate.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='bank';
$menuh='Bank';
$phead='bankcre';
$page='Add Bank';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['save_bank'])){
	$name = remove_junk(escape($_POST['name']));
    $sort = strtoupper(remove_junk(escape($_POST['sort'])));
	
	if(isset($_POST['name'])){
	$ducode = mysqli_query($con,"SELECT * FROM tbl_bank WHERE name = '$name'");
	}
	
	if($ducode->num_rows > 0) {
		save_msg('i','Bank name alrady used! Plz try another');
		echo "<script>window.location='ban_bankcreate.php'</script>";
	}else{
    $sql="INSERT INTO tbl_bank(name,sort,uid,date) VALUES ('$name','$sort','$aid','$dtnow')";    
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));	
    if($result){
    $act =remove_junk(escape('Bank name: '.$name));    
    write_activity($aid,'BAN','New bank has been Added',$act);    
    }
    save_msg('s','Data Successfully Saved!');
    echo "<script>window.location='ban_bankcreate.php'</script>";  
	}  
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Add New Bank</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="ban_bankcreate.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">

<div class="row ">
<div class="col-md-12">
<div class="col-md-2"></div>
<div class="col-md-6">
<div class="form-group">
<label>Bank Name</label>
<input type="text" name="name" maxlength="45" value="" id="pname" class="form-control" placeholder="Bank Name"  />
</div>   
</div>
<div class="col-md-2">
<div class="form-group">
<label>Sort Name</label>
<input type="text" name="sort" maxlength="6" value="" id="psort" class="form-control" placeholder="Sort Name"  />
</div>
</div>     
<div class="col-md-2"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="save_bank" id="submit" class="btn btn-flat bg-purple btn-sm " value="Save"/> <a href="ban_banklist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'BAN','A');}else{echo read_activity($aid,'BAN','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function () {  
var pname = new LiveValidation('pname');
pname.add(Validate.Presence);
var psort = new LiveValidation('psort');
psort.add(Validate.Presence);    
});
</script>    
<!-- /page script -->
</html>    