<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='blank_page.php';   
$cuPage='blank_page.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='waaranty';
$menuh='Warranty Management';
$phead='wasecen';
$page='Service Center';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">All Service Center</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px; text-align:center;">SN</th>   
<th>Name</th>
<th>Contact</th>
<th>Address</th>       
<th>Status</th>    
<th style="width:40px; text-align:center;">Action</th>    
</tr>
</thead>    
<tbody id="itemdata">  
  
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<a href="#" class="btn btn-flat bg-purple" id="addnew">Add New</a>
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" id="hisdata">

</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->
<?php include('../layout/rside.php'); ?>    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
ReadITEM();
function ReadITEM() {
$.ajax({
url: "war_service_cart.php",
method: "POST",
data:{viewitem:1},
beforeSend: function () {
$('#datarec').DataTable().clear().destroy();    
},    
success: function(data) {
$('#itemdata').html(data);
$('#datarec').DataTable({stateSave: true});    
}
})
    
$.ajax({
url: "war_service_cart.php",
method: "POST",
data:{viewitemhis:1},    
success: function(data) {
$('#hisdata').html(data);     
}
})   
}
    
$(document).on('click', function(e){
if (!$(e.target).is(".right-side-add, .side-cont, #addnew") && !$(e.target).parents(".right-side-add").length && $('.right-side-add').hasClass('open-right-add')) {
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');
}    
});
    
$(document).on('click', '#closepop', function() {
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
});

$(document).on('click', '.details-invoice', function(e) {    
id_arr = $(this).attr('id');
id = id_arr.split("_");
ids=id[1];    
$.ajax({
url: "war_service_cart.php",
method: "POST",
data:{addsitem:1,item:ids},
success: function(data){
$('#addsitem').html(data);
$('.right-side-add').toggle('slide', { direction: 'right' }, 300);     
}
})    
e.preventDefault();    
});
    
$(document).on('click', '#addnew', function(e) {
$.ajax({
url: "war_service_cart.php",
method: "POST",
data:{addsitem:1,item:0},
success: function(data){
$('#addsitem').html(data);
$('.right-side-add').toggle('slide', { direction: 'right' }, 300);     
}
})    
e.preventDefault();    
}); 

$(document).on('click', '#additem', function() { 
var cash_data = $('.addservice input, .addservice select, .addservice textarea');
toastr.options = {'positionClass': 'toast-top-center'};    
if(!chek_error()){   
return;   
}
$.ajax({
url: "war_service_cart.php",
data: cash_data,
type: 'post',
dataType: 'json',    
beforeSend: function () {
chek_error();    
},    
success: function(data){
if(data.status === "success"){
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
toastr.success(data.message);
ReadITEM();    
}else{
toastr.error(data.message);    
}         
}
})    
});
    
function remove_item(id) {
ide = id.split("_");
var ids = ide[1];  
//toastr.options = {'positionClass': 'toast-top-center'};     
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
$.ajax({
url: "war_service_cart.php",
data: {delsercent:1,item:ids},
type: 'post',
dataType: 'json',        
success: function(data){
if(data.status === "success"){    
toastr.success(data.message);
ReadITEM();    
}else{
toastr.error(data.message);    
}         
}
})
}
}
});
}      
</script>    
<!-- /page script -->
</html>    