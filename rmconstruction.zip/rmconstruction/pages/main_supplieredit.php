<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
//get_pagesecurity('36','edits','R');     
$_SESSION['cuPages']='main_supplierlist.php';   
$cuPage='main_supplierlist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='client';
$menuh='Client';
$phead='prcre';
$page='Edit Supplier';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['update_suplier'])){
	$supid = remove_junk(escape($_POST['supid']));
    $name = ucwords(remove_junk(escape($_POST['name'])));
    $cperson = remove_junk(escape($_POST['cperson']));
    $cnumber = remove_junk(escape($_POST['cnumber']));
    $cphone = remove_junk(escape($_POST['cphone']));
    $cemail = remove_junk(escape($_POST['cemail']));
    $address = remove_junk(escape($_POST['address']));
    $faddress = remove_junk(escape($_POST['faddress']));
    $status = remove_junk(escape($_POST['status']));
    $climit = remove_junk(escape($_POST['climit']));
    $scgid = remove_junk(escape($_POST['scgid']));
    if($scgid!=''){$scgid="'".$scgid."'";}else{$scgid='NULL';}
    $orsupid = remove_junk(escape($_POST['orsupid']));
    if($orsupid!=''){$orsupid="'".$orsupid."'";}else{$orsupid='NULL';}
    $rank = remove_junk(escape($_POST['rank']));
	
	if(isset($_POST['cnumber'])){
	$ducode = mysqli_query($con,"SELECT * FROM tbl_supplier WHERE cnumber = '$cnumber' AND id!='$supid'");
	}
	
	if($ducode->num_rows > 0) {
		save_msg('i','Supplier name alrady used! Plz try another');
		echo "<script>window.location='main_supplierlist.php'</script>";
	}else{
    $sql="UPDATE tbl_supplier SET gid=$scgid,susid=$orsupid,name='$name',cperson='$cperson',cnumber='$cnumber',cphone='$cphone',cemail='$cemail',creditlimit='$climit',address='$address',saddress='$faddress',rank='$rank',status='$status' WHERE id='$supid'";    
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $efid=mysqli_affected_rows($con);    
    if($efid>0){
    $act =remove_junk(escape('Supplier name: '.$name));    
    write_activity($aid,'SUP','Supplier has been Updated',$act);
    save_msg('s','Data Successfully Updated!');    
    }else{
    save_msg('w','Data Fail to Update!');    
    }
    echo "<script>window.location='main_supplierlist.php'</script>";  
	}  
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-9">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Edit Supplier</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<form action="main_supplieredit.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">
<div class="col-md-1"></div>   
<div class="col-md-10">
<?php 
if(isset($_POST['editsup'])){
$ids = $_POST['editsup'];
$sql="SELECT * FROM tbl_supplier WHERE id='".$ids."' ORDER BY id ASC LIMIT 1";    
$admin=mysqli_query($con,$sql) or die(mysqli_error($con));    
$adm=mysqli_fetch_array($admin);
?>     
<div class="col-md-12">

<div class="row">
<div class="col-md-6">
<div class="form-group">
<label>Name</label>    
<input type="text" name="name" maxlength="45" value="<?php echo $adm['name'];?>" id="name" class="form-control" placeholder="e.g. Md.Sumon Rahman"/>
<input type="hidden" maxlength="11" value="<?php echo $adm['id'];?>" class="form-control" name="supid" autocomplete="off" readonly>    
</div>    
</div>
<div class="col-md-3">
<div class="form-group">
<label>Status</label>    
<select class="form-control" name="status" id="status">
<option <?php if($adm['status']==1){echo 'selected';}?> value="1">Acive</option> 
<option <?php if($adm['status']==0){echo 'selected';}?> value="0">De-Acive</option>     
</select>
</div>    
</div>    
<div class="col-md-3">
<div class="form-group">
<label>Code</label>    
<input type="text" name="code" maxlength="15" value="<?php echo $adm['code'];?>" id="code" class="form-control" placeholder="e.g. ABA/SU/001" readonly/>
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-3">
<div class="form-group">
<label>Contact Name</label>    
<input type="text" name="cperson" maxlength="45" value="<?php echo $adm['cperson'];?>" id="cperson" class="form-control" placeholder="e.g. Md.Rahman Sumon(CEO)"/>
</div>    
</div>
<div class="col-md-3">
<div class="form-group">
<label>Contact Number</label>    
<input type="text" name="cnumber" maxlength="18" value="<?php echo $adm['cnumber'];?>" id="cnumber" class="form-control" placeholder="e.g. +88016161xxxxx70"/>
</div>    
</div>
<div class="col-md-3">
<div class="form-group">
<label>Contact Phone</label>    
<input type="text" name="cphone" maxlength="14" value="" id="cphone" class="form-control" placeholder="e.g. +88-02-721xxx1"/>
</div>    
</div>
<div class="col-md-3">    
<div class="form-group">
<label>Select Under</label>
<select class="form-control select2" name="orsupid" id="orsupid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_supplier ORDER BY name ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<?php if($rows['id']==$adm['susid']){ ?>
<option selected value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php }else{?>    
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?> 
<?php } ?>
</select>    
</div>
</div>    
    
</div>    
<div class="row">
<div class="col-md-3">
<div class="form-group">
<label>Contact Email</label>    
<input type="text" name="cemail" maxlength="45" value="<?php echo $adm['cemail'];?>" id="cemail" class="form-control" placeholder="e.g. info@axesgl.com"/>
</div>    
</div>
<div class="col-md-3">    
<div class="form-group">
<label>Credit Limit</label>
<input type="text" name="climit" maxlength="12" value="<?php echo $adm['creditlimit'];?>" id="climit" class="form-control" onkeypress="return isNumberKey(event)" placeholder="e.g. 350000.00"/>   
</div>
</div>
<div class="col-md-3">    
<div class="form-group">
<label>Select Group</label>
<select class="form-control select2" name="scgid" id="scgid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_group ORDER BY name ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<?php if($rows['id']==$adm['gid']){ ?>
<option selected value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php }else{?>    
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?> 
<?php } ?>
</select>    
</div>
</div>    
<div class="col-md-3">     
<div class="form-group">
<label>Ranking</label>
<input type="text" name="rank" maxlength="3" value="<?php echo $adm['rank'];?>" id="rank" class="form-control" onkeypress="return isNumberKey(event)" placeholder="e.g. 127"/>   
</div>    
</div>    
</div>    
<div class="row">
<div class="col-md-6"> 
<div class="form-group">    
<label>Address</label>
<textarea class="form-control" name="address" id="address" maxlength="200" rows="4" placeholder="Office Address"><?php echo $adm['address'];?></textarea>    
</div>
</div>    
<div class="col-md-6">    
<div class="form-group">
<label>Factory Address</label>
<textarea class="form-control" name="faddress" id="faddress" maxlength="200" rows="4" placeholder="Factory Address"><?php echo $adm['saddress'];?></textarea>   
</div>
</div>    
</div>     
    
</div>
<?php } ?>    
</div>    
<div class="col-md-1"></div>    
</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8 ">
</div>
<div class="col-md-4 text-right" >
<input type="submit" name="update_suplier" id="submit" class="btn btn-flat bg-purple btn-sm" value="Update"/> <a href="main_supplierlist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'SUP','A');}else{echo read_activity($aid,'SUP','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>    

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function () {
var name = new LiveValidation('name');
name.add(Validate.Presence); 
var cperson = new LiveValidation('cperson');
cperson.add(Validate.Presence); 
var cnumber = new LiveValidation('cnumber');
cnumber.add(Validate.Presence);
var address = new LiveValidation('address');
address.add(Validate.Presence);
var cemail = new LiveValidation('cemail');
cemail.add(Validate.Email);
    
var dlimit = new LiveValidation('dlimit');
dlimit.add(Validate.Presence);     
dlimit.add(Validate.Numericality, { minimum: 0, onlyInteger: true });
var mlimit = new LiveValidation('mlimit');
mlimit.add(Validate.Presence);     
mlimit.add(Validate.Numericality, { minimum: 0, onlyInteger: true });
var ylimit = new LiveValidation('ylimit');
ylimit.add(Validate.Presence);     
ylimit.add(Validate.Numericality, { minimum: 0, onlyInteger: true });
var climit = new LiveValidation('climit');
climit.add(Validate.Presence);     
climit.add(Validate.Numericality, { minimum: 0, onlyInteger: true });
var rank = new LiveValidation('rank');
rank.add(Validate.Presence);     
rank.add(Validate.Numericality, { minimum: 0, onlyInteger: true });    
});
</script>    
<!-- /page script -->
</html>    