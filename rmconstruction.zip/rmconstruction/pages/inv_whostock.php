<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='inv_whostock.php';   
$cuPage='inv_whostock.php';    
$aid=$_SESSION['uid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='inventor';
$menuh='Inventory';
$phead='whostock';
$page='Warehouse Stock';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Warehouse Stock Status</h3>
</div>
<div class="box-body">    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped table-hover table_list" id="datarec">
<thead>
<tr>
<th rowspan="2" style="width:40px;" class="text-center">SN</th>
<th rowspan="2" style="width:80px;">Image</th>
<th rowspan="2">Name</th>
<th rowspan="2">SKU</th>
<th rowspan="2">Warehouse</th>    
<th colspan="2" class="text-center">Purchase Details</th>
<th colspan="2" class="text-center">Transaction Details</th>
<th rowspan="2" class="text-center">Adjust</th>     
<th rowspan="2" class="text-center">Available</th>    
</tr>
<tr>
<th class="text-center">Purchase</th>
<th class="text-center">Received</th>   
<th class="text-center">Received</th>
<th class="text-center">Send</th>    
</tr>    
</thead>    
<tbody>
<?php
$tpoqty=0;$tpqty=0;$trqty=0;$tsqty=0;$tfavqty=0;$tadjqt=0;   
$sql="SELECT pid,waid,image,name,code,SUM(poqty) AS poqty,SUM(pqty) AS pqty,SUM(rcvqty) AS rcvqty,SUM(senqty) AS senqty,SUM(adjqty) AS adjqty,SUM(avqty) AS avqty FROM tbl_whstock GROUP BY waid,pid ORDER BY waid ASC,name ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$tpoqty+=$row['poqty'];$tpqty+=$row['pqty'];$trqty+=$row['rcvqty'];$tsqty+=$row['senqty'];$tfavqty+=$row['avqty'];$tadjqt+=$row['adjqty'];    
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td class="text-center"><img src="../img/product/<?php if(empty($row['image'])){echo "no_image.png";}else{echo $row['image'];} ?>" height="40px" width="40px"></td>
<td><b class="prodetail" id="PI_<?php echo $row['pid'];?>" style="cursor: pointer;"><?php echo $row['name']; ?></b></td>
<td><?php echo $row['code']; ?></td>
<td><?php echo get_fild_data('tbl_warehouse',$row['waid'],'name'); ?></td>    
<td class="text-center"><?php echo $row['poqty']; ?></td>
<td class="text-center"><?php echo $row['pqty']; ?></td>
<td class="text-center"><?php echo $row['rcvqty']; ?></td>
<td class="text-center"><?php echo $row['senqty']; ?></td>
<td class="text-center"><?php echo $row['adjqty']; ?></td>    
<td class="text-center"><?php echo $row['avqty']; ?></td>  
</tr>    
<?php } ?>     
</tbody>
<tfoot>
<tr>
<td class="text-center" colspan="5"><strong>-Total-</strong></td>
<td class="text-center"><strong><?php echo $tpoqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tpqty; ?></strong></td>
<td class="text-center"><strong><?php echo $trqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tsqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tadjqt; ?></strong></td>    
<td class="text-center"><strong><?php echo $tfavqty; ?></strong></td>    
</tr>    
</tfoot>    
</table>    
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->
<?php include('../layout/details.php'); ?>    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script src='../plugins/chart/Chartup.js'></script>
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
});
    
$(document).on('click', '.prodetail', function(e) { 
id_arr = $(this).attr('id');
id = id_arr.split("_");

$.ajax({
url: 'axe_prodetails.php',
method: "POST",
data:{ prodet: 1,pid: id[1] },
success: function(data){
$('#profile').html(data);    
}
});    
    
$.ajax({
url: 'axe_prodetails.php',
method: "POST",
data:{ details: 1,pid: id[1] },
success: function(data){
$('#details').html(data);   
}
});    
    
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);    
e.preventDefault();    
});
    
$(document).on('click', '#closedet', function() {
$('#profile').html('');
$('#details').html('');    
if($('.right-side-details').is(':visible')) {
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);
}    
});     
</script>    
<!-- /page script -->
</html>    