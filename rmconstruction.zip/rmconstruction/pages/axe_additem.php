<?php
session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;     
}
$dtnow = date("Y-m-d h:i:s", time());
?>

<?php if(isset($_POST['addexpi'])){ ?>   
<div class="col-md-12 popup_details_div addexphead">
<div class="row">
<div id="server-results"><!-- For server results --></div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<div class="form-group">
<label>Name</label>
<input type="text" name="name" maxlength="35" value="" id="name" class="form-control" placeholder="e.g. Electric Bill" />
<input type="hidden" name="exphead" readonly />    
</div>
<div class="form-group">
<label>Expeses Type</label>
<select class="form-control" name="etype" id="etype">
<option value="">-Select-</option>
<option value="0">Administration Expenses</option>
<option value="1">Operating Expenses</option>    
</select>    
</div>    
<div class="form-group">
<label>Description</label>
<textarea class="form-control" maxlength="250" rows="6" name="description" placeholder="Description"></textarea>
</div>   
</div>    
<div class="col-md-1"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="adexp" class="btn btn-flat bg-purple btn-sm " value="Save"/>
</div> 
</div>     

<script type="text/javascript">
$(document).on('click', '#adexp', function() { 
var exhead_data = $('.addexphead input, .addexphead select, .addexphead textarea');
if(!chek_error()){   
return;   
}
$.ajax({
url: "axe_subdata.php",
data: exhead_data,
type: 'post',
dataType: 'json',    
beforeSend: function () {
chek_error();    
},    
success: function(data){
if(data.status === "success"){
var id=parseFloat(data.id);
getexphead(id);
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
}else{
toastr.error(data.message);    
}         
}
})    
});

function chek_error(){
var name = $('#name').val();
var etype = $('#etype').val();
$('.LV_validation_message').remove();
    
if(name.length<=0){
$('#name').addClass('LV_invalid_field');   
$('#name').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); } else {
$('#name').removeClass('LV_invalid_field'); 
}    
    
if(etype == '-Select-' || etype == ''){
$('#etype').addClass('LV_invalid_field');   
$('#etype').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); } else {
$('#etype').removeClass('LV_invalid_field');     
}

if(name.length<=0 || etype == ''){
return false;    
}else{
return true;     
}    
}
$(document).on('blur', '#name, #etype', function() {
chek_error();    
});
    
function getexphead(id){   
$.ajax({
url: 'axe_getsub.php',
type: 'post',
data: {getexphead : id},
success:function(data) {
$('#expid').html(data);
}
});
};    
</script>
<?php } ?>

<?php if(isset($_POST['addcus'])){ ?>
<div class="col-md-12 popup_details_div addcustomer">
<div class="row">
<div id="server-results"><!-- For server results --></div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<div class="form-group">
<label>Name</label>
<input type="text" name="name" maxlength="45" value="" id="name" class="form-control" placeholder="e.g. Md.Sumon Rahman"/>
<input type="hidden" name="addcus" readonly />    
</div>    
<div class="form-group">
<label>Father / Contact Name</label>    
<input type="text" name="cperson" maxlength="45" value="" id="cperson" class="form-control" placeholder="e.g. Md.Rahman Sumon(CEO)"/>
</div>
<div class="form-group">
<label>Contact Number</label>    
<input type="text" name="cnumber" maxlength="18" value="" id="cnumber" class="form-control" placeholder="e.g. +88016161xxxxx70"/>
</div>
<div class="form-group">
<label>Contact Email</label>    
<input type="text" name="cemail" maxlength="45" value="" id="cemail" class="form-control" placeholder="e.g. info@axesgl.com"/>
</div>
<div class="form-group">    
<label>Address</label>
<textarea class="form-control" name="address" id="address" maxlength="250" rows="5" placeholder="Office Address"></textarea>    
</div>    
</div>    
<div class="col-md-1"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="adcus" class="btn btn-flat bg-purple btn-sm " value="Save"/>
</div> 
</div>

<script type="text/javascript">
function chek_error(){
var name = $('#name').val();
var cnumber = $('#cnumber').val();
var cemail = $('#cemail').val();    
var result = true;
    
var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,8}|[0-9]{1,3})(\]?)$/;
    
$('.LV_validation_message').remove();
    
if(name.length<=0){
$('#name').addClass('LV_invalid_field');   
$('#name').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); } else {
$('#name').removeClass('LV_invalid_field'); 
}    
    
if(cnumber.length<=0){
$('#cnumber').addClass('LV_invalid_field');   
$('#cnumber').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); } else {
$('#cnumber').removeClass('LV_invalid_field'); 
}    

if(cemail.length >0){
result = expr.test(cemail);
if(result){
$('#cemail').removeClass('LV_invalid_field');        
}else{
$('#cemail').addClass('LV_invalid_field');
$('#cemail').after("<span class='LV_validation_message LV_invalid'>Not a valid email address!</span>").addClass('has-error');    
}    
}    
    
if(name.length<=0 || cnumber.length<=0 || !result){
return false;    
}else{
return true;     
}    
}
    
$(document).on('blur', '#name, #cnumber, #cemail', function() {
chek_error();    
});    

$(document).on('click', '#adcus', function() { 
var customer_data = $('.addcustomer input, .addcustomer textarea');
if(!chek_error()){
return;   
}
$.ajax({
url: "axe_subdata.php",
data: customer_data,
type: 'post',
dataType: 'json',    
beforeSend: function () {
chek_error();    
},    
success: function(data){
if(data.status === "success"){
var id=parseFloat(data.id);
getcustomer(id);
cusupdate(id);    
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
}else{
toastr.error(data.message);    
}         
}
})    
});

function cusupdate(id){
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
upcusid: id
},
success: function(data){

}
});    
}    
    
function getcustomer(id){   
$.ajax({
url: 'axe_getsub.php',
type: 'post',
data: {getcustomer : id},
success:function(data) {
$('#cusid').html(data);
}
});
};    
</script>    
<?php } ?>

<?php if(isset($_POST['addsup'])){ ?>
<div class="col-md-12 popup_details_div addsupplier">
<div class="row">
<div id="server-results"><!-- For server results --></div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<div class="form-group">
<label>Name</label>
<input type="text" name="name" maxlength="45" value="" id="name" class="form-control" placeholder="e.g. Md.Sumon Rahman"/>
<input type="hidden" name="addsup" readonly />    
</div>    
<div class="form-group">
<label>Father / Contact Name</label>    
<input type="text" name="cperson" maxlength="45" value="" id="cperson" class="form-control" placeholder="e.g. Md.Rahman Sumon(CEO)"/>
</div>
<div class="form-group">
<label>Contact Number</label>    
<input type="text" name="cnumber" maxlength="18" value="" id="cnumber" class="form-control" placeholder="e.g. +88016161xxxxx70"/>
</div>
<div class="form-group">
<label>Contact Email</label>    
<input type="text" name="cemail" maxlength="45" value="" id="cemail" class="form-control" placeholder="e.g. info@axesgl.com"/>
</div>
<div class="form-group">    
<label>Address</label>
<textarea class="form-control" name="address" id="address" maxlength="250" rows="5" placeholder="Office Address"></textarea>    
</div>    
</div>    
<div class="col-md-1"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="adsup" class="btn btn-flat bg-purple btn-sm " value="Save"/>
</div> 
</div>

<script type="text/javascript">
function chek_error(){
var name = $('#name').val();
var cnumber = $('#cnumber').val();
var cemail = $('#cemail').val();    
var result = true;
    
var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,8}|[0-9]{1,3})(\]?)$/;
    
$('.LV_validation_message').remove();
    
if(name.length<=0){
$('#name').addClass('LV_invalid_field');   
$('#name').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); } else {
$('#name').removeClass('LV_invalid_field'); 
}    
    
if(cnumber.length<=0){
$('#cnumber').addClass('LV_invalid_field');   
$('#cnumber').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); } else {
$('#cnumber').removeClass('LV_invalid_field'); 
}    

if(cemail.length >0){
result = expr.test(cemail);
if(result){
$('#cemail').removeClass('LV_invalid_field');        
}else{
$('#cemail').addClass('LV_invalid_field');
$('#cemail').after("<span class='LV_validation_message LV_invalid'>Not a valid email address!</span>").addClass('has-error');    
}    
}    
    
if(name.length<=0  || cnumber.length<=0 || !result){
return false;    
}else{
return true;     
}    
}
    
$(document).on('blur', '#name, #cnumber, #cemail', function() {
chek_error();    
});    

$(document).on('click', '#adsup', function() { 
var supplier_data = $('.addsupplier input, .addsupplier textarea');
if(!chek_error()){
return;   
}
$.ajax({
url: "axe_subdata.php",
data: supplier_data,
type: 'post',
dataType: 'json',    
beforeSend: function () {
chek_error();    
},    
success: function(data){
if(data.status === "success"){
var id=parseFloat(data.id);
getsupplier(id);
supupdate(id);
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
}else{
toastr.error(data.message);    
}         
}
})    
});

function supupdate(id){
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
upsupid: id
},
success: function(data){

}
});    
}    
    
function getsupplier(id){   
$.ajax({
url: 'axe_getsub.php',
type: 'post',
data: {getsuplier : id},
success:function(data) {
$('#supid').html(data);
}
});
};    
</script>    
<?php } ?>

<?php if(isset($_POST['addpro'])){ ?>
<div class="col-md-12 popup_details_div addproduct">
<div class="row">
<div id="server-results"><!-- For server results --></div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<div class="form-group">
<label>Name</label>
<input type="text" name="name" maxlength="45" value="" id="name" class="form-control" placeholder="e.g. Denim"/>
<input type="hidden" name="addpro" readonly />     
</div>    
<div class="form-group">
<label>Parent (Optional)</label>   
<select class="form-control select2" name="preid" id="preid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_parent ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>       
</div>
<div class="form-group">
<label>Category</label>   
<select class="form-control select2" name="catid" id="catid" onchange="getAllSubgroup(this.value)">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_category ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>       
</div>
<div class="form-group">
<label>Sub-Category</label>       
<select class="form-control select2" name="scatid" id="scatid">
<option value="">-Select-</option>
    
</select>    
</div>
<div class="form-group">
<label>Brand</label>  
<select class="form-control select2" name="braid" id="braid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_brand ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>    
</div> 
<div class="form-group">
<label>Manufacturer</label>   
<select class="form-control select2" name="manid" id="manid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_manfacturer ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>    
</select>    
</div>
<div class="form-group">
<label>Unit</label>    
<select class="form-control select2" name="unid" id="unid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_unit ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>    
</select>    
</div>
<div class="form-group">
<label>Color</label>   
<select class="form-control select2" name="colid" id="colid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_color ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>    
</div>
<div class="form-group">
<label>Country</label>   
<select class="form-control select2" name="couid" id="couid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_country ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>    
</select>    
</div>
<div class="form-group">
<label>Status</label>
<select class="form-control select2" name="status" id="status">
<option value="1">Active</option>
<option value="0">De-Active</option>    
</select>
</div>
<div class="form-group">
<label>Description</label>
<textarea class="form-control" maxlength="250" rows="6" name="description" placeholder="Description"></textarea>
</div>    
</div>    
<div class="col-md-1"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="adpro" class="btn btn-flat bg-purple btn-sm " value="Save"/>
</div> 
</div>

<script type="text/javascript">
    
function chek_error(){
var name = $('#name').val();
var unid = $('#unid').val();
$('.LV_validation_message').remove();
    
if(name.length<=0){
$('#name').addClass('LV_invalid_field');   
$('#name').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); } else {
$('#name').removeClass('LV_invalid_field'); 
}    
    
if(unid == '-Select-' || unid == ''){
$('#unid').addClass('LV_invalid_field');   
$('#unid').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); } else {
$('#unid').removeClass('LV_invalid_field');     
}

if(name.length<=0 || unid == ''){
return false;    
}else{
return true;     
}    
}
$(document).on('blur', '#name, #unid', function() {
chek_error();    
});

$(document).on('click', '#adpro', function() { 
var product_data = $('.addproduct input, .addproduct select, .addproduct textarea');
if(!chek_error()){   
return;   
}
$.ajax({
url: "axe_subdata.php",
data: product_data,
type: 'post',
dataType: 'json',    
beforeSend: function () {
chek_error();    
},    
success: function(data){
if(data.status === "success"){
var id=parseFloat(data.id);
addproduct(id);
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
}else{
toastr.error(data.message);    
}         
}
})    
});    

function addproduct(id){
$.ajax({
url: 'axe_cart.php',
type: 'post',
data: {proid:id,request:2},
dataType: 'json',
success:function(response){
ReadData();
}
});    
}    
    
function getAllSubgroup(id){
$.ajax({
url: 'axe_getsub.php',
type: 'post',
data: {subcat : id},
success:function(data) {
$('#scatid').html(data);
}
});
};     
</script>
<?php } ?>

<?php if(isset($_POST['addcash'])){ ?>
<div class="col-md-12 popup_details_div addcash">
<div class="row">
<div id="server-results"><!-- For server results --></div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<div class="form-group">
<label>Transfer From (<span id="cashbal" style="color:red;">0.00</span>)</label>    
<select class="form-control select2" name="cid" id="cid">
<option value="">-Select-</option>
<option value="LE_2">Cash</option>    
<?php
$sql="SELECT tbl_bacount.id,CONCAT(tbl_bank.sort,' - ',tbl_bacount.acno) AS name FROM tbl_bacount LEFT JOIN tbl_bank ON tbl_bank.id=tbl_bacount.bid ORDER BY tbl_bank.sort ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'BA_'.$rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>
<input type="hidden" name="addcash" readonly />     
</div>
<div class="form-group">
<label>Cheque No</label>
<input type="text" maxlength="20" class="form-control" name="chkno" id="chkno" value="" placeholder="e.g. KA7865467" autocomplete="off" disabled="disabled">
</div>
<div class="form-group" >
<label>Cheque Date</label>
<input type="text" class="form-control datetimepicker" name="chkdt" id="chkdt" value="" placeholder="Cheque Date" autocomplete="off" disabled="disabled" readonly>
</div>
<div class="form-group">
<label>Ref</label>
<input type="text" maxlength="35" class="form-control" name="ref" id="ref" placeholder="e.g. #For expenses" autocomplete="off">    
</div>    
<div class="form-group">
<label>Amount</label>    
<input type="text" maxlength="10" class="form-control" name="amo" id="amo"  onkeypress="return isNumberKey(event)" placeholder="e.g. 500" autocomplete="off">    
</div>
<div class="form-group">
<label>Note</label>
<textarea class="form-control" maxlength="150" rows="3" name="note" placeholder="Note"></textarea>
</div>    
</div>    
<div class="col-md-1"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="adtra" class="btn btn-flat bg-purple btn-sm " value="Transfer"/>
</div> 
</div>

<script type="text/javascript">
function chek_error(){
var amo = parseFloat($('#amo').val());
var cid = $('#cid').val();
var chkno = $('#chkno').val();
var chkdt = $('#chkdt').val();
var result = true;    
ty = cid.split("_");
type=ty[0];
$('.LV_invalid_field').removeClass('LV_invalid_field');     
$('.LV_validation_message').remove();    

if(cid == '-Select-' || cid == ''){
$('#cid').addClass('LV_invalid_field');   
$('#cid').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); } else {
$('#cid').removeClass('LV_invalid_field');     
}     

if(type=='BA'){    
if(chkno.length>=0 && chkno.length<5){
$('#chkno').addClass('LV_invalid_field');   
$('#chkno').after("<span class='LV_validation_message LV_invalid'>Enter Valid Cheque No!</span>").addClass('has-error'); 
result=false;
}else{
$('#chkno').removeClass('LV_invalid_field');
result=true;    
}    

if(chkno.length>0){
if(chkdt.length<=0){
$('#chkdt').addClass('LV_invalid_field');   
$('#chkdt').after("<span class='LV_validation_message LV_invalid'>Enter Cheque Date!</span>").addClass('has-error');
result=false;    
}else{
$('#chkdt').removeClass('LV_invalid_field');
result=true;    
}    
}    
}    

if(isNaN(amo) != false || amo <= 0){
$('#amo').addClass('LV_invalid_field');   
$('#amo').after("<span class='LV_validation_message LV_invalid'>Enter Valid Amount!</span>").addClass('has-error'); }else{
$('#amo').removeClass('LV_invalid_field');    
}

if(cid == '' || amo.length<=0 || !result){
return false;    
}else{
return true;     
}    
   
}

$(document).on('click', '#adtra', function() { 
var cash_data = $('.addcash input, .addcash select, .addcash textarea');
if(!chek_error()){   
return;   
}
$.ajax({
url: "axe_subdata.php",
data: cash_data,
type: 'post',
dataType: 'json',    
beforeSend: function () {
chek_error();    
},    
success: function(data){
if(data.status === "success"){
var cash=parseFloat(data.cash);
$('#cbal').html(cash.toFixed(2));
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
}else{
toastr.error(data.message);    
}         
}
})    
});    
    
$(document).on('change', '#cid', function() {
id_arr = $(this).val();
id = id_arr.split("_");
type=id[0];
ids=id[1];    
if(type=='BA'){
document.getElementById("chkno").disabled=false; 
document.getElementById("chkdt").disabled=false;     
}else{
$('#chkno').val('');
$('#chkdt').val('');    
document.getElementById("chkno").disabled=true; 
document.getElementById("chkdt").disabled=true;    
}
cal_cashbal(id_arr);    
});

function cal_cashbal(id){
$.ajax({
url: 'axe_cart.php',
type: 'post',
data: {checkbales:id},
success:function(data){
$('#cashbal').html(data);
}
});    
}    
    
$(document).on('blur', '#amo, #cid, #chkno, #chkdt', function() {
chek_error();    
});

$('.datetimepicker').datepicker({format: "yyyy-mm-dd", autoclose: true, clearBtn: true, orientation: 'auto bottom'});    
</script>    
<?php } ?>

<?php 
if(isset($_POST['addsitem'])){ 
$item=intval($_POST['item']);   
?>
<div class="col-md-12 popup_details_div addservice">
<div class="row">
<div id="server-results"><!-- For server results --></div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<?php if($item <=0){ ?>     
<div class="form-group">
<label>Name</label>
<input type="text" maxlength="35" value="" name="name" id="name" class="form-control" placeholder="e.g. Mother Board Repair"/>
</div>    
<div class="form-group">
<label>Category</label>    
<select class="form-control select2" name="catid" id="catid" onchange="getAllSubgroup(this.value)">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_category ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>
<input type="hidden" name="addseritem" readonly />     
</div>
<div class="form-group">
<label>Sub-Category</label>        
<select class="form-control select2" name="scatid" id="scatid">
<option value="">-Select-</option>
    
</select>    
</div>       
<div class="form-group">
<label>Cost</label>    
<input type="text" maxlength="10" class="form-control" name="cost" id="cost"  onkeypress="return isNumberKey(event)" placeholder="e.g. 500" autocomplete="off">    
</div>
<div class="form-group">
<label>Price</label>    
<input type="text" maxlength="10" class="form-control" name="price" id="price"  onkeypress="return isNumberKey(event)" placeholder="e.g. 500" autocomplete="off">    
</div>
<div class="form-group">
<label>Description</label>
<textarea class="form-control" maxlength="250" rows="5" name="description" placeholder="Description"></textarea>
</div>
<div class="row">
<div class="col-md-4">    
<div class="form-group">
<label>Code</label>    
<input type="text" name="code" maxlength="45" value="<?php echo get_genid('SE','ABA');?>" id="code" class="form-control" placeholder="e.g. Code" readonly/>    
</div>
</div>    
<div class="col-md-8">
<div class="form-group">
<label>Status</label>
<select class="form-control select2" name="status" id="status">
<option value="1">Active</option>
<option value="0">De-Active</option>    
</select>
</div>
</div>     
</div>
<?php 
}else{ 
$sql="SELECT * FROM tbl_seritem WHERE id='".$item."' ORDER BY id ASC LIMIT 1";    
$admin=mysqli_query($con,$sql) or die(mysqli_error($con));    
$adm=mysqli_fetch_array($admin);    
?>
<div class="form-group">
<label>Name</label>
<input type="text" maxlength="35" value="<?php echo $adm['name'];?>" name="name" id="name" class="form-control" placeholder="e.g. Mother Board Repair"/>
<input type="hidden" maxlength="11" value="<?php echo $adm['id'];?>" class="form-control" name="itmid" autocomplete="off" readonly>    
</div>    
<div class="form-group">
<label>Category</label>    
<select class="form-control select2" name="catid" id="catid" onchange="getAllSubgroup(this.value)">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_category ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<?php if($rows['id']==$adm['catid']){ ?>
<option selected value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php }else{?>    
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
<?php } ?>    
</select>
<input type="hidden" name="editseritem" readonly />     
</div>
<div class="form-group">
<label>Sub-Category</label>        
<select class="form-control select2" name="scatid" id="scatid">
<option value="">-Select-</option>
<?php if($adm['catid']!=''){?>
<?php
$sql="SELECT * FROM tbl_subcat WHERE catid='".$adm['catid']."' ORDER BY id ASC";           
$querysc=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowsc=mysqli_fetch_array($querysc)){
?>
<?php if($rowsc['id']==$adm['scatid']){ ?>
<option selected value="<?php echo $rowsc['id'];?>"><?php echo $rowsc['name'];?></option>
<?php }else{?>
<option value="<?php echo $rowsc['id'];?>"><?php echo $rowsc['name'];?></option>
<?php } ?>
<?php } ?>    
<?php } ?>     
</select>    
</div>       
<div class="form-group">
<label>Cost</label>    
<input type="text" maxlength="10" class="form-control" value="<?php echo $adm['cost'];?>" name="cost" id="cost"  onkeypress="return isNumberKey(event)" placeholder="e.g. 500" autocomplete="off">    
</div>
<div class="form-group">
<label>Price</label>    
<input type="text" maxlength="10" class="form-control" value="<?php echo $adm['price'];?>" name="price" id="price"  onkeypress="return isNumberKey(event)" placeholder="e.g. 500" autocomplete="off">    
</div>
<div class="form-group">
<label>Description</label>
<textarea class="form-control" maxlength="250" rows="5" name="description" placeholder="Description"><?php echo $adm['description'];?></textarea>
</div>
<div class="row">
<div class="col-md-4">    
<div class="form-group">
<label>Code</label>    
<input type="text" name="code" maxlength="45" value="<?php echo $adm['code'];?>" id="code" class="form-control" placeholder="e.g. Code" readonly/>    
</div>
</div>    
<div class="col-md-8">
<div class="form-group">
<label>Status</label>
<select class="form-control select2" name="status" id="status">
<option <?php if($adm['status']==1){echo 'selected';}?> value="1">Active</option>
<option <?php if($adm['status']==0){echo 'selected';}?> value="0">De-Active</option>    
</select>
</div>
</div>     
</div>    
<?php } ?>   
</div>    
<div class="col-md-1"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="additem" class="btn btn-flat bg-purple btn-sm " value="<?php if($item <=0){echo 'Save';}else{echo 'Update';} ?>"/>
</div> 
</div>
<script type="text/javascript">
$(".select2").select2();
    
function getAllSubgroup(id){
$.ajax({
url: 'axe_getsub.php',
type: 'post',
data: {subcat : id},
success:function(data) {
$('#scatid').html(data);
}
});
};
    
function chek_error(){
var result = true;
var name = $('#name').val();
var cost = parseFloat($('#cost').val()); 
var price = parseFloat($('#price').val()); 

$('.LV_invalid_field').removeClass('LV_invalid_field');     
$('.LV_validation_message').remove();     

if(name.length<1){
$('#name').addClass('LV_invalid_field');   
$('#name').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#name').removeClass('LV_invalid_field');
result=true;    
}    

if(isNaN(cost) != false || cost < 0){
$('#cost').addClass('LV_invalid_field');   
$('#cost').after("<span class='LV_validation_message LV_invalid'>Enter Valid Cost!</span>").addClass('has-error');
result=false;    
}else{
$('#cost').removeClass('LV_invalid_field');
result=true;     
}    

if(isNaN(price) != false || price < 0){
$('#price').addClass('LV_invalid_field');   
$('#price').after("<span class='LV_validation_message LV_invalid'>Enter Valid Price!</span>").addClass('has-error');
result=false;    
}else{
$('#price').removeClass('LV_invalid_field');
result=true;     
}    

if(cost.length<0 || cost.length<0 || !result){
return false;    
}else{
return true;     
}        
}
    
$(document).on('blur', '#name, #cost, #price', function() {
chek_error();    
});    
</script> 

<?php }
if(isset($_POST['addseritem'])){
$name = ucwords(remove_junk(escape($_POST['name'])));
$code = get_genid('SE','ABA');
$catid = remove_junk(escape($_POST['catid']));
if($catid==''){$catid='NULL';}else{$catid="'".$catid."'";}
$scatid = remove_junk(escape($_POST['scatid']));
if($scatid==''){$scatid='NULL';}else{$scatid="'".$scatid."'";}
$cost = remove_junk(escape($_POST['cost']));
$price = remove_junk(escape($_POST['price']));
$status = remove_junk(escape($_POST['status']));   
$description = remove_junk(escape($_POST['description'])); 

if(isset($_POST['name'])){
$sql="SELECT * FROM tbl_seritem WHERE name = '$name'";           
$ducode = mysqli_query($con,$sql);
}
    
if($ducode->num_rows > 0) {
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Service Item Already Exists!!'
));
return;
exit;
}else{ 
$sql="INSERT INTO tbl_seritem (code,name,description,catid,scatid,cost,price,status,brid,uid,date) VALUES ('$code','$name','$description',$catid,$scatid,'$cost','$price','$status','$brid','$aid','$dtnow')";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$pid=$con->insert_id;    
$efid=mysqli_affected_rows($con);    
if($efid>0){    
$act =remove_junk(escape('Service name: '.$name));    
write_activity($aid,'SEI','New service has been created',$act);    
echo json_encode(array(
'status' => 'success',
'message'=> 'Data Save Successfully!!'   
));
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));    
} 
}   
}

if(isset($_POST['editseritem'])){
$name = ucwords(remove_junk(escape($_POST['name'])));
$itemid = remove_junk(escape($_POST['itmid']));;
$catid = remove_junk(escape($_POST['catid']));
if($catid==''){$catid='NULL';}else{$catid="'".$catid."'";}
$scatid = remove_junk(escape($_POST['scatid']));
if($scatid==''){$scatid='NULL';}else{$scatid="'".$scatid."'";}
$cost = remove_junk(escape($_POST['cost']));
$price = remove_junk(escape($_POST['price']));
$status = remove_junk(escape($_POST['status']));   
$description = remove_junk(escape($_POST['description'])); 

if(isset($_POST['name'])){
$sql="SELECT * FROM tbl_seritem WHERE name = '$name' AND id!='$itemid'";           
$ducode = mysqli_query($con,$sql);
}
    
if($ducode->num_rows > 0) {
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Service Item Already Exists!!'
));
return;
exit;
}else{ 
$sql="UPDATE tbl_seritem SET name='$name',description='$description',catid=$catid,scatid=$scatid,cost='$cost',price='$price',status='$status' WHERE id='$itemid'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$pid=$con->insert_id;    
$efid=mysqli_affected_rows($con);    
if($efid>0){    
$act =remove_junk(escape('Service name: '.$name));    
write_activity($aid,'SEI','Service has been Updated',$act);    
echo json_encode(array(
'status' => 'success',
'message'=> 'Data Update Successfully!!'   
));
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Update!!'
));    
} 
}   
}

function check_deseritem($id){
$flage=0;
global $con;
$sql="SELECT * FROM tbl_sersalesde WHERE sid='$id'";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}

if($flage>0){
return $flage;
exit;    
}    
return $flage;    
}

if(isset($_POST['delseritem'])){
$id=intval($_POST['item']);
    
if(check_deseritem($id)){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Service Item Depend On Other Table!!'
));
exit;
return;    
}

$name=get_fild_data('tbl_seritem',$id,'name');
$sql="DELETE FROM tbl_seritem WHERE id='$id'";
$fdel=mysqli_query($con,$sql)or die(mysqli_error($con));    
$efid=mysqli_affected_rows($con);
if($efid>0){
$act =remove_junk(escape('Service item: '.$name));    
write_activity($aid,'SEI','Service item has been deleted',$act);        
echo json_encode(array(
'status' => 'success',
'message'=> 'Data Deleted Successfully!!'   
));
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Delete!!'
));    
}       
}
?> 

<?php if(isset($_POST['viewitem'])){
$sql="SELECT * FROM tbl_seritem ORDER BY name ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$cat='';    
if($row['catid']!=''){
$cat.='<strong>'.get_fild_data('tbl_category',$row['catid'],'name').'</strong>';    
}
if($row['scatid']!=''){
$cat.='<br>'.get_fild_data('tbl_subcat',$row['scatid'],'name');    
}    
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td><?php echo $row['name'];?></td>      
<td><?php echo $row['code'];?></td>
<td><?php echo $cat;?></td>   
<td><?php echo numtolocal($row['cost'],get_fild_data('tbl_currency','1','symbol'));?></td>
<td><?php echo numtolocal($row['price'],get_fild_data('tbl_currency','1','symbol'));?></td>
<td><?php echo $row['description'];?></td>    
<td><?php if($row['status']>0){echo 'Active';}else{echo 'De-Active';}?></td>    
<td nowrap="">
<a class="btn btn-flat bg-purple details-invoice" href="#" id="ser_<?php echo $row['id']; ?>"><i class="fa fa-edit cat-child"></i></a>    
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
<form action="sel_sreturncteate.php" id="RE_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="selret" value="<?php echo $row['id']; ?>" />
</form>
<form action="sel_sinvlist.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delsel" value="<?php echo $row['id']; ?>" />
</form>
</td>    
</tr>    
<?php }} ?>

<?php 
if(isset($_POST['viewitemhis'])){
if($_SESSION['utype']=='1'){echo read_activity($aid,'SEI','A');}else{echo read_activity($aid,'SEI','U');}
}?>