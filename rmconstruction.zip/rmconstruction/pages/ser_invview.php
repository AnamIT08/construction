<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
$body='';
$foot='';
$buton='';
$s=0;
$totqty=0;

if(isset($_SESSION['axes_service'])){
if(is_array($_SESSION['axes_service'])){
$max=count($_SESSION['axes_service']);
for($i=($max-1);$i>=0;$i=$i-1){
$code=$_SESSION['axes_service'][$i]['code'];
$sid=$_SESSION['axes_service'][$i]['sid'];    
$code=$_SESSION['axes_service'][$i]['code'];
$name=$_SESSION['axes_service'][$i]['name'];    
$cost=$_SESSION['axes_service'][$i]['cost']; 
$qty=$_SESSION['axes_service'][$i]['qty'];
$price=$_SESSION['axes_service'][$i]['price'];
$disp=$_SESSION['axes_service'][$i]['disp'];
$disf=$_SESSION['axes_service'][$i]['disf'];    
$disamo=$_SESSION['axes_service'][$i]['disamo'];
$snote=$_SESSION['axes_service'][$i]['snote'];    
$subtot=$_SESSION['axes_service'][$i]['subtot'];
   
$s+=1;
$totqty+=$qty;    

$body.='<tr>';
$body.='<td class="text-center" width="30px">'.$s.'</td>';    
$body.='<td data-toggle="collapse" data-target="#sitem'.$i.'" class="accordion-toggle" style="cursor: pointer;" width="249px">'.$name.'</td>';
$body.='<td width="72px"><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control quantity" id="qty_'.$i.'" value="'.$qty.'"  size="2" style="height: 24px;"/></td>';
$body.='<td width="72px"><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control price" id="price_'.$i.'" value="'.$price.'"  size="2" style="height: 24px;"/></td>';
$body.='<td width="77px" id="stotal_'.$i.'" class="text-right">'.getfloatval($subtot).'</td>';
$body.='<td class="text-center" width="25px"><a id="'.$i.'" class="remove"><span style="cursor: pointer;" class="fa fa-times"></span></a></td>';    
$body.='</tr>';
    
$body.='<tr>';
$body.='<td colspan="6" class="hiddenRow"><div class="accordian-body collapse" id="sitem'.$i.'">';
$body.='<table class="table table-bordered table-striped" style="margin-bottom: 0;">';
$body.='<thead>';
$body.='<tr>';
$body.='<th colspan="3" rowspan="2" class="text-center" width="316px">Service Note</th>';   
$body.='<th colspan="4" class="text-center" width="316px">Sales Discount</th>';    
$body.='</tr>';
$body.='<tr>';
$body.='<th class="text-center" width="72px">Percent(%)</th>';
$body.='<th class="text-center" width="72px">Fixed</th>';
$body.='<th colspan="2" class="text-center">Total</th>';    
$body.='</tr>';
$body.='</thead>';
$body.='<tbody>';
$body.='<tr>';
$body.='<td colspan="3"><input type="text" maxlength="45" class="form-control pnote" id="snote_'.$i.'" value="'.$snote.'"  size="2" style="height: 24px;"/></td>';    
$body.='<td><input type="text" min="0" onkeypress="return isNumberKey(event)" class="form-control disp" id="disp_'.$i.'" value="'.$disp.'"  size="2" style="height: 24px;"/></td>';
$body.='<td><input type="text" min="0" onkeypress="return isNumberKey(event)" class="form-control disf" id="disf_'.$i.'" value="'.$disf.'"  size="2" style="height: 24px;"/></td>';
$body.='<td id="disamo_'.$i.'" class="text-right">'.$disamo.'</td>';   
$body.='</tr>';    
$body.='</tbody></table></div></td></tr>';     
}    

if($max>0){
if (!isset($_SESSION['axes_servide'])) {
$_SESSION['axes_servide'] = array();
$_SESSION['axes_servide'][0]['disp']=0;
$_SESSION['axes_servide'][0]['disamo']=0;    
$_SESSION['axes_servide'][0]['vatp']=0;
$_SESSION['axes_servide'][0]['vatamo']=0;
$_SESSION['axes_servide'][0]['aitp']=0;
$_SESSION['axes_servide'][0]['aitamo']=0;
$_SESSION['axes_servide'][0]['name']='Others';
$_SESSION['axes_servide'][0]['others']=0;
$_SESSION['axes_servide'][0]['less']=0;
$_SESSION['axes_servide'][0]['freight']=0;
$_SESSION['axes_servide'][0]['gtotal']=$subtot;    
}
}else{
if(isset($_SESSION['axes_servide'])){
unset($_SESSION['axes_servide']);    
}    
}
if(isset($_SESSION['axes_servide'])){
if(is_array($_SESSION['axes_servide'])){    
$disp=$_SESSION['axes_servide'][0]['disp'];
$vatp=$_SESSION['axes_servide'][0]['vatp'];
$vatamo=$_SESSION['axes_servide'][0]['vatamo'];
$aitp=$_SESSION['axes_servide'][0]['aitp'];
$aitamo=$_SESSION['axes_servide'][0]['aitamo'];
$otname=$_SESSION['axes_servide'][0]['name'];
$others=$_SESSION['axes_servide'][0]['others'];
$less=$_SESSION['axes_servide'][0]['less'];
$freight=$_SESSION['axes_servide'][0]['freight'];
$gtotal=$_SESSION['axes_servide'][0]['gtotal'];    
}else{
$disp=0;
$vatp=0;
$vatamo=0;
$otname='Others';
$others=0;
$less=0;
$freight=0;
$gtotal=0;    
}
}else{
$disp=0;
$vatp=0;
$vatamo=0;
$aitp=0;
$aitamo=0;
$otname='Others';
$others=0;
$less=0;
$freight=0;
$gtotal=0;    
}    

$foot.='<tr>';
$foot.='<td width="30px"></td>';
$foot.='<td width="249px"></td>';
$foot.='<td width="72px"></td>';
$foot.='<td width="72px"></td>';
$foot.='<td width="77px"></td>';
$foot.='<td width="25px"></td>';
$foot.='</tr>';    
$foot.='<tr>';
$foot.='<td colspan="2" class="text-center" width="279px"><strong>-Total-</strong></td>';
$foot.='<td width="72px"><strong>'.$totqty.'</strong></td>';
$foot.='<td width="72px"></td>';
$foot.='<td width="77px" class="text-right"><strong>'.getfloatval(get_service_total()).'</strong></td>';
$foot.='<td></td>';
$foot.='</tr>';	

if(get_serdiscount_total()>0){
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>Discount on Item:</strong></td>';
$foot.='<td align="center"></td>';    
$foot.='<td id="disitem" class="text-right"><strong>'.getfloatval(get_serdiscount_total()).'</strong></td>';
$foot.='<td></td>';    
$foot.='</tr>';	
}
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>Discount (%)</strong></td>';
$foot.='<td><input type="text" maxlength="5" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="discount" value="'.getfloatval($disp).'"  size="2" style="height: 24px;"/></td>';    
$foot.='<td id="disitems" class="text-right"><strong>'.getfloatval(get_serdiscount_total($disp)-get_serdiscount_total()).'</strong></td>';
$foot.='<td></td>';
$foot.='</tr>';	
if(get_serdiscount_total()>0){
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>Total Discount (%)</strong></td>';
$foot.='<td align="center"></td>';    
$foot.='<td id="totdisamo" class="text-right"><strong>'.getfloatval(get_serdiscount_total($disp)).'</strong></td>';
$foot.='<td></td>';     
$foot.='</tr>';	
}    

$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>VAT (%)</strong></td>';
$foot.='<td><input type="text" maxlength="5" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="vatp" value="'.getfloatval($vatp).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="vatamo" class="text-right"><strong>'.getfloatval($vatamo).'</strong></td>';
$foot.='<td></td>';    
$foot.='</tr>';
$foot.='<tr>';     
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>AIT (%)</strong></td>';
$foot.='<td><input type="text" maxlength="5" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="aitp" value="'.getfloatval($aitp).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="aitamo" class="text-right"><strong>'.getfloatval($aitamo).'</strong></td>';
$foot.='<td></td>';    
$foot.='</tr>';
$foot.='<tr>';
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><div style="display: inline;"><i class="fa fa-angle-right cart-icon" id="icon"></i></div><span id="otdname"><strong>'.$otname.':</strong></span></td>';
$foot.='<td><input type="text" maxlength="5" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="others" value="'.getfloatval($others).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="othersamo" class="text-right"><strong>'.getfloatval($others).'</strong></td>';
$foot.='<td></td>';    
$foot.='</tr>';
$foot.='<tr class="dshow" style="display: none;">';   
$foot.='<td colspan="3" align="right"><strong>Oters Name:</strong></td>';
$foot.='<td colspan="2"><input type="text" maxlength="20" min="0" class="form-control" id="otname" value="'.$otname.'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td></td>';    
$foot.='</tr>';
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>Freight:</strong></td>';
$foot.='<td><input type="text" maxlength="6" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="freight" value="'.getfloatval($freight).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="freightd" class="text-right"><strong>'.getfloatval($freight).'</strong></td>';
$foot.='<td></td>';    
$foot.='</tr>';
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>Fractional Discount:</strong></td>';
$foot.='<td><input type="text" maxlength="6" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="less" value="'.getfloatval($less).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="lessd" class="text-right"><strong>'.getfloatval($less).'</strong></td>';
$foot.='<td></td>';    
$foot.='</tr>';
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>Grand Total:</strong></td>';
$foot.='<td></td>'; 
$foot.='<td id="grtotal" class="text-right"><strong>'.getfloatval($gtotal).'</strong></td>';
$foot.='<td></td>';    
$foot.='</tr>';    
}else{
$body.='<tr>';
$body.='<td colspan="7" class="text-center">There are no Service Item!</td>';
$body.='</tr>'; 
} 
}else{
$body.='<tr>';
$body.='<td colspan="7" class="text-center">There are no Service Item!</td>';
$body.='</tr>';
}
    
$body.="<script>";
$body.="$('.accordian-body').on('show.bs.collapse', function () {";
$body.="$(this).closest('table')";
$body.=".find('.collapse.in')";
$body.=".not(this)";
$body.=".collapse('toggle')";
$body.="})";
$body.="</script>";

if(isset($_SESSION['axes_service'])){
$buton.='<br>';    
$buton.='<div class="col-md-6">';
$buton.='<input type="button" id="emptycart" class="btn btn-flat bg-red btn-sm" value="Empty"/></div>';
$buton.='<div class="col-md-6 text-right">';   
$buton.='<input type="button" id="save_service" class="btn btn-flat bg-purple btn-sm" value="Checkout"/>'; 
$buton.='</div>';
}

if(isset($_POST['body'])){
echo $body;
}elseif(isset($_POST['foot'])){
echo $foot;
}elseif(isset($_POST['buton'])){
echo $buton;    
}
exit; 