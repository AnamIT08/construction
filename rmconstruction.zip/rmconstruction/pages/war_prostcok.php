<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='blank_page.php';   
$cuPage='blank_page.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='waaranty';
$menuh='Warranty Management';
$phead='prostcok';
$page='Warranty Stock';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Warranty Product Stock Status</h3>
</div>
<div class="box-body">    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped table-hover table_list" id="datarec">
<thead>
<tr>
<th rowspan="2" style="width:40px;" class="text-center">SN</th>
<th rowspan="2" style="width:80px;">Image</th>
<th rowspan="2">Name</th>
<th rowspan="2">SKU</th>   
<th colspan="3" class="text-center">Stock Details</th>     
<th rowspan="2" class="text-center">Available</th>
<th colspan="3" class="text-center">Bad Stock Details</th>    
</tr>
<tr>
<th class="text-center">In</th>
<th class="text-center">Out</th>   
<th class="text-center">Delivered</th>   
<th class="text-center">In</th>
<th class="text-center">Out</th>   
<th class="text-center">Available</th>   
</tr>    
</thead>    
<tbody>
<?php
$tin=0; $tout=0; $tdqty=0;$tavqty=0; $tbin=0; $tbout=0; $tbavqty=0;  
//$sql="SELECT wst.pid,itm.name,itm.image,itm.code,wst.colid,wst.sizid,wst.p_in,wst.dqty,wst.p_out,wst.avqty,wst.b_in,wst.b_out,wst.bavqty FROM (SELECT pid,colid,sizid,SUM(p_in+p_out) AS p_in,SUM(p_out) AS p_out,SUM(IF(d_status!=0,p_out,0)) AS dqty,SUM((p_in+p_out)-p_out) AS avqty,SUM(IFNULL(b_in,0)) AS b_in,SUM(IFNULL(b_out,0)) AS b_out,SUM(IFNULL(b_in,0)-IFNULL(b_out,0)) AS bavqty FROM tbl_waranty GROUP BY pid,colid,sizid) wst LEFT JOIN (SELECT id,name,image,code FROM tbl_item) itm ON itm.id=wst.pid ORDER BY name ASC";
$sql="SELECT wst.pid,itm.name,itm.image,itm.code,wst.colid,wst.sizid,wst.p_in,wst.dqty,wst.p_out,wst.avqty,wst.b_in,wst.b_out,wst.bavqty FROM (SELECT pid,colid,sizid,SUM(p_in+p_out) AS p_in,SUM(p_out) AS p_out,SUM(IF(d_status!=0,p_out,0)) AS dqty,SUM((p_in+p_out)-p_out) AS avqty,SUM(IFNULL(b_in,0)) AS b_in,SUM(IFNULL(b_out,0)) AS b_out,SUM(IFNULL(b_in,0)-IFNULL(b_out,0)) AS bavqty FROM (SELECT pid,colid,sizid,p_in,p_out,d_status,b_in,b_out FROM tbl_waranty WHERE brid='$brid') stwar GROUP BY pid,colid,sizid) wst LEFT JOIN (SELECT id,name,image,code FROM tbl_item) itm ON itm.id=wst.pid ORDER BY name ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$tin+=$row['p_in']; $tout+=$row['p_out']; $tdqty+=$row['dqty'];$tavqty+=$row['avqty']; $tbin+=$row['b_in']; $tbout+=$row['b_out']; $tbavqty+=$row['bavqty'];     
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td class="text-center"><img src="../img/product/<?php if(empty($row['image'])){echo "no_image.png";}else{echo $row['image'];} ?>" height="40px" width="40px"></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['code']; ?></td>   
<td class="text-center"><?php echo $row['p_in']; ?></td>
<td class="text-center"><?php echo $row['p_out']; ?></td>
<td class="text-center"><?php echo $row['dqty']; ?></td> 
<td class="text-center"><?php echo $row['avqty']; ?></td>
<td class="text-center"><?php echo $row['b_in']; ?></td>
<td class="text-center"><?php echo $row['b_out']; ?></td>
<td class="text-center"><?php echo $row['bavqty']; ?></td>    
</tr>    
<?php } ?>     
</tbody>
<tfoot>
<tr>
<td class="text-center" colspan="4"><strong>-Total-</strong></td>
<td class="text-center"><strong><?php echo $tin; ?></strong></td>
<td class="text-center"><strong><?php echo $tout; ?></strong></td>
<td class="text-center"><strong><?php echo $tdqty; ?></strong></td> 
<td class="text-center"><strong><?php echo $tavqty; ?></strong></td>
<td class="text-center"><strong><?php echo $tbin; ?></strong></td>
<td class="text-center"><strong><?php echo $tbout; ?></strong></td>
<td class="text-center"><strong><?php echo $tbavqty; ?></strong></td>    
</tr>    
</tfoot>    
</table>    
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
});    
</script>    
<!-- /page script -->
</html>    