<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='inv_brtrcreate.php';   
$cuPage='inv_brtrcreate.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='inventor';
$menuh='Inventory';
$phead='bratra';
$page='Branch Transfer Create';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-7">
<div class="box box-solid">
<div class="box-body">
<div class="col-md-12">
<div class="row">
<div class="col-md-5">
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-truck"></span></span>     
<select class="form-control select2" name="ibrid" id="ibrid">
<?php if($brid==0){?>
<option selected value="0">No-Branch</option>    
<?php }else{ ?>    
<option value="0">No-Branch</option>
<?php } ?>    
<?php									
$query=mysqli_query($con,"SELECT * FROM tbl_branch ORDER BY name ASC")or die(mysqli_error($con));
while ($bra=mysqli_fetch_array($query)){
?>
<?php if($bra['id']==$brid){?>
<option selected value="<?php echo $bra['id'];?>"><?php echo $bra['name'];?></option>    
<?php }else{ ?>    
<option value="<?php echo $bra['id'];?>"><?php echo $bra['name'];?></option>    
<?php } ?>
<?php } ?>    
</select>
</div>    
</div>    
</div>
<div class="col-md-7">
<div class="form-group">  
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>
<input type="text" class="form-control search" placeholder="e.g. Product Code or Name" autocomplete="off">    
</div>
</div>    
</div>    
</div>
    
<div class="row">
<div class="cart cart-sm">     
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<thead>
<th width="30px" class="text-center">SN</th>
<th width="60px" class="text-center">Image</th>
<th width="450px">Product</th>
<th width="95px" class="text-center">Code</th>
<th width="60px" class="text-center">Quantity</th>    
<th width="30px" class="text-center"><i class="fa fa-paper-plane-o"></i></th>    
</thead>
</table>
<div class="cart-tra style-3 item" style="padding:0px;">    
<table class="table table-bordered table-striped results" style="margin-bottom: 0;">    
<tbody id="traitem">

</tbody>    
</table>
</div>   
</div>    
</div>    
    
</div>    
</div>
</div>
</div>
<div class="col-md-5">
<div class="box box-solid">
<div class="box-body">

<div class="col-md-12">

<div class="row">
<div class="cart cart-sm">     
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<thead>
<th width="30px">SN</th>
<th width="326px">Item</th>
<th width="144px">Qty</th>
<th width="25px"><a class="empty" style="cursor: pointer;"><i class="fa fa-trash"></i></a></th>    
</thead>
</table>
<div class="cart-msg style-3 item" style="padding:0px;">    
<table class="table table-bordered table-striped" style="margin-bottom: 0;">    
<tbody id="itemdata">

</tbody>    
</table>
</div>
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<tfoot id="itemfoot">

</tfoot>
</table>    
</div>    
</div>    

<div class="row" id="serialpro">
        
</div>    
  
<div class="row" id="extra">
 
</div>    
    
</div> 
    
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->
<?php include('../layout/rside.php'); ?>    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
ReadItem();
    
function ReadItem(){
$.ajax({
url: "inv_trabritm.php",
method: "POST",
success: function(data) {
$('#traitem').html(data);
}
})
}

ReadData();
function ReadData(){
$.ajax({
url: "inv_tbrview.php",
method: "POST",
data:{ 
body:1
},
success: function(data){
$('#itemdata').html(data);
}
})

$.ajax({
url: "inv_tbrview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})
ReadButon();    
ReadIMEI();    
};

function ReadButon(){
$.ajax({
url: "inv_tbrview.php",
method: "POST",
data:{ 
buton:1
},
success: function(data){
$('#extra').html(data);
}
})	
}     
    
function ReadIMEI() {
$.ajax({
url: "inv_serialbrview.php",
method: "POST",
success: function(data) {
$('#serialpro').html(data);
}
})
}     

function ReadFoot(){
$.ajax({
url: "inv_tbrview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})	
}    
    
$(document).on('change', '#ibrid', function() {
var ids = $(this).val();
$.ajax({
url: "inv_trabritm.php",
method: "POST",
data: {
brid:ids
},
success: function(data) {
$('#traitem').html(data);
ReadData();
}
});
});    
    
$(document).ready(function() {
$(".search").keyup(function () {
var searchTerm = $(".search").val();
var listItem = $('.results tbody').children('tr');
var searchSplit = searchTerm.replace(/ /g, "'):containsi('")
    
$.extend($.expr[':'], {'containsi': function(elem, i, match, array){
return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
}
});
    
$(".results tbody tr").not(":containsi('" + searchSplit + "')").each(function(e){
$(this).css("display", "none");
});

$(".results tbody tr:containsi('" + searchSplit + "')").each(function(e){
$(this).css("display", "");
});

var jobCount = $('.results tbody tr[visible="true"]').length;
$('.counter').text(jobCount + ' item');

if(jobCount == '0') {$('.no-result').show();}
else {$('.no-result').hide();}
});
});

$(document).on('click', '.tranfer', function () {    
var id = $(this).attr('id');
pid_arr = $(this).attr('id');
unid = pid_arr.split("_");    
var unqid = unid[1];
   
$.ajax({
url: 'inv_trcart.php',
method: "POST",
data:{ 
additem: unqid
},
success: function(data){
ReadData();
}
});    
});
    
$(document).on('click', '.remove', function () {
var id = $(this).attr('id');
$.ajax({
url: 'inv_trcart.php',
method: "POST",
data:{ 
remove: id
},
success: function(data){
ReadData();
}
});    
});
    
$(document).on('blur', '.quantity', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var qty = parseFloat($('#qty_'+id[1]).val());
$.ajax({
url: 'inv_trcart.php',
method: "POST",
data:{ 
upqty: ids, qty: qty
},
dataType: 'json',
success: function(data){
$('#qty_'+id[1]).val(data[0]);
ReadFoot();    
ReadIMEI();    
}
});     
});

$(document).on('click', '.slremove', function () {
var id = $(this).attr('id');
$.ajax({
url: 'inv_trcart.php',
method: "POST",
data:{ 
removeitmsl: id
},
success: function(data){
ReadData();
}
});    
});    
    
$(document).on('blur', '.imei', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var imei = $('#imei_'+id[1]).val();   
$.ajax({
url: 'inv_trcart.php',
method: "POST",
data:{ 
upimei: ids, imeidata: imei
},
dataType: 'json',
success: function(data){
$('#imei_'+id[1]).val(data[0]);
}
});     
});    
    
$(document).on('keydown', '.imei', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids=id[1];
var ibrid = $('#ibrid').val();
    
$('.imei' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'inv_trcart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term, audimei:ids, ibrid:ibrid
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
var pid = ui.item.value;    
var srl = ui.item.label; // selected id to input
$(this).val(srl);
    
$.ajax({
url: 'inv_trcart.php',
method: "POST",
data:{ 
upimei: ids, imeidata: srl
},
success: function(data){
//$('#imei_'+id[1]).val(data[0]);
}
});

return false;
}
});
});    
    
$(document).on('click', '#emptycart', function () {
var id = $(this).attr('id');    
$.ajax({
url: 'inv_trcart.php',
method: "POST",
data:{ 
clear: id
},
success: function(data){
ReadData();
}
});    
});
    
$(document).on('click', function(e){    
if (!$(e.target).is(".right-side-add, .side-cont") && !$(e.target).parents(".right-side-add").length && $('.right-side-add').hasClass('open-right-add')) {
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');
}    
});
    
$(document).on('click', '#save_transfer', function() {     
toastr.options = {'positionClass': 'toast-top-center'};    
$.ajax({
url: 'inv_trcart.php',
method: "POST",
data:{ 
trbdata:1
},
dataType: 'json',
success: function(response) {
    
var sri = response[0];

if(sri>0){
toastr.warning('Missing Product Serial!!')	
return;
}    
    
trbsave(); 
}
});          
});    

function trbsave(){
var brid=$('#ibrid').val();    
$.ajax({
url: "inv_trcart.php",
method: "POST",
data:{savetra:1,brid:brid},
success: function(data){
$('#addsitem').html(data);
$('.right-side-add').toggle('slide', { direction: 'right' }, 300);     
}
})    
}
    
$(document).on('click', '#closepop', function() {    
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
});
    
$(document).on('click', '#fintrb', function() { 
var cash_data = $('.addtransfer input, .addtransfer select, .addtransfer textarea');
toastr.options = {'positionClass': 'toast-top-center'};    
if(!chek_error()){   
return;   
}
$.ajax({
url: "inv_trcart.php",
data: cash_data,
type: 'post',
dataType: 'json',    
beforeSend: function () {
chek_error();    
},    
success: function(data){
if(data.status === "success"){
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');
ReadItem();    
ReadData();    
toastr.success(data.message);    
}else{
toastr.error(data.message);    
}         
}
})    
});    
</script>
<!-- /page script -->
</html>    