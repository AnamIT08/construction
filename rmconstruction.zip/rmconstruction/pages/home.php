<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='home.php'; 
$cuPage='home.php';
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='home';
if(get_fild_data('tbl_setting','1','sval')==0){$menuh = 'Dashboard';}else{$menuh = 'ড্যাশবোর্ড';}
$phead='home';
if(get_fild_data('tbl_setting','1','sval')==0){$page = 'Dashboard';}else{$page = 'ড্যাশবোর্ড';}
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php
if(isset($_POST['ibrid']) && $_POST['ibrid']!=''){
$ibrid=$_POST['ibrid'];    
}else{
$ibrid=$brid;    
}
?> 
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
<!-- Main row -->
<div class="row">
    
<div class="col-md-4 col-xs-12 " >
<div class="box " style="height: 458px;">
<div class="box-header">
<i class="fa fa-bell"></i>

<h3 class="box-title">
Notifications
</h3>
</div>
<div class="box-body" >
<div class="col-md-12 no-padding db-notification-container" style="">
<table id="dash_notifications" class="table notification_table">
    
</table>
</div>
</div>

</div> 
</div>    

<div class="col-md-8 shortcuts">
<div class="row">
<div class="col-md-3 col-xs-6">
<!-- small box -->
<a href="">
<div class="small-box">
<div class="ribbon"><span>Pending</span></div>
<div class="icon">
<i class="fa fa-handshake-o"></i>
</div>
<div class="inner">
<h3 id="crm-count">0</h3>
<p>CRM</p>
</div>

</div>
</a>
</div>
<div class="col-md-3 col-xs-6">
<!-- small box -->
<a href="">
<div class="small-box ">
<div class="ribbon"><span>Pending</span></div>
<div class="inner">
<h3 id="lead-count">0</h3>
<p>Leads</p>
</div>
<div class="icon">
<i class="fa fa-sun-o"></i>
</div>
</div>
</a>
    
</div>

<div class="col-md-3 col-xs-6">

<a href="">
<!-- small box -->
<div class="small-box ">
<div class="ribbon"><span>Pending</span></div>
<div class="inner">
<h3 id="opportunity-count">0</h3>
<p>Opportunities</p>
</div>
<div class="icon">
<i class="fa fa-rocket"></i>
</div>
</div>
</a>

</div>
<div class="col-md-3 col-xs-6">

<a href="">
<!-- small box -->
<div class="small-box">
<div class="ribbon"><span>Today</span></div>
<div class="icon">
<i class="fa fa-shopping-cart"></i>
</div>
<div class="inner">
<h3 id="sale-count">0</h3>
<p>Sales</p>
</div>
</div>
</a>

</div>


<div class="clearfix"></div>
</div>
<div class = "nav-tabs-custom enquiry_tab" style="box-shadow: none;border-radius: 0;border: 1px solid #d9d7d7;">
<ul class = "nav nav-tabs" style="    background: linear-gradient(to bottom,#00a3e3 0,#00305d 200%);border-radius: 0;">
<li class = "active">
<a href = "#enqueries_block" data-toggle = "tab" class="text-uppercase"><i class = "fa fa-inbox" aria-hidden = "true"></i> Enquiries</a>
</li>

<li >
<a href = "#target_achiement_block" data-toggle = "tab" onclick="setTimeout(validate_target_chart_filter, 100)"><i class = "fa fa-trophy" aria-hidden = "true"></i> Target & Achievements</a>
</li>

</ul>
<div class = "tab-content" style="height: 302px;">
<div class = "active tab-pane" id = "enqueries_block">
<style>
    .db_enq_filter td{
        padding-right:3px;   
    }
    .enqueries_block_wrapper .created_on_text{
        font-size: 11px;
        margin-bottom: 0px;
        color: #999;
        text-transform: none !important;
    }
    .enqueries_block_wrapper .name_tag{
        width: 35px;
        margin: 0;
        text-align: center;
        height: 35px;
        padding-top: 5px;
        font-size: 18px;
        font-weight: bold;
        border-radius: 50%;
    }
    .enqueries_block_wrapper .enq_table td{
        border-right: 0px ;
        border-left: 0px ;
    }
    .enqueries_block_wrapper .enq_table{
        border: 1px solid #e8e6e6;
    }
    .enqueries_block_wrapper .statusbox{
        font-weight: bold;
        text-transform: uppercase;
        font-size: 15px;
        background: #3c8dbc;
        color: #fff;
        padding: 5px;
    }
    .db_enq_table_div::-webkit-scrollbar-track {
        background-color: #fff;
    }
    .db_enq_table_div::-webkit-scrollbar {
        width: 6px;
        background-color: #fff;
    }
    .db_enq_table_div::-webkit-scrollbar-thumb {
        border-radius: 10px;
        background-color: #ddd;
    }
    .db_enq_table_div{
        max-height: 173px;
        overflow: auto;

    }

</style>
<div class="row">
<div class="col-md-11">
<form action="" id="db_enquiry_form" onsubmit="return false" method="post" accept-charset="utf-8">
<table class="db_enq_filter">
<tr>
<td></td>
<td style="">
<div class="form-group">
<label>Play By</label>
<select name="db_enquiry_member" id="db_enquiry_member" class="form-control text-uppercase">
<?php    
$query=mysqli_query($con,"SELECT id,name FROM tbl_user ORDER BY name ASC")or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
?>
<?php if($row['id']==$aid){?>
<option selected value="<?php echo $row['id'];?>"><?php echo $row['name'];?></option>
<?php }else{ ?>    
<option value="<?php echo $row['id'];?>"><?php echo $row['name'];?></option>
<?php } ?>    
<?php } ?>
</select>
</div>
</td>
<td style="width: 123px;">
<div class="form-group">
<label>Date From</label>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
<input type="text" value="<?php echo date('Y').'-'.date('m').'-01';?>" id="db_enquiry_date_from" class="form-control filter_date" placeholder="FROM DATE" readonly="true"  />
</div>
</div>
</td>
<td style="width: 123px;">
<div class="form-group">
<label>Date To</label>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
<input type="text" value="<?php echo $today; ?>" id="db_enquiry_date_to" class="form-control filter_date" placeholder="TO DATE" readonly="true"  />
</div>
</div>
</td>
<td>
<div class="form-group" style="padding-top: 23px;">
<input type="button" value="Enquiries" id="db_enquiry_submit" class="btn btn-flat bg-purple " onclick="get_enquiries_list(1)"  />
 <input type="button" value="Follow-ups" id="db_enquiry_submit2" class="btn btn-flat bg-purple " onclick="get_enquiries_list(2)"  />
</div>
</td>
</tr>
</table>
</form>    
</div>
<div class="col-md-1 form-group text-right">
<a class="label label-success bg-purple text-uppercase" onclick="load_enquiry_form()"><i class="fa fa-plus"></i> New</a>
</div>
</div>
<div class="row enqueries_block_wrapper"></div>
<script>
function get_enquiries_list(type) {
try {
var error = '';
var branch = $('#db_enquiry_form').find('#db_enquiry_branch').val();
var member = $('#db_enquiry_form').find('#db_enquiry_member').val();
var date_from = $('#db_enquiry_form').find('#db_enquiry_date_from').val();
var date_to = $('#db_enquiry_form').find('#db_enquiry_date_to').val();
if(!type)type=1;
if (!checkValueExists(branch))
//error = error + 'Branch is required<br>';
if (!checkValueExists(date_from))
error = error + 'Date from is required<br>';
if (!checkValueExists(date_to))
error = error + 'Date to is required<br>';
if (error) {
toaster(error);
return false;
} else {

$('#db_enquiry_submit').prop('disabled', true);
$('#db_enquiry_submit2').prop('disabled', true);
$('.enqueries_block_wrapper').html('<div class="col-md-12">Loading...</div>');
$.ajax({
type: "POST",
url: "axe_enquirylist.php",
cache: false,
dataType: 'json',
data: {'branch': branch, 'member': member, 'date_from': date_from, 'date_to': date_to,'type':type},
timeout: 15000,
success: function (data)
{
$('.enqueries_block_wrapper').html(data['result']);
$('#db_enquiry_submit').prop('disabled', false);
$('#db_enquiry_submit2').prop('disabled', false);
},
error: function (jqXHR, textStatus, errorThrown) {
$('.enqueries_block_wrapper').html('<div class="col-md-12">Error</div>');

$('#db_enquiry_submit').prop('disabled', false);
$('#db_enquiry_submit2').prop('disabled', false);
}

});
}
} catch (exception) {
alert(exception);
}

return false;
}
function load_enquiry_form(id) {
$("#public_modal .modal-content").html('Loading..');
$("#public_modal").addClass('common_modal_mediaum');
$.ajax({
type: "POST",
url: "",
cache: false,
data: {'id': id},
timeout: 15000,
success: function (data)
{
$("#public_modal").modal('show');
$("#public_modal .modal-content").html(data);
},
error: function (jqXHR, textStatus, errorThrown) {
alert("Error");
}
});
}
</script>                                    
</div>
<div class = "tab-pane" id = "target_achiement_block">
<div class="row">
<div class="col-md-6">
<form action="" id="target_chart_form" method="post" accept-charset="utf-8">
<div class=" form-group">
<table class="chart_filter">
<tr>
<td></td>
</tr>
</table>
</div>
</form> 
</div>
<div class="col-md-6 text-right">
<a style="color: #0084bf"><i class="fa fa-square"></i> Target</a>&nbsp;&nbsp;<a style="color: #009900"><i class="fa fa-square"></i> Achievement</a>   
</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-12 target_chart_container nopadding" style="overflow: hidden"></div>
</div>
</div> 
</div>

</div>
</div>
</div>
</div>
<style>
.cash_balance_box{
min-height: 71px;
margin-bottom: 1px;
}
.cash_balance_box .info-box-icon{
height: 71px;
width: 50px;
line-height: 71px;
font-size: 18px;
}
.cash_balance_box .info-box-content{
margin-left: 50px;
text-transform: uppercase;
}
.cash_balance_box .info-box-number{
font-size: 15px;
}
#overview_services th{
padding: 5px;
}
</style>
<div class="row bussiness_overview_wrapper">
<section class="col-lg-12">
<div class="box ">
<div class="box-header">
<i class="fa fa fa-pie-chart"></i>
<h3 class="box-title">
Business Overview
</h3>
</div>
<div class="box-body">
<div class="row">   
<form action="" id="bussiness_overview_form" onsubmit="return load_bussiness_overview()" method="post" accept-charset="utf-8">
<div class="col-md-12 form-group table-responsive">
<table class="chart_filter">
<tr>
<td>
<select name="bussiness_overview_branch" id="bussiness_overview_branch" class="form-control select2">
<option <?php if($ibrid=='A'){echo 'selected';}?> value="A">-All Branch-</option>
<option <?php if($ibrid=='0'){echo 'selected';}?> value="0">-Main Branch-</option>    
<?php    
$querybr=mysqli_query($con,"SELECT id,name FROM tbl_branch ORDER BY name ASC")or die(mysqli_error($con));
while ($rowbr=mysqli_fetch_array($querybr)){
?>
<?php if($rowbr['id']==$ibrid){?>
<option selected value="<?php echo $rowbr['id'];?>"><?php echo $rowbr['name'];?></option>
<?php }else{ ?>    
<option value="<?php echo $rowbr['id'];?>"><?php echo $rowbr['name'];?></option>
<?php } ?>    
<?php } ?>
</select>
</td>
<td>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
<input type="text" value="<?php echo date('Y').'-'.date('m').'-01';?>" id="bussiness_overview_date_from" class="form-control filter_date" placeholder="FROM DATE" readonly="true"  />
</div></td>
<td>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
<input type="text" value="<?php echo $today; ?>" id="bussiness_overview_date_to" class="form-control filter_date" placeholder="TO DATE" readonly="true"  />
</div></td>
<td><input type="submit" value="Generate" id="done" class="btn btn-flat bg-purple" /></td>
</tr>
</table>
</div>
</form>
</div>
<div class="row bussiness_overview_results"></div>
</div>
</div>
</section>
</div>
<div class="row bussiness_insights_wrapper"></div>
    
<div class="row">
<section class="col-lg-12">
<div class="box ">
<div class="box-header">
<i class="fa fa fa-line-chart"></i>

<h3 class="box-title">
Sales by Employees
</h3>
</div>
<div class="box-body sale_charts">
<div class="row">
<style>
.chart_filter td{
padding-right: 5px;
}
.chart_filter .form-control{
min-width: 80px;
}
</style>
<form action="" id="sale_chart_form" onsubmit="return load_sales_chart_by_emp()" method="post" accept-charset="utf-8">
<div class="col-md-12 form-group table-responsive">
<table class="chart_filter">
<tr>
<td><select name="graph_type" id="graph_type" class="form-control">
<option value="1">Sale</option>
<option value="2">Margin</option>
</select>
</td>
<td><select name="branch" id="branch" class="form-control" onchange="get_member_list()">
<option <?php if($ibrid=='A'){echo 'selected';}?> value="A">-All Branch-</option>
<option <?php if($ibrid=='0'){echo 'selected';}?> value="0">-Main Branch-</option>    
<?php    
$querybr=mysqli_query($con,"SELECT id,name FROM tbl_branch ORDER BY name ASC")or die(mysqli_error($con));
while ($rowbr=mysqli_fetch_array($querybr)){
?>
<?php if($rowbr['id']==$ibrid){?>
<option selected value="<?php echo $rowbr['id'];?>"><?php echo $rowbr['name'];?></option>
<?php }else{ ?>    
<option value="<?php echo $rowbr['id'];?>"><?php echo $rowbr['name'];?></option>
<?php } ?>    
<?php } ?>
</select>
</td>
<td><select name="member" id="member" class="form-control">
<option value="">All</option>
</select>
</td>
<td><div class="input-group">
<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
<input type="text" name="date_from" value="11-01-2020" id="date_from" class="form-control filter_date" placeholder="FROM DATE" readonly="readonly"  />
</div></td>
<td>
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
<input type="text" name="date_to" value="11-02-2020" id="date_to" class="form-control filter_date" placeholder="TO DATE" readonly="readonly"  />
</div></td>
<td><input type="submit" name="done" value="Generate" id="done" class="btn btn-flat bg-purple "  />
</td>
</tr>
</table>
</div>
</form>                
<div class="col-md-12 sales_chart_members  form-group text-right"></div>  
<div class="col-md-12">
<div class="col-md-12 sales_chart_container nopadding" style="overflow: hidden"></div>
</div>
</div>

    
    
</div>
</div>
</section>
</div>                    

<div class="row">
<style>
.chart_option_labels{
padding-left: 0; list-style: none;   
font-size: 10px;
}
.chart_option_labels i{
color:#85141d
}
#chart_sales_ticketing,#chart_sales_hotel,#chart_sales_others,#chart_sales_visa{
height: 250px;z-index: 100;
}
</style>
    
<section class="col-lg-12">
<div class="box ">
<div class="box-header">
<i class="fa fa fa-pie-chart"></i>
<h3 class="box-title">
Purchase Graph
</h3>
</div>
<div class="box-body">
<div class="row">
<form action="" id="purchase_graph_form" onsubmit="return load_purchase_graph()" method="post" accept-charset="utf-8">
<div class="col-md-12 form-group table-responsive">
<table class="chart_filter">
<tr>
<td>
<select name="purchase_graph_branch" id="purchase_graph_branch" class="form-control">
<option <?php if($ibrid=='A'){echo 'selected';}?> value="A">-All Branch-</option>
<option <?php if($ibrid=='0'){echo 'selected';}?> value="0">-Main Branch-</option>    
<?php    
$querybr=mysqli_query($con,"SELECT id,name FROM tbl_branch ORDER BY name ASC")or die(mysqli_error($con));
while ($rowbr=mysqli_fetch_array($querybr)){
?>
<?php if($rowbr['id']==$ibrid){?>
<option selected value="<?php echo $rowbr['id'];?>"><?php echo $rowbr['name'];?></option>
<?php }else{ ?>    
<option value="<?php echo $rowbr['id'];?>"><?php echo $rowbr['name'];?></option>
<?php } ?>    
<?php } ?>
</select>
</td>
<td>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
<input type="text" value="<?php echo date('Y').'-'.date('m').'-01';?>" id="purchase_graph_date_from" class="form-control filter_date_pie" placeholder="FROM DATE" readonly="true"  />
</div></td>
<td>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
<input type="text" value="<?php echo $today; ?>" id="purchase_graph_date_to" class="form-control filter_date_pie" placeholder="TO DATE" readonly="true"  />
</div></td>
<td><input type="submit" value="Generate" id="done" class="btn btn-flat bg-purple "  />
</td>
</tr>
</table>
</div>
</form>            
</div>
<div class="row" >
<div class="col-md-3">
<div class="row">
<div class="col-md-12 text-center" ><label>TICKETING & BAGGAGE</label></div>

<div class="col-md-9" id="chart_sales_ticketing" ></div>
<div class="col-md-3">
<ul id="chart_sales_ticketing_keys" class="chart_option_labels"></ul>
</div>
<div class="col-md-12 hidden chart_sales_ticketing_msg"><p class="text-center" style="font-size: 12px;margin-top: 50px;margin-bottom: 50px;color: #ccc;">- No Records Found - </p>
</div>
</div>

</div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12  text-center"><label>VISA & VISA MESSAGE</label></div>

<div class="col-md-9" id="chart_sales_visa"></div>
<div class="col-md-3">
<ul id="chart_sales_visa_keys" class="chart_option_labels"></ul>
</div>
<div class="col-md-12 hidden chart_sales_visa_msg"><p class="text-center" style="font-size: 12px;margin-top: 50px;margin-bottom: 50px;color: #ccc;">- No Records Found - </p></div>

</div>

</div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12  text-center"><label>HOTEL</label></div>
<div class="col-md-9" id="chart_sales_hotel" ></div>
<div class="col-md-3">
<ul id="chart_sales_hotel_keys" class="chart_option_labels"></ul>

</div>
<div class="col-md-12 hidden chart_sales_hotel_msg"><p class="text-center" style="font-size: 12px;margin-top: 50px;margin-bottom: 50px;color: #ccc;">- No Records Found - </p></div>
</div>

</div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12  text-center"><label>INSURANCE & OTHERS</label></div>

<div class="col-md-9" id="chart_sales_others"></div>
<div class="col-md-3">
<ul id="chart_sales_others_keys" class="chart_option_labels"></ul>
</div>
<div class="col-md-12 hidden chart_sales_others_msg"><p class="text-center" style="font-size: 12px;margin-top: 50px;margin-bottom: 50px;color: #ccc;">- No Records Found - </p></div>

</div>
</div>
</div>
</div>
</div>
</section>
</div>
    
<div class="row">
<section class="col-lg-12">
<div class="box ">
<div class="box-header">
<i class="fa fa fa-pie-chart"></i>
<h3 class="box-title">
Outstanding Graph
</h3>
</div>
<div class="box-body">
<div class="row">

<form action="" id="outstanding_graph_form" onsubmit="return load_outstanding_graphs()" method="post" accept-charset="utf-8">
<div class="col-md-12 form-group table-responsive">
<table class="chart_filter">
<tr>

<td>
<select name="outstanding_graph_branch" id="outstanding_graph_branch" class="form-control">
<option <?php if($ibrid=='A'){echo 'selected';}?> value="A">-All Branch-</option>
<option <?php if($ibrid=='0'){echo 'selected';}?> value="0">-Main Branch-</option>    
<?php    
$querybr=mysqli_query($con,"SELECT id,name FROM tbl_branch ORDER BY name ASC")or die(mysqli_error($con));
while ($rowbr=mysqli_fetch_array($querybr)){
?>
<?php if($rowbr['id']==$ibrid){?>
<option selected value="<?php echo $rowbr['id'];?>"><?php echo $rowbr['name'];?></option>
<?php }else{ ?>    
<option value="<?php echo $rowbr['id'];?>"><?php echo $rowbr['name'];?></option>
<?php } ?>    
<?php } ?>
</select>
</td>
<td>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
<input type="text" value="<?php echo date('Y').'-'.date('m').'-01';?>" id="outstanding_graph_date_from" class="form-control filter_date" placeholder="FROM DATE" readonly="true"  />
</div>
</td>
<td>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
<input type="text" value="<?php echo $today; ?>" id="outstanding_graph_date_to" class="form-control filter_date" placeholder="TO DATE" readonly="true"  />
</div></td>
<td><input type="submit" value="Generate" id="done" class="btn btn-flat bg-purple "  /></td>
</tr>
</table>
</div>
</form>            
</div>
<div class="row" >
<div class="col-md-12">
<div class="col-md-12 text-right form-group">
<a style="color: #0092cc"><i class="fa fa-square"></i> Sales</a>&nbsp;&nbsp;
<a style="color: #029602"><i class="fa fa-square"></i> Receipts</a>
<a style="color: #c3b533"><i class="fa fa-square"></i> Outstanding</a>
</div></div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12 text-center" ><label>TICKETING & BAGGAGE</label></div>

<div class="col-md-12" id="outstanding_sales_ticketing"></div>

<div class="col-md-12 hidden outstanding_sales_ticketing_msg"><p class="text-center" style="font-size: 12px;margin-top: 50px;margin-bottom: 50px;color: #ccc;">- No Records Found - </p></div>

</div>

</div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12  text-center"><label>VISA & VISA MESSAGE</label></div>

<div class="col-md-12" id="outstanding_sales_visa"></div>

<div class="col-md-12 hidden outstanding_sales_visa_msg"><p class="text-center" style="font-size: 12px;margin-top: 50px;margin-bottom: 50px;color: #ccc;">- No Records Found - </p></div>

</div>

</div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12  text-center"><label>HOTEL</label></div>

<div class="col-md-12" id="outstanding_sales_hotel"></div>


<div class="col-md-12 hidden outstanding_sales_hotel_msg"><p class="text-center" style="font-size: 12px;margin-top: 50px;margin-bottom: 50px;color: #ccc;">- No Records Found - </p></div>
</div>

</div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12  text-center"><label>INSURANCE & OTHERS</label></div>

<div class="col-md-12" id="outstanding_sales_others"></div>

<div class="col-md-12 hidden outstanding_sales_others_msg"><p class="text-center" style="font-size: 12px;margin-top: 50px;margin-bottom: 50px;color: #ccc;">- No Records Found - </p></div>

</div>
</div>


</div>
</div>
</div>
</section>
</div>
    
<!-- /.row (main row) -->
<?php include('../layout/quick.php');?>     
</section>   
<!-- /.main content -->    
</div>

<?php include('../layout/footer.php');?>
<!-- page script -->
<script src="../plugins/chart/Chart.js"></script>
<input type='hidden' id='current_page_name' value='dashboard'/>
<script type="text/javascript">
$(document).ready(function () {
$('.filter_date').datepicker({format: "yyyy-mm-dd", autoclose: true, clearBtn: true, orientation: 'auto bottom', });
$('.filter_date_pie').datepicker({format: "yyyy-mm-dd", autoclose: true, clearBtn: true, orientation: 'auto top', });
refresh_dashboard();

setTimeout(function () {
get_enquiries_list();
}, 800);

setTimeout(function () {
load_bussiness_overview();
}, 1500);
setTimeout(function () {
$(".bussiness_insights_wrapper").load("axe_busincsid.php");
}, 1800);



setTimeout(function () {
load_sales_chart_by_emp();
}, 2000);
setTimeout(function () {
load_purchase_graph();
}, 2500);
setTimeout(function () {
load_outstanding_graphs();
}, 3000);
});
    
function refresh_dashboard() {
$.ajax({
type: "POST",
url: "axe_ref_dashboard.php",
cache: false,
dataType: 'json',
data: {'null_post': 1},
timeout: 15000,
success: function (data)
{
var norecords = '<p class="text-center" style="font-size: 25px;margin-top: 100px;color: #ccc;" >- No Records Found - </p>';
var norecords2 = '<p class="text-center" style="font-size: 20px;margin-top: 50px;color: #ccc;" >- No Notification Found - </p>';
if (data) {
if (data['dash_notifications'])
$('#dash_notifications').html(data['dash_notifications']);
else
$('#dash_notifications').html(norecords2);
//crm
if (data['crm_list'])
$('#crm-dashboard').html(data['crm_list']);
else
$('#crm-dashboard').html(norecords);
//leads
if (data['lead_list'])
$('#lead-dashboard').html(data['lead_list']);
else
$('#lead-dashboard').html(norecords);
//opprtunites
if (data['opportunity_list'])
$('#opportunity-dashboard').html(data['opportunity_list']);
else
$('#opportunity-dashboard').html(norecords);
//sales
if (data['sales_list'])
$('#sale-dashboard').html(data['sales_list']);
else
$('#sale-dashboard').html(norecords);
//broadcasts
if (data['broadcast_list'])
$('#broadcast-dashboard').html(data['broadcast_list']);
else
$('#broadcast-dashboard').html(norecords);
//careers                    
if (data['dash_careers'])
$('#career-dashboard').html(data['dash_careers']);
else
$('#career-dashboard').html(norecords);
$('#attendance-dashboard').html(data['attendance_list']);
//counts
$('#crm-count').text(data['module_count']['crm']);
$('#lead-count').text(data['module_count']['leads']);
$('#opportunity-count').text(data['module_count']['opportunities']);
$('#sale-count').text(data['module_count']['sales']);
}

},
error: function (jqXHR, textStatus, errorThrown) {}

});
}

function load_bussiness_overview(){
var branch = $('#bussiness_overview_form').find('#bussiness_overview_branch').val();
var date_from = $('#bussiness_overview_form').find('#bussiness_overview_date_from').val();
var date_to = $('#bussiness_overview_form').find('#bussiness_overview_date_to').val();
$.ajax({
type: "POST",
url: "axe_busines_ovw.php",
cache: false,
data: {'branch': branch, 'date_from': date_from, 'date_to': date_to},
timeout: 15000,
dataType: 'json',
success: function (data)
{
$('.bussiness_overview_results').html(data['html']);
business_overview_graph(data['graph']['months'], data['graph']['values']);
},
error: function (jqXHR, textStatus, errorThrown) {
console.log(textStatus);
}

});
return false;
}

function business_overview_graph(months, monthvalues){
//['January', 'February', 'March', 'April', 'May', 'June', 'July']
//[65, 59, 80, 81, 56, 55, 40]

$('.business_overview_graph_div').html('<canvas id="business_overview_graph" style="height:250px"></canvas>');
var areaChartCanvas = $('#business_overview_graph').get(0).getContext('2d')
var areaChart = new Chart(areaChartCanvas)

var areaChartData = {
labels: months,
datasets: [
{
label: 'Net Income',
fillColor: '#c3b533',
strokeColor: '#c3b533',
pointColor: '#c3b533',
pointStrokeColor: '#c3b533',
pointHighlightFill: '#c3b533',
pointHighlightStroke: '#c3b533',
data: monthvalues
}
]
}

var areaChartOptions = {
//Boolean - If we should show the scale at all
showScale: true,
//Boolean - Whether grid lines are shown across the chart
scaleShowGridLines: false,
//String - Colour of the grid lines
scaleGridLineColor: 'rgba(0,0,0,.05)',
//Number - Width of the grid lines
scaleGridLineWidth: 1,
//Boolean - Whether to show horizontal lines (except X axis)
scaleShowHorizontalLines: true,
//Boolean - Whether to show vertical lines (except Y axis)
scaleShowVerticalLines: true,
//Boolean - Whether the line is curved between points
bezierCurve: true,
//Number - Tension of the bezier curve between points
bezierCurveTension: 0.3,
//Boolean - Whether to show a dot for each point
pointDot: false,
//Number - Radius of each point dot in pixels
pointDotRadius: 4,
//Number - Pixel width of point dot stroke
pointDotStrokeWidth: 1,
//Number - amount extra to add to the radius to cater for hit detection outside the drawn point
pointHitDetectionRadius: 20,
//Boolean - Whether to show a stroke for datasets
datasetStroke: true,
//Number - Pixel width of dataset stroke
datasetStrokeWidth: 2,
//Boolean - Whether to fill the dataset with a color
datasetFill: true,
//String - A legend template
legendTemplate: '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].lineColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
//Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
maintainAspectRatio: true,
//Boolean - whether to make the chart responsive to window resizing
responsive: true
}

//Create the line chart
areaChart.Line(areaChartData, areaChartOptions)
}    

function load_sales_chart_by_emp() {

$.ajax({
type: "POST",
url: "axe_saleschart.php",
cache: false,
dataType: 'json',
data: $('#sale_chart_form').serialize(),
timeout: 15000,
success: function (data)
{

sale_chart(data['chart_data']);
$('.sales_chart_members').html(data['member_icons']);
},
error: function (jqXHR, textStatus, errorThrown) {
console.log(textStatus);
}

});
return false;
}
    
function sale_chart(chart_data) {
$('.sales_chart_container').html('<canvas id="sale_chart_graph" style="height:253px"></canvas>');
var lineChartCanvas = $('#sale_chart_graph').get(0).getContext('2d');
var lineChart = new Chart(lineChartCanvas);
var options = {
//Boolean - If we should show the scale at all
showScale: true,
//Boolean - Whether grid lines are shown across the chart
scaleShowGridLines: false,
//String - Colour of the grid lines
scaleGridLineColor: 'rgba(0,0,0,.05)',
//Number - Width of the grid lines
scaleGridLineWidth: 1,
//Boolean - Whether to show horizontal lines (except X axis)
scaleShowHorizontalLines: true,
//Boolean - Whether to show vertical lines (except Y axis)
scaleShowVerticalLines: true,
//Boolean - Whether the line is curved between points
bezierCurve: true,
//Number - Tension of the bezier curve between points
bezierCurveTension: 0.3,
//Boolean - Whether to show a dot for each point
pointDot: true,
//Number - Radius of each point dot in pixels
pointDotRadius: 2,
//Number - Pixel width of point dot stroke
pointDotStrokeWidth: 1,
//Number - amount extra to add to the radius to cater for hit detection outside the drawn point
pointHitDetectionRadius: 20,
//Boolean - Whether to show a stroke for datasets
datasetStroke: true,
//Number - Pixel width of dataset stroke
datasetStrokeWidth: 2,
//Boolean - Whether to fill the dataset with a color
datasetFill: true,
//String - A legend template
legendTemplate: '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].lineColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
//Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
maintainAspectRatio: false,
//Boolean - whether to make the chart responsive to window resizing
responsive: true,
}

options.datasetFill = false;
lineChart.Line(chart_data, options);
}    

function load_purchase_graph(){
var branch = $('#purchase_graph_form').find('#purchase_graph_branch').val();
var date_from = $('#purchase_graph_form').find('#purchase_graph_date_from').val();
var date_to = $('#purchase_graph_form').find('#purchase_graph_date_to').val();
if (date_from && date_to) {
$('#purchase_graph_form').find('#done').val('Loading..');
$('#purchase_graph_form').find('#done').prop('disabled', 'true');
$.ajax({
type: "POST",
url: "axe_loadsalegraph.php",
cache: false,
data: {'branch': branch, 'date_from': date_from, 'date_to': date_to},
timeout: 15000,
'dataType': 'json',
success: function (data)
{
$('#purchase_graph_form').find('#done').val('generate');
$('#purchase_graph_form').find('#done').prop('disabled', false);
sales_graphs(data['ticketing_baggage']['data'], data['ticketing_baggage']['keys'], 'chart_sales_ticketing');
sales_graphs(data['visa_visa_message']['data'], data['visa_visa_message']['keys'], 'chart_sales_visa');
sales_graphs(data['hotel']['data'], data['hotel']['keys'], 'chart_sales_hotel');
sales_graphs(data['ins_otheres']['data'], data['ins_otheres']['keys'], 'chart_sales_others');
},
error: function (jqXHR, textStatus, errorThrown) {
alert(textStatus);
$('#purchase_graph_form').find('#done').val('generate');
$('#purchase_graph_form').find('#done').prop('disabled', false);
}
});
} else {
toaster('Date From and To is required')
}
return false;
}

function load_outstanding_graphs() {
var branch = $('#outstanding_graph_form').find('#outstanding_graph_branch').val();
var date_from = $('#outstanding_graph_form').find('#outstanding_graph_date_from').val();
var date_to = $('#outstanding_graph_form').find('#outstanding_graph_date_to').val();
if (date_from && date_to) {
$('#outstanding_graph_form').find('#done').val('Loading..');
$('#outstanding_graph_form').find('#done').prop('disabled', 'true');
$.ajax({
type: "POST",
url: "axe_outstgrapg.php",
cache: false,
data: {'branch': branch, 'date_from': date_from, 'date_to': date_to},
timeout: 15000,
'dataType': 'json',
success: function (data)
{
$('#outstanding_graph_form').find('#done').val('generate');
$('#outstanding_graph_form').find('#done').prop('disabled', false);
oustanding_graph(data['ticketing_baggage'], data['interval'], 'outstanding_sales_ticketing');
oustanding_graph(data['visa_visa_message'], data['interval'], 'outstanding_sales_visa');
oustanding_graph(data['hotel'], data['interval'], 'outstanding_sales_hotel');
oustanding_graph(data['ins_otheres'], data['interval'], 'outstanding_sales_others');
},
error: function (jqXHR, textStatus, errorThrown) {
$('#outstanding_graph_form').find('#done').val('generate');
$('#outstanding_graph_form').find('#done').prop('disabled', false);
}
});
} else {
toaster('Date From and To is required')
}

return false;
}

function oustanding_graph(data, date_interval, CanvasId)
{

var total_sales = data['total_sales'];
var total_receipt = data['total_receipt'];
var outstanding = data['outstanding'];
if (num(total_sales) > 0 || num(total_receipt) > 0 || num(outstanding) > 0) {
$('#' + CanvasId).html('<canvas id="' + CanvasId + '_canvas" style="height:250px"></canvas>');
$('#' + CanvasId).show();
$('.' + CanvasId + '_msg').addClass('hidden');
var areaChartData = {
labels: [date_interval, ],
datasets: [
{
label: 'Sales',
fillColor: '#0092cc',
strokeColor: '#0092cc',
pointColor: '#0092cc',
pointStrokeColor: '#0092cc',
pointHighlightFill: '#0092cc',
pointHighlightStroke: '#0092cc',
data: [total_sales]
},
{
label: 'Receipts',
fillColor: '#029602',
strokeColor: '#029602',
pointColor: '#029602',
pointStrokeColor: '#029602',
pointHighlightFill: '#029602',
pointHighlightStroke: '#029602',
data: [total_receipt]
},
{
label: 'Outstanding',
fillColor: '#c3b533',
strokeColor: '#c3b533',
pointColor: '#c3b533',
pointStrokeColor: '#c3b533',
pointHighlightFill: '#c3b533',
pointHighlightStroke: '#c3b533',
data: [outstanding]
}
]
}

var barChartCanvas = $('#' + CanvasId + '_canvas').get(0).getContext('2d');
var barChart = new Chart(barChartCanvas);
var barChartData = areaChartData;
var barChartOptions = {
//Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
scaleBeginAtZero: true,
//Boolean - Whether grid lines are shown across the chart
scaleShowGridLines: true,
//String - Colour of the grid lines
scaleGridLineColor: 'rgba(0,0,0,.05)',
//Number - Width of the grid lines
scaleGridLineWidth: 1,
//Boolean - Whether to show horizontal lines (except X axis)
scaleShowHorizontalLines: true,
//Boolean - Whether to show vertical lines (except Y axis)
scaleShowVerticalLines: true,
//Boolean - If there is a stroke on each bar
barShowStroke: true,
//Number - Pixel width of the bar stroke
barStrokeWidth: 2,
//Number - Spacing between each of the X value sets
barValueSpacing: 5,
//Number - Spacing between data sets within X values
barDatasetSpacing: 1,
//String - A legend template
legendTemplate: '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<datasets.length; i++){%><li><span style="background-color:<%=datasets[i].fillColor%>"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>',
//Boolean - whether to make the chart responsive
responsive: true,
tooltipFontSize: 10,
maintainAspectRatio: true
}

barChartOptions.datasetFill = false;
barChart.Bar(barChartData, barChartOptions);
} else {

$('#' + CanvasId).html('');
$('#' + CanvasId).hide();
$('.' + CanvasId + '_msg').removeClass('hidden');
}
}    

function sales_graphs(PieData, keyVals, canvasId){

if (PieData.length > 0 && canvasId) {
$('#' + canvasId).html('<canvas id="' + canvasId + '_canvas" style="height:250px"></canvas>');
$('.' + canvasId + '_msg').addClass('hidden');
$('#' + canvasId).show();
$('#' + canvasId + '_keys').show();
// Get context with jQuery - using jQuery's .get() method.
var pieChartCanvas = $('#' + canvasId + '_canvas').get(0).getContext('2d');
var pieChart = new Chart(pieChartCanvas);
var pieOptions = {
//Boolean - Whether we should show a stroke on each segment
segmentShowStroke: true,
//String - The colour of each segment stroke
segmentStrokeColor: '#fff',
//Number - The width of each segment stroke
segmentStrokeWidth: 2,
//Number - The percentage of the chart that we cut out of the middle
percentageInnerCutout: 50, // This is 0 for Pie charts
//Number - Amount of animation steps
animationSteps: 100,
//String - Animation easing effect
animationEasing: 'easeOutBounce',
//Boolean - Whether we animate the rotation of the Doughnut
animateRotate: true,
//Boolean - Whether we animate scaling the Doughnut from the centre
animateScale: false,
//Boolean - whether to make the chart responsive to window resizing

// Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
maintainAspectRatio: true,
tooltipFontSize: 9,
responsive: true,
//String - A legend template
legendTemplate: '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<segments.length; i++){%><li><span style="background-color:<%=segments[i].fillColor%>"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>'
}
//Create pie or douhnut chart
// You can switch between pie and douhnut using the method below.
pieChart.Doughnut(PieData, pieOptions);
if (keyVals) {
var htmls = '';
for (var i = 0; i < keyVals.length; i++) {
htmls = htmls + '<li><a><i style="color:' + keyVals[i]['color'] + '" class="fa fa-square"></i></a><small> ' + keyVals[i]['value'] + '</small></li>';
$('#' + canvasId + '_keys').html(htmls);
}
}
} else {

$('.' + canvasId + '_msg').removeClass('hidden');
$('#' + canvasId + '_keys').hide();
$('#' + canvasId).html('');
$('#' + canvasId).hide('');
}    
}
    
function validate_target_chart_filter() {

$.ajax({
type: "POST",
url: "axe_tagerghmem.php",
cache: false,
dataType: 'json',
data: $('#target_chart_form').serialize(),
timeout: 15000,
success: function (data)
{
if (data['is_graph'] == 1) {
target_chart(data['chart_data']);
} else {
$('.target_chart_container').html('<p>No Records Found</p>');
}
},
error: function (jqXHR, textStatus, errorThrown) {
console.log(textStatus);
}

});
return false;
}    
</script>    
<!-- /page script -->
</html>