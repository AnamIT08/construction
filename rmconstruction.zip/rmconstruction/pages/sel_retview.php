<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/invfunctions.php');
include ('../inc/cartfunctions.php');
$body='';
$foot='';
$buton='';
$s=0;
$totqty=0;


if(isset($_SESSION['axes_sereturn'])){
if(is_array($_SESSION['axes_sereturn'])){
$max=count($_SESSION['axes_sereturn']);
for($i=($max-1);$i>=0;$i=$i-1){
$unqid=$_SESSION['axes_sereturn'][$i]['unqid'];
$pid=$_SESSION['axes_sereturn'][$i]['pid'];    
$code=$_SESSION['axes_sereturn'][$i]['code'];
$name=$_SESSION['axes_sereturn'][$i]['name'];
$unit=$_SESSION['axes_sereturn'][$i]['unid'];
$col=$_SESSION['axes_sereturn'][$i]['col'];
if($col==0){$col='';}    
$siz=$_SESSION['axes_sereturn'][$i]['siz'];
if($siz==0){$siz='';}        
$cost=$_SESSION['axes_sereturn'][$i]['cost']; 
$sold=$_SESSION['axes_sereturn'][$i]['qty'];
$prqty=$_SESSION['axes_sereturn'][$i]['prqty'];
$qty=$_SESSION['axes_sereturn'][$i]['rqty'];    
$price=$_SESSION['axes_sereturn'][$i]['price'];
$disp=$_SESSION['axes_sereturn'][$i]['disp'];
$disf=$_SESSION['axes_sereturn'][$i]['disf'];    
$disamo=$_SESSION['axes_sereturn'][$i]['disamo'];
$wday=$_SESSION['axes_sereturn'][$i]['wday'];
$pnote=$_SESSION['axes_sereturn'][$i]['pnote'];    
$subtot=$_SESSION['axes_sereturn'][$i]['subtot'];

if($col=='' && $siz==''){
$name=$name;    
}elseif($col!='' && $siz==''){
$name= $name.' '.get_fild_data('tbl_color',$col,'name');    
}elseif($col=='' && $siz!=''){
$name= $name.' '.get_fild_data('tbl_size',$siz,'sval');    
}elseif($col!='' && $siz!=''){    
$name= $name.' '.get_fild_data('tbl_color',$col,'name').' '.get_fild_data('tbl_size',$siz,'sval');    
}    
$s+=1;
$totqty+=$qty;

$body.='<tr>';
$body.='<td class="text-center" style="width:35px; max-width:35px;">'.$s.'</td>';
$body.='<td style="width:300px; max-width:300px;">'.$name.'</td>';
$body.='<td style="width:75px; max-width:75px;" class="text-center">'.$sold.'</td>';
$body.='<td style="width:75px; max-width:75px;" class="text-right">'.getfloatval($price).'</td>';
$body.='<td style="width:60px; max-width:60px;" class="text-right">'.$disp.'</td>';    
$body.='<td style="width:60px; max-width:60px;" class="text-right">'.$disf.'</td>';
$body.='<td style="width:75px; max-width:75px;" class="text-center">'.$prqty.'</td>';    
$body.='<td style="width:75px; max-width:75px;" class="text-center"><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control quantity" id="qty_'.$i.'" value="'.$qty.'"  size="2" style="height: 24px;"/></td>';
$body.='<td id="stotal_'.$i.'" style="width:75px; max-width:75px;" class="text-right">'.getfloatval($subtot).'</td>';    
$body.='</tr>';    
}
    
$disp=$_SESSION['axes_returnde'][0]['disp'];
$disamo=$_SESSION['axes_returnde'][0]['disamo'];    
$vatp=$_SESSION['axes_returnde'][0]['vatp'];
$vatamo=$_SESSION['axes_returnde'][0]['vatamo'];
$aitp=$_SESSION['axes_returnde'][0]['aitp'];
$aitamo=$_SESSION['axes_returnde'][0]['aitamo'];
$invdue=$_SESSION['axes_returnde'][0]['invdue'];    
$less=$_SESSION['axes_returnde'][0]['less'];
$grtotal=$_SESSION['axes_returnde'][0]['gtotal'];     
    
$foot.='<tr>';
$foot.='<td style="width:35px; max-width:35px;"></td>';
$foot.='<td style="width:300px; max-width:300px;"></td>';
$foot.='<td style="width:75px; max-width:75px;"></td>';
$foot.='<td style="width:75px; max-width:75px;"></td>';
$foot.='<td style="width:60px; max-width:60px;"></td>';
$foot.='<td style="width:60px; max-width:60px;"></td>';
$foot.='<td style="width:75px; max-width:75px;"></td>';
$foot.='<td style="width:75px; max-width:75px;"></td>';
$foot.='<td style="width:75px; max-width:75px;"></td>';    
$foot.='</tr>';    

$foot.='<tr>';
$foot.='<td colspan="2" class="text-center" width="340px"><strong>-Total-</strong></td>';
$foot.='<td colspan="5"></td>';
$foot.='<td width="75px"><strong>'.$totqty.'</strong></td>';
$foot.='<td width="75px" class="text-right"><strong>'.getfloatval(get_sereturn_total()).'</strong></td>';
$foot.='</tr>';    

if(get_retdiscount_total()>0){
$foot.='<tr>';
$foot.='<td colspan="7" class="text-right" width="340px"><strong>Discount on Item :</strong></td>';
$foot.='<td width="75px"></td>';
$foot.='<td width="75px" class="text-right"><strong>'.getfloatval(get_retdiscount_total()).'</strong></td>';
$foot.='</tr>';    
}    
$foot.='<tr>';
$foot.='<td colspan="7" class="text-right" width="340px"><strong>Discount (%) :</strong></td>';
$foot.='<td width="75px" class="text-right">'.getfloatval($disp).'</td>';
$foot.='<td width="75px" class="text-right"><strong>'.getfloatval(get_retdiscount_total($disp)-get_retdiscount_total()).'</strong></td>';
$foot.='</tr>';
if(get_retdiscount_total()>0){
$foot.='<tr>';
$foot.='<td colspan="7" class="text-right" width="340px"><strong>Total Discount :</strong></td>';
$foot.='<td width="75px"></td>';
$foot.='<td width="75px" class="text-right"><strong>'.getfloatval(get_retdiscount_total($disp)).'</strong></td>';
$foot.='</tr>';    
}    
$foot.='<tr>';
$foot.='<td colspan="7" class="text-right" width="340px"><strong>VAT (%) :</strong></td>';
$foot.='<td width="75px" class="text-right">'.getfloatval($vatp).'</td>';
$foot.='<td width="75px" class="text-right"><strong>'.getfloatval($vatamo).'</strong></td>';
$foot.='</tr>';
$foot.='<tr>';
$foot.='<td colspan="7" class="text-right" width="340px"><strong>AIT (%) :</strong></td>';
$foot.='<td width="75px" class="text-right">'.getfloatval($aitp).'</td>';
$foot.='<td width="75px" class="text-right"><strong>'.getfloatval($aitamo).'</strong></td>';
$foot.='</tr>';
//$foot.='<tr>';
//$foot.='<td colspan="7" class="text-right" width="340px"><strong>Invoice Due :</strong></td>';
//$foot.='<td width="75px" class="text-right"></td>';
//$foot.='<td width="75px" class="text-right"><strong>'.getfloatval($invdue).'</strong></td>';
//$foot.='</tr>';    
$foot.='<tr>';
$foot.='<td colspan="7" class="text-right" width="340px"><strong>Fractional Discount:</strong></td>';
$foot.='<td width="75px" class="text-right"><input type="text" maxlength="6" min="0" onkeypress="return isNumberKey(event)" class="form-control text-right" id="less" value="'.getfloatval($less).'"  size="2" style="height: 24px;"/></td>';
$foot.='<td width="75px" class="text-right" id="lessd"><strong>'.getfloatval($less).'</strong></td>';
$foot.='</tr>';
$foot.='<tr>';
$foot.='<td colspan="7" class="text-right" width="340px"><strong>Return Total:</strong></td>';
$foot.='<td width="75px" class="text-right"></td>';
$foot.='<td width="75px" class="text-right"><strong>'.getfloatval($grtotal).'</strong></td>';
$foot.='</tr>';    
    
    
    
}else{
$body.='<tr>';
$body.='<td colspan="7" class="text-center">There are no Return Item!</td>';
$body.='</tr>'; 
} 
}else{
$body.='<tr>';
$body.='<td colspan="7" class="text-center">There are no Return Item!</td>';
$body.='</tr>';
}


if(isset($_SESSION['axes_sereturn'])){
$buton.='<div class="col-md-6">';
$buton.='<a href="sel_sinvlist.php" class="btn btn-flat bg-gray">Invoice</a><input type="button" id="retcancel" class="btn btn-flat bg-blue btn-sm" onclick="take_action('."'cansre'".')" value="Cancel"/></div>';
$buton.='<div class="col-md-6 text-right">';   
$buton.='<input type="button" id="save_return" class="btn btn-flat bg-purple btn-sm" value="Return"/>'; 
$buton.='</div>';
}

if(isset($_POST['body'])){
echo $body;
}elseif(isset($_POST['foot'])){
echo $foot;
}elseif(isset($_POST['buton'])){
echo $buton;    
}
?>

<?php if(isset($_SESSION['returninv']) && isset($_POST['invdata'])){ 
$inv = $_SESSION['returninv'];
$sql="SELECT * FROM tbl_sales WHERE id='".$inv."' LIMIT 1";    
$selre=mysqli_query($con,$sql) or die(mysqli_error($con));    
$ret=mysqli_fetch_array($selre);
?>
<div class="row-cols row">
<div class="col-6 col-xs-6">
<h4>Customer</h4>    
<?php if(isset($_SESSION['returninv'])){ if($ret['type']=='CU'){echo get_csinfogen($ret['cusid'],'tbl_customer');}else{echo get_csinfogen($ret['cusid'],'tbl_supplier');}}?>    
</div>
<div class="col-6 col-xs-6">
<h4>Address</h4>
<?php if(isset($_SESSION['returninv'])){ if($ret['type']=='CU'){echo get_csinfogen($ret['cusid'],'tbl_customer','address');}else{echo get_csinfogen($ret['cusid'],'tbl_supplier','address');}}?>    
</div>
<div class="clearfix"></div>
</div>    
<div class="row-cols row">
<div class="col-6 col-xs-6">
<strong>Date:</strong> <?php if(isset($_SESSION['returninv'])){ echo date("d M Y", strtotime($ret['apdate']));}?>    
</div>
<div class="col-6 col-xs-6 text-right">
<strong>Invoice No:</strong> <?php if(isset($_SESSION['returninv'])){ echo $ret['invno'];}?>    
</div>
</div>
<?php } ?>