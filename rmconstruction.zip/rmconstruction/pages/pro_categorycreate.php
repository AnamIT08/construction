<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){  
get_pagesecurity('12','creates','R');    
$_SESSION['cuPages']='pro_categorycreate.php';   
$cuPage='pro_categorycreate.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='product';
$menuh='Product Process';
$phead='catcre';
$page=' Create Category';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['save_category'])){
	$name = ucwords(remove_junk(escape($_POST['name'])));
    //$pid = remove_junk(escape($_POST['pid']));
    $description = remove_junk(escape($_POST['description']));
	
	if(isset($_POST['name'])){
	$ducode = mysqli_query($con,"SELECT * FROM tbl_category WHERE name = '$name'");
	}
	
	if($ducode->num_rows > 0) {
	save_msg('i','Category name alrady used! Plz try another');
	echo "<script>window.location='pro_categorycreate.php'</script>";
	}else{
    if($pid==''){$pid='NULL';}else{$pid="'".$pid."'";}    
    $sql="INSERT INTO tbl_category(name,description,uid,date) VALUES ('$name','$description','$aid','$dtnow')";    
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $efid=mysqli_affected_rows($con);    
    if($efid>0){
    $act =remove_junk(escape('Category name: '.$name));    
    write_activity($aid,'CAT','New Category has been created',$act);    
    save_msg('s','Data Successfully Saved!');
    }else{
    save_msg('w','Data Fail to Saved!');    
    }
    echo "<script>window.location='pro_categorycreate.php'</script>";  
	}  
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Create New Category For Product</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="pro_categorycreate.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">

<div class="row">
<div class="col-md-12">
<div class="col-md-3"></div>
<div class="col-md-6">
<div class="form-group">
<label>Category Name</label>
<input type="text" name="name" maxlength="45" value="" id="cname" class="form-control" placeholder="Category Name"  />
</div>
<!--<div class="form-group">
<label>Select Parent</label>
<select class="form-control select2" name="pid">
<option value="">-Select-</option>
<?php									
//$querys=mysqli_query($con,"SELECT * FROM tbl_parent ORDER BY id ASC")or die(mysqli_error($con));
//while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php //echo $rows['id'];?>"><?php //echo $rows['name'];?></option>
<?php //} ?>
</select>    
</div>-->    
<div class="form-group">
<label>Description</label>
<textarea class="form-control" maxlength="250" rows="6" name="description" placeholder="Description"></textarea>
</div>   
</div>    
<div class="col-md-3"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="save_category" id="submit" class="btn btn-flat bg-purple btn-sm " value="Save"/> <a href="pro_categorylist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'CAT','A');}else{echo read_activity($aid,'CAT','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function () {  
var pname = new LiveValidation('cname');
pname.add(Validate.Presence);
});
</script>    
<!-- /page script -->
</html>    