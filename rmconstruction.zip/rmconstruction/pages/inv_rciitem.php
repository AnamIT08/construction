<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}

$output='';

if(isset($_POST['invno'])){
$invno=$_POST['invno'];
$sql="SELECT * FROM (SELECT type,tid,invno,pid,unqid,colid,sizid,SUM(p_qty) AS pqty,SUM(p_in) AS receiv,SUM(p_qty-p_in) AS resqty FROM tbl_traproduct WHERE (invno='$invno' OR refinv='$invno') GROUP BY unqid) dli WHERE resqty>0";   
$result = mysqli_query($con, $sql) or die(mysqli_error($con));
if($result->num_rows > 0) {
$s=0;    
while ($row=mysqli_fetch_array($result)){
$s+=1;
$name='';
$name=get_fild_data('tbl_item',$row['pid'],'name');
if(get_fild_data('tbl_item',$row['pid'],'pmod')>0){
$cls = 'serial';    
}else{
$cls = '';    
}    
if($row['colid']!='0'){$name.=' - '.get_fild_data('tbl_color',$row['colid'],'name');}
if($row['sizid']!='0'){$name.=' - '.get_fild_data('tbl_size',$row['sizid'],'sval');}
    
$output.='<tr>';
$output.='<td style="width:35px; text-align:center;">'.$s.'</td>';
$output.='<td  style="width:60px; text-align:center;"><img src="../img/product/';
if(empty($row['image'])){
$output.='no_image.png';}else{
$output.=$row['image'];
}
$output.='" height="40px" width="40px"></td>';    
$output.='<td style="width:280px; text-align:left;">'.$name;
$output.='<input type="hidden" name="data['.$s.'][unqid]" value="'.$row['unqid'].'" readonly>';
$output.='<input type="hidden" id="res_'.$row['unqid'].'" value="'.$row['resqty'].'" readonly>'; 
$output.='<input type="hidden" id="sl_'.$row['pid'].'" value="0" readonly>';     
$output.='</td>'; 
$output.='<td style="width:100px; text-align:center;">'.get_fild_data('tbl_item',$row['pid'],'code').'</td>';
$output.='<td style="width:60px; text-align:center;">'.$row['pqty'].'</td>';
$output.='<td style="width:60px; text-align:center;">'.$row['receiv'].'</td>'; 
$output.='<td style="width:60px; text-align:center;">'.$row['resqty'].'</td>';
$output.='<td style="width:80px; text-align:center;"><input type="text" min="0" onkeypress="return isNumberKey(event)" name="data['.$s.'][dqty]" class="form-control '.$cls.' dlqty" id="dlq_'.$row['unqid'].'_'.$row['pid'].'" value="" step="any" style="width:100%; height: 24px; text-align:center;"></td>';    
$output.='</tr>';    
}
}else{
$output.='<tr>';
$output.='<td colspan="8" class="text-center">No Item For Deliver</td>';    
$output.='</tr>';    
}
echo $output;
exit;    
}

if(isset($_POST['serial'])){
$output='';    
$invno=$_POST['serial'];
$sql="SELECT * FROM tbl_serial WHERE purinv='$invno' AND rci='N'";   
$result = mysqli_query($con, $sql) or die(mysqli_error($con));
if($result->num_rows > 0) { 
$s=0;     
$output.='<table class="table table-bordered table-striped">';
$output.='<tr>';
$output.='<th style="width:35px; max-width:35px;" class="text-center">#</th>';
$output.='<th style="width:475px; max-width:475px;">Name</th>';
$output.='<th>IMEI/Serial</th>';
$output.='<th width="25px" align="center"></th>';
$output.='</tr>';
while ($row=mysqli_fetch_array($result)){
$s+=1;
$name=get_fild_data('tbl_item',$row['pid'],'name');
$output.='<tr>';
$output.='<td align="center">'.$s.'</td>';
$output.='<td>'.$name.'</td>';
$output.='<td>'.$row['serial'].'</td>';
$output.='<td class="text-center" width="35px">';
$output.='<input type="hidden" id="seal_'.$s.'" value="'.$row['serial'].'" readonly>';    
$output.='<input type="checkbox" class="bscan '.$row['pid'].'" id="bs_'.$s.'_'.$row['pid'].'" value="" name="serial['.$s.'][dlse]" />';
$output.='</td>';
$output.='</tr>';    
}
$output.='</table>';    
}else{
$output='';    
}
echo $output;
exit;
}