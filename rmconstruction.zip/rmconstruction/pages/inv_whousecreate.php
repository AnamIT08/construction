<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='inv_whousecreate.php';   
$cuPage='inv_whousecreate.php';    
$aid=$_SESSION['uid'];
if(get_limitpermision('tbl_warehouse')>=get_fild_data('tbl_limitset','1','whlim')){
header('Location:inv_whouselist.php');   
}    
}else{
header('Location:../index.php');
exit;    
}
$mhead='inventor';
$menuh='Inventory';
$phead='whocreate';
$page='Warehouse Create';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['save_whouse'])){
	$name = ucwords(remove_junk(escape($_POST['name'])));
    //$bname = remove_junk(escape($_POST['bname']));
    $phone = remove_junk(escape($_POST['phone']));
    $email = remove_junk(escape($_POST['email']));
    $address = remove_junk(escape($_POST['address']));
    //$baddress = $_POST['baddress'];
	
	if(isset($_POST['name'])){
	//$ducode = mysqli_query($con,"SELECT * FROM tbl_warehouse WHERE (name IS NOT NULL AND name = '$name') OR (bname IS NOT NULL AND bname='$bname')");
    $ducode = mysqli_query($con,"SELECT * FROM tbl_warehouse WHERE name = '$name'");    
	}
	
	if($ducode->num_rows > 0) {
		save_msg('i','Werhouse alrady exists! Plz try another');
		echo "<script>window.location='inv_whousecreate.php'</script>";
	}else{
    //$sql="INSERT INTO tbl_warehouse(name,bname,address,baddress,phone,email,uid,date) VALUES ('$name','$bname',$address','$baddress','$phone','$email','$aid','$dtnow')";
    $sql="INSERT INTO tbl_warehouse(name,address,phone,email,uid,date) VALUES ('$name','$address','$phone','$email','$aid','$dtnow')";    
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $efid=mysqli_affected_rows($con);    
    if($efid>0){
    $act =remove_junk(escape('Werhouse name: '.$name));    
    write_activity($aid,'WAR','New werhouse has been Added',$act);
    save_msg('s','Data Successfully Saved!');    
    }else{
    save_msg('w','Data Fail to Saved!');    
    }
    echo "<script>window.location='inv_whousecreate.php'</script>";  
	}  
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Add Warehouse';}else{echo 'গুদাম ঘর (ওয়্যারহাউজ) যোগ করুন';}?></h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="inv_whousecreate.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">    

<div class="row ">
<div class="col-md-12">
<div class="col-md-2"></div>
<div class="col-md-8">
<div class="col-md-12">
<div class="row">   
<div class="form-group">
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Name';}else{echo 'নাম (ইংলিশ)';}?></label>
<input type="text" name="name" maxlength="45" value="" id="name" class="form-control" placeholder="e.g. Taltola" />
</div>
<!--<div class="form-group">
<label><?php //if(get_fild_data('tbl_setting','1','sval')==0){echo 'Name (Bangla)';}else{echo 'নাম (বাংলায়)';}?></label>
<input type="text" name="bname" maxlength="255" value="" id="bname" class="form-control" placeholder="e.g. তালতলা" />
</div>-->    
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group" >
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Phone';}else{echo 'ফোন';}?></label>
<input type="text" name="phone" maxlength="18" value="" id="phone" class="form-control" placeholder="e. g. 0161xx700xx" />    
</div>
</div>
<div class="col-md-6">
<div class="form-group" >
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Email';}else{echo 'ইমেইল';}?></label>
<input type="text" name="email" maxlength="45" value="" id="email" class="form-control" placeholder="e.g. info@axesgl.com" />     
</div>
</div>    
</div>
<div class="row">
<div class="form-group">
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Address (English)';}else{echo 'ঠিকানা (ইংলিশ)';}?></label>
<textarea class="form-control" maxlength="250" rows="6" name="address" id="address" placeholder="Address"></textarea>
</div>
<!--<div class="form-group">
<label><?php //if(get_fild_data('tbl_setting','1','sval')==0){echo 'Address (Bengoli)';}else{echo 'ঠিকানা (বাংলায়)';}?></label>
<textarea class="form-control" maxlength="350" rows="6" name="baddress" id="baddress" placeholder="ঠিকানা"></textarea>
</div>-->    
</div>    
</div>
</div>    
<div class="col-md-2"></div>    
</div>    
</div>    
    
</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="save_whouse" id="submit" class="btn btn-flat bg-purple btn-sm " value="<?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Save';}else{echo 'সংরক্ষণ';}?>"/> <a href="inv_whouselist.php" class="btn btn-flat bg-gray"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Close';}else{echo 'বন্দ';}?></a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'History';}else{echo 'ইতিহাস';}?> </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'WAR','A');}else{echo read_activity($aid,'WAR','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function () {
<?php if(get_fild_data('tbl_setting','1','sval')==0){?>    
var name = new LiveValidation('name');
name.add(Validate.Presence);
    
var address = new LiveValidation('address');
address.add(Validate.Presence);    
<?php }else{ ?>
var bname = new LiveValidation('bname');
bname.add(Validate.Presence); 
    
var baddress = new LiveValidation('baddress');
baddress.add(Validate.Presence);    
<?php } ?>
var phone = new LiveValidation('phone');
phone.add(Validate.Presence);
var address = new LiveValidation('address');
address.add(Validate.Presence);
var email = new LiveValidation('email');
email.add(Validate.Email);    
});   
</script>    
<!-- /page script -->
</html>    