<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('26','views','R');    
$_SESSION['cuPages']='acc_paylist.php';   
$cuPage='acc_paylist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='account';
$menuh='Account';
$phead='paylist';
$page='Payment Record';
$print='print';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['delpay'])){
$id=$_POST['delpay'];
$invno= get_fild_data('tbl_payvoucher',$id,'invno');

$sql="DELETE FROM tbl_trarecord WHERE invno='$invno'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
        
$sql="DELETE FROM tbl_payvoucher WHERE id='$id'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
    
$efid=mysqli_affected_rows($con);    
if($efid>0){
$act =remove_junk(escape('Payment no: '.$invno));    
write_activity($aid,'PAY','Payment has been deleted',$act);        
save_msg('s','Payment Successfully Deleted!!!');
}else{
save_msg('w','Payment Fail to Delete!!!');    
}
echo "<script>window.location='acc_paylist.php'</script>";
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Payment Record</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px;">SN</th>   
<th>Date</th>
<th>Invno</th>
<th>Project No</th>    
<th>Amount</th>
<th>Note</th>        
<th style="width:40px; text-align:center;">Action</th>    
</tr>
</thead>    
<tbody>
<?php
$sql="SELECT * FROM tbl_payvoucher WHERE brid='$brid' ORDER BY apdate DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$id=$row['id'];
?>
<tr>
<td class="center"><?php echo count_id();?></td>
<td><?php echo date("d M Y", strtotime($row['apdate']));?></td>        
<td><?php echo $row['invno'];?></td>
<td><?php if($row['pjid']!=''){echo get_fild_data('tbl_project',$row['pjid'],'prjid');}?></td>     
<td><?php echo numtolocal($row['amount'],'');?></td>
<td><?php echo $row['note'];?></td>     
<td nowrap="">
<a class="btn btn-flat bg-purple details-invoice" href="#" id="inv_<?php echo $row['id']; ?>"><i class="fa fa-eye cat-child"></i></a>    
<!--<a class="btn btn-flat bg-purple" href="#"><i class="fa fa-edit"></i></a>--> 
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
<form action="acc_paylist.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delpay" value="<?php echo $row['id']; ?>" />
</form>
</td>    
</tr>    
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<a href="acc_paycreate.php" class="btn btn-flat bg-purple">Create Payment</a>
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'PAY','A');}else{echo read_activity($aid,'PAY','U');}?>
</div>
</div>
</div>
</div>
</div>
</div> 

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->
<?php include('../layout/print.php'); ?>     
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
});
    
function edit_item(id) {
document.getElementById(id).submit(); 
}
    
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});

}
    
$(".details-invoice").click(function (e) {
id_arr = $(this).attr('id');
id = id_arr.split("_");

$.ajax({
url: 'acc_viewpaylist.php',
method: "POST",
data:{ 
invid: id[1]
},
success: function(data){
$('#listitem').html(data);
pagelist();    
}
});    
    
$.ajax({
url: 'acc_viewpay.php',
method: "POST",
data:{ 
print: id[1]
},
success: function(data){
$('#invhold').html(data);
sethead();    
}
});
    
$('.right-side').toggle('slide', { direction: 'right' }, 300);    

e.preventDefault();
});

$(document).on('click', '#closepop', function() {
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }   
});    

$('#listitem').on('click','li', function(){
   $(this).addClass('active').siblings().removeClass('active');
});
    
$(document).on('click', '.invpayv', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
$.ajax({
url: 'acc_viewpay.php',
method: "POST",
data:{ 
print: ids
},
beforeSend: function() {
$("#invhold").fadeOut('slow');
},    
success: function(data){    
$('#invhold').html(data);
$("#invhold").fadeIn('slow');    
sethead();    
}
});     
});    
    
</script>    
<!-- /page script -->
</html>    