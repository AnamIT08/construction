<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
//get_pagesecurity('84','views','R');    
$_SESSION['cuPages']='main_group.php';   
$cuPage='main_group.php';    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='client';
$menuh='Client';
$phead='scgrlist';
$page='All Group';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php 
if(isset($_POST['delscg'])){
$id=$_POST['delscg'];
if(delete_check('tbl_supplier','gid',$id)>0 || delete_check('tbl_customer','gid',$id)>0){
save_msg('w','Group Depend On Other Table!!!');
echo "<script>window.location='main_group.php'</script>";
return;    
}
$name= get_fild_data('tbl_group',$id,'name');    
$sql="DELETE FROM tbl_group WHERE id='$id'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);    
if($efid>0){
$act =remove_junk(escape('Group name: '.$name));    
write_activity($aid,'SCG','Grouphas been deleted',$act);        
save_msg('s','Group Successfully Deleted!!!');
}else{
save_msg('w','Group Fail to Delete!!!');    
}
echo "<script>window.location='main_group.php'</script>";
}
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Group List</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead class="text-uppercase">
<tr>
<th style="width:40px;">SN</th>   
<th>Name</th>     
<th>Description</th>
<th style="width:40px; text-align:center;">Action</th>    
</tr>
</thead>    
<tbody>
<?php
$sql="SELECT * FROM tbl_group ORDER BY name ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$id=$row['id'];
?>
<tr>
<td class="center"><?php echo count_id();?></td>  
<td><?php echo $row['name'];?></td>      
<td><?php echo $row['description'];?></td>
<td nowrap="">
<?php //if(get_pagesecurity('84','edits','P')){?>    
<a class="btn btn-flat bg-purple" href="#" onclick="edit_item('ED_<?php echo $row['id'];?>')"><i class="fa fa-edit"></i></a>
<?php //} ?>    
<?php //if(get_pagesecurity('84','deletes','P')){?>    
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
<form action="main_group.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delscg" value="<?php echo $row['id']; ?>" />
</form>
<?php //} ?>    
<?php //if(get_pagesecurity('84','edits','P')){?>    
<form action="main_groupedit.php" id="ED_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="editscg" value="<?php echo $row['id']; ?>" />
</form>
<?php //} ?>    
</td>    
</tr>    
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<?php //if(get_pagesecurity('84','creates','P')){?>    
<a href="main_groupcre.php" class="btn btn-flat bg-purple">Add Group</a>
<?php //} ?>    
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'SCG','A');}else{echo read_activity($aid,'SCG','U');}?>
</div>
</div>
</div>
</div>
</div>
</div> 
        
<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
} );
function edit_item(id) {
document.getElementById(id).submit(); 
}
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});

} 
</script>    
<!-- /page script -->
</html>    