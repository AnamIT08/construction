<?php 
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_POST['subgroup'])){
$output='';   
$ids=$_POST['subgroup'];     
$queirys = "SELECT * FROM tbl_acsubgroup WHERE grid='$ids'";
$results = mysqli_query($con, $queirys);
$output .= '<option value="">-Select-</option>';
while ($rowcu=mysqli_fetch_array($results)){
$output .= '<option value="'.$rowcu["id"].'">'.$rowcu["name"].'</option>';
}
    
echo $output;
exit;
}

if(isset($_POST['subcat'])){
$output='';   
$ids=$_POST['subcat'];     
$queirys = "SELECT * FROM tbl_subcat WHERE catid='$ids'";
$results = mysqli_query($con, $queirys);
$output .= '<option value="">-Select-</option>';
while ($rowcu=mysqli_fetch_array($results)){
$output .= '<option value="'.$rowcu["id"].'">'.$rowcu["name"].'</option>';
}
    
echo $output;
exit;
}

if(isset($_POST['psgid'])){
$output='';   
$ids=$_POST['psgid'];     
$queirys = "SELECT * FROM tbl_prosubgroup WHERE pgid='$ids'";
$results = mysqli_query($con, $queirys);
$output .= '<option value="">-Select-</option>';
while ($rowcu=mysqli_fetch_array($results)){
$output .= '<option value="'.$rowcu["id"].'">'.$rowcu["name"].'</option>';
}
    
echo $output;
exit;
}

if(isset($_POST['zone'])){
$output='';   
$ids=$_POST['zone'];     
$queirys = "SELECT * FROM tbl_zone WHERE did='$ids'";
$results = mysqli_query($con, $queirys);
$output .= '<option value="">-Select-</option>';
while ($rowcu=mysqli_fetch_array($results)){
$output .= '<option value="'.$rowcu["id"].'">'.$rowcu["name"].'</option>';
}
    
echo $output;
exit;
}

if(isset($_POST['getledger'])){
if(isset($_POST['sgrid'])){    
$sgrid = intval($_POST['sgrid']);
}else{
$sgrid=0;    
}
$output='';
if($sgrid==2){
$sql="SELECT tbl_bacount.id,CONCAT('BA',100+tbl_bacount.id,' - ',tbl_bank.sort,' / ',tbl_bacount.acno) AS name FROM tbl_bacount LEFT JOIN tbl_bank ON tbl_bank.id=tbl_bacount.bid ORDER BY tbl_bacount.id ASC";    
}elseif($sgrid==3){
$sql="SELECT id,CONCAT(code,' - ',name) AS name FROM tbl_item ORDER BY id ASC";
}elseif($sgrid==4){
$sql="SELECT id,CONCAT(code,' - ',name) AS name FROM tbl_customer ORDER BY id ASC";     
}elseif($sgrid==13){
$sql="SELECT id,CONCAT(code,' - ',name) AS name FROM tbl_supplier ORDER BY id ASC";    
}elseif($sgrid==33){    
$sql="SELECT id,CONCAT(code,' - ',name) AS name FROM tbl_employe ORDER BY id ASC";
}elseif($sgrid==34){    
$sql="SELECT id,CONCAT(name,' - ',mobile) AS name FROM tbl_acmobile ORDER BY id ASC";
}elseif($sgrid==39){    
$sql="SELECT id,CONCAT(code,' - ',name) AS name FROM tbl_contractor ORDER BY id ASC";    
}else{
$sql="SELECT id,CONCAT(code,' - ',name) AS name FROM tbl_acledger WHERE sgrid='$sgrid' ORDER BY id ASC";    
}    
    
$results = mysqli_query($con, $sql);
$output .= '<option value="">-Select-</option>';
while ($rowcu=mysqli_fetch_array($results)){
$output .= '<option value="'.$rowcu["id"].'">'.$rowcu["name"].'</option>';
}    
echo $output;
exit;    
}

if(isset($_POST['getexphead'])){
$id=$_POST['getexphead'];
$output='';    
$sql="SELECT * FROM tbl_acledger WHERE grid IN (8,9) AND sgrid IN (20,21) ORDER BY id ASC";
$results = mysqli_query($con, $sql);    
$output .= '<option value="">-Select-</option>';
while ($row=mysqli_fetch_array($results)){
if($row['id']!=$id){    
$output .= '<option value="'.$row['id'].'">'.$row['code'].' - '.$row['name'].'</option>';
}else{
$output .= '<option selected value="'.$row['id'].'">'.$row['code'].' - '.$row['name'].'</option>';    
}
}    
echo $output;
exit;    
}

if(isset($_POST['getcustomer'])){
$id=$_POST['getcustomer'];
$output='';    
$sql="SELECT * FROM tbl_customer ORDER BY name ASC"; 
$results = mysqli_query($con, $sql);    
$output .= '<option value="">-Select-</option>';
while ($row=mysqli_fetch_array($results)){
if($row['id']!=$id){    
$output .= '<option value="'.$row['id'].'">'.$row['name'].'</option>';
}else{
$output .= '<option selected value="'.$row['id'].'">'.$row['name'].'</option>';    
}
}    
echo $output;
exit;    
}

if(isset($_POST['getsuplier'])){
$id=$_POST['getsuplier'];
$output='';    
$sql="SELECT * FROM tbl_supplier ORDER BY name ASC"; 
$results = mysqli_query($con, $sql);    
$output .= '<option value="">-Select-</option>';
while ($row=mysqli_fetch_array($results)){
if($row['id']!=$id){    
$output .= '<option value="SU_'.$row['id'].'">'.$row['code'].'-'.$row['name'].'</option>';
}else{
$output .= '<option selected value="SU_'.$row['id'].'">'.$row['code'].'-'.$row['name'].'</option>';    
}
}    
echo $output;
exit;    
}

if(isset($_POST['gettrdebit'])){
if(strlen($_POST['gettrdebit'])>0){    
$eid=explode('_',$_POST['gettrdebit']);
$cty=$eid['0'];
$cid=$eid['1'];
}else{
$cty='';
$cid='';    
}
$output='';
$output .= '<option value="">-Select-</option>';
if($cty=='BA'){
$output .= '<option value="LE_2">Cash</option>';
$sql="SELECT tbl_bacount.id,CONCAT(tbl_bank.sort,' - ',tbl_bacount.acno) AS name FROM tbl_bacount LEFT JOIN tbl_bank ON tbl_bank.id=tbl_bacount.bid WHERE tbl_bacount.id!='$cid' ORDER BY tbl_bank.sort ASC";
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
if($querys->num_rows > 0) {    
while ($row=mysqli_fetch_array($querys)){
$output .= '<option value="'.'BA_'.$row['id'].'">'.$row['name'].'</option>';   
}
}    
}elseif($cty=='LE'){
$sql="SELECT tbl_bacount.id,CONCAT(tbl_bank.sort,' - ',tbl_bacount.acno) AS name FROM tbl_bacount LEFT JOIN tbl_bank ON tbl_bank.id=tbl_bacount.bid ORDER BY tbl_bank.sort ASC";
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
if($querys->num_rows > 0) {    
while ($row=mysqli_fetch_array($querys)){
$output .= '<option value="'.'BA_'.$row['id'].'">'.$row['name'].'</option>';   
}
}    
}
echo $output;
exit;    
}
?>