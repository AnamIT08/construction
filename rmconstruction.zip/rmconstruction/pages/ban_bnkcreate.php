<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('41','creates','R');     
$_SESSION['cuPages']='ban_bnkcreate.php';   
$cuPage='ban_bnkcreate.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='bank';
$menuh='Bank';
$phead='bnkcre';
$page='Add Transaction';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['save_trament'])){
	
//   if(!isset($_SESSION['axes_tradata'])){
//   save_msg('w','No Transaction data found!!');
//	echo "<script>window.location='ban_bnkcreate.php'</script>";
//   exit;    
//   }
    
	if(!isset($_SESSION['axes_traitem'])){
    save_msg('w','No Transaction found!!');
	echo "<script>window.location='ban_bnkcreate.php'</script>";
    exit;    
    }
    
    $payno = gen_newinvno('tbl_banktra','TRN');
    $apdate = remove_junk(escape($_POST['apdate']));
    $note = remove_junk(escape($_POST['note']));
    $total = total_travalue();
    
    $sql="INSERT INTO tbl_banktra (invno,note,amount,apdate,uid,date) VALUES ('$payno','$note','$total','$apdate','$aid','$dtnow')";    
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $sid=$con->insert_id;
    $efid=mysqli_affected_rows($con);
    
    if($efid>0){
    if(isset($_SESSION['axes_traitem'])){
    if(is_array($_SESSION['axes_traitem'])){
    $max=count($_SESSION['axes_traitem']);
    for($i=0;$i<$max;$i++){
        
    $dty = $_SESSION['axes_traitem'][$i]['dty'];
    $did=$_SESSION['axes_traitem'][$i]['did'];    
    $amo=$_SESSION['axes_traitem'][$i]['amo'];
    $cid=$_SESSION['axes_traitem'][$i]['cid'];
    $cty=$_SESSION['axes_traitem'][$i]['cty'];   
    $chkno=$_SESSION['axes_traitem'][$i]['chkno'];
    $chkdt=$_SESSION['axes_traitem'][$i]['chkdt'];
    if($chkno=='' || strlen($chkno)<2){$chkdt='NULL';$chkno='NULL';}else{$chkdt="'".$chkdt."'";$chkno="'".$chkno."'";}    
    $ref=$_SESSION['axes_traitem'][$i]['ref'];
        
    $sql="INSERT INTO tbl_banktrade (seid,cid,cty,amount,did,dty,cheno,chedt,chest,ref ) VALUES ('$sid','$cid','$cty','$amo','$did','$dty',$chkno,$chkdt,'0','$ref')";
    mysqli_query($con,$sql) or die(mysqli_error($con));
        
    $sql="INSERT INTO tbl_trarecord (invno,dty,did,amo,cid,cty,chkno,chkdt,ref,curid,xrate,apdate,brid,uid,date) VALUES ('$payno','$dty','$did','$amo','$cid','$cty',$chkno,$chkdt,'$ref','0','0','$apdate','$brid','$aid','$dtnow')";
    mysqli_query($con,$sql) or die(mysqli_error($con)); 
        
    }}}
    unset($_SESSION['axes_tradata']);
    unset($_SESSION['axes_traitem']);    
    $act =remove_junk(escape('Transaction No: '.$payno));    
    write_activity($aid,'TRA','Transaction has been Added',$act);    
    save_msg('s','Data Successfully Saved!');
    }else{
    save_msg('w','Data Fail to Saved!');    
    }
    echo "<script>window.location='ban_bnkcreate.php'</script>";  
	}  
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Add Transaction</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="ban_bnkcreate.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">
<div class="row">    
<center>
<h3 class="page-title">TRANSACTION RECORD</h3>
</center>
</div>
<div class="row">    
<div class="col-md-4 col-md-offset-8">
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><b>Tra. No:</b></span>
<input type="text" class="form-control" maxlength="15" name="invno" id="invno" value="<?php if(isset($_SESSION['axes_tradata']['invno'])){$_SESSION['axes_tradata']['invno']=gen_newinvno('tbl_banktra','TRN');echo $_SESSION['axes_tradata']['invno'];}else{echo gen_newinvno('tbl_banktra','TRN');}?>" placeholder="e.g. TRN121119101" readonly>
</div>
</div>
<div class="form-group" >
<div class="input-group">
<span class="input-group-addon"><b>Date:</b></span>
<input type="text" class="form-control datetimepicker" name="apdate" id="apdate" value="<?php if(isset($_SESSION['axes_tradata']['date'])){echo $_SESSION['axes_tradata']['date'];}else{ echo date('Y-m-d');}?>" placeholder="Date:" autocomplete="off" readonly>
</div>
</div>    
</div>
</div>
<div class="row">    
<div class="col-md-4">    
<div class="form-group">
<label>Deposit From </label>    
<select class="form-control select2" name="cid" id="cid">
<option value="">-Select-</option>
<option value="LE_2">Cash</option>    
<?php
$sql="SELECT tbl_bacount.id,CONCAT(tbl_bank.sort,' - ',tbl_bacount.acno) AS name FROM tbl_bacount LEFT JOIN tbl_bank ON tbl_bank.id=tbl_bacount.bid ORDER BY tbl_bank.sort ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'BA_'.$rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>
</div>    
</div>
<div class="col-md-2">    
<div class="form-group">
<label>Cheque No</label>
<input type="text" maxlength="20" class="form-control" name="chkno" id="chkno" value="" placeholder="e.g. KA7865467" autocomplete="off" disabled="disabled">
</div>    
</div>
<div class="col-md-2">    
<div class="form-group" >
<label>Cheque Date</label>
<input type="text" class="form-control datetimepicker" name="chkdt" id="chkdt" value="" placeholder="Cheque Date" autocomplete="off" disabled="disabled">
</div>    
</div>    
<div class="col-md-4">    
<div class="form-group">
<label></label>    
<center>
<a style="cursor: pointer;font-size: 16px;margin-right: 4px;color: red;"></a>    
<span style="font-size: 20px;font-weight: bold;">Balance: </span><span style="font-size: 20px;font-weight: bold;color:blue;" id="cbal">0.00</span>
</center>    
</div>    
</div>    
</div>    
<div class="row">
<div class="col-md-5">
<div class="form-group" >
<label>Deposit To</label>
<div class="input-group">
<select class="form-control select2" name="did" id="did">

</select>
<span class="input-group-addon"><a href=""><span class="fa fa-plus"></span></a></span>     
</div>   
</div>
</div>
<div class="col-md-3">
<div class="form-group" >
<label>Ref</label>
<input type="text" maxlength="25" class="form-control" name="ref" id="ref" placeholder="e.g. Sumon" autocomplete="off">    
</div>    
</div>
<div class="col-md-2">
<div class="form-group">
<label>Amount</label>    
<input type="text" maxlength="10" class="form-control" name="amo" id="amo"  onkeypress="return isNumberKey(event)" placeholder="e.g. 500" autocomplete="off">    
</div> 
</div>
<div class="col-md-1">
<div class="form-group">
<label>&nbsp;</label>    
<input type="button" id="addtra" class="btn btn-flat bg-red" value="Add"/>    
</div>
</div>    
</div>
<div class="row">
<div class="col-md-12">
<table class="table table-bordered table-striped">
<thead>    
<th style="width:40px; text-align:center">SN</th>
<th>Sourch</th>
<th>Pay To</th>    
<th>Amount</th>
<th>Cheque</th>
<th>Date</th>    
<th>Ref</th>
<th style="width:40px; text-align:center"><a class="empty" style="cursor: pointer;"><i class="fa fa-trash"></i></a></th>    
</thead>
<tbody id="itemdata">

</tbody>
<tfoot id="itemfoot">

</tfoot>    
</table> 
</div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="form-group">
<label>Note</label>
<textarea class="form-control" name="note" id="note" maxlength="150" rows="3" placeholder="e.g. Note"><?php if(isset($_SESSION['axes_tradata']['note'])){echo $_SESSION['axes_tradata']['note'];}?></textarea>
</div>    
</div>   
</div>    
    
</div>    
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="trareset" class="btn btn-flat bg-red btn-sm " value="Reset"/>    
<input type="submit" name="save_trament" id="submit" class="btn btn-flat bg-purple btn-sm" value="Save"/> <a href="ban_bnktranlist.php" class="btn btn-flat bg-gray">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'TRA','A');}else{echo read_activity($aid,'TRA','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function (){ 
var apdate = new LiveValidation('apdate');
apdate.add(Validate.Presence);
});
    
$(document).on('click change', '#cid', function() {
var id = $(this).val();

ids = id.split("_");
type=ids[0];
if(type=='BA'){
document.getElementById("chkno").disabled=false; 
document.getElementById("chkdt").disabled=false;     
}else{
$('#chkno').val('');
$('#chkdt').val('');    
document.getElementById("chkno").disabled=true; 
document.getElementById("chkdt").disabled=true;    
}     

$.ajax({
url: "axe_cart.php",
method: "POST",
data: {
getbalance: id 
},
success: function(data) {	
$('#cbal').html(data);
}
})    
    
$.ajax({
url: "axe_getsub.php",
method: "POST",
data: {
gettrdebit: id 
},
success: function(data) {	
$('#did').html(data);
}
})
	
});
    
ReadData();
function ReadData(){
$.ajax({
url: "ban_traview.php",
method: "POST",
data:{ 
body:1
},
success: function(data){
$('#itemdata').html(data);
}
})

$.ajax({
url: "ban_traview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})    
};
    
$(document).on('click', '#addtra', function(e) {
scid = $('#cid').val();
chkno = $('#chkno').val();
chkdt = $('#chkdt').val();    
sdid = $('#did').val();
amo = parseFloat($('#amo').val());    
ref = $('#ref').val();    
toastr.options = {'positionClass': 'toast-top-center'};

if(scid == '-Select-' || scid == ''){
toastr.info('Please Select Deposit From!');
return;
};    

ecid = scid.split("_");
cty=ecid[0];
cid=ecid[1];    

if(cty=='BA'){    
if(chkno.length>=0 && chkno.length<5){
toastr.info('Please Enter Valid Cheque No!');
return;    
}    

if(chkno.length>0){
if(chkdt.length<=0){
toastr.info('Please Enter Cheque Date!');
return;    
}    
}    
}
    
if(sdid == '-Select-' || sdid == ''){
toastr.info('Please Select Deposit To!');
return;
}
    
edid = sdid.split("_");
dty=edid[0];
did=edid[1];
    
if(isNaN(amo) != false || amo <= 0){
toastr.info('Please Enter Amount!');
return;
}    

$.ajax({
url: 'axe_cart.php',
type: 'post',
data: {gettransaction:1,did:did,dty:dty,amo:amo,cty:cty,cid:cid,chkno:chkno,chkdt:chkdt,ref:ref},
success:function(data) {
$("#cid").val("").trigger("change");    
$("#did").val("").trigger("change");
$('#amo').val("");
$('#chkno').val(""); 
$('#chkdt').val("");     
$('#ref').val("");
ReadData();
}
});    
    
e.preventDefault();     
});
    
$(document).on('blur change', '#apdate', function() {
apdate=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
tradate: apdate
},
dataType: 'json',
success: function(data){
$('#apdate').val(data[0]);
}
});     
});    

$(document).on('blur', '#note', function() {
note = $(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
tranote: note
},
dataType: 'json',
success: function(data){
$('#note').val(data[0]);
}
});     
});    

$(document).on('click','.empty',function() {
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
tradata: 1
},
success: function(data){
ReadData();    
}
});    
});    

$(document).on('click', '.remove', function () {
var id = $(this).attr('id');
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
traremove: id
},
success: function(data){
ReadData();
}
});    
});    

$(document).on('click','#trareset',function() {
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
traclear: 1
},
success: function(data){
$("#note").val("");   
ReadData();    
}
});    
});    
</script>    
<!-- /page script -->
</html>    