<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
?>
<?php 
function get_pidsl_count($unqid){
if(isset($_SESSION['axes_dispos'])){
$max=count($_SESSION['axes_dispos']);
$sum=0;
$qty=0;
for($i=0;$i<$max;$i++){
$qty=$_SESSION['axes_dispos'][$i]['qty'];
$epid=$_SESSION['axes_dispos'][$i]['unqid'];
if($unqid==$epid){
$sum+=$qty;
}
}
if($sum > 0){
return $sum;
}else{
return 0;    
}
}else{
return 0;        
}	
}

function get_slpid_count($unqid){
if(isset($_SESSION['axes_dspse'])){
$max=count($_SESSION['axes_dspse']);
$sum=0;
for($i=0;$i<$max;$i++){
$epid=$_SESSION['axes_dspse'][$i]['unqid'];
if($unqid==$epid){
$sum+=1;
}    
}
return $sum;    
}else{
return 0;    
}
}
    
function pid_slexits($unqid){   
$max=count($_SESSION['axes_dspse']);
$flag=0;    
for($i=0;$i<$max;$i++){
if($unqid==$_SESSION['axes_dspse'][$i]['unqid']){
$flag=1;    
break;    
}    
}
return $flag;    
}

function remove_slpid($unqid,$dmax){
$c=0;    
$max=count($_SESSION['axes_dspse']);
for($i=($max-1);$i>=0;$i=$i-1){    
if($unqid==$_SESSION['axes_dspse'][$i]['unqid']){
$c+=1;    
unset($_SESSION['axes_dspse'][$i]);
if($c==$dmax){
break;    
}     
}    
}
$_SESSION['axes_dspse']=array_values($_SESSION['axes_dspse']);    
}
?>
<table class="table table-bordered table-striped">
<?php if(get_disposserial_count()>0){ ?>
    
<?php 
$max=count($_SESSION['axes_dispos']);    
for($i=0;$i<$max;$i++){
if($_SESSION['axes_dispos'][$i]['imei']>=1){
$pid=$_SESSION['axes_dispos'][$i]['pid'];
$unqid=$_SESSION['axes_dispos'][$i]['unqid'];    
$qty=$_SESSION['axes_dispos'][$i]['qty'];    
$eqty=get_pidsl_count($unqid);
if(isset($_SESSION['axes_dspse'])){    
if(pid_slexits($unqid)){
$dmax=0;    
$sqty=get_slpid_count($unqid);
if($sqty!=$eqty){
if($sqty<$eqty){
$dmax=($eqty-$sqty);   
for($p=0;$p<$dmax;$p++){
add_disposserial($pid,$unqid,'','B');    
}   
}elseif($sqty>$eqty){
$dmax=($sqty-$eqty);    
remove_slpid($unqid,$dmax);    
}        
}    
}else{
add_disposserial($pid,$unqid,'','B');    
}
}else{
add_disposserial($pid,$unqid,'','B');    
}    
}        
}
?>     
<tr>
<td colspan="4" align="center">
</td>
</tr>
<tr>
<th width="30px" align="center">#</th>
<th width="300px">Name</th>
<th width="170px">IMEI/Serial</th>
<th width="25px" align="center"><i class="fa fa-trash"></i></th>
</tr>    
<?php } ?>
<?php
if(isset($_SESSION['axes_dspse'])){
usort($_SESSION['axes_dspse'], function ($a, $b) {
return $a['cartid'] <=> $b['cartid'];
});    
if(is_array($_SESSION['axes_dspse'])){    
?>	
<?php
$s=0;
$max=count($_SESSION['axes_dspse']);
for($i=($max-1);$i>=0;$i=$i-1){ ?>
<?php if($_SESSION['axes_dspse'][$i]['reumei']>=1){
$requ=1;	
}else{
$requ=0;	
}
?>
<?php $s=$s+1; ?>

<tr>
<td align="center"><?php echo $s; ?></td>
<td <?php if($requ){echo 'style="color:red;"';}?>><?php echo $_SESSION['axes_dspse'][$i]['name']; ?></td>
<td><input type="text" name="imei_<?php echo $i; ?>" maxlength="25" class="form-control imei" id="imei_<?php echo $i; ?>" value="<?php echo $_SESSION['axes_dspse'][$i]['imei']; ?>"  size="2" style="height: 24px;" autocomplete="off"/></td>
<td align="center"><a id="<?php echo $i; ?>" class="slremove"><span style="cursor: pointer;" class="fa fa-times"></span></a></td>
</tr>
<?php } ?>	
<?php }else{ ?>
<tr>
<td colspan="4" align="center">No IMEI or Product Serial!</td>
</tr> 
<?php } ?> 
<?php }else{ ?>
<tr><td colspan="4" align="center">No IMEI or Product Serial!</td>
</tr>
<?php } ?>
</table>