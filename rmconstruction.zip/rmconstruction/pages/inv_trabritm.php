<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}

$output='';

$bsql="SELECT * FROM tbl_branch";
$query=mysqli_query($con,$bsql)or die(mysqli_error($con));
if($query->num_rows > 0) {
if(isset($_POST['brid'])){    
$ibrid=$_POST['brid'];
if(isset($_SESSION['axes_transbr'])){
unset($_SESSION['axes_transbr']);
}
if(isset($_SESSION['axes_trbse'])){
unset($_SESSION['axes_trbse']);	
}    
}else{
$ibrid=$brid;    
}
$sql="SELECT * FROM tbl_brstock WHERE brid='$ibrid' AND avqty>0 ORDER BY name ASC";    
}else{
$sql="SELECT * FROM tbl_brstock WHERE brid='$brid' AND avqty>0 ORDER BY name ASC";    
}

$result = mysqli_query($con, $sql);
if($result->num_rows > 0) {
$s=0;
$totqty=0;    
while ($row=mysqli_fetch_array($result)){
$s+=1;
$totqty+=($row['avqty']-$row['sloc']);    
$output.='<tr>';
$output.='<td width="30px" class="text-center">'.$s.'</td>';
$output.='<td width="60px" class="text-center"><img src="../img/product/';
if(empty($row['image'])){
$output.='no_image.png';}else{
$output.=$row['image'];
}
$output.='" height="40px" width="40px"></td>';    
$output.='<td width="450px">'.$row['name'].'</td>'; 
$output.='<td width="95px" class="text-center">'.$row['code'].'</td>'; 
$output.='<td width="60px" class="text-center">'.($row['avqty']-$row['sloc']).'</td>';
$output.='<td class="text-center" width="25px"><a id="TRX_'.$row['unqid'].'" class="tranfer"><span style="cursor: pointer;" class="fa fa-plus"></span></a></td>';     
$output.='</tr>';    
}
$output.='<tr>';
$output.='<td colspan="4" class="text-center"><strong>-Total-</strong></td>';
$output.='<td colspan="2" class="text-center"><strong>'.$totqty.'</strong></td>';    
$output.='</tr>';     
}else{
$output.='<tr>';
$output.='<td colspan="6" class="text-center">No Item For Transfer</td>';    
$output.='</tr>';    
}

echo $output;
exit;