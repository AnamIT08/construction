<?php session_start();
require_once '../inc/dbcon.php';
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('2','views','R');    
$_SESSION['cuPages']='dai_pricelist.php';   
$cuPage='dai_pricelist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='daily';
$menuh='Daily process';
$phead='prilist';
$page='Price List';
$print='print';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Price List</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px; text-align:center;">SN</th>   
<th>Name</th>
<th>Code</th>    
<th class="text-center">Available Qty</th>    
<th>Old Price</th>
<th>Current Price</th>
<th class="text-center">Warranty</th>    
<th>Last Update</th>    
<th style="width:40px; text-align:center;">Action</th>    
</tr>
</thead>    
<tbody id="itemdata">
   
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<a href="dai_priceupdate.php" class="btn btn-flat bg-purple">Add/Update Price</a>
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" id="hisdata">

</div>
</div>
</div>
</div>
</div>
</div> 

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->
<?php include('../layout/print.php'); ?>    
<?php include('../layout/rside.php'); ?>    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
ReadITEM();
function ReadITEM() {
$.ajax({
url: "dai_priceup.php",
method: "POST",
data:{viewitem:1},
beforeSend: function () {
$('#datarec').DataTable().clear().destroy();    
},     
success: function(data) {
$('#itemdata').html(data);
$('#datarec').DataTable({stateSave: true});    
}
})
    
$.ajax({
url: "dai_priceup.php",
method: "POST",
data:{viewitemhis:1},    
success: function(data) {
$('#hisdata').html(data);     
}
})   
}
function edit_item(id) {
document.getElementById(id).submit(); 
}
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});

}
    
$(document).on('click', function(e){
if (!$(e.target).is(".right-side-add, .side-cont, #addnew") && !$(e.target).parents(".right-side-add").length) {
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');
}    
});

$(document).on('click', '#closepop', function() {
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }    
});    
    
$(document).on('click', '.edit_price', function(e) {    
id_arr = $(this).attr('id');
id = id_arr.split("_");
ids=id[1];    
$.ajax({
url: "dai_priceup.php",
method: "POST",
data:{addsitem:1,item:ids},
success: function(data){
$('#addsitem').html(data);
$('.right-side-add').toggle('slide', { direction: 'right' }, 300);     
}
})    
e.preventDefault();    
});
    
$(document).on('click', '#additem', function() { 
var cash_data = $('.addservice input');
toastr.options = {'positionClass': 'toast-top-center'};    
if(!chek_error()){   
return;   
}
$.ajax({
url: "dai_priceup.php",
data: cash_data,
type: 'post',
dataType: 'json',    
beforeSend: function () {
chek_error();    
},    
success: function(data){
if(data.status === "success"){
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
toastr.success(data.message);
ReadITEM();    
}else{
toastr.error(data.message);    
}         
}
})    
});
    
$(document).on('click','.barcode',function(e) {      
id_arr = $(this).attr('id');
id = id_arr.split("_");

$.ajax({
url: 'dai_barcode.php',
method: "POST",
data:{ 
invid: id[1]
},
success: function(data){
$('#listitem').html(data);
pagelist();    
}
});    
    
$.ajax({
url: 'dai_barcodeprint.php',
method: "POST",
data:{ 
print: id[1]
},
success: function(data){
$('#invhold').html(data);
sethead();    
}
});
    
$('.right-side').toggle('slide', { direction: 'right' }, 300);    

e.preventDefault();
});
    
$('#listitem').on('click','li', function(){
   $(this).addClass('active').siblings().removeClass('active');
});
    
$(document).on('click', '.invpiv', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
$.ajax({
url: 'dai_barcodeprint.php',
method: "POST",
data:{ 
print: ids
},
beforeSend: function() {
//$("#invhold").fadeOut('slow');
},    
success: function(data){    
$('#invhold').html(data);
$("#invhold").fadeIn('slow');    
sethead();    
}
});     
});     
</script>    
<!-- /page script -->
</html>    