<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('30','views','R');     
$_SESSION['cuPages']='fin_proandlos.php';   
$cuPage='fin_proandlos.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='financ';
$menuh='Financials';
$phead='finprls';
$page='Profit &amp; Loss';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-9">    
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Profit &amp; Loss Statement</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<div class="row">    
<center>
<h3 class="page-title">INCOME STATEMENT</h3>
</center>
</div>
<div class="row" id="itemdata">     

</div>    
</div>
</div>
</div>    
</div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">Filter</h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<div class="col-md-12 popup_details_div">
<div class="col-md-1"></div>
<div class="col-md-10">    
<div class="form-group" >
<label>From:</label>
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-calendar"></span></span>
<input type="text" maxlength="18" class="form-control datetimepicker" id="stdate" placeholder="From Date" autocomplete="off" readonly>
</div>
</div>
<div class="form-group" >
<label>To:</label>
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-calendar"></span></span>
<input type="text" maxlength="18" class="form-control datetimepicker" id="endate" placeholder="End Date" autocomplete="off" readonly>
</div>
</div>
</div>    
<div class="col-md-1"></div>    
</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-6"></div>
<div class="col-md-6 text-right" >
<input type="button" id="reset" class="btn btn-flat bg-red btn-sm " value="Reset"/>    
<input type="button" id="plview" class="btn btn-flat bg-purple btn-sm" value="Submit"/>
</div> 
</div>    
</div>
</div>
</div>
</div>    
</div>
</div>    

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
ReadData();
function ReadData(){
$.ajax({
url: "fin_plview.php",
method: "POST",
data:{ 
body:1
},
success: function(data){
$('#itemdata').html(data);   
}
})
};
    
$(document).on('click', '#plview', function(e) {
var fdate = $('#stdate').val();
var tdate = $('#endate').val();
toastr.options = {'positionClass': 'toast-top-center'};
    
if(fdate.length<=0){
toastr.info('Please Enter From Date!');
return;    
}

if(tdate.length<=0){
toastr.info('Please Enter To Date!');
return;    
}

if(Date.parse(tdate) <= Date.parse(fdate)){
toastr.info('To Date Must Greater or Equel than From Date!');
return;    
}    

$.ajax({
url: "fin_plview.php",
method: "POST",
data:{ 
tfdate:fdate, ttdate:tdate
},
success: function(data){    
$('#itemdata').html(data);   
}
})    
    
});    
</script>    
<!-- /page script -->
</html>    