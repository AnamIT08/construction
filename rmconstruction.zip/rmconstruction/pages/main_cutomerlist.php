<?php session_start();
include('../inc/dbcon.php');
include('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
//get_pagesecurity('35','views','R');     
$_SESSION['cuPages']='main_cutomerlist.php';   
$cuPage='main_cutomerlist.php';
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='client';
$menuh='Client';
$phead='cuslist';
$page='Customer List';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['delcus'])){
$id=$_POST['delcus'];
if(delete_check('tbl_purchase','supid',$id,'type','CU')>0 || delete_check('tbl_sales','cusid',$id,'type','CU')>0 || delete_check('tbl_trarecord','did',$id,'dty','CU')>0 || delete_check('tbl_trarecord','cid',$id,'cty','CU')>0){
save_msg('w','Customer Depend On Other Table!!!');
echo "<script>window.location='main_cutomerlist.php'</script>";
return;    
}
$name=get_fild_data('tbl_customer',$id,'name');   
$sql="DELETE FROM tbl_customer WHERE id='$id'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);    
if($efid>0){    
$act =remove_junk(escape('Customer name: '.$name));    
write_activity($aid,'CUS','Customer has been deleted',$act);       
save_msg('s','Customer Successfully Deleted!!!');
}else{
save_msg('w','Customer Fail to Delete!!!');   
}
echo "<script>window.location='main_cutomerlist.php'</script>";     
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-9">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Customer List</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px;">SN</th>
<th>Name</th>    
<th>Code</th>
<th style="min-width:150px;">Other Info</th>
<th>Address</th>    
<th style="width:40px; text-align:center;">Action</th>    
</tr>    
</thead>    
<tbody>
<?php
$sql="SELECT * FROM tbl_customer ORDER BY name ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$id=$row['id'];
?>
<tr>
<td class="center"><?php echo count_id();?></td>
<td><?php echo show_addres($row['name'],$row['cnumber'],$row['cemail'],'','','CU_'.$row['id']);?></td>     
<td><?php echo $row['code'];?></td>
<td>
<?php 
$exinf='';
if (strlen($row['cperson'])>1){
$exinf.='<strong>'.$row['cperson'].'</strong>';    
}
if(strlen($row['mname'])>1){
if(strlen($exinf)>1){
$exinf.='<br><i class="fa fa-female"></i> '.$row['mname'];    
}else{
$exinf.='<strong>'.$row['mname'].'</strong>';    
}
}
if(strlen($row['nid'])>1){
if(strlen($exinf)>1){
$exinf.='<br><i class="fa fa-ticket"></i> '.$row['nid'];    
}else{
$exinf.='<strong>'.$row['nid'].'</strong>';    
}    
}
echo $exinf;    
?>
</td>
<td><?php echo $row['address'];?></td>    
<td nowrap="">
<?php //if(get_pagesecurity('35','edits','P')){?>    
<a class="btn btn-flat bg-purple" href="#" onclick="edit_item('ED_<?php echo $row['id'];?>')"><i class="fa fa-edit"></i></a>
<?php //} ?>
<?php //if(get_pagesecurity('35','deletes','P')){?>    
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
<form action="main_cutomerlist.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delcus" value="<?php echo $row['id']; ?>" />
</form>
<?php //} ?>
<?php //if(get_pagesecurity('35','edits','P')){?>    
<form action="main_customeredit.php" id="ED_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="editcus" value="<?php echo $row['id']; ?>" />
</form>
<?php //} ?>    
</td>    
</tr>    
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<?php //if(get_pagesecurity('35','creates','P')){?>    
<a href="main_cutomercreate.php" class="btn btn-flat bg-purple">Add Customer</a>
<?php //} ?>    
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'CUS','A');}else{echo read_activity($aid,'CUS','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->
<?php include('../layout/details.php'); ?>    
</div>

<?php include('../layout/footer.php'); ?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
});
function edit_item(id) {
document.getElementById(id).submit(); 
}
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});
}

$(document).on('click', '.detailsrec', function(e) {    
id_arr = $(this).attr('id');
id = id_arr.split("_");
if(id[1]==0)return;

$.ajax({
url: 'axe_details.php',
method: "POST",
data:{ 
cusdet: 1,cusid: id[1],type:id[0]
},
success: function(data){
$('#profile').html(data);    
}
});    
    
$.ajax({
url: 'axe_details.php',
method: "POST",
data:{ 
tradet: 1,cusid: id[1],type:id[0]
},
success: function(data){
$('#details').html(data);   
}
});    
    
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);    
e.preventDefault();    
});
    
$(document).on('click', '#closedet', function() {
$('#profile').html('');
$('#details').html('');    
if($('.right-side-details').is(':visible')) {
$('.right-side-details').toggle('slide', { direction: 'right' }, 300);
}    
});    
</script>
<!-- /page script -->
</html>