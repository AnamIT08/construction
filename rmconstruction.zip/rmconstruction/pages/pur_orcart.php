<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
include ('../inc/repfunctions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
$today = strftime("%Y-%m-%d", time());    
$dtnow = date("Y-m-d h:i:s", time());    
}else{
header('Location:../index.php');
exit;    
}

if(isset($_POST['additem'])){
$pid=intval($_POST['additem']);
$col=$_POST['col'];
$siz=$_POST['siz'];    
addpurorder($pid,1,$col,$siz);    
}

if(isset($_POST['itmsear'])){
$search = $_POST['search'];
$sql = "SELECT id,code,name FROM tbl_item WHERE status='1' AND (name LIKE '%$search%' OR code LIKE '%$search%') LIMIT 20";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
while($row = mysqli_fetch_array($result) ){
$response[] = array("value"=>$row['id'],"label"=>$row['code'].' | '.$row['name']);
}

echo json_encode($response);
exit;    
}

if(isset($_POST['remove'])){
$ids = floatval($_POST['remove']);
$pid=$_SESSION['axes_purorder'][$ids]['pid'];    
remove_purorder($ids);       
$max=count($_SESSION['axes_purorder']);
if($max <= 0){
unset($_SESSION['axes_purorder']);
unset($_SESSION['axes_orderde']);	
}   
}

if(isset($_POST['upqty'])){
$ids=intval($_POST['upqty']);
$qty=floatval($_POST['qty']);
if($qty<0 || $qty==''){exit;}
$dis = $_SESSION['axes_purorder'][$ids]['disf']; 
$_SESSION['axes_purorder'][$ids]['qty']=$qty;
$cost = $_SESSION['axes_purorder'][$ids]['cost'];
$sqty = $_SESSION['axes_purorder'][$ids]['qty'];
$disamo = ($dis*$sqty);
$stot = ($cost*$sqty);
if($cost>0){
$disp=(($dis/$cost)*100);
}else{
$disp=0;	
}
$_SESSION['axes_purorder'][$ids]['disp']=getfloatval($disp);
$_SESSION['axes_purorder'][$ids]['disamo']=$disamo;
$_SESSION['axes_purorder'][$ids]['subtot'] = ($stot-$disamo);
$redata=array($_SESSION['axes_purorder'][$ids]['qty'],$_SESSION['axes_purorder'][$ids]['cost'],$_SESSION['axes_purorder'][$ids]['disp'],$_SESSION['axes_purorder'][$ids]['disf'],$_SESSION['axes_purorder'][$ids]['wday'],$_SESSION['axes_purorder'][$ids]['subtot'],$_SESSION['axes_purorder'][$ids]['price'],$_SESSION['axes_purorder'][$ids]['sdisp'],$_SESSION['axes_purorder'][$ids]['sdisf'],$_SESSION['axes_purorder'][$ids]['disamo']);
echo json_encode($redata);
}

if(isset($_POST['upcost'])){
$ids=intval($_POST['upcost']);
$amo=floatval($_POST['amo']);
if($amo<0 || $amo==''){exit;}
$qty=$_SESSION['axes_purorder'][$ids]['qty'];
$dis=$_SESSION['axes_purorder'][$ids]['disf'];
$_SESSION['axes_purorder'][$ids]['cost']=$amo;
$disamo= ($dis*$qty);
$disp=(($dis/$amo)*100);
$_SESSION['axes_purorder'][$ids]['disp']=getfloatval($disp);
$_SESSION['axes_purorder'][$ids]['disamo']=$disamo;
$_SESSION['axes_purorder'][$ids]['subtot']=(($amo*$qty)-$disamo);
$redata=array($_SESSION['axes_purorder'][$ids]['qty'],$_SESSION['axes_purorder'][$ids]['cost'],$_SESSION['axes_purorder'][$ids]['disp'],$_SESSION['axes_purorder'][$ids]['disf'],$_SESSION['axes_purorder'][$ids]['wday'],$_SESSION['axes_purorder'][$ids]['subtot'],$_SESSION['axes_purorder'][$ids]['price'],$_SESSION['axes_purorder'][$ids]['sdisp'],$_SESSION['axes_purorder'][$ids]['sdisf'],$_SESSION['axes_purorder'][$ids]['disamo']);
echo json_encode($redata);	
}

if(isset($_POST['itemdisp'])){
$ids=intval($_POST['itemdisp']);
$disc=floatval($_POST['disp']);
//if( $disc==''){exit;}
$_SESSION['axes_purorder'][$ids]['disp']=$disc;
$cost=$_SESSION['axes_purorder'][$ids]['cost'];
$uqty=$_SESSION['axes_purorder'][$ids]['qty'];
$dis=(($cost*$disc)*0.01);
$disamo = ($dis*$uqty); 
$_SESSION['axes_purorder'][$ids]['disf']=getfloatval($dis);
$_SESSION['axes_purorder'][$ids]['disamo']=getfloatval($disamo);
$_SESSION['axes_purorder'][$ids]['subtot']=(($cost*$uqty)-$disamo);
$redata=array($_SESSION['axes_purorder'][$ids]['qty'],$_SESSION['axes_purorder'][$ids]['cost'],$_SESSION['axes_purorder'][$ids]['disp'],$_SESSION['axes_purorder'][$ids]['disf'],$_SESSION['axes_purorder'][$ids]['wday'],$_SESSION['axes_purorder'][$ids]['subtot'],$_SESSION['axes_purorder'][$ids]['price'],$_SESSION['axes_purorder'][$ids]['sdisp'],$_SESSION['axes_purorder'][$ids]['sdisf'],$_SESSION['axes_purorder'][$ids]['disamo']);
echo json_encode($redata);
}

if(isset($_POST['itemdisf'])){
$ids=intval($_POST['itemdisf']);
$dica=floatval($_POST['disf']);
$cost=$_SESSION['axes_purorder'][$ids]['cost'];
$uqty=$_SESSION['axes_purorder'][$ids]['qty'];
$disp=(($dica/$cost)*100);
$_SESSION['axes_purorder'][$ids]['disf']=getfloatval($dica);
$disamo = ($dica*$uqty);
$_SESSION['axes_purorder'][$ids]['disamo']=getfloatval($disamo);
if($dica<=0){
$_SESSION['axes_purorder'][$ids]['disp']=getfloatval(0);	
}else{
$_SESSION['axes_purorder'][$ids]['disp']=getfloatval($disp);	
}
$_SESSION['axes_purorder'][$ids]['subtot']=(($cost*$uqty)-$disamo);
$redata=array($_SESSION['axes_purorder'][$ids]['qty'],$_SESSION['axes_purorder'][$ids]['cost'],$_SESSION['axes_purorder'][$ids]['disp'],$_SESSION['axes_purorder'][$ids]['disf'],$_SESSION['axes_purorder'][$ids]['wday'],$_SESSION['axes_purorder'][$ids]['subtot'],$_SESSION['axes_purorder'][$ids]['price'],$_SESSION['axes_purorder'][$ids]['sdisp'],$_SESSION['axes_purorder'][$ids]['sdisf'],$_SESSION['axes_purorder'][$ids]['disamo']);
echo json_encode($redata);
}

if(isset($_POST['warranty'])){
$ids=intval($_POST['warranty']);
$wday=floatval($_POST['wday']);
if($wday<0 || $wday==''){$wday=0;}
$_SESSION['axes_purorder'][$ids]['wday']=$wday;
$redata=array($_SESSION['axes_purorder'][$ids]['qty'],$_SESSION['axes_purorder'][$ids]['cost'],$_SESSION['axes_purorder'][$ids]['disp'],$_SESSION['axes_purorder'][$ids]['disf'],$_SESSION['axes_purorder'][$ids]['wday'],$_SESSION['axes_purorder'][$ids]['subtot'],$_SESSION['axes_purorder'][$ids]['price'],$_SESSION['axes_purorder'][$ids]['sdisp'],$_SESSION['axes_purorder'][$ids]['sdisf'],$_SESSION['axes_purorder'][$ids]['disamo']);
echo json_encode($redata);
}

if(isset($_POST['foot'])){
$disp=$_SESSION['axes_orderde'][0]['disp'];
$redata=array($_SESSION['axes_orderde'][0]['disp'],(get_orddiscount_total(floatval($disp))-get_orddiscount_total()),get_orddiscount_total($disp),$_SESSION['axes_orderde'][0]['vatp'],$_SESSION['axes_orderde'][0]['vatamo'],$_SESSION['axes_orderde'][0]['freight'],$_SESSION['axes_orderde'][0]['less'],$_SESSION['axes_orderde'][0]['gtotal'],$_SESSION['axes_orderde'][0]['taxp'],$_SESSION['axes_orderde'][0]['taxamo'],$_SESSION['axes_orderde'][0]['spmony'],$_SESSION['axes_orderde'][0]['others'],$_SESSION['axes_orderde'][0]['name']);
echo json_encode($redata);	
exit;
}

if(isset($_POST['purdis'])){
$disp=floatval($_POST['purdis']);
if(isset($_SESSION['axes_orderde'])){
if($disp>0){
$_SESSION['axes_orderde'][0]['disp']= getfloatval($disp);
$_SESSION['axes_orderde'][0]['disamo']=getfloatval(get_orddiscount_total(floatval($disp)));    
}else{    
$_SESSION['axes_orderde'][0]['disp']= getfloatval(0);
$_SESSION['axes_orderde'][0]['disamo']=getfloatval(0);    
}
}
}

if(isset($_POST['purvat'])){
$rvat=floatval($_POST['purvat']);
$disp=$_SESSION['axes_orderde'][0]['disp'];    
if(isset($_SESSION['axes_orderde'])){
if($rvat>0){	
$_SESSION['axes_orderde'][0]['vatp']= getfloatval($rvat);
$_SESSION['axes_orderde'][0]['vatamo']= getfloatval((((get_porder_total()-(get_orddiscount_total($disp)-get_orddiscount_total()))*$rvat)*0.01));    
}else{    
$_SESSION['axes_orderde'][0]['vatp']= 0;
$_SESSION['axes_orderde'][0]['vatamo']= 0;    
}
} 
}

if(isset($_POST['purtax'])){
$rtax=floatval($_POST['purtax']);
$disp=$_SESSION['axes_orderde'][0]['disp'];    
if(isset($_SESSION['axes_orderde'])){
if($rtax>0){	
$_SESSION['axes_orderde'][0]['taxp']= getfloatval($rtax);
$_SESSION['axes_orderde'][0]['taxamo']= getfloatval((((get_porder_total()-(get_orddiscount_total($disp)-get_orddiscount_total()))*$rtax)*0.01));    
}else{    
$_SESSION['axes_orderde'][0]['taxp']= 0;
$_SESSION['axes_orderde'][0]['taxamo']= 0;    
}
}
}

if(isset($_POST['others'])){
$ota=floatval($_POST['others']);
if(isset($_SESSION['axes_orderde'])){
$_SESSION['axes_orderde'][0]['others']=getfloatval($ota);	
}
}

if(isset($_POST['otname'])){
$otn=$_POST['otname'];
if($otn==''){return;}
if(isset($_SESSION['axes_orderde'])){
$_SESSION['axes_orderde'][0]['name']=ucwords($otn);	
}	
}

if(isset($_POST['spmoney'])){
$spe=floatval($_POST['spmoney']);
if(isset($_SESSION['axes_orderde'])){
$_SESSION['axes_orderde'][0]['spmony']=getfloatval($spe);	
} 
}

if(isset($_POST['freight'])){
$fre=floatval($_POST['freight']);
if(isset($_SESSION['axes_orderde'])){
$_SESSION['axes_orderde'][0]['freight']=getfloatval($fre);	
}
}

if(isset($_POST['less'])){
$less=floatval($_POST['less']);
if(isset($_SESSION['axes_orderde'])){
if($less>0){
$_SESSION['axes_orderde'][0]['less']= getfloatval($less);    
}else{    
$_SESSION['axes_orderde'][0]['less']= 0;   
}
}
}

if(isset($_SESSION['axes_orderde'])){
if(is_array($_SESSION['axes_orderde'])){    
$disps=$_SESSION['axes_orderde'][0]['disp'];
if($disps>0){
$_SESSION['axes_orderde'][0]['disamo']=getfloatval(get_orddiscount_total(floatval($disps)));	
}else{
$_SESSION['axes_orderde'][0]['disamo']=getfloatval(get_orddiscount_total());	
}
$vatps=$_SESSION['axes_orderde'][0]['vatp'];
if($vatps>0){
$_SESSION['axes_orderde'][0]['vatamo']= getfloatval(((get_porder_total()-(get_orddiscount_total($disps)- get_orddiscount_total()))*$vatps)*0.01);	
}
$taxps=$_SESSION['axes_orderde'][0]['taxp'];
if($taxps>0){
$_SESSION['axes_orderde'][0]['taxamo']= getfloatval(((get_porder_total()-(get_orddiscount_total($disps)- get_orddiscount_total()))*$taxps)*0.01);	
}
$freight=$_SESSION['axes_orderde'][0]['freight'];
$vatamos=$_SESSION['axes_orderde'][0]['vatamo'];
$taxamos=$_SESSION['axes_orderde'][0]['taxamo'];
$spmoney=$_SESSION['axes_orderde'][0]['spmony'];
$other=$_SESSION['axes_orderde'][0]['others'];
$lesss=$_SESSION['axes_orderde'][0]['less'];    
}else{
$disps=0;
$vatps=0;
$vatamos=0;
$taxamos=0;
$spmoney=0;
$freight=0;
$other=0;
$lesss=0;    
}
$_SESSION['axes_orderde'][0]['gtotal']=getfloatval((get_porder_total()+$vatamos+$spmoney+$other+$taxamos+$freight)-((get_orddiscount_total(floatval($disps))- get_orddiscount_total())+$lesss));
}

if(isset($_POST['clear'])){
if(isset($_SESSION['axes_purorder'])){
unset($_SESSION['axes_purorder']);
unset($_SESSION['axes_orderde']);    
}
}

if(isset($_POST['supbal'])){
if(strlen($_POST['supbal'])>0){    
$id=str_replace('_','',$_POST['supbal']);
$ldebit=get_ledgerval($id,'D','N');
$lcredit=get_ledgerval($id,'C','N');
$lnet=($ldebit-$lcredit);
echo number_format($lnet,2);
}else{
echo '0.00';    
}    
}

if(isset($_POST['purdata'])){
$edata=array(getcheck_ordprice('IC'),getcheck_ordprice('PC'));
echo json_encode($edata);
}

if(isset($_POST['addpurorder'])){
$invno = gen_newinvno('tbl_purorder','POR');
$apdate = remove_junk(escape($_POST['purdt']));
$nxtdt = remove_junk(escape($_POST['nextdt']));    
    
$sdata=explode('_',remove_junk(escape($_POST['customer'])));
$dty=$sdata['0'];    
$did = $sdata['1'];

$ref = remove_junk(escape($_POST['ref']));
$note = remove_junk(escape($_POST['note']));
$purp = remove_junk(escape($_POST['purp']));
if($purp=='' || $purp=='-Select-'){$purp='NULL';}else{$purp="'".$purp."'";}     
    
$itmdis=remove_junk(escape(get_orddiscount_total()));    
$disp=remove_junk(escape($_SESSION['axes_orderde'][0]['disp']));
$disamo=remove_junk(escape($_SESSION['axes_orderde'][0]['disamo']));   
$vatp=remove_junk(escape($_SESSION['axes_orderde'][0]['vatp']));
$vatamo=remove_junk(escape($_SESSION['axes_orderde'][0]['vatamo']));
$taxp=remove_junk(escape($_SESSION['axes_orderde'][0]['taxp']));
$itax=$taxp;    
$taxamo=remove_junk(escape($_SESSION['axes_orderde'][0]['taxamo']));
$freight=remove_junk(escape($_SESSION['axes_orderde'][0]['freight']));
$spmony=remove_junk(escape($_SESSION['axes_orderde'][0]['spmony']));
$otname=remove_junk(escape($_SESSION['axes_orderde'][0]['name']));
$otamo=remove_junk(escape($_SESSION['axes_orderde'][0]['others']));
$less=remove_junk(escape($_SESSION['axes_orderde'][0]['less']));
$subtot=get_porder_total();    
$gtotal=remove_junk(escape($_SESSION['axes_orderde'][0]['gtotal']));
if($disp>0){
$invdis=($disamo-$itmdis);    
}else{
$invdis=0;    
}
    
if(!isset($_SESSION['axes_purorder'])){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! No item found!!'
));
return;
exit;  
}   

$sql="INSERT INTO tbl_purorder (invno,type,supid,itemdis,subtot,disp,disamo,totdis,vatp,vatamo,taxp,taxamo,spmoney,otname,otamo,freight,less,total,curid,ref,note,apdate,expdate,purp,brid,uid,date) VALUES ('$invno','$dty','$did','$itmdis','$subtot','$disp','$invdis','$disamo','$vatp','$vatamo','$taxp','$taxamo','$spmony','$otname','$otamo','$freight','$less','$gtotal','0','$ref','$note','$apdate','$nxtdt',$purp,'$brid','$aid','$dtnow')";
   
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sid=$con->insert_id;    
$efid=mysqli_affected_rows($con);
  
if($efid>0){
$max=count($_SESSION['axes_purorder']);
for($i=0;$i<$max;$i++){
$pid=$_SESSION['axes_purorder'][$i]['pid'];   
$col=$_SESSION['axes_purorder'][$i]['col'];
$siz=$_SESSION['axes_purorder'][$i]['siz'];
$eqty=$_SESSION['axes_purorder'][$i]['eqty'];
$oldcost = get_proval($pid,'C');    
$cost=$_SESSION['axes_purorder'][$i]['cost'];
$puqty=$_SESSION['axes_purorder'][$i]['qty'];   

    
$soqty=0;
$qtyout=0;
$taxp=0;
$taxamo=0;
$idisp=$_SESSION['axes_purorder'][$i]['disp'];
$idisf=$_SESSION['axes_purorder'][$i]['disf'];
$disamo=$_SESSION['axes_purorder'][$i]['disamo'];
$sdisp=$_SESSION['axes_purorder'][$i]['sdisp'];
$sdisf=$_SESSION['axes_purorder'][$i]['sdisf'];
$price=$_SESSION['axes_purorder'][$i]['price'];
$isubtot=$_SESSION['axes_purorder'][$i]['subtot'];
$wday=$_SESSION['axes_purorder'][$i]['wday'];    
    
$sql="INSERT INTO tbl_purorderde (invno,pid,colid,sizid,exqty,oldprice,cuqty,cuprice,disp,disf,disamo,taxp,taxamo,vatp,vatamo,wday,subtot,pnote) VALUES ('$invno','$pid','$col','$siz','$eqty','$oldcost','$puqty','$cost','$idisp','$idisf','$disamo','$taxp','$taxamo','0','0','$wday','$isubtot',NULL)";  
$result = mysqli_query($con,$sql) or die(mysqli_error($con));    
}
   
unset($_SESSION['axes_purorder']);
unset($_SESSION['axes_orderde']);
    
$act =remove_junk(escape('Order Invoice: '.$invno));
$bact =remove_junk('ক্রয় আদেশ নং: '.$invno);    
write_activity($aid,'POR','New Purchase Order has been Created',$act,'নতুন ক্রয় আদেশের রসিদ করেছেন ',$bact);
echo json_encode(array(
'status' => 'success',
'message'=> 'Purchase Order Save Successfully!!',
'invid'=> $sid     
));
exit;    
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));    
}    
}
?>

<?php 
if(isset($_POST['checkview'])){
$cusd=explode('_',$_POST['cusid']);
$typ=$cusd[0];    
$cusid=$cusd[1];   
if(isset($_SESSION['axes_orderde'])){    
$gtotal=$_SESSION['axes_orderde'][0]['gtotal'];
}else{
$gtotal=0;    
}
$id=str_replace('_','',$_POST['cusid']);
$ldebit=get_ledgerval($id,'D','N');
$lcredit=get_ledgerval($id,'C','N');
if($cusid!=0){
$lnet=($ldebit-$lcredit);     
}else{
$lnet=0;    
}        
?>
<div class="addpurorder">
<div class="row">
<div class="col-md-3 col-xs-6">
<div class="small-box">
<div class="inner">
<h3 id="pabamo"><?php echo $gtotal;?></h3>
<p>Order Total</p>
</div>

</div>
<input type="hidden" value="<?php echo $_POST['cusid']; ?>" id="customer" name="customer" readonly />
<input type="hidden" value="<?php if($lnet<0){echo ABS($lnet);}else{echo 0;} ?>" id="balance" name="balance" readonly />
<input type="hidden" name="addpurorder" readonly />
<input type="hidden" name="scusid" id="scusid" value="<?php echo $cusid; ?>" readonly />    
</div>   
</div>
<div class="row">
<div class="col-md-2 col-xs-6">
<div class="form-group" >
<label>Order Date</label>
<input type="text" class="form-control datetimepicker" name="purdt" id="purdt" value="<?php echo $today;?>" placeholder="Order Date" autocomplete="off" readonly>
</div>
</div>
<div class="col-md-2 col-xs-6">
<div class="form-group" >
<label>Expire Date</label>
<input type="text" class="form-control datetimepicker" name="nextdt" id="nextdt" value="<?php echo date('Y-m-d', strtotime('+7 days',strtotime($today)));?>" placeholder="Expire Date" autocomplete="off" readonly>
</div>    
</div>
</div>
<div class="row">
<br>   
<div class="col-md-4">   
<div class="form-group">
<label>Ref</label>
<input type="text" maxlength="25" class="form-control" name="ref" id="ref" placeholder="e.g. #ORD8976453" autocomplete="off">    
</div>
<div class="form-group">
<label>Request Person</label>    
<select class="form-control select2" name="purp" id="purp">
<option value="">-Select-</option>    
<?php
$sql="SELECT id,name FROM tbl_employe ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>    
</div>    
</div>
<div class="col-md-8">    
<div class="form-group">    
<label>Note</label>
<textarea class="form-control" name="note" id="note" maxlength="150" rows="5" placeholder="Invoice Note"></textarea>    
</div>   
</div>    
</div>
</div>    
<div class="row">
<div class="col-md-12 text-center side-checkhead">
<button class="btn btn-flat bg-blue saveseinv" id="saveinv"><i class="fa fa-floppy-o"></i>&nbsp;&nbsp;Save</button>    
<button class="btn btn-flat bg-gray saveseinv" id="sinvprint"><i class="fa fa-floppy-o"></i>&nbsp;&nbsp; Invoice &nbsp;&nbsp;<i class="fa fa-print"></i></button>   
</div>    
</div>
<script type="text/javascript">    
$(".select2").select2();    
$('.datetimepicker').datepicker({format: "yyyy-mm-dd", autoclose: true, clearBtn: true, orientation: 'auto bottom'});    
</script>    
<?php } ?>

<?php 
if(isset($_POST['checkout'])){
$cusd=explode('_',$_POST['cusid']);
$typ=$cusd[0];    
$cusid=$cusd[1];    
?>
<div class="col-md-12 cart-border-left text-center">
<div class="horizontal-scroll">
<h5 class="text-center" style="font-size: 20px;">Purchase Order Details</h5> 
<div>
<div class="text-center header-line-height">
<small class="text-center" style="font-size: 15px;"><?php echo get_cominfo('1','name');?></small>
<br> <small class="text-center"><?php echo date("d M Y", strtotime($today));?></small>
<br> <small class="text-center" style="font-size: 12px;"><strong>Purchase Order Receipt</strong></small>
<!--<br> <small class="text-left">Sold By: John Doe</small>--> 
<br> <small><span>Order To: <?php if($cusid!=0){if($typ=='SU'){echo get_fild_data('tbl_supplier',$cusid,'name');}else{echo get_fild_data('tbl_customer',$cusid,'name');}}else{echo 'Walk-In Customer';};?></span></small> 
<small class="text-left invoice-show" style="display: none;">Invoice ID:</small>
</div> 
<div class="invoice-table">
<table class="table product-card-font" style="font-weight: 500;">
<thead class="border-top-0">    
<tr>
<th class="cart-summary-table text-left">Items</th> 
<th class="cart-summary-table text-left">Qty</th> 
<th class="cart-summary-table text-right">Price</th>
<th class="cart-summary-table text-right">Discount</th>
<th class="cart-summary-table text-right" width="80px;">Total</th>
</tr>   
</thead> 
<tbody>
<?php 
$s=0;    
if(isset($_SESSION['axes_purorder'])){
$max=count($_SESSION['axes_purorder']);
for($i=($max-1);$i>=0;$i=$i-1){
$name=$_SESSION['axes_purorder'][$i]['name'];
$col=$_SESSION['axes_purorder'][$i]['col'];
if($col==0){$col='';}
$siz=$_SESSION['axes_purorder'][$i]['siz'];
if($siz==0){$siz='';}    
$qty=$_SESSION['axes_purorder'][$i]['qty'];
$price=$_SESSION['axes_purorder'][$i]['cost'];
$disp=$_SESSION['axes_purorder'][$i]['disp'];    
$subtot=$_SESSION['axes_purorder'][$i]['subtot'];
$pnote=$_SESSION['axes_purorder'][$i]['price'];
if($col=='' && $siz==''){
$name=$name;    
}elseif($col!='' && $siz==''){
$name= $name.' '.get_fild_data('tbl_color',$col,'name');    
}elseif($col=='' && $siz!=''){
$name= $name.' '.get_fild_data('tbl_size',$siz,'sval');    
}elseif($col!='' && $siz!=''){    
$name= $name.' '.get_fild_data('tbl_color',$col,'name').' '.get_fild_data('tbl_size',$siz,'sval');    
}     
$s+=1;    
?>    
<tr>
<td class="cart-summary-table text-left"><?php echo $name;?><br></td>
<td class="cart-summary-table"><?php echo $qty;?></td> 
<td class="text-right cart-summary-table"><?php echo numtolocal($price,''); ?></td> 
<td class="text-right cart-summary-table"><?php echo $disp;?> %</td> 
<td class="text-right cart-summary-table"><?php echo numtolocal($subtot,''); ?></td>
<?php }} ?>     
</tbody> 
<tfoot>
<?php 
$disp=$_SESSION['axes_orderde'][0]['disp'];
$vatp=$_SESSION['axes_orderde'][0]['vatp'];
$vatamo=$_SESSION['axes_orderde'][0]['vatamo'];
$taxp=$_SESSION['axes_orderde'][0]['taxp'];
$taxamo=$_SESSION['axes_orderde'][0]['taxamo'];
$otname=$_SESSION['axes_orderde'][0]['name'];
$others=$_SESSION['axes_orderde'][0]['others'];
$spmony=$_SESSION['axes_orderde'][0]['spmony'];    
$less=$_SESSION['axes_orderde'][0]['less'];
$freight=$_SESSION['axes_orderde'][0]['freight'];
$gtotal=$_SESSION['axes_orderde'][0]['gtotal'];    
?>    
<tr>
<td class="cart-summary-table font-weight-bold text-left">Sub Total</td> 
<td class="cart-summary-table"></td>
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table"><?php echo numtolocal(get_porder_total(),'Tk');?></td>
</tr>
<?php if(get_orddiscount_total()>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">Discount(<?php echo $disp.'';?>%)</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal(get_orddiscount_total($disp),'Tk');?></td>
</tr>    
<?php } ?>
<?php if($vatamo>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">VAT(<?php echo $vatp.'';?>%)</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($vatamo,'Tk');?></td>
</tr>    
<?php } ?>
<?php if($taxamo>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">TAX(<?php echo $taxp.'';?>%)</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($taxamo,'Tk');?></td>
</tr>    
<?php } ?>    
<?php if($others>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left"><?php echo $otname;?></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($others,'Tk');?></td>
</tr>    
<?php } ?>
<?php if($spmony>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">Speed Money</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($spmony,'Tk');?></td>
</tr>    
<?php } ?>    
<?php if($freight>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">Freight</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($freight,'Tk');?></td>
</tr>    
<?php } ?> 
<?php if($less>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">Adjust</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($less,'Tk');?></td>
</tr>    
<?php } ?>     
<tr>
<td class="cart-summary-table font-weight-bold text-left">Total</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($gtotal,'Tk');?></td>
</tr> 
</tfoot>
</table>
</div>
</div>
</div>
</div>   
<?php } ?>