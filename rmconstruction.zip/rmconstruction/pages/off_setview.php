<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
$body='';
$buton='';
$s=0;
if(isset($_SESSION['axes_offer'])){
if(is_array($_SESSION['axes_offer'])){
$max=count($_SESSION['axes_offer']);
for($i=($max-1);$i>=0;$i=$i-1){
$s+=1;
$name=$_SESSION['axes_offer'][$i]['itmname'];
$ofname=$_SESSION['axes_offer'][$i]['ofname'];    
$body.='<tr>';
$body.='<td class="text-center" width="30px">'.$s.'</td>';
$body.='<td width="280px" class="text-left">'.$name.'</td>';
$body.='<td width="180px" class="text-left">'.$ofname.'</td>';    
$body.='<td class="text-center" width="25px"><a id="'.$i.'" class="remove"><span style="cursor: pointer;" class="fa fa-times"></span></a></td>';    
$body.='</tr>';    
}
}else{
$body.='<tr>';
$body.='<td colspan="4" class="text-center">There are no Offer Item!</td>';
$body.='</tr>'; 
} 
}else{
$body.='<tr>';
$body.='<td colspan="4" class="text-center">There are no Offer Item!</td>';
$body.='</tr>';
}

if(isset($_SESSION['axes_offer'])){
$buton.='<br>';    
$buton.='<div class="col-md-6">';
$buton.='<input type="button" id="emptycart" class="btn btn-flat bg-red btn-sm" value="Empty"/></div>';
$buton.='<div class="col-md-6 text-right">';   
$buton.='<input type="button" id="save_offer" class="btn btn-flat bg-purple btn-sm" value="Set Offer"/>'; 
$buton.='</div>';
}

if(isset($_POST['body'])){
echo $body;
}elseif(isset($_POST['buton'])){
echo $buton;    
}
exit;