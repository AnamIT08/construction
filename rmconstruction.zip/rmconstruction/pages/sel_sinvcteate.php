<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='sel_sinvcteate.php';   
$cuPage='sel_sinvcteate.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='sales';
$menuh='Sales';
$phead='sinvcreate';
$page='Invoice Create';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-7">
<div class="box box-solid">
<div class="box-body">
<div class="col-md-12">
<div class="row">
<div class="col-md-12">
<div class="form-group text-center">
<ul style="margin-top: 0;" class="pagination alphabets"><li><a data-id="" href="#"><b>ALL</b></a></li><li><a href="#" data-id="A"><b>A</b></a></li><li><a href="#" data-id="B"><b>B</b></a></li><li><a href="#" data-id="C"><b>C</b></a></li><li><a href="#" data-id="D"><b>D</b></a></li><li><a href="#" data-id="E"><b>E</b></a></li><li><a href="#" data-id="F"><b>F</b></a></li><li><a href="#" data-id="G"><b>G</b></a></li><li><a href="#" data-id="H"><b>H</b></a></li><li><a href="#" data-id="I"><b>I</b></a></li><li><a href="#" data-id="J"><b>J</b></a></li><li><a href="#" data-id="K"><b>K</b></a></li><li><a href="#" data-id="L"><b>L</b></a></li><li><a href="#" data-id="M"><b>M</b></a></li><li><a href="#" data-id="N"><b>N</b></a></li><li><a href="#" data-id="O"><b>O</b></a></li><li><a href="#" data-id="P"><b>P</b></a></li><li><a href="#" data-id="Q"><b>Q</b></a></li><li><a href="#" data-id="R"><b>R</b></a></li><li><a href="#" data-id="S"><b>S</b></a></li><li><a href="#" data-id="T"><b>T</b></a></li><li><a href="#" data-id="U"><b>U</b></a></li><li><a href="#" data-id="V"><b>V</b></a></li><li><a href="#" data-id="W"><b>W</b></a></li><li><a href="#" data-id="X"><b>X</b></a></li><li><a href="#" data-id="Y"><b>Y</b></a></li><li><a href="#" data-id="Z"><b>Z</b></a></li></ul>    
</div>     
<div class="form-group">  
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>
<input type="text" class="form-control" name="search" id="search" placeholder="e.g. Product Code or Name" autocomplete="off">    
</div>
</div>   
</div>   
</div>
<div class="row">
<div class="product-panel style-2" id="purchaseitem">

</div>
</div>
</div>    
</div>
</div>
</div>
<div class="col-md-5">
<div class="box box-solid">
<div class="box-body">

<div class="col-md-12">
<div class="row">
<div class="col-md-9">
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-user-o"></span></span>
<span class="input-group-addon"><a data-toggle="collapse" data-target="#walkcus" class="accordion-toggle" id="walkin" style="cursor: pointer;">Walk-In</a></span>   
<input type="text" class="form-control" id="cusname" value="" placeholder="Type Customer Code, Name Or Mobile No..." autocomplete="off" />
<span class="input-group-addon"><a id="addcus" style="cursor: pointer;"><span class="fa fa-plus"></span></a></span>    
</div>
<input type="hidden" name="cusid" id="cusid" class="form-control" value="" readOnly />    
</div>    
</div>
<div class="col-md-3"><span style="font-size: 18px;color: red;font-weight: bold;">Bal.: </span><span style="font-size: 18px;color: blue;font-weight: bold;" id="cusbal">0.00</span></div>    
</div>
<div class="row">   
<div class="accordian-body collapse" id="walkcus">
<div class="col-md-6">    
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-id-card-o"></span></span>    
<input type="text" id="walkname" maxlength="35" class="form-control" value="Walk-In Customer" placeholder="Customer Name" autocomplete="off">
</div>
</div>
<div class="form-group">
<label>Select District</label>
<select class="form-control select2" name="wdid" id="wdid" onchange="getAllSubwgroup(this.value)">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_district ORDER BY name ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>    
</div>
<div class="form-group">
<label>Email</label>
<input type="text" name="wemail" maxlength="50" value="" id="wemail" class="form-control" placeholder="e.g. info@axesgl.com"/>   
</div>    
</div>
<div class="col-md-6">     
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-mobile"></span></span>    
<input type="text" id="walkmobile" maxlength="18" class="form-control" value="" placeholder="e.g. 016167xx7x" autocomplete="off">
</div>
</div>
<div class="form-group">
<label>Select Zone</label>
<select class="form-control select2" name="wzid" id="wzid">
<option value="">-Select-</option>    
</select>     
</div>
<div class="form-group">
<label>Address</label>
<input type="text" name="wadd" maxlength="250" value="" id="wadd" class="form-control" placeholder="e.g. B-323, Khilgaon"/>   
</div>    
</div>    
</div>    
</div>     
<div class="row">
<div class="col-md-8">
<div class="form-group">  
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>
<input type="text" class="form-control" id="pcode" placeholder="e.g. Product Code or Name" autocomplete="off">   <span class="input-group-addon"><a id="addpro" style="cursor: pointer;"><span class="fa fa-plus"></span></a></span>  
</div>
</div>       
</div>
<div class="col-md-4">
<div class="form-group">  
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-barcode"></span></span>
<input type="text" class="form-control" id="bcode" placeholder="e.g. Barcode" autocomplete="off">   
</div>
</div>
</div>       
</div>
    
<div class="row">
<div class="cart cart-sm">     
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<thead>
<th width="30px">SN</th>
<th width="214px">Item</th>
<th width="72px">Qty</th>
<th width="72px">Price</th>
<th width="35px">ASL</th>    
<th width="77px">SubTotal</th>
<th width="25px"><a class="empty" style="cursor: pointer;"><i class="fa fa-trash"></i></a></th>    
</thead>
</table>
<div class="cart-msg style-3 item" style="padding:0px;">    
<table class="table table-bordered table-striped" style="margin-bottom: 0;">    
<tbody id="itemdata">

</tbody>    
</table>
</div>
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<tfoot id="itemfoot">

</tfoot>
</table>    
</div>    
</div>
    
<div class="row" id="serialpro">
    
    
</div>    
  
<div class="row" id="extra">
 
</div>     
    
</div> 
    
</div>
</div>
</div>
</div>
    
<div class="rotate btn-cat-con">
<button type="button" id="open-brands" class="btn btn-info open-brands" tabindex="-1">Brands</button>
<button type="button" id="open-subcategory" class="btn btn-warning open-subcategory" tabindex="-1">Sub Categories</button>
<button type="button" id="open-category" class="btn btn-primary open-category" tabindex="-1">Categories</button>
</div>
    
<div id="brands-slider">
<div class="row">
<div class="col-md-2"></div>
<div class="col-md-8">
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>    
<input type="text" class="form-control form-control-lg" id="searchbrands" placeholder="Search by Name" autocomplete="off">
</div>
</div>
</div>    
</div>
<div class="col-md-2"></div>
<div id="brands-list" class="ps-container style-2">
<button id="brand_0" type="button" value="0" class="btn-prni brand" tabindex="-1"><img src="../img/product/no_image.png" class="img-rounded img-thumbnail"><span>ALL Brands</span></button>
<?php
$sql="SELECT tbl_brstock.brnid AS id,tbl_brand.name FROM tbl_brstock  LEFT JOIN tbl_brand ON tbl_brand.id=tbl_brstock.brnid WHERE tbl_brstock.brnid IS NOT NULL GROUP BY tbl_brstock.brnid ORDER BY tbl_brand.name ASC";	
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowc=mysqli_fetch_array($query)){
$id=$rowc['id'];
?>
<button id="brand_<?php echo $rowc['id']?>" type="button" value="<?php echo $rowc['id']?>" class="btn-prni brand" tabindex="-1"><img src="../img/product/<?php if(empty($rowc['image']) || $rowc['image']==''){echo 'no_image.png';}else{echo $rowc['image'];}?>" class="img-rounded img-thumbnail"><span class="bname"><?php echo $rowc['name']?></span></button>    
<?php } ?>
<div class="ps-scrollbar-x-rail" style="width: 0px; display: none; left: 0px; bottom: 3px;"><div class="ps-scrollbar-x" style="left: 0px; width: 0px;"></div></div><div class="ps-scrollbar-y-rail" style="top: 0px; height: 0px; display: none; right: 3px;"><div class="ps-scrollbar-y" style="top: 0px; height: 0px;"></div></div>
</div>
</div>

<div id="category-slider">
<div class="row">
<div class="col-md-2"></div>
<div class="col-md-8">
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>     
<input type="text" class="form-control form-control-lg" id="searchcategory" placeholder="Search by Name" autocomplete="off">
</div>
</div>
</div>   
<div class="col-md-2"></div>
</div>
<div id="category-list" class="ps-container style-2">
<button id="category_0" type="button" value="0" class="btn-prni category" tabindex="-1"><img src="../img/product/<?php if(empty($rowc['image']) || $rowc['image']==''){echo 'no_image.png';}else{echo $rowc['image'];}?>" class="img-rounded img-thumbnail"><span>All Categories</span></button>
<?php
$sql="SELECT tbl_brstock.catid AS id,tbl_category.name FROM tbl_brstock  LEFT JOIN tbl_category ON tbl_category.id=tbl_brstock.catid WHERE tbl_brstock.catid IS NOT NULL GROUP BY tbl_brstock.catid ORDER BY tbl_category.name ASC";	

$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowc=mysqli_fetch_array($query)){
$id=$rowc['id'];
?>
<button id="category_<?php echo $rowc['id']?>" type="button" value="<?php echo $rowc['id']?>" class="btn-prni category" tabindex="-1"><img src="../img/product/<?php if(empty($rowc['image']) || $rowc['image']==''){echo 'no_image.png';}else{echo $rowc['image'];}?>" class="img-rounded img-thumbnail"><span class="cname"><?php echo $rowc['name']?></span></button>    
<?php } ?>
<div class="ps-scrollbar-x-rail" style="width: 0px; display: none; left: 0px; bottom: 3px;"><div class="ps-scrollbar-x" style="left: 0px; width: 0px;"></div></div><div class="ps-scrollbar-y-rail" style="top: 0px; height: 0px; display: none; right: 3px;"><div class="ps-scrollbar-y" style="top: 0px; height: 0px;"></div></div>
</div>
</div>

<div id="subcategory-slider">
<div class="row">
<div class="col-md-2"></div>
<div class="col-md-8">
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>     
<input type="text" class="form-control form-control-lg" id="searchsubcategory" placeholder="Search by Name" autocomplete="off">
</div>
</div>   
</div>
<div class="col-md-2"></div>
</div>
<div id="subcategory" class="ps-container style-2">
    
</div>
</div>

<!-- Same Barcode Mutiproduct -->
<div id="saleBarcode" class="modal fade">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<h4 class="modal-title" id="global-modal-title">Fill the product's options</h4>
</div>
<div class="modal-body color-black" id="posProductOptions">
<div class="form-group"> <label class="control-label">Purchase Batch</label>
<div id="multipro">

</div>
</div>
<input type="hidden" name="emn" id="emn" value="" readonly />
<button type="button" id="cart_product" class="form-control btn-primary"><span class="hidden-xs hidden-sm hidden-md">Add to Cart</span> <i class="icon-cart-add2"></i></button>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>
<!--end same barcode-->    
    
<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->
<?php include('../layout/rside.php'); ?>
<?php include('../layout/checkout.php'); ?>
<div id="invdata" style="display: none;"></div>     
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
    
$(function(){
$('.product-panel').css({ height: $(window).innerHeight()-150 });
$(window).resize(function(){
$('.product-panel').css({ height: $(window).innerHeight()-150 });
});
});    
    
ReadItem();
    
function ReadItem() {
$.ajax({
url: "sel_item.php",
method: "POST",
success: function(data) {
$('#purchaseitem').html(data);
}
})
}

ReadData();
function ReadData(){
$.ajax({
url: "sel_invview.php",
method: "POST",
data:{ 
body:1
},
success: function(data){
$('#itemdata').html(data);
}
})

$.ajax({
url: "sel_invview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})
ReadButon();    
ReadIMEI();    
};    

function ReadFoot(){
$.ajax({
url: "sel_invview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})	
}    

function ReadButon(){
$.ajax({
url: "sel_invview.php",
method: "POST",
data:{ 
buton:1
},
success: function(data){
$('#extra').html(data);
}
})	
}     
    
function ReadIMEI() {
$.ajax({
url: "sel_serialview.php",
method: "POST",
success: function(data) {
$('#serialpro').html(data);
}
})
}    

$(document).on('keyup', '#search', function () {    
var search = $("#search").on('input',function(){
var matcher = new RegExp($(this).val(), 'i');

$('.selitem').show().not(function(){
return matcher.test($(this).find('.name, .sku').text())
}).hide();
}); 
});
    
$(document).on('click', '.alphabets a', function () {
si=$(this).data('id');
var matcher = new RegExp(si, 'i');

$('.selitem').show().not(function(){
return matcher.test($(this).find('.indexg').text())
}).hide();   
});

$(document).on('keyup', '#searchcategory', function () {
var search = $("#searchcategory").on('input',function(){
var matcher = new RegExp($(this).val(), 'i');

$('.category').show().not(function(){
return matcher.test($(this).find('.cname').text())
}).hide();
})
});

$(document).on('keyup', '#searchsubcategory', function () {
var search = $("#searchsubcategory").on('input',function(){
var matcher = new RegExp($(this).val(), 'i');

$('.subcat').show().not(function(){
return matcher.test($(this).find('.sname').text())
}).hide();
})
});

$(document).on('keyup', '#searchbrands', function () {
var search = $("#searchbrands").on('input',function(){
var matcher = new RegExp($(this).val(), 'i');

$('.brand').show().not(function(){
return matcher.test($(this).find('.bname').text())
}).hide();
})
});

$(".open-brands").click(function () {
$('#brands-slider').toggle('slide', { direction: 'right' }, 700);
});
$(".open-category").click(function () {
$('#category-slider').toggle('slide', { direction: 'right' }, 700);
});
$(".open-subcategory").click(function () {
$('#subcategory-slider').toggle('slide', { direction: 'right' }, 700);
});
    
$(document).on('click', function(e){
if (!$(e.target).is(".open-brands, .cat-child") && !$(e.target).parents("#brands-slider").length && $('#brands-slider').is(':visible')) {
$('#brands-slider').toggle('slide', { direction: 'right' }, 700);
}
if (!$(e.target).is(".open-category, .cat-child") && !$(e.target).parents("#category-slider").length && $('#category-slider').is(':visible')) {
$('#category-slider').toggle('slide', { direction: 'right' }, 700);
}
if (!$(e.target).is(".open-subcategory, .cat-child") && !$(e.target).parents("#subcategory-slider").length && $('#subcategory-slider').is(':visible')) {
$('#subcategory-slider').toggle('slide', { direction: 'right' }, 700);
}
if (!$(e.target).is(".right-side-add, .side-cont") && !$(e.target).parents(".right-side-add").length && $('.right-side-add').hasClass('open-right-add')) {
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');
}    
});

$(document).on('click', '.category', function () {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
$.ajax({
url: 'sel_item.php',
method: "POST",
data:{ 
catid: ids
},
success: function(data){
$('#purchaseitem').html(data);
}
});
    
$.ajax({
url: 'sel_subcat.php',
method: "POST",
data:{ 
catid: ids
},
success: function(data){
$('#subcategory').html(data);
}
});    
});
    
$(document).on('click', '.subcat', function () {
sid_arr = $(this).attr('id');
sid = sid_arr.split("_");    
var scid = sid[1];
$.ajax({
url: 'sel_item.php',
method: "POST",
data:{ 
subcatid: scid
},
success: function(data){
$('#purchaseitem').html(data);
}
});    
});
    
$(document).on('click', '.brand', function () {
sid_arr = $(this).attr('id');
sid = sid_arr.split("_");    
var brid = sid[1];
$.ajax({
url: 'sel_item.php',
method: "POST",
data:{ 
brandid: brid
},
success: function(data){
$('#purchaseitem').html(data);
}
});    
});
    
$(document).on('click', '#icon', function() {
if(!$("#icon").hasClass('cart-icon-rotate')){
$("#icon").addClass('cart-icon-rotate');
$(".cart tr.dshow").toggle();
}else{
$("#icon").removeClass('cart-icon-rotate');	
$(".cart tr.dshow").hide();
}	
});

$(document).on('click', '.selitem', function () {    
var id = $(this).attr('id');
pid_arr = $(this).attr('id');
unid = pid_arr.split("_");    
var unqid = unid[1];    
$.ajax({
url: 'sel_cart.php',
method: "POST",
data:{ 
additem: unqid
},
success: function(data){
ReadData();
}
});    
});

$(document).on('keydown', '#pcode', function () {
$('#pcode' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'sel_cart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term,itmsear:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
var te='';
$(this).val(te); // display the selected text
var unqid = ui.item.value; // selected id to input

$.ajax({
url: 'sel_cart.php',
type: 'post',
data: {additem:unqid},
success:function(response){
ReadData();
}
});
return false;
}
});        
});    

$(document).on('keydown', '#bcode', function() {    
$('#bcode' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'sel_cart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term,tyserial:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
var te='';
$(this).val(te); // display the selected text
var unqid = ui.item.value; // selected id to input
var serial = ui.item.label;    
$.ajax({
url: 'sel_cart.php',
type: 'post',
data: {addslitem:unqid, serial:serial},
success:function(response){
ReadData();
}
});

return false;
}
});
});    
    
$(document).on('click', '.remove', function () {
var id = $(this).attr('id');
$.ajax({
url: 'sel_cart.php',
method: "POST",
data:{ 
remove: id
},
success: function(data){
ReadData();
}
});    
});

//barcode 
var bscode='';   
$(document).scannerDetection({
timeBeforeScanTest: 200,
//startChar: [120],
endChar: [13],
avgTimeByChar: 30,
onComplete: function(barcode,event){
bscode='';    
bscode = barcode; 
$('#bcode').val(bscode);
$.ajax({
url: 'sel_cart.php',
method: "POST",
data:{ 
scanbarcode: bscode , qty: 1
},
dataType: 'json',    
success: function(data){
if(data.status==='fail'){
toastr.error(data.message);
}else if(data.status==='exits'){
toastr.info(data.message);
ReadData();    
}else if(data.status==='invno'){    
viewinvoice(data.invoice);
}else if(data.status==='success'){     
ReadData();
toastr.success(data.message);
}else if(data.status==='multi'){
$('#multipro').html(data.html);
$('#saleBarcode').modal('show');    
}
}
});      
},
onKeyDetect: function(event){
if(event.keyCode === 13 || event.keyCode === 17 || event.keyCode === 74 ){
if (event.target.tagName == "INPUT" || event.target.tagName == "TEXTAREA") {
if(bscode.length>1){
event.preventDefault();    
}    
}else{
event.preventDefault();    
}    
} 
}   
});    

function myFunctions(prorbuton) {
document.getElementById("emn").value = prorbuton;
}    

$(document).on('click', '#cart_product', function () {
var enm = $('#emn').val();   
$.ajax({
url: 'sel_cart.php',
method: "POST",
data:{ 
additem: enm
},
success: function(data){
$('#saleBarcode').modal('hide');
ReadData();
}
});    
});    
    
function viewinvoice(invno){
$.ajax({
url: 'axe_globalview.php',
method: "POST",
data:{sbcode: invno},
success: function(data){
var foundSomething = false;
for(var i=0; i<data.length; ++i) {
if(data[i] !== null) foundSomething = true;
break;
}    
if(foundSomething){
$('#datacon').html(data);   
$('.right-side-free').toggle('slide', { direction: 'right' }, 300);
}
}
});    
}    
    
$(document).on('blur', '.quantity', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var qty = parseFloat($('#qty_'+id[1]).val());
$.ajax({
url: 'sel_cart.php',
method: "POST",
data:{ 
upqty: ids, qty: qty
},
dataType: 'json',
success: function(data){
$('#qty_'+id[1]).val(data[0]);
$('#price_'+id[1]).val(data[1]);    
$('#stotal_'+id[1]).html(data[2]);
$('#pnote_'+id[1]).val(data[3]);    
$('#disp_'+id[1]).val(data[4]);
$('#disf_'+id[1]).val(data[5]);
$('#disamo_'+id[1]).html(data[6]);        
ReadFoot();
ReadIMEI();    
}
});     
});

$(document).on('blur', '.price', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var amo = parseFloat($('#price_'+id[1]).val());
$.ajax({
url: 'sel_cart.php',
method: "POST",
data:{ 
upprice: ids, amo: amo
},
dataType: 'json',
success: function(data){
$('#qty_'+id[1]).val(data[0]);
$('#price_'+id[1]).val(data[1]);    
$('#stotal_'+id[1]).html(data[2]);
$('#pnote_'+id[1]).val(data[3]);    
$('#disp_'+id[1]).val(data[4]);
$('#disf_'+id[1]).val(data[5]);
$('#disamo_'+id[1]).html(data[6]); 
ReadFoot();
}
});     
});

$(document).on('change', '.bscan', function () {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var chkid = 0;	
$('.bscan').not(this).prop('checked', false);
if ($('.bscan').is(":checked")){
chkid = 1;
}else{
chkid = 0;	
}

$.ajax({
url: 'sel_cart.php',
method: "POST",
data: {
check: chkid, pid:ids
},
success: function(data) {

}
});

});    
    
$(document).on('blur', '.pnote', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var ref = $('#pnote_'+id[1]).val();  
$.ajax({
url: 'sel_cart.php',
method: "POST",
data:{ 
upnote: ids, note: ref
},
dataType: 'json',
success: function(data){
$('#qty_'+id[1]).val(data[0]);
$('#price_'+id[1]).val(data[1]);    
$('#stotal_'+id[1]).html(data[2]);
$('#pnote_'+id[1]).val(data[3]);    
$('#disp_'+id[1]).val(data[4]);
$('#disf_'+id[1]).val(data[5]);
$('#disamo_'+id[1]).html(data[6]); 
ReadFoot();
}
});     
});
    
$(document).on('blur', '.disp', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var dic = parseFloat($('#disp_' + id[1]).val());
$.ajax({
url: 'sel_cart.php',
method: "POST",
data: {
itemdisp: ids,
disp: dic
},
dataType: 'json',
success: function(data) {
$('#qty_'+id[1]).val(data[0]);
$('#price_'+id[1]).val(data[1]);    
$('#stotal_'+id[1]).html(data[2]);
$('#pnote_'+id[1]).val(data[3]);    
$('#disp_'+id[1]).val(data[4]);
$('#disf_'+id[1]).val(data[5]);
$('#disamo_'+id[1]).html(data[6]);
ReadFoot();
}
});
});
    
$(document).on('blur', '.disf', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var dica = parseFloat($('#disf_' + id[1]).val());
$.ajax({
url: 'sel_cart.php',
method: "POST",
data: {
itemdisf: ids,
disf: dica
},
dataType: 'json',
success: function(data) {
$('#qty_'+id[1]).val(data[0]);
$('#price_'+id[1]).val(data[1]);    
$('#stotal_'+id[1]).html(data[2]);
$('#pnote_'+id[1]).val(data[3]);    
$('#disp_'+id[1]).val(data[4]);
$('#disf_'+id[1]).val(data[5]);
$('#disamo_'+id[1]).html(data[6]);
ReadFoot();
}
});
});
    
function get_foot(){
$.ajax({
url: 'sel_cart.php',
method: "POST",
data: {
foot: 1
},
dataType: 'json',
success: function(data) {	
$('#discount').val((Math.round(data[0] * 100) / 100).toFixed(2));
$('#disitems').html('<strong>'+(Math.round(data[1] * 100) / 100).toFixed(2)+'</strong>');
if(parseFloat((Math.round(data[2] * 100) / 100).toFixed(2))>0){
$('#totdisamo').html('<strong>'+(Math.round(data[2] * 100) / 100).toFixed(2)+'</strong>');
}
    
$('#vatp').val((Math.round(data[3] * 100) / 100).toFixed(2));
$('#vatamo').html('<strong>'+(Math.round(data[4] * 100) / 100).toFixed(2)+'</strong>');

$('#aitp').val((Math.round(data[5] * 100) / 100).toFixed(2));
$('#aitamo').html('<strong>'+(Math.round(data[6] * 100) / 100).toFixed(2)+'</strong>');
        
$('#otdname').html('<strong>'+data[7]+'</strong>');
$('#others').val((Math.round(data[8] * 100) / 100).toFixed(2));
$('#othersamo').html('<strong>'+(Math.round(data[8] * 100) / 100).toFixed(2)+'</strong>');
    
$('#otame').html(data[7]);

$('#freight').val((Math.round(data[9] * 100) / 100).toFixed(2));
$('#freightd').html('<strong>'+(Math.round(data[9] * 100) / 100).toFixed(2)+'</strong>');
$('#less').val((Math.round(data[10] * 100) / 100).toFixed(2));
$('#lessd').html('<strong>'+(Math.round(data[10] * 100) / 100).toFixed(2)+'</strong>');
$('#grtotal').html('<strong>'+(Math.round(data[11] * 100) / 100).toFixed(2)+'</strong>');
}
});	
}
    
$(document).on('blur', '#discount', function() {
var disp = parseFloat($('#discount').val());
$.ajax({
url: 'sel_cart.php',
method: "POST",
data: {
seldis: disp
},
success: function(data) {
get_foot();
}
});
});
    
$(document).on('blur', '#vatp', function() {
var vatp = parseFloat($('#vatp').val());
$.ajax({
url: 'sel_cart.php',
method: "POST",
data: {
selvat: vatp
},
success: function(data) {
get_foot();
}
});
});
    
$(document).on('blur', '#aitp', function() {
var aitp = parseFloat($('#aitp').val());
$.ajax({
url: 'sel_cart.php',
method: "POST",
data: {
seltax: aitp
},
success: function(data) {
get_foot();
}
});
});
    
$(document).on('blur', '#others', function() {
var others = parseFloat($('#others').val());
$.ajax({
url: 'sel_cart.php',
method: "POST",
data: {
others: others
},
success: function(data) {
get_foot();
}
});
});

$(document).on('blur', '#otname', function() {
var otname = $('#otname').val();
$.ajax({
url: 'sel_cart.php',
method: "POST",
data: {
otname: otname
},
success: function(data) {
get_foot();
}
});
});
    
$(document).on('blur', '#freight', function() {
var frei = parseFloat($('#freight').val());
$.ajax({
url: 'sel_cart.php',
method: "POST",
data: {
freight: frei
},
success: function(data) {
get_foot();
}
});
});				
				
$(document).on('blur', '#less', function() {
var less = parseFloat($('#less').val());
$.ajax({
url: 'sel_cart.php',
method: "POST",
data: {
less: less
},
success: function(data) {
get_foot();
}
});
});
    
$(document).on('click', '.slremove', function () {
var id = $(this).attr('id');
$.ajax({
url: 'sel_cart.php',
method: "POST",
data:{ 
removeitmsl: id
},
success: function(data){
ReadData();
}
});    
});
    
$(document).on('blur', '.imei', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var imei = $('#imei_'+id[1]).val();
$.ajax({
url: 'sel_cart.php',
method: "POST",
data:{ 
upimei: ids, imeidata: imei
},
dataType: 'json',
success: function(data){
$('#imei_'+id[1]).val(data[0]);
}
});     
});

$(document).on('keydown', '.imei', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids=id[1];
   
$('.imei' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'sel_cart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term, audimei:ids
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
var pid = ui.item.value;    
var srl = ui.item.label; // selected id to input
$(this).val(srl);
    
$.ajax({
url: 'sel_cart.php',
method: "POST",
data:{ 
upimei: ids, imeidata: srl
},
success: function(data){
//$('#imei_'+id[1]).val(data[0]);
}
});

return false;
}
});
});    
    
$(document).on('click', '#emptycart', function () {
var id = $(this).attr('id');    
$.ajax({
url: 'sel_cart.php',
method: "POST",
data:{ 
clear: id
},
success: function(data){
ReadData();
}
});    
});
    
$(document).on('click', '#walkin', function() {	
$('#cusname').val('Walk-In Customer');
$('#cusid').val('CU_0');
$('#cusbal').html('0.00');	
});
    
$(document).on('keyup', '#cusname', function() { 
var bal = $(this).val();
if(bal.length<1){
$('#cusid').val('');
$('#cusbal').html('0.00');	
}
});
    
$(document).on('keydown', '#cusname', function() {    
$('#cusname' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'sel_cart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term,getcus:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
$(this).val(ui.item.label);	
var cusid = ui.item.value; // selected id to input
$('#cusid').val(cusid);
$.ajax({
url: 'sel_cart.php',
type: 'post',
data: {checkbal:cusid},
success:function(data){
$('#cusbal').html(data);
}
});

return false;
}
});
});

$(document).on('click', '#addcus', function() {
$('#addsitem').html('');    
$.ajax({
url: "sel_cart.php",
method: "POST",
data:{addcus:1},
success: function(data){
$('#addsitem').html(data);
$('.right-side-add').toggle('slide', { direction: 'right' }, 300);     
}
})       
});
    
$(document).on('click', '#adcus', function() { 
var customer_data = $('.addcustomer input, .addcustomer select, .addcustomer textarea');
if(!chek_error()){
return;   
}
$.ajax({
url: "sel_cart.php",
data: customer_data,
type: 'post',
dataType: 'json',    
beforeSend: function () {
chek_error();    
},    
success: function(data){
if(data.status === "success"){
$('#cusname').val(data.cudata);
$('#cusbal').val(data.cbal);
$('#cusid').val(data.cuid);    
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
}else{
$('#cusname').val('');
$('#cusbal').val('0.00');
$('#cusid').val('');    
toastr.error(data.message);    
}         
}
})    
});    
    
$(document).on('click', '#save_sales', function() {
var cusid = $('#cusid').val();     
toastr.options = {'positionClass': 'toast-top-center'};
    
$.ajax({
url: 'sel_cart.php',
method: "POST",
data:{ 
seldata:1
},
dataType: 'json',
success: function(response) {
if(cusid.length < 1 || cusid == ''){
toastr.info('Please Select Customer!');
return;
}
    
var pri = response[0];
var sri = response[1];

if(pri>0){
toastr.warning('Missing price Information!!')	
return;
}    

if(sri>0){
toastr.warning('Missing Product Serial!!')	
return;
}    
    
selsave(); 
}
});          
});    

function selsave(){
var cusid = $('#cusid').val();
var wname = $('#walkname').val();
var wmobil = $('#walkmobile').val();
var wdid = $('#wdid').val();
var wzid = $('#wzid').val();
var wadd = $('#wadd').val();
var wemail = $('#wemail').val();    
    

$.ajax({
url: "sel_cart.php",
method: "POST",
data:{checkview:1,cusid:cusid,wname:wname,wmobil:wmobil,wdid:wdid,wzid:wzid,wadd:wadd,wemail:wemail},
success: function(data){
$('#checkview').html('');
$('#checkview').html(data); 
}
})    
    
$.ajax({
url: "sel_cart.php",
method: "POST",
data:{checkout:1,cusid:cusid},
success: function(data){
$('#invhold').html('');
$('#invhold').html(data);       
}
})
$('.right-side-checkout').addClass('open-right-checkout');    
}
    
$(document).on('click', '#closechk', function() {
$('.right-side-checkout').removeClass('open-right-checkout');
$('#addsitem').html('');    
});    
    
$(document).on('click', '#closepop', function() {    
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
});
    
$(document).on('click', '.saveseinv', function() {
var cusid = parseFloat($('#scusid').val());
var due = parseFloat($('#dueamo').html());
var stype = $(this).attr('id');
var cash_data = $('.addsersales input, .addsersales select, .addsersales textarea');    
toastr.options = {'positionClass': 'toast-top-center'};    
    
if(cusid<=0 && due > 0){
toastr.warning('Due Not Permitted for Walking Customer!');
return;
}

if(!chek_error()){return;}
    
$.ajax({
url: "sel_cart.php",
data: cash_data,
type: 'post',
dataType: 'json',    
success: function(data){
if(data.status === "success"){
$('.right-side-checkout').removeClass('open-right-checkout');
$('#addsitem').html('');
$('#cusname').val('');    
$("#cusid").val('');
$("#cusbal").html('0.00');
ReadItem();    
ReadData();    
toastr.success(data.message);
if(stype!='saveinv'){
print_inv(data.invid,stype);       
}    
}else{
toastr.error(data.message);    
}         
}
})    
    
});

function print_inv(id,key){
var mode = 'iframe'; //popup
var close = mode == "popup";
var options = {
mode: mode,
popClose: close
};    
$.ajax({
url: "sel_print.php",
data:{print:id,key:key}, 
type: 'post',    
success: function(data){
$("#invdata").html(data);    
$("div.printableArea").printArea(options);
$("#invdata").html('');    
}
})    
};
    
function getAllSubwgroup(id){
$.ajax({
url: 'axe_getsub.php',
type: 'post',
data: {zone : id},
success:function(data) {
$('#wzid').html(data);
}
});
};    
</script>    
<!-- /page script -->
</html>    