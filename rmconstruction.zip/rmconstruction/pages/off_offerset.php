<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='off_offerset.php';   
$cuPage='off_offerset.php';    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='offer';
$menuh='Set Offer &amp; Rebeat';
$phead='ofset';
$page='Set Coupon &amp; Offer On Item';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-7">
<div class="box box-solid">
<div class="box-body">
<div class="col-md-12">
<div class="row">
<div class="col-md-12">    
<div class="form-group text-center" id="indexl">
<ul style="margin-top: 0;" class="pagination alphabets"><li><a data-id="" href="#"><b>ALL</b></a></li><li><a href="#" data-id="A"><b>A</b></a></li><li><a href="#" data-id="B"><b>B</b></a></li><li><a href="#" data-id="C"><b>C</b></a></li><li><a href="#" data-id="D"><b>D</b></a></li><li><a href="#" data-id="E"><b>E</b></a></li><li><a href="#" data-id="F"><b>F</b></a></li><li><a href="#" data-id="G"><b>G</b></a></li><li><a href="#" data-id="H"><b>H</b></a></li><li><a href="#" data-id="I"><b>I</b></a></li><li><a href="#" data-id="J"><b>J</b></a></li><li><a href="#" data-id="K"><b>K</b></a></li><li><a href="#" data-id="L"><b>L</b></a></li><li><a href="#" data-id="M"><b>M</b></a></li><li><a href="#" data-id="N"><b>N</b></a></li><li><a href="#" data-id="O"><b>O</b></a></li><li><a href="#" data-id="P"><b>P</b></a></li><li><a href="#" data-id="Q"><b>Q</b></a></li><li><a href="#" data-id="R"><b>R</b></a></li><li><a href="#" data-id="S"><b>S</b></a></li><li><a href="#" data-id="T"><b>T</b></a></li><li><a href="#" data-id="U"><b>U</b></a></li><li><a href="#" data-id="V"><b>V</b></a></li><li><a href="#" data-id="W"><b>W</b></a></li><li><a href="#" data-id="X"><b>X</b></a></li><li><a href="#" data-id="Y"><b>Y</b></a></li><li><a href="#" data-id="Z"><b>Z</b></a></li></ul>    
</div>
</div>
<div class="col-md-8">    
<div class="form-group">  
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>
<input type="text" class="form-control" name="search" id="search" placeholder="e.g. Product Code or Name" autocomplete="off">    
</div>
</div>   
</div>
<div class="col-md-4">
<div class="form-group">
<div class="input-group">    
<select class="form-control select2" name="ofid" id="ofid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_offer WHERE status='1' AND endate >= '$today' ORDER BY id DESC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>
<span class="input-group-addon"><a href="off_alloffer.php"><span class="fa fa-plus"></span></a></span>     
</div>    
</div>    
</div>    
</div>
<div class="row">
<div class="product-panel style-2" id="purchaseitem">

</div>
</div>
</div>    
</div>
</div>
</div>
<div class="col-md-5">
<div class="box box-solid">
<div class="box-body">

<div class="col-md-12">    
<div class="row">
<div class="cart cart-sm">     
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<thead>
<th width="30px">SN</th>
<th width="286px">Item</th>
<th width="184px">Offer</th>
<th width="25px"><a class="empty" style="cursor: pointer;"><i class="fa fa-trash"></i></a></th>    
</thead>
</table>
<div class="cart-msg style-3 item" style="padding:0px;">    
<table class="table table-bordered table-striped" style="margin-bottom: 0;">    
<tbody id="itemdata">

</tbody>    
</table>
</div>
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<tfoot id="itemfoot">

</tfoot>
</table>    
</div>    
</div>
    
<div class="row" id="serialpro">
    
    
</div>    
  
<div class="row" id="extra">
 
</div>     
    
</div> 
    
</div>
</div>
</div>
</div>
    
<div class="rotate btn-cat-con">
<button type="button" id="open-brands" class="btn btn-info open-brands" tabindex="-1">Brands</button>
<button type="button" id="open-subcategory" class="btn btn-warning open-subcategory" tabindex="-1">Sub Categories</button>
<button type="button" id="open-category" class="btn btn-primary open-category" tabindex="-1">Categories</button>
</div>
    
<div id="brands-slider">
<div class="row">
<div class="col-md-2"></div>
<div class="col-md-8">
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>    
<input type="text" class="form-control form-control-lg" id="searchbrands" placeholder="Search by Name" autocomplete="off">
</div>
</div>
</div>    
</div>
<div class="col-md-2"></div>
<div id="brands-list" class="ps-container style-2">
<button id="brand_0" type="button" value="0" class="btn-prni brand" tabindex="-1"><img src="../img/product/no_image.png" class="img-rounded img-thumbnail"><span>ALL Brands</span></button>
<?php
$sql="SELECT DISTINCT brid AS id,brand AS name FROM (SELECT tbl_item.name,tbl_item.brid,tbl_brand.name AS brand,tbl_item.catid,tbl_category.name AS category,tbl_item.scatid,tbl_stock.code,tbl_stock.unqid,tbl_stock.cost,tbl_stock.price,(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0))+(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0)) AS avqty FROM tbl_stock LEFT JOIN tbl_item ON tbl_item.id=tbl_stock.pid LEFT JOIN tbl_brand ON tbl_brand.id=tbl_item.brid LEFT JOIN tbl_category ON tbl_category.id=tbl_item.catid) ofitm WHERE avqty>0 ORDER BY name ASC";	
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowc=mysqli_fetch_array($query)){
$id=$rowc['id'];
?>
<button id="brand_<?php echo $rowc['id']?>" type="button" value="<?php echo $rowc['id']?>" class="btn-prni brand" tabindex="-1"><img src="../img/product/<?php if(empty($rowc['image']) || $rowc['image']==''){echo 'no_image.png';}else{echo $rowc['image'];}?>" class="img-rounded img-thumbnail"><span class="bname"><?php echo $rowc['name']?></span></button>    
<?php } ?>
<div class="ps-scrollbar-x-rail" style="width: 0px; display: none; left: 0px; bottom: 3px;"><div class="ps-scrollbar-x" style="left: 0px; width: 0px;"></div></div><div class="ps-scrollbar-y-rail" style="top: 0px; height: 0px; display: none; right: 3px;"><div class="ps-scrollbar-y" style="top: 0px; height: 0px;"></div></div>
</div>
</div>

<div id="category-slider">
<div class="row">
<div class="col-md-2"></div>
<div class="col-md-8">
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>     
<input type="text" class="form-control form-control-lg" id="searchcategory" placeholder="Search by Name" autocomplete="off">
</div>
</div>
</div>   
<div class="col-md-2"></div>
</div>
<div id="category-list" class="ps-container style-2">
<button id="category_0" type="button" value="0" class="btn-prni category" tabindex="-1"><img src="../img/product/<?php if(empty($rowc['image']) || $rowc['image']==''){echo 'no_image.png';}else{echo $rowc['image'];}?>" class="img-rounded img-thumbnail"><span>All Categories</span></button>
<?php
$sql="SELECT DISTINCT catid AS id,category AS name FROM (SELECT tbl_item.name,tbl_item.brid,tbl_brand.name AS brand,tbl_item.catid,tbl_category.name AS category,tbl_item.scatid,tbl_stock.code,tbl_stock.unqid,tbl_stock.cost,tbl_stock.price,(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0))+(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0)) AS avqty FROM tbl_stock LEFT JOIN tbl_item ON tbl_item.id=tbl_stock.pid LEFT JOIN tbl_brand ON tbl_brand.id=tbl_item.brid LEFT JOIN tbl_category ON tbl_category.id=tbl_item.catid) ofitm WHERE avqty>0 AND category IS NOT NULL ORDER BY name ASC";	

$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowc=mysqli_fetch_array($query)){
$id=$rowc['id'];
?>
<button id="category_<?php echo $rowc['id']?>" type="button" value="<?php echo $rowc['id']?>" class="btn-prni category" tabindex="-1"><img src="../img/product/<?php if(empty($rowc['image']) || $rowc['image']==''){echo 'no_image.png';}else{echo $rowc['image'];}?>" class="img-rounded img-thumbnail"><span class="cname"><?php echo $rowc['name']?></span></button>    
<?php } ?>
<div class="ps-scrollbar-x-rail" style="width: 0px; display: none; left: 0px; bottom: 3px;"><div class="ps-scrollbar-x" style="left: 0px; width: 0px;"></div></div><div class="ps-scrollbar-y-rail" style="top: 0px; height: 0px; display: none; right: 3px;"><div class="ps-scrollbar-y" style="top: 0px; height: 0px;"></div></div>
</div>
</div>

<div id="subcategory-slider">
<div class="row">
<div class="col-md-2"></div>
<div class="col-md-8">
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>     
<input type="text" class="form-control form-control-lg" id="searchsubcategory" placeholder="Search by Name" autocomplete="off">
</div>
</div>   
</div>
<div class="col-md-2"></div>
</div>
<div id="subcategory" class="ps-container style-2">
    
</div>
</div>
        
<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(function(){
$('.product-panel').css({ height: $(window).innerHeight()-150 });
$(window).resize(function(){
$('.product-panel').css({ height: $(window).innerHeight()-150 });
});
});    
ReadIndex();    
ReadItem();
    
function ReadItem() {
$.ajax({
url: "off_item.php",
method: "POST",
success: function(data) {
$('#purchaseitem').html(data);
}
})
};

function ReadIndex() {
$.ajax({
url: "off_serindex.php",
method: "POST",
success: function(data) {
$('#indexl').html(data);
}
})
};    

ReadData();
function ReadData(){
$.ajax({
url: "off_setview.php",
method: "POST",
data:{ 
body:1
},
success: function(data){
$('#itemdata').html(data);
}
})
ReadButon();    
};

function ReadButon(){
$.ajax({
url: "off_setview.php",
method: "POST",
data:{ 
buton:1
},
success: function(data){
$('#extra').html(data);
}
})	
}    
    
$(document).on('keyup', '#search', function () {    
var search = $("#search").on('input',function(){
var matcher = new RegExp($(this).val(), 'i');

$('.selitem').show().not(function(){
return matcher.test($(this).find('.name, .sku').text())
}).hide();
}); 
});
    
$(document).on('click', '.alphabets a', function () {
si=$(this).data('id');
var matcher = new RegExp(si, 'i');

$('.selitem').show().not(function(){
return matcher.test($(this).find('.indexg').text())
}).hide();   
});

$(document).on('keyup', '#searchcategory', function () {
var search = $("#searchcategory").on('input',function(){
var matcher = new RegExp($(this).val(), 'i');

$('.category').show().not(function(){
return matcher.test($(this).find('.cname').text())
}).hide();
})
});

$(document).on('keyup', '#searchsubcategory', function () {
var search = $("#searchsubcategory").on('input',function(){
var matcher = new RegExp($(this).val(), 'i');

$('.subcat').show().not(function(){
return matcher.test($(this).find('.sname').text())
}).hide();
})
});

$(document).on('keyup', '#searchbrands', function () {
var search = $("#searchbrands").on('input',function(){
var matcher = new RegExp($(this).val(), 'i');

$('.brand').show().not(function(){
return matcher.test($(this).find('.bname').text())
}).hide();
})
});

$(".open-brands").click(function () {
$('#brands-slider').toggle('slide', { direction: 'right' }, 700);
});
$(".open-category").click(function () {
$('#category-slider').toggle('slide', { direction: 'right' }, 700);
});
$(".open-subcategory").click(function () {
$('#subcategory-slider').toggle('slide', { direction: 'right' }, 700);
});
    
$(document).on('click', function(e){
if (!$(e.target).is(".open-brands, .cat-child") && !$(e.target).parents("#brands-slider").length && $('#brands-slider').is(':visible')) {
$('#brands-slider').toggle('slide', { direction: 'right' }, 700);
}
if (!$(e.target).is(".open-category, .cat-child") && !$(e.target).parents("#category-slider").length && $('#category-slider').is(':visible')) {
$('#category-slider').toggle('slide', { direction: 'right' }, 700);
}
if (!$(e.target).is(".open-subcategory, .cat-child") && !$(e.target).parents("#subcategory-slider").length && $('#subcategory-slider').is(':visible')) {
$('#subcategory-slider').toggle('slide', { direction: 'right' }, 700);
}
if (!$(e.target).is(".right-side-add, .side-cont") && !$(e.target).parents(".right-side-add").length && $('.right-side-add').hasClass('open-right-add')) {
if($('.right-side-add').is(':visible')) { $('.right-side-add').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');
}    
});

$(document).on('click', '.category', function () {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
$.ajax({
url: 'off_item.php',
method: "POST",
data:{ 
catid: ids
},
success: function(data){
$('#purchaseitem').html(data);
}
});
    
$.ajax({
url: 'off_subcat.php',
method: "POST",
data:{ 
catid: ids
},
success: function(data){
$('#subcategory').html(data);
}
});    
});
    
$(document).on('click', '.subcat', function () {
sid_arr = $(this).attr('id');
sid = sid_arr.split("_");    
var scid = sid[1];
$.ajax({
url: 'off_item.php',
method: "POST",
data:{ 
subcatid: scid
},
success: function(data){
$('#purchaseitem').html(data);
}
});    
});
    
$(document).on('click', '.brand', function () {
sid_arr = $(this).attr('id');
sid = sid_arr.split("_");    
var brid = sid[1];
$.ajax({
url: 'off_item.php',
method: "POST",
data:{ 
brandid: brid
},
success: function(data){
$('#purchaseitem').html(data);
}
});    
});
    
$(document).on('click', '.selitem', function () {    
var id = $(this).attr('id');
var ofid = $('#ofid').val();    
pid_arr = $(this).attr('id');
unid = pid_arr.split("_");    
var unqid = unid[1];
    
toastr.options = {'positionClass': 'toast-top-center'};

if(ofid.length < 1 || ofid == ''){
toastr.info('Please Select Offer First!');
return;
}    
    
$.ajax({
url: 'off_cart.php',
method: "POST",
data:{ 
addoffer: unqid, ofid: ofid
},
success: function(data){
ReadData();
}
});    
});

$(document).on('click', '.remove', function () {
var id = $(this).attr('id');
$.ajax({
url: 'off_cart.php',
method: "POST",
data:{ 
remove: id
},
success: function(data){
ReadData();
}
});    
});    
    
$(document).on('click', '#emptycart', function () {
var id = $(this).attr('id');    
$.ajax({
url: 'off_cart.php',
method: "POST",
data:{ 
clear: id
},
success: function(data){
ReadData();
}
});    
});
    
$(document).on('click', '#save_offer', function() {
$.ajax({
url: 'off_cart.php',
method: "POST",
dataType: 'json',    
data:{ saveoff: 1 },
success: function(data){
if(data.status === "success"){    
ReadData();
toastr.success(data.message);    
}else{
toastr.error(data.message);    
}    
}
});    
});    
</script>    
<!-- /page script -->
</html>    