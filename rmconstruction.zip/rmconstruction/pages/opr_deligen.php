<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='opr_deligen.php';   
$cuPage='opr_deligen.php';    
$aid=$_SESSION['uid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='operation';
$menuh='Operation Process';
$phead='delicre';
$page='Add Delivery Record';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['save_deli'])){
$blno=strtoupper(remove_junk(escape($_POST['blno'])));    
$invno=strtoupper(remove_junk(escape($_POST['invno'])));    
$pino=strtoupper(remove_junk(escape($_POST['pino'])));
$esddate=remove_junk(escape($_POST['esddate']));
$esadate=remove_junk(escape($_POST['esadate']));
$carrier=remove_junk(escape($_POST['carrier']));

if(isset($_POST['blno'])){
$sql="SELECT * FROM tbl_delivery WHERE blno = '$blno' AND invno = '$invno'";
$ducode = mysqli_query($con,$sql);    
}
if($ducode->num_rows > 0) {
save_msg('i','BL no alrady exists!');
echo "<script>window.location='opr_deligen.php'</script>";
}else{
$sql="INSERT INTO tbl_delivery (pino,invno,esddate,esadate,blno,carrier,uid,date) VALUES ('$pino','$invno','$esddate','$esadate','$blno','$carrier','$aid','$dtnow')";    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));	
$efid=mysqli_affected_rows($con);    
if($efid>0){ 
$act =remove_junk(escape('BL no: '.$blno));    
write_activity($aid,'DLI','New BL has been Added',$act);    
save_msg('s','Data Successfully Saved!');
}else{
save_msg('w','Data Fail to Saved!');   
}
echo "<script>window.location='opr_deligen.php'</script>";    
}    
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Add Delivery</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="opr_deligen.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">    
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">    

<div class="row">
<div class="col-md-4">    
<div class="form-group">
<label>BL No</label>
<input type="text" name="blno" maxlength="25" value="" id="blno" class="form-control" placeholder="e.g. OOLU2110502880" />
</div>
</div>     
<div class="col-md-4">    
<div class="form-group">
<label>Invoice No</label>
<input type="text" name="invno" maxlength="25" value="" id="invno" class="form-control" placeholder="e.g. AXE120120101"/>
</div>
</div>
<div class="col-md-4">    
<div class="form-group">
<label>PI No</label>
<input type="text" name="pino" maxlength="25" value="" id="pino" class="form-control" placeholder="e.g. ABA120120101"/>
</div>
</div>       
</div>    
<div class="row">
<div class="col-md-3">
<div class="form-group" >
<label>Estimate Delivery Date</label>
<div class="input-group">
<span class="input-group-addon">
<span class="fa fa-calendar"></span>
</span>
<input type="text" class="form-control datetimepicker" name="esddate" id="esddate" placeholder="e.g. 2020-01-10" autocomplete="off" readonly>
</div>
</div>
</div>
<div class="col-md-3">
<div class="form-group" >
<label>Estimate Arrival Date</label>
<div class="input-group">
<span class="input-group-addon">
<span class="fa fa-calendar"></span>
</span>
<input type="text" class="form-control datetimepicker" name="esadate" id="esadate" placeholder="e.g. 2020-02-10" autocomplete="off" readonly>
</div>
</div>
</div>
<div class="col-md-6">
<div class="form-group">
<label>Shipping Line / Carrier</label>
<div class="input-group">    
<select class="form-control select2" name="carrier" id="carrier">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_shipline ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['sortn'].' - '.$rows['name'];?></option>
<?php } ?>
</select>
<span class="input-group-addon"><a href="mas_shipcreate.php"><span class="fa fa-plus"></span></a></span>     
</div>    
</div>
</div>    
</div>    
    
</div>    
    
<div class="col-md-1"></div>    
</div>    
</div>    
</div>
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="save_deli" id="submit" class="btn btn-flat bg-purple btn-sm " value="Save"/> <a href="opr_delilist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'DLI','A');}else{echo read_activity($aid,'DLI','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function (){ 
var invno = new LiveValidation('invno');
invno.add(Validate.Presence);
var pino = new LiveValidation('pino');
pino.add(Validate.Presence);
var blno = new LiveValidation('blno');
blno.add(Validate.Presence);
var esddate = new LiveValidation('esddate');
esddate.add(Validate.Presence);
var esadate = new LiveValidation('esadate');
esadate.add(Validate.Presence);
var carrier = new LiveValidation('carrier');
carrier.add(Validate.Presence);    
});
    
$(document).on('keydown', '#invno', function() {
$('#invno' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'axe_cart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term, getdpi:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
var inv=ui.item.label;
var pin=ui.item.value;    
$(this).val(inv); // display the selected text
$('#pino').val(pin);    
return false;
}
});    
});    
</script>    
<!-- /page script -->
</html>    