<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('25','creates','R');    
$_SESSION['cuPages']='acc_ledgercreate.php';   
$cuPage='acc_ledgercreate.php';    
$aid=$_SESSION['uid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='account';
$menuh='Account';
$phead='ledcre';
$page='Ledger Create';
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php 
if(isset($_POST['save_ledger'])){
	$name = ucwords(remove_junk(escape($_POST['name'])));
    $grid = remove_junk(escape($_POST['grid']));
    $sgrid = remove_junk(escape($_POST['sgrid']));
    if($sgrid==''){$sgrid='NULL';}else{$sgrid="'".$sgrid."'";}
    $code = get_ledgercode($grid);
    $description = remove_junk(escape($_POST['description']));
	
	if(isset($_POST['name'])){
	$ducode = mysqli_query($con,"SELECT * FROM tbl_acledger WHERE name = '$name' AND grid='$grid'");
	}
	
	if($ducode->num_rows > 0) {
	save_msg('i','Ledger name alrady used under selected Group! Plz try another');
	echo "<script>window.location='acc_ledgercreate.php'</script>";
	}else{    
    $sql="INSERT INTO tbl_acledger(code,grid,sgrid,name,description,uid,date) VALUES ('$code','$grid',$sgrid,'$name','$description','$aid','$dtnow')";    
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));	
    $efid=mysqli_affected_rows($con);    
    if($efid>0){ 
    $act =remove_junk(escape('Ledger name: '.$name));    
    write_activity($aid,'LED','New ledger has been created',$act);    
    save_msg('s','Data Successfully Saved!');
    echo "<script>window.location='acc_ledgercreate.php'</script>";
    }else{
    save_msg('w','Data Fail to Saved!');
    echo "<script>window.location='acc_ledgercreate.php'</script>";    
    }
	}  
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Add Ledger</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="acc_ledgercreate.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">

<div class="row">
<div class="col-md-12">
<div class="col-md-2"></div>
<div class="col-md-8">
<div class="col-md-12">
<div class="row">
<div class="col-md-7">    
<div class="form-group">
<label>Name</label>
<input type="text" name="name" maxlength="45" value="" id="name" class="form-control" placeholder="e.g. Petty Cash" />
</div>
</div>
<div class="col-md-5">
<div class="form-group">
<label>Code</label>
<input type="text" name="code" maxlength="3" value="" id="code" class="form-control" placeholder="e.g. 11-4040" readonly/>
</div>    
</div>
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group" >
<label>Select Group</label> 
<select class="form-control" name="grid" id="grid" onchange="getAllSubgroup(this.value)">
<option value="">-Select-</option>
<?php									
$queryd=mysqli_query($con,"SELECT * FROM tbl_acgroup ORDER BY id ASC")or die(mysqli_error($con));
while ($rowd=mysqli_fetch_array($queryd)){
?>
<option value="<?php echo $rowd['id'];?>"><?php echo $rowd['name'];?></option>
<?php } ?>
</select>    
</div>    
</div>    
<div class="col-md-6">
<div class="form-group" >
<label>Select Sub-Group</label> 
<select class="form-control" name="sgrid" id="sgrid">

</select>    
</div>    
</div>   
</div>    
<div class="row">
<div class="col-md-12">    
<div class="form-group">
<label>Description</label>
<textarea class="form-control" maxlength="150" rows="6" name="description" placeholder="Description"></textarea>
</div>
</div>    
</div>    
</div>
</div>    
<div class="col-md-2"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="save_ledger" id="submit" class="btn btn-flat bg-purple btn-sm " value="Save"/> <a href="acc_ledgerlist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'LED','A');}else{echo read_activity($aid,'LED','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>    

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function () {  
var name = new LiveValidation('name');
name.add(Validate.Presence);
var grid = new LiveValidation('grid');
grid.add(Validate.Presence); 
var sgrid = new LiveValidation('sgrid');
sgrid.add(Validate.Presence);     
});
    
function getAllSubgroup(id){
$.ajax({
url: 'axe_getsub.php',
type: 'post',
data: {subgroup : id},
success:function(data) {
$('#sgrid').html(data);
}
});
};    
</script>    
<!-- /page script -->
</html>