<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
$body='';
$foot='';
$buton='';
$s=0;
$totqty=0;

if(isset($_SESSION['axes_purchase'])){
if(is_array($_SESSION['axes_purchase'])){
$max=count($_SESSION['axes_purchase']);
for($i=($max-1);$i>=0;$i=$i-1){
$pid=$_SESSION['axes_purchase'][$i]['pid'];    
$name=$_SESSION['axes_purchase'][$i]['name'];
$qty=$_SESSION['axes_purchase'][$i]['qty'];
$cost=$_SESSION['axes_purchase'][$i]['cost'];
$subtot=$_SESSION['axes_purchase'][$i]['subtot'];
$price=$_SESSION['axes_purchase'][$i]['price'];
$idisp=$_SESSION['axes_purchase'][$i]['disp'];
$idisf=$_SESSION['axes_purchase'][$i]['disf'];
$disamo=$_SESSION['axes_purchase'][$i]['disamo'];
$sdisp=$_SESSION['axes_purchase'][$i]['sdisp'];
$sdisf=$_SESSION['axes_purchase'][$i]['sdisf'];
$rep=$_SESSION['axes_purchase'][$i]['rebp'];
$ref=$_SESSION['axes_purchase'][$i]['rebf'];    
$wday=$_SESSION['axes_purchase'][$i]['wday'];
$check=$_SESSION['axes_purchase'][$i]['check'];
$col=$_SESSION['axes_purchase'][$i]['col'];
$siz=$_SESSION['axes_purchase'][$i]['siz'];  
if($col=='' && $siz==''){
$name=$name;    
}elseif($col!='' && $siz==''){
$name= $name.' '.get_fild_data('tbl_color',$col,'name');    
}elseif($col=='' && $siz!=''){
$name= $name.' '.get_fild_data('tbl_size',$siz,'sval');    
}elseif($col!='' && $siz!=''){    
$name= $name.' '.get_fild_data('tbl_color',$col,'name').' '.get_fild_data('tbl_size',$siz,'sval');    
}    
$s+=1;
$totqty+=$qty;    
$body.='<tr>';
$body.='<td class="text-center" width="30px">'.$s.'</td>';
$body.='<td data-toggle="collapse" data-target="#pitem'.$i.'" class="accordion-toggle" style="cursor: pointer;" width="190px">'.$name.'</td>';
$body.='<td width="60px"><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control quantity" id="qty_'.$i.'" value="'.$qty.'"  size="2" style="height: 24px;"/></td>';
$body.='<td width="60px"><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control cost" id="cost_'.$i.'" value="'.$cost.'"  size="2" style="height: 24px;"/></td>';

if($check==1){    
$body.='<td class="text-center" width="35px"><input type="checkbox" class="bscan" id="bscan_'.$i.'" value="'.$pid.'" name="radio-group" checked /></td>';
}else{
$body.='<td class="text-center" width="35px"><input type="checkbox" class="bscan" id="bscan_'.$i.'" value="'.$pid.'" name="radio-group" /></td>';    
}

$body.='<td width="65px" id="stotal_'.$i.'" class="text-right">'.getfloatval($subtot).'</td>';
$body.='<td width="60px"><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control price" id="price_'.$i.'" value="'.$price.'"  size="2" style="height: 24px;"/></td>';
$body.='<td class="text-center" width="25px"><a id="'.$i.'" class="remove"><span style="cursor: pointer;" class="fa fa-times"></span></a></td>';    
$body.='</tr>';
    
$body.='<tr>';
$body.='<td colspan="8" class="hiddenRow"><div class="accordian-body collapse" id="pitem'.$i.'">';
$body.='<table class="table table-bordered table-striped" style="margin-bottom: 0;">';
$body.='<thead>';
$body.='<tr>';
$body.='<th colspan="3" class="text-center">Purchase Discount</th>';
$body.='<th rowspan="2" class="text-center">Warranty Days</th>';
$body.='<th colspan="2" class="text-center">Rebeat</th>';    
$body.='<th colspan="2" class="text-center">Sales Discount</th>';    
$body.='</tr>';
$body.='<tr>';
$body.='<th class="text-center">Percent(%)</th>';
$body.='<th class="text-center">Fixed</th>';
$body.='<th class="text-center">Total</th>';
$body.='<th class="text-center">Percent(%)</th>';
$body.='<th class="text-center">Fixed</th>';
$body.='<th class="text-center">Percent(%)</th>';
$body.='<th class="text-center">Fixed</th>';    
$body.='</tr>';
$body.='</thead>';
$body.='<tbody>';
$body.='<tr>';
$body.='<td><input type="text" min="0" onkeypress="return isNumberKey(event)" class="form-control disp" id="disp_'.$i.'" value="'.$idisp.'"  size="2" style="height: 24px;"/></td>';
$body.='<td><input type="text" min="0" onkeypress="return isNumberKey(event)" class="form-control disf" id="disf_'.$i.'" value="'.$idisf.'"  size="2" style="height: 24px;"/></td>';
$body.='<td id="disamo_'.$i.'" class="text-right">'.$disamo.'</td>';
$body.='<td><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control wdays" id="wdays_'.$i.'" value="'.$wday.'"  size="2" style="height: 24px;"/></td>';
$body.='<td><input type="text" min="0" onkeypress="return isNumberKey(event)" class="form-control rebp" id="rebp_'.$i.'" value="'.$rep.'"  size="2" style="height: 24px;"/></td>';
$body.='<td><input type="text" min="0" onkeypress="return isNumberKey(event)" class="form-control rebf" id="rebf_'.$i.'" value="'.$ref.'"  size="2" style="height: 24px;"/></td>';     
$body.='<td><input type="text" min="0" onkeypress="return isNumberKey(event)" class="form-control sdisp" id="sdisp_'.$i.'" value="'.$sdisp.'"  size="2" style="height: 24px;"/></td>';
$body.='<td><input type="text" min="0" onkeypress="return isNumberKey(event)" class="form-control sdisf" id="sdisf_'.$i.'" value="'.$sdisf.'"  size="2" style="height: 24px;"/></td>';   
$body.='</tr>';    
$body.='</tbody></table></div></td></tr>';    
}
if($max>0){
if (!isset($_SESSION['axes_purde'])){
$_SESSION['axes_purde'] = array();
$_SESSION['axes_purde'][0]['disp']=0;
$_SESSION['axes_purde'][0]['disamo']=0;    
$_SESSION['axes_purde'][0]['vatp']=0;
$_SESSION['axes_purde'][0]['vatamo']=0;
$_SESSION['axes_purde'][0]['taxp']=0;
$_SESSION['axes_purde'][0]['taxamo']=0;
$_SESSION['axes_purde'][0]['freight']=0;
$_SESSION['axes_purde'][0]['spmony']=0;
$_SESSION['axes_purde'][0]['name']='Others';
$_SESSION['axes_purde'][0]['others']=0;
$_SESSION['axes_purde'][0]['less']=0;
$_SESSION['axes_purde'][0]['gtotal']=$subtot;    
}
}else{
if(isset($_SESSION['axes_purde'])){
unset($_SESSION['axes_purde']);    
}    
}

if(isset($_SESSION['axes_purde'])){
if(is_array($_SESSION['axes_purde'])){    
$disp=$_SESSION['axes_purde'][0]['disp'];
$disamoe=$_SESSION['axes_purde'][0]['disamo'];
$vatp=$_SESSION['axes_purde'][0]['vatp'];
$vatamo=$_SESSION['axes_purde'][0]['vatamo'];
$taxp=$_SESSION['axes_purde'][0]['taxp'];
$taxamo=$_SESSION['axes_purde'][0]['taxamo'];
$freight=$_SESSION['axes_purde'][0]['freight'];
$spmoney=$_SESSION['axes_purde'][0]['spmony'];	
$otname=$_SESSION['axes_purde'][0]['name'];
$others=$_SESSION['axes_purde'][0]['others'];
$less=$_SESSION['axes_purde'][0]['less'];
$gtotal=$_SESSION['axes_purde'][0]['gtotal'];    
}else{
$disp=0;
$disamoe=0;
$vatp=0;
$vatamo=0;
$taxp=0;
$taxamo=0;
$freight=0;
$spmoney=0;
$otname='';
$others=0;	
$less=0;
$gtotal=0;    
}
}else{
$disp=0;
$disamoe=0;
$vatp=0;
$vatamo=0;
$taxp=0;
$taxamo=0;
$freight=0;
$spmoney=0;
$otname=0;
$others=0;	
$less=0;
$gtotal=0;    
}

$foot.='<tr>';
$foot.='<td width="30px"></td>';
$foot.='<td width="190px"></td>';
$foot.='<td width="60px"></td>';
$foot.='<td width="60px"></td>';
$foot.='<td width="35px"></td>';
$foot.='<td width="65px"></td>';
$foot.='<td width="60px"></td>';
$foot.='<td width="25px"></td>';
$foot.='</tr>';

$foot.='<tr>';
$foot.='<td colspan="2" class="text-center" width="220px">-Total-</td>';
$foot.='<td width="60px">'.$totqty.'</td>';
$foot.='<td colspan="2" width="95px"></td>';
$foot.='<td width="65px" class="text-right">'.getfloatval(get_purchase_total()).'</td>';
$foot.='<td colspan="2" width="85px"></td>';
$foot.='</tr>';	
if(get_purdiscount_total()>0){
$foot.='<tr>';   
$foot.='<td colspan="3" align="right">Discount on Item:</td>';
$foot.='<td align="center" colspan="2"></td>';    
$foot.='<td id="disitem" class="text-right">'.getfloatval(get_purdiscount_total()).'</td>';
$foot.='<td colspan="2"></td>';    
$foot.='</tr>';	
}
$foot.='<tr>';   
$foot.='<td colspan="3" align="right">Discount (%)</td>';
$foot.='<td colspan="2"><input type="text" maxlength="5" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="discount" value="'.getfloatval($disp).'"  size="2" style="height: 24px;"/></td>';    
$foot.='<td id="disitems" class="text-right">'.getfloatval(get_purdiscount_total($disp)-get_purdiscount_total()).'</td>';
$foot.='<td colspan="2" width="85px"></td>';
$foot.='</tr>';	
if(get_purdiscount_total()>0){
$foot.='<tr>';   
$foot.='<td colspan="3" align="right">Total Discount (%)</td>';
$foot.='<td align="center" colspan="2"></td>';    
$foot.='<td id="totdisamo" class="text-right">'.getfloatval(get_purdiscount_total($disp)).'</td>';
$foot.='<td colspan="2"></td>';     
$foot.='</tr>';	
}
$foot.='<tr>';   
$foot.='<td colspan="3" align="right">VAT (%)</td>';
$foot.='<td colspan="2"><input type="text" maxlength="5" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="vatp" value="'.getfloatval($vatp).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="vatamo" class="text-right">'.getfloatval($vatamo).'</td>';
$foot.='<td  colspan="2"></td>';    
$foot.='</tr>';
$foot.='<tr>';   
$foot.='<td colspan="3" align="right">TAX (%)</td>';
$foot.='<td colspan="2"><input type="text" maxlength="5" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="taxp" value="'.getfloatval($taxp).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="taxamo" class="text-right">'.getfloatval($taxamo).'</td>';
$foot.='<td  colspan="2"></td>';    
$foot.='</tr>';    
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><div style="display: inline;"><i class="fa fa-angle-right cart-icon" id="icon"></i></div><span id="otdname">'.$otname.':</span></td>';
$foot.='<td colspan="2"><input type="text" maxlength="7" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="others" value="'.getfloatval($others).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="othersamo" class="text-right">'.getfloatval($others).'</td>';
$foot.='<td  colspan="2"></td>';    
$foot.='</tr>';     
$foot.='<tr class="dshow" style="display: none;">';   
$foot.='<td colspan="3" align="right">Others Name:</td>';
$foot.='<td colspan="4"><input type="text" maxlength="20" min="0" class="form-control" id="otname" value="'.$otname.'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td  colspan="2"></td>';    
$foot.='</tr>';
$foot.='<tr>';   
$foot.='<td colspan="3" align="right">Speed Money:</td>';
$foot.='<td colspan="2"><input type="text" maxlength="6" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="speed" value="'.getfloatval($spmoney).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="spmoney" class="text-right">'.getfloatval($spmoney).'</td>';
$foot.='<td  colspan="2"></td>';    
$foot.='</tr>';
$foot.='<tr>';   
$foot.='<td colspan="3" align="right">Freight:</td>';
$foot.='<td colspan="2"><input type="text" maxlength="6" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="freight" value="'.getfloatval($freight).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="freightd" class="text-right">'.getfloatval($freight).'</td>';
$foot.='<td  colspan="2"></td>';    
$foot.='</tr>';
$foot.='<tr>';   
$foot.='<td colspan="3" align="right">Fractional Discount:</td>';
$foot.='<td colspan="2"><input type="text" maxlength="6" min="0" onkeypress="return isNumberKey(event)" class="form-control" id="less" value="'.getfloatval($less).'"  size="2" style="height: 24px;"/></td>'; 
$foot.='<td id="lessd" class="text-right">'.getfloatval($less).'</td>';
$foot.='<td  colspan="2"></td>';    
$foot.='</tr>';
$foot.='<tr>';   
$foot.='<td colspan="3" align="right"><strong>Grand Total:</strong></td>';
$foot.='<td colspan="2"></td>'; 
$foot.='<td id="grtotal" class="text-right"><strong>'.getfloatval($gtotal).'</strong></td>';
$foot.='<td  colspan="2"></td>';    
$foot.='</tr>';    
}else{
$body.='<tr>';
$body.='<td colspan="8" class="text-center">There are no Purchase Item!</td>';
$body.='</tr>'; 
} 
}else{
$body.='<tr>';
$body.='<td colspan="8" class="text-center">There are no Purchase Item!</td>';
$body.='</tr>';
}
$body.="<script>";
$body.="$('.accordian-body').on('show.bs.collapse', function () {";
$body.="$(this).closest('table')";
$body.=".find('.collapse.in')";
$body.=".not(this)";
$body.=".collapse('toggle')";
$body.="})";
$body.="</script>";

if(isset($_SESSION['axes_purchase'])){
$buton.='<div class="col-md-6">';
if(isset($_SESSION['conpor'])){
$buton.='<input type="button" id="cancelcon" class="btn btn-flat bg-blue btn-sm" onclick="take_action('."'cancon'".')" value="Cancel"/><input type="button" id="emptycart" class="btn btn-flat bg-red btn-sm" value="Empty"/></div>';
}else{
$buton.='<input type="button" id="emptycart" class="btn btn-flat bg-red btn-sm" value="Empty"/></div>';    
}    
$buton.='<div class="col-md-6 text-right">';   
$buton.='<input type="button" id="save_purchase" class="btn btn-flat bg-purple btn-sm" value="Checkout"/>'; 
$buton.='</div>';
}

if(isset($_POST['body'])){
echo $body;
}elseif(isset($_POST['foot'])){
echo $foot;
}elseif(isset($_POST['buton'])){
echo $buton;    
}
exit;     