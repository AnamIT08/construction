<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
$body='';
$foot='';
$s=0;
$totqty=0;
$totamo=0;
$totcom=0;
if(isset($_SESSION['axes_piitem'])){
if(is_array($_SESSION['axes_piitem'])){
$max=count($_SESSION['axes_piitem']);
for($i=($max-1);$i>=0;$i=$i-1){
$pid=$_SESSION['axes_piitem'][$i]['itemid'];
$name=$_SESSION['axes_piitem'][$i]['itemname'];
$color=$_SESSION['axes_piitem'][$i]['color'];
$price=$_SESSION['axes_piitem'][$i]['price'];
$qty=$_SESSION['axes_piitem'][$i]['qty'];
$unit=$_SESSION['axes_piitem'][$i]['unit'];
$subtot=$_SESSION['axes_piitem'][$i]['subtot'];
$fixed=$_SESSION['axes_piitem'][$i]['cfamo'];
$percent=$_SESSION['axes_piitem'][$i]['cp'];
$totcom=$_SESSION['axes_piitem'][$i]['tcamo'];
    
if($color!=''){
$name=$name.'-'.get_fild_data('tbl_color',$pid,'name');    
}    
$s=$s+1;    
$body.='<tr>';
$body.='<td>'.$s.'</td>';
$body.='<td>'.$name.'</td>';
$body.='<td><input type="text" min="0" onkeypress="return isNumberKey(event)" class="form-control price" id="price_'.$i.'" value="'.$price.'" step="any" size="2" style="height: 24px;"></td>';    
$body.='<td><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control quantity" id="qty_'.$i.'" value="'.$qty.'"  size="2" style="height: 24px;"/></td>';
$body.='<td class="text-right" id="stot_'.$i.'">'.$subtot.'</td>';
$body.='<td><input type="text" min="0" onkeypress="return isNumberKey(event)" class="form-control cfixed" id="cfixed_'.$i.'" value="'.$fixed.'" step="any" size="2" style="height: 24px;"></td>';    
$body.='<td><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control cpercet" id="cpercet_'.$i.'" value="'.$percent.'"  size="2" style="height: 24px;"/></td>';
$body.='<td class="text-right" id="tcom_'.$i.'">'.$totcom.'</td>';
$body.='<td align="center"><a id="'.$i.'" class="remove"><span style="cursor: pointer;" class="fa fa-times"></span></a></td>';    
$body.='</tr>';     
}
$foot.='<tr>';
$foot.='<th colspan="3" class="text-right">TOTAL</th>';
$foot.='<th class="text-right">'.total_pivalue('Q').'</th>';
$foot.='<th class="text-right">'.number_format(total_pivalue('V'),2).'</th>';
$foot.='<th class="text-right" colspan="2"></th>';
$foot.='<th class="text-right">'.number_format(total_pivalue('C'),2).'</th>';     
$foot.='<th></th>';    
$foot.='</tr>';    
}else{
$body.='<tr>';
$body.='<td colspan="9" class="text-center">There are no items in your pi list!</td>';
$body.='</tr>'; 
} 
}else{
$body.='<tr>';
$body.='<td colspan="9" class="text-center">There are no items in your pi list!</td>';
$body.='</tr>';
}
            
if(isset($_POST['body'])){
echo $body;
}elseif(isset($_POST['foot'])){
echo $foot;	
}
exit;    
?>