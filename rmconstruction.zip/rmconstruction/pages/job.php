<div class="col-md-12 form-group">
    <table class="table table-bordered table-striped">
        <tr>
            <td width="150"><label>Job #</label></td>
            <td><span class="label label-primary label-block">JB-000009</span></td>

            <td width="150"><label>Published On</label></td>
            <td>20 Mar 2020</td>
        </tr>
        <tr>
            <td ><label>Title</label></td><td >Senior PHP Developer</td>

            <td ><label>Type</label></td><td colspan="3">Permanent, Full time Job</td>
        </tr>
        <tr>
            <td ><label>Location</label></td><td colspan="3">Kochin - Kerala - India</td>
        </tr>
        <tr>
            <td ><label>Education</label></td><td>Under Graduate, Graduate, Post Graduate</td>
            <td ><label>Experience</label></td><td>1 - 2 Years</td>
        </tr>
        
        <tr>
            <td ><label>Gender</label></td><td >Any</td>

            <td ><label>No of Vacancies</label></td><td >2</td>
        </tr>
        <tr>
            <td ><label>Status</label></td><td colspan="3">Open</td>
        </tr>
        <tr>
            <td colspan="4">XO Bills is an industry-based Software Development Company urgently looking for an experienced logical thinking personal to join its team in Kochin.<br />
<br />
We&rsquo;re searching for a professional who have a solid track record. He / She is responsible for creating and implementing an array of Web-based products using&nbsp;<strong>PHP</strong>, MySQL, Ajax, and JavaScript. You develop back-end components, connect the application with other web services, and assist front-end&nbsp;<strong>developers</strong>&nbsp;by ensuring their work integrates with the application.<br />
<br />
<strong>The candidate should have</strong>&nbsp;<strong>2+</strong>&nbsp;years of experience with excellent knowledge in CodeIgnitor, MySQL.<br />
<br />
<strong>Functional Area</strong><br />
IT - Update existing skill set in PHP, Understand the given requirement and code as per the requirements, able to read and write code written by others.<br />
<br />
<strong>Job Responsibilities and Requirements</strong>
<ul>
	<li>Coding according to the requirements confirming to the coding standards and guidelines.</li>
	<li>Learn new open source packages.</li>
	<li>Unit test the code components; Document the code and the functionality.</li>
	<li>Candidate should be familiar with PHP framework.</li>
	<li>Candidate should be Good knowledge of CodeIgnitor ,JavaScript, AJAX, Jquery</li>
	<li>Candidate should be a good learner, and open to learn new technologies on php and other languages as well.</li>
	<li>Analyze system issues and problems and implement solutions rapidly; formulate/use design patterns wherever applicable.</li>
	<li>Meet aggressive deadlines while working under pressure, dedication to building high-quality deliverables while being thorough in all aspects of the development lifecycle.</li>
	<li>Worked on performance optimization, SQL tuning, SQL Indexing, SQL partitioning, caching techniques</li>
	<li>Ability to manage web hosting</li>
</ul>
<strong>Salary &amp; Benefits</strong>

<ul>
	<li>Salary package starts from Rs. 20,000/- to Rs. 25,000/- (depends on expertise and experience)</li>
</ul>
<strong>How to Apply</strong>

<ul>
	<li>Candidates must apply through the Career page on our web site www.xobills.com (https://xobills.com/contents/careers)</li>
	<li>Candidates must upload recent resume with a passport size photograph</li>
</ul>

<ul>
	<li>A clear copy of the highest qualification certificate has to be uploaded.</li>
</ul>
Job Types: Full-time<br />
Salary: ₹20,000.00 to ₹23,000.00 /month</td>
        </tr>
    </table>
</div>
<div class="clearfix"></div>