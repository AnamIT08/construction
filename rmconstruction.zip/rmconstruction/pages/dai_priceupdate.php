<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('2','edits','R');     
$_SESSION['cuPages']='dai_priceupdate.php';   
$cuPage='dai_priceupdate.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='daily';
$menuh='Daily Process';
$phead='priupd';
$page='Update Price List';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');

function get_curlist($curid){
global $con;
$out='';
$sql='SELECT * FROM tbl_currency ORDER BY name ASC';
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
$out.='<option value="0">-Selcet-</option>';    
while ($row=mysqli_fetch_array($query)){
if($row['id']==$curid){
$out.='<option selected value="'.$row['id'].'">'.$row['name'].' ('.$row['symbol'].')</option>';    
}else{
$out.='<option value="'.$row['id'].'">'.$row['name'].' ('.$row['symbol'].')</option>';     
}    
}
return $out;    
}

if(isset($_POST['save_price'])){
$efr=0;
if(isset($_POST['data']) && !empty($_POST['data'])){    
$deitems=$_POST['data'];
foreach($deitems as $item){
$id = remove_junk(escape($item['id']));
$cuprice = remove_junk(escape($item['cuprice']));
$upprice = remove_junk(escape($item['uprice']));
$curid = remove_junk(escape($item['currency']));    
if($upprice!='' && floatval($upprice)>0){
if(floatval($cuprice)>0){
$sql="UPDATE tbl_stock SET oldprice='$cuprice',price='$upprice',pupdate='$dtnow' WHERE id='$id'";    
}else{
$sql="UPDATE tbl_stock SET price='$upprice',pupdate='$dtnow' WHERE id='$id'";    
}    
if($upprice!='' && floatval($upprice)>0 && floatval($curid)>0){     
$update = mysqli_query($con,$sql) or die(mysqli_error($con));
$itid=mysqli_affected_rows($con);
if($itid>0){
$efr+=1;    
}else{
$efr+=0;     
}
}else{
$efr+=0;    
}
}    
if($itid>0){
$efr+=1;    
}else{
$efr+=0;     
}    
}    
if($efr>0){
$act =remove_junk(escape('Product Price Update'));    
write_activity($aid,'PRI','Price list has been Update',$act);    
save_msg('s','Data Successfully Saved!');    
}else{
save_msg('w','Data Fail to Saved!');    
}    
}else{
save_msg('i','No data found!!! Data Fail to Save');    
}    
echo "<script>window.location='dai_priceupdate.php'</script>"; 
}    
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Add or Update Price</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="dai_priceupdate.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">    
<div class="row">
<div class="table-responsive">
<table class="table table-bordered table-striped">
<thead>
<tr>
<th style="width:40px; text-align:center;">SN</th>   
<th>Name</th>
<th>Code</th>     
<th>Available Qty</th>    
<th>Old Price</th>
<th>Current Price</th>
<th style="width:200px; text-align:center;">Currency</th>    
<th style="width:100px;">Update Price</th>   
</tr>
</thead>
<tbody>
<?php
$s=0;    
//$sql="SELECT id,oldprice,curprice,CAST(pupdate AS DATE) AS udate,DATE_FORMAT(pupdate, '%r') AS utime,pcurid FROM tbl_item WHERE status='1' ORDER BY id ASC";
$sql="SELECT stk.id,stk.pid,stk.unqid,name,image,pcode,stk.oldprice,stk.udate,stk.utime,stk.uid,stk.price,IFNULL(brqty,0) AS brqty,IFNULL(whqty,0) AS whqty,(IFNULL(brqty,0)+IFNULL(whqty,0)) AS avqty FROM (SELECT id,pid,unqid,oldprice,CAST(pupdate AS DATE) AS udate,DATE_FORMAT(pupdate, '%r') AS utime,uid,price FROM tbl_stock) stk LEFT JOIN (SELECT name,image,pcode,unqid,SUM(avqty) AS brqty FROM tbl_brstock GROUP BY unqid) bst ON bst.unqid=stk.unqid LEFT JOIN (SELECT unqid,SUM(avqty) AS whqty FROM tbl_whstock GROUP BY unqid) wst ON wst.unqid=stk.unqid WHERE (IFNULL(brqty,0)+IFNULL(whqty,0))>0 ORDER BY name ASC";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){ 
$s+=1;    
?>    
<tr>
<td style="text-align:center;"><?php echo $s; ?></td>
<td ><?php echo $row['name']; ?>
<input type="hidden" maxlength="11" name="data[<?php echo $s; ?>][id]" value="<?php echo $row['id']; ?>" autocomplete="off">    
</td>
<td><?php echo $row['pcode']; ?></td>    
<td><?php echo $row['avqty']; ?></td>    
<td style="text-align:right;"><?php echo numtolocal($row['oldprice'],get_fild_data('tbl_currency','1','symbol'));?></td>
<td style="text-align:right;"><?php echo numtolocal($row['price'],get_fild_data('tbl_currency','1','symbol'));?>
<input type="hidden" name="data[<?php echo $s; ?>][cuprice]" class="form-control"  value="<?php echo $row['price'];?>" readonly/>    
</td>
<td style="text-align:center;">
<select class="form-control select2" name="data[<?php echo $s; ?>][currency]">
<?php echo get_curlist('1');?>
</select>
</td>    
<td><input type="text" min="0" onkeypress="return isNumberKey(event)" name="data[<?php echo $s; ?>][uprice]" class="form-control"  value="" step="any" style="width:65px; height: 24px; width:100%;"></td>    
</tr>
<?php } ?>    
</tbody>    
</table>    
</div>    
</div>
</div>
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="save_price" id="submit" class="btn btn-flat bg-purple btn-sm " value="Update"/> <a href="dai_pricelist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'PRI','A');}else{echo read_activity($aid,'PRI','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">

</script>    
<!-- /page script -->
</html>    