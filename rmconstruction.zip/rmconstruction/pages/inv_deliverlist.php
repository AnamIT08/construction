<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='inv_deliverlist.php';   
$cuPage='inv_deliverlist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='inventor';
$menuh='Inventory';
$phead='dellist';
$page='Sales Delivery';
$print='print';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php 
function check_desales($invno){
$flage=0;
global $con;
$sql="SELECT * FROM tbl_sreturn WHERE refinv='$invno'";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}
return $flage;  
}

if(isset($_POST['deldli'])){
$id=$_POST['deldli'];

$sql="SELECT * FROM tbl_pdlirecord WHERE id='$id' LIMIT 1";
$dsales=mysqli_query($con,$sql) or die(mysqli_error($con));    
$dsel=mysqli_fetch_array($dsales);     

$invno=$dsel['invno'];
$refinv=$dsel['refinv'];    
    
if(check_desales($refinv)){
save_msg('w','Sales Depend on others data!!!');
echo "<script>window.location='inv_deliverlist.php'</script>";
return;    
}    

$sql="SELECT * FROM tbl_serialsale WHERE dlno='$invno'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {  
$sql="UPDATE tbl_serialsale SET dli='N',dlno=NULL WHERE dlno='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));      
}    

$sql="DELETE FROM tbl_traproduct WHERE invno='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));    

$sql="DELETE FROM tbl_pdlirecord WHERE id='$id'";
$fdel=mysqli_query($con,$sql)or die(mysqli_error($con));    
$efid=mysqli_affected_rows($con);
if($efid>0){
$act =remove_junk(escape('Delivery Challan No: '.$invno));
$bact =remove_junk('ডেলিবারী চালান নং: '.$invno);    
write_activity($aid,'DLI','Delivery Challan has been deleted',$act,'ডেলিবারী চালান মুছে ফেলেছেন',$bact);        
save_msg('s','Delivery Successfully Deleted!!!');
}else{
save_msg('s','Delivery Fail to Delete!!!');    
}
echo "<script>window.location='inv_deliverlist.php'</script>";
    
}
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Delivered Record</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px; text-align:center;">SN</th>   
<th>Date</th>
<th>Challan No</th>
<th>Invoice No</th>    
<th>From</th>    
<th>Note</th>    
<th style="width:40px; text-align:center;">Action</th>    
</tr>
</thead>    
<tbody>
<?php
$sql="SELECT tbl_pdlirecord.id,tbl_pdlirecord.invno,tbl_pdlirecord.refinv,tbl_pdlirecord.ibrid,tbl_pdlirecord.note,tbl_sales.type,tbl_sales.cusid,tbl_pdlirecord.apdate,tbl_pdlirecord.brid,tbl_pdlirecord.uid,tbl_pdlirecord.date FROM tbl_pdlirecord LEFT JOIN tbl_sales ON tbl_sales.invno=tbl_pdlirecord.refinv ORDER BY apdate DESC,id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){    
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td><?php echo date("d M Y", strtotime($row['apdate']));?></td>
<td><?php echo $row['invno'];?></td>
<td><?php echo $row['refinv'];?></td>    
<td>
<?php 
if($row['ibrid']!=0){    
echo get_fild_data('tbl_branch',$row['ibrid'],'name');
}else{
echo 'No Branch';    
}
?>
</td>    
<td><?php echo $row['note'];?></td>   
<td nowrap="">
<a class="btn btn-flat bg-purple details-invoice" href="#" id="inv_<?php echo $row['id'].'_'.$row['cusid'].'_'.$row['type']; ?>"><i class="fa fa-eye cat-child"></i></a>   
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>   
<form action="inv_deliverlist.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="deldli" value="<?php echo $row['id']; ?>" />
</form>
</td>    
</tr>    
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<a href="inv_delivercre.php" class="btn btn-flat bg-purple"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Create Delivery';}else{echo ' বিতরণ করুন';}?></a>
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'DLI','A');}else{echo read_activity($aid,'DLI','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->
<?php include('../layout/print.php'); ?>     
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
});
    
function take_action(id) {
document.getElementById(id).submit(); 
}
    
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});
}
    
$(document).on('click','.details-invoice',function(e) {      
id_arr = $(this).attr('id');
id = id_arr.split("_");

$.ajax({
url: 'inv_viewdli.php',
method: "POST",
data:{ 
invid: id[1],cusid: id[2],type:id[3]
},
success: function(data){
$('#listitem').html(data);
pagelist();    
}
});    
    
$.ajax({
url: 'inv_viewdlocha.php',
method: "POST",
data:{ 
print: id[1]
},
success: function(data){
$('#invhold').html(data);
sethead();    
}
});
    
$('.right-side').toggle('slide', { direction: 'right' }, 300);    

e.preventDefault();
});

$(document).on('click', '#closepop', function() {
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }   
});
    
$('#listitem').on('click','li', function(){
   $(this).addClass('active').siblings().removeClass('active');
});
    
$(document).on('click', '.invpiv', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
$.ajax({
url: 'inv_viewdlocha.php',
method: "POST",
data:{ 
print: ids
},
beforeSend: function() {
//$("#invhold").fadeOut('slow');
},    
success: function(data){    
$('#invhold').html(data);
$("#invhold").fadeIn('slow');    
sethead();    
}
});     
});    
</script>    
<!-- /page script -->
</html>    