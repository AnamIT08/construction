<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
$today = strftime("%Y-%m-%d", time());    
$dtnow = date("Y-m-d h:i:s", time());    
}else{
header('Location:../index.php');
exit;    
}
?>
<?php
if(isset($_POST['delnt'])){
$id=$_POST['ids'];
$sql="DELETE FROM tbl_note WHERE id='$id'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);
if($efid>0){
$title=get_fild_data('tbl_note',$id,'title');    
$act =remove_junk(escape('Note: '.$title));    
write_activity($aid,'NET','Note has been Deleted',$act);
echo json_encode(array(
'status' => 'success',
'message'=> 'Note delete Successfully!!' 
));
exit;    
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Delete!!'
));    
}    
}

if(isset($_POST['upfav'])){
$id=$_POST['ids'];
$sql="UPDATE tbl_note SET isfav=(if(isfav='N','Y','N')) WHERE id='$id'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);
if($efid>0){
$title=get_fild_data('tbl_note',$id,'title');    
$act =remove_junk(escape('Note: '.$title));    
//write_activity($aid,'NET','Note has been Updated',$act);
echo json_encode(array(
'status' => 'success',
'message'=> 'Note update Successfully!!' 
));
exit;    
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Update!!'
));    
}    
}

if(isset($_POST['uplab'])){
$id=$_POST['ids'];
$typ=$_POST['typ'];    
$sql="UPDATE tbl_note SET type='$typ' WHERE id='$id'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$efid=mysqli_affected_rows($con);
if($efid>0){
$title=get_fild_data('tbl_note',$id,'title');    
$act =remove_junk(escape('Note: '.$title));    
//write_activity($aid,'NET','Note has been Updated',$act);
echo json_encode(array(
'status' => 'success',
'message'=> 'Note update Successfully!!' 
));
exit;    
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Update!!'
));    
}    
}

if(isset($_POST['savent'])){
$title = remove_junk(escape($_POST['title']));
$note = remove_junk(escape($_POST['note']));
$sql="INSERT INTO tbl_note (title,note,apdate,brid,uid,date) VALUES ('$title','$note','$today','$brid','$aid','$dtnow')";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));    
$efid=mysqli_affected_rows($con);
if($efid>0){
$act =remove_junk(escape('Note: '.$title));    
write_activity($aid,'NET','New note has been Created',$act);
echo json_encode(array(
'status' => 'success',
'message'=> 'Note Save Successfully!!'   
));
exit;    
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));    
}
}
?>
<?php if(isset($_POST['note'])){ ?>
<?php
$sql="SELECT * FROM tbl_note ORDER BY title ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
if($row['type']==1){
$type='note-personal';    
}elseif($row['type']==2){
$type='note-work';
}elseif($row['type']==3){
$type='note-social';
}elseif($row['type']==4){
$type='note-important';    
}else{
$type='';    
}    
?>
<div class="note-item all-notes <?php echo $type;?> <?php if($row['isfav']!='N'){echo 'note-fav';}?>">
<div class="note-inner-content">
<div class="note-content">
<p class="note-title" data-noteTitle="<?php echo $row['title'];?>"><?php echo $row['title'];?></p>
<p class="meta-time"><?php echo date("d M Y", strtotime($row['apdate']));?></p>
<div class="note-description-content">
<p class="note-description" data-noteDescription="<?php echo $row['note'];?>"><?php echo $row['note'];?></p>
</div>
</div>
<div class="note-action <?php if($row['isfav']!='N'){echo 'note-fav';}?>">
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-star fav-note" id="FAV_<?php echo $row['id'];?>"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2 delete-note" id="DEL_<?php echo $row['id'];?>"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
</div>
<div class="note-footer">
<div class="tags-selector btn-group">
<a class="nav-link dropdown-toggle d-icon label-group" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="true">
<div class="tags">
<div class="g-dot-personal"></div>
<div class="g-dot-work"></div>
<div class="g-dot-social"></div>
<div class="g-dot-important"></div>
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
</div>
</a>
<div class="dropdown-menu dropdown-menu-right d-icon-menu">
<a class="note-personal label-group-item label-personal dropdown-item position-relative g-dot-personal" href="javascript:void(0);" id="PER_<?php echo $row['id'];?>"> Personal</a>
<a class="note-work label-group-item label-work dropdown-item position-relative g-dot-work" href="javascript:void(0);" id="WRK_<?php echo $row['id'];?>"> Work</a>
<a class="note-social label-group-item label-social dropdown-item position-relative g-dot-social" href="javascript:void(0);" id="SOC_<?php echo $row['id'];?>"> Social</a>
<a class="note-important label-group-item label-important dropdown-item position-relative g-dot-important" href="javascript:void(0);" id="IMP_<?php echo $row['id'];?>"> Important</a>
</div>
</div>
</div>
</div>
</div>
<script>
deleteNote();
favNote();
addLabelGroups();
</script>
<?php } ?>
<?php } ?>
