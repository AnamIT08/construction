<?php
session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;     
}
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php
if(isset($_POST['addseritem'])){   
$name = remove_junk(escape($_POST['name']));
$bname = remove_junk(escape($_POST['bname']));
$type = remove_junk(escape($_POST['type']));   
$mobile = remove_junk(escape($_POST['mobile']));
$acno = remove_junk(escape($_POST['acno']));     
$address = remove_junk(escape($_POST['address']));    

if($type==1){    
if(isset($_POST['mobile'])){
$sql="SELECT * FROM tbl_loanid WHERE mobile = '$mobile'";           
$ducode = mysqli_query($con,$sql);
}
}else{
if(isset($_POST['acno'])){
$sql="SELECT * FROM tbl_loanid WHERE acno = '$acno'";           
$ducode = mysqli_query($con,$sql);
}    
}

if($type==1){$code=get_genid('LO','LON','P'); $acno='NULL'; $mobile="'".$mobile."'";}else{$code=get_genid('LO','LON','B');$acno="'".$acno."'"; $mobile='NULL';}    
    
if($ducode->num_rows > 0) {
if($type==1){    
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Mobile Account Already Exists!!'
));
return;
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Bank Account Already Exists!!'
));
return;
exit;    
}    
}else{ 
$sql="INSERT INTO tbl_loanid (code,name,bname,type,acno,mobile,address,brid,uid,date) VALUES ('$code','$name','$bname','$type',$acno,$mobile,'$address','$brid','$aid','$dtnow')";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$pid=$con->insert_id;    
$efid=mysqli_affected_rows($con);    
if($efid>0){    
if($type==1){
$act =remove_junk(escape('Loan Account: '.$name.'-'.$mobile));    
}else{
$act =remove_junk(escape('Loan Account: '.$name.'-'.$acno));    
}    
write_activity($aid,'LON','Loan account has been created',$act);    
echo json_encode(array(
'status' => 'success',
'message'=> 'Data Save Successfully!!'   
));
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));    
} 
}   
}

if(isset($_POST['editseritem'])){
$name = remove_junk(escape($_POST['name']));
$bname = remove_junk(escape($_POST['bname']));
$type = remove_junk(escape($_POST['type']));   
$mobile = remove_junk(escape($_POST['mobile']));
$acno = remove_junk(escape($_POST['acno']));     
$address = remove_junk(escape($_POST['address']));    
$itemid = remove_junk(escape($_POST['itmid']));;

if($type==1){    
if(isset($_POST['mobile'])){
$sql="SELECT * FROM tbl_loanid WHERE mobile = '$mobile' AND id!='$itemid'";           
$ducode = mysqli_query($con,$sql);
}
}else{
if(isset($_POST['acno'])){
$sql="SELECT * FROM tbl_loanid WHERE acno = '$acno' AND id!='$itemid'";           
$ducode = mysqli_query($con,$sql);
}    
}
    
if($type==1){$code=substr_replace(get_fild_data('tbl_loanid',$itemid,'code'),'P',-1); $acno='NULL'; $mobile="'".$mobile."'";}else{$code=substr_replace(get_fild_data('tbl_loanid',$itemid,'code'),'B',-1);$acno="'".$acno."'"; $mobile='NULL';}    

if($ducode->num_rows > 0) {
if($type==1){    
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Mobile Account Already Exists!!'
));
return;
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Bank Account Already Exists!!'
));
return;
exit;    
} 
}else{ 
$sql="UPDATE tbl_loanid SET code='$code',name='$name',bname='$bname',type='$type',acno=$acno,mobile=$mobile,address='$address' WHERE id='$itemid'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$pid=$con->insert_id;    
$efid=mysqli_affected_rows($con);    
if($efid>0){
if($type==1){
$act =remove_junk(escape('Loan Account: '.$name.'-'.$mobile));    
}else{
$act =remove_junk(escape('Loan Account: '.$name.'-'.$acno));    
}        
write_activity($aid,'LON','Loan Account has been Updated',$act);    
echo json_encode(array(
'status' => 'success',
'message'=> 'Data Update Successfully!!'   
));
exit;
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Update!!'
));    
} 
}  
}


function check_desales($id){
$flage=0;
global $con;
$sql="SELECT * FROM tbl_trarecord WHERE (dty='LO' AND did='$id') OR (cty='LO' AND cid='$id')";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}
return $flage;
}

if(isset($_POST['dellon'])){
$id=$_POST['dellon'];
if(check_desales($id)){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data depend on other table!!'
));
return;
exit;    
}else{
$name=get_fild_data('tbl_loanid',$id,'name');      
$sql="DELETE FROM tbl_loanid WHERE id='$id'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));    
$efid=mysqli_affected_rows($con);    
if($efid>0){  
$act =remove_junk(escape('Loan Account: '.$name));    
write_activity($aid,'LON','Loan Account has been Deleted',$act);    
echo json_encode(array(
'status' => 'success',
'message'=> 'Data Deleted Successfully!!'   
));
exit;    
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Delete!!'
));     
}    
}    
}
?>

<?php if(isset($_POST['viewitem'])){
$sql="SELECT * FROM tbl_loanid ORDER BY name ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$id='LO'.$row['id'];    
$ldebit=get_ledgerval($id,'D','N');
$lcredit=get_ledgerval($id,'C','N');
$lnet=($ldebit-$lcredit);    
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td><?php echo $row['code'];?></td>
<td><?php echo $row['name'];?></td>
<?php if($row['type']==1){?>    
<td><?php echo $row['mobile'];?></td>
<?php }else{ ?>
<td><?php echo $row['acno'];?></td>    
<?php } ?>
<td><?php if($row['type']==1){echo 'Person';}else{echo 'Bank';}?></td>    
<td><?php echo numtolocal($ldebit,get_fild_data('tbl_currency','1','symbol'));?></td>
<td><?php echo numtolocal($lcredit,get_fild_data('tbl_currency','1','symbol'));?></td>
<td><?php echo numtolocal($lnet,get_fild_data('tbl_currency','1','symbol'));?></td>   
<td nowrap="">
<a class="btn btn-flat bg-purple details-invoice" href="#" id="stm_<?php echo $row['id']; ?>"><i class="fa fa-eye cat-child"></i></a>     
<a class="btn btn-flat bg-purple edit-loan" href="#" id="LO_<?php echo $row['id']; ?>"><i class="fa fa-edit cat-child"></i></a>    
<a class="btn btn-flat bg-purple delete-loan" href="#" onclick="remove_item('<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
</td>    
</tr>    
<?php }} ?>

<?php 
if(isset($_POST['viewitemhis'])){
if($_SESSION['utype']=='1'){echo read_activity($aid,'LON','A');}else{echo read_activity($aid,'LON','U');}
}?>

<?php 
if(isset($_POST['addsitem'])){ 
$item=intval($_POST['item']);   
?>
<div class="col-md-12 popup_details_div addservice">
<div class="row">
<div id="server-results"><!-- For server results --></div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<?php if($item <=0){ ?>     
<div class="form-group">
<label>Name</label>
<input type="text" maxlength="25" value="" name="name" id="name" class="form-control" placeholder="e.g. Md.Sumon"/>   
<input type="hidden" name="addseritem" readonly /> 
</div>
<div class="form-group">
<label>নাম (বাংলায়)</label>
<input type="text" maxlength="255" value="" name="bname" id="bname" class="form-control" placeholder="e.g. মোঃ সুমন"/>   
</div>    
<div class="row">
<div class="col-md-4">    
<div class="form-group">
<label>Code</label>    
<input type="text" name="code" maxlength="45" value="<?php echo get_genid('LO','LON','P');?>" id="code" class="form-control" placeholder="e.g. Code" readonly/>    
</div>
</div>    
<div class="col-md-8">
<div class="form-group">
<label>Type</label>
<select class="form-control select2" name="type" id="type">
<option value="1">Person</option>
<option value="0">Bank</option>    
</select>
</div>
</div>     
</div>
<div class="form-group">
<label>Mobile</label>
<input type="text" maxlength="18" value="" name="mobile" id="mobile" class="form-control" placeholder="e.g. 0161617xx7x"/>
</div>
<div class="form-group">
<label>Account</label>
<input type="text" maxlength="25" value="" name="acno" id="acno" class="form-control" placeholder="e.g. 045247824"/>
</div>
<div class="form-group">
<label>Address</label>
<textarea class="form-control" maxlength="250" rows="5" name="address" placeholder="Address"></textarea>
</div>    
<?php 
}else{ 
$sql="SELECT * FROM tbl_loanid WHERE id='".$item."' ORDER BY id ASC LIMIT 1";    
$admin=mysqli_query($con,$sql) or die(mysqli_error($con));    
$adm=mysqli_fetch_array($admin);    
?>
<div class="form-group">
<label>Name</label>
<input type="text" maxlength="25" value="<?php echo $adm['name'];?>" name="name" id="name" class="form-control" placeholder="e.g. bKash"/>
<input type="hidden" maxlength="11" value="<?php echo $adm['id'];?>" class="form-control" name="itmid" autocomplete="off" readonly>
<input type="hidden" name="editseritem" readonly />     
</div>
<div class="form-group">
<label>নাম (বাংলায়)</label>
<input type="text" maxlength="255" value="<?php echo $adm['bname'];?>" name="bname" id="bname" class="form-control" placeholder="e.g. মোঃ সুমন"/>   
</div>
<div class="row">
<div class="col-md-4">    
<div class="form-group">
<label>Code</label>    
<input type="text" name="code" maxlength="45" value="<?php echo $adm['code'];?>" id="code" class="form-control" placeholder="e.g. Code" readonly/>    
</div>
</div>    
<div class="col-md-8">
<div class="form-group">
<label>Type</label>
<select class="form-control select2" name="type" id="type">
<option <?php if($adm['type']==1){echo 'selected';}?> value="1">Person</option>
<option <?php if($adm['type']==0){echo 'selected';}?> value="0">Bank</option>    
</select>
</div>
</div>     
</div>    
<div class="form-group">
<label>Mobile</label>
<input type="text" maxlength="18" value="<?php echo $adm['mobile'];?>" name="mobile" id="mobile" class="form-control" placeholder="e.g. 0161617xx7x"/>
</div>
<div class="form-group">
<label>Account</label>
<input type="text" maxlength="25" value="<?php echo $adm['acno'];?>" name="acno" id="acno" class="form-control" placeholder="e.g. 045247824"/>
</div>
<div class="form-group">
<label>Address</label>
<textarea class="form-control" maxlength="250" rows="5" name="address" placeholder="Address"><?php echo $adm['address'];?></textarea>
</div>    
<?php } ?>   
</div>    
<div class="col-md-1"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-7"></div>
<div class="col-md-3 text-right" >
<input type="button" id="additem" class="btn btn-flat bg-purple btn-sm " value="<?php if($item <=0){echo 'Save';}else{echo 'Update';} ?>"/>
</div>
<div class="col-md-1"></div>    
</div>
<script type="text/javascript">

function chek_error(){
var result = true;
var name = $('#name').val();
var type = $('#type').val();    
var mobile = $('#mobile').val();
var acno = $('#acno').val();    

$('.LV_invalid_field').removeClass('LV_invalid_field');     
$('.LV_validation_message').remove();     

if(name.length<1){
$('#name').addClass('LV_invalid_field');   
$('#name').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#name').removeClass('LV_invalid_field');
result=true;    
}    

if(type==1){        
if(mobile.length<1){
$('#mobile').addClass('LV_invalid_field');   
$('#mobile').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#mobile').removeClass('LV_invalid_field');
result=true;    
}    
}else{
if(acno.length<1){
$('#acno').addClass('LV_invalid_field');   
$('#acno').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#acno').removeClass('LV_invalid_field');
result=true;    
}    
}
    
if(name.length<1 || !result){
return false;    
}else{
return true;     
}        
}
    
$(document).on('blur', '#name, #mobile, #acno', function() {
chek_error();    
});    
</script> 

<?php } ?>