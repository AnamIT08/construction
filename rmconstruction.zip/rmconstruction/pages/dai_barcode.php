<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){       
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
?>
<style>
.node-text {
  display: inline-block;
  width: 10em;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
</style>
<?php 
if(isset($_POST['invid'])){
$piid=$_POST['invid'];    
$sql="SELECT stk.id,stk.pid,stk.unqid,name,pcode,stk.price,IFNULL(brqty,0) AS brqty,IFNULL(whqty,0) AS whqty,(IFNULL(brqty,0)+IFNULL(whqty,0)) AS avqty FROM (SELECT id,pid,unqid,price FROM tbl_stock) stk LEFT JOIN (SELECT name,pcode,unqid,SUM(avqty) AS brqty FROM tbl_brstock GROUP BY unqid) bst ON bst.unqid=stk.unqid LEFT JOIN (SELECT unqid,SUM(avqty) AS whqty FROM tbl_whstock GROUP BY unqid) wst ON wst.unqid=stk.unqid WHERE (IFNULL(brqty,0)+IFNULL(whqty,0))>0";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){    
?>
<li <?php if($row['unqid']==$piid){echo 'class="invpiv active"';}else{echo 'class="invpiv"';}?> id="pi_<?php echo $row['unqid'];?>"><p><strong class="pino"><?php echo $row['pcode'];?></strong><br><b class="node-text"><?php echo $row['name'];?></b></p>
<div class="sname" style="margin-top: -52px;float: right; position: relative;top: 6px;"><strong><?php echo 'B: '.$row['unqid']; ?></strong><br><strong><?php echo 'Q: '.$row['avqty']; ?></strong></div>
</li>
<?php }} ?>