<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='inv_whotra.php';   
$cuPage='inv_whotra.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];
$uty=$_SESSION['utype'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='inventor';
$menuh='Inventory';
$phead='whotra';
$page='Warehouse Transfer';
$print='print';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php
function get_avqty($mods,$bwid,$unqid){
global $con;
if($mods=='BR'){    
$sql="SELECT COALESCE ((SELECT avqty FROM tbl_brstock WHERE brid='$bwid' AND unqid='$unqid' LIMIT 1),0) AS avqty";
}elseif($mods=='WH'){
$sql="SELECT COALESCE ((SELECT avqty FROM tbl_whstock WHERE waid='$bwid' AND unqid='$unqid' LIMIT 1),0) AS avqty";    
}
$result=mysqli_query($con,$sql) or die(mysqli_error($con));    
$row=mysqli_fetch_array($result);
return $row['avqty'];    
}

function get_srlinfo($serial,$key){
global $con;
$sql="SELECT ".$key." AS rdata FROM tbl_serial WHERE serial='$serial' LIMIT 1";
$result=mysqli_query($con,$sql) or die(mysqli_error($con));    
$row=mysqli_fetch_array($result);
return $row['rdata'];    
}

function check_trbinvdel($invno){
$flage=0;
global $con;

$sql="SELECT * FROM tbl_traproduct WHERE invno='$invno' AND p_in>0";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$unqid=$row['unqid'];
$qty=$row['p_in'];
if($row['brid']!=''){
$mods='BR';
$bwid=$row['brid'];    
}else{
$mods='WH';
$bwid=$row['waid'];    
}
$avqty=get_avqty($mods,$bwid,$unqid);
if($qty<$avqty){
$flage=1;
break;    
}else{
$flage=0;    
}    
}    

if($flage>0){
return $flage;
exit;    
}    
 
$sql="SELECT * FROM tbl_serialsale WHERE invno='$invno'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$serial=$row['serial'];
$sql="SELECT * FROM tbl_serial WHERE serial='$serial' AND status>0";
$que=mysqli_query($con,$sql)or die(mysqli_error($con));    
if($que->num_rows > 0) {
$flage=1;
break;    
}else{
$flage=0;    
}    
}    

if($flage>0){
return $flage;
exit;    
}    

$sql="SELECT * FROM tbl_trafrwho WHERE invno='$invno'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));    
$row=mysqli_fetch_array($query);
if($row['ttype']=='BR'){
$key='brid';    
}else{
$key='whid';    
}    
$tid=$row['tsourch'];

$sql="SELECT * FROM tbl_serialsale WHERE invno='$invno'";
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));   
if($querys->num_rows > 0) {
while ($srl=mysqli_fetch_array($querys)){
$serial=$srl['serial'];
$sel=get_srlinfo($serial,$key);
if($sel!=$tid){
$flage=1;
break;    
}    
}    
}else{
$flage=0;    
}        

if($flage>0){
return $flage;
exit;    
}
return $flage;     
}

if(isset($_POST['delwtra'])){
$id=$_POST['delwtra'];

$sql="SELECT * FROM tbl_trafrwho WHERE id='$id' LIMIT 1";
$dsales=mysqli_query($con,$sql) or die(mysqli_error($con));    
$dsel=mysqli_fetch_array($dsales); 

$invno=$dsel['invno'];    
$iwhid=$dsel['fsourch'];
    
if(check_trbinvdel($invno)){
save_msg('w','Transfer Depend on others data!!!');
echo "<script>window.location='inv_whotra.php'</script>";
return;    
}    

$sql="SELECT * FROM tbl_serialsale WHERE invno='$invno'";
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));   
if($querys->num_rows > 0) {
while ($srl=mysqli_fetch_array($querys)){
$serial=$srl['serial'];    
$sql="UPDATE tbl_serial SET brid=NULL,whid='$whid' WHERE serial='$serial'";
mysqli_query($con,$sql)or die(mysqli_error($con));    
}
$sql="DELETE FROM tbl_serialsale WHERE invno='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));    
}
    
$sql="DELETE FROM tbl_traproduct WHERE invno='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));

$sql="DELETE FROM tbl_trafrwho WHERE id='$id'";
$fdel=mysqli_query($con,$sql)or die(mysqli_error($con));    
$efid=mysqli_affected_rows($con);
if($efid>0){
$act =remove_junk(escape('Transfer Challan: '.$invno));    
write_activity($aid,'TRW','Transfer challan has been deleted',$act);        
save_msg('s','Transfer Successfully Deleted!!!');
}else{
save_msg('w','Transfer Fail to Delete!!!');    
}    
    
echo "<script>window.location='inv_whotra.php'</script>";     
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Transfer Record</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px; text-align:center;">SN</th>   
<th>Date</th>
<th>Transfer No</th>
<th>From</th>    
<th>To</th>
<th>Note</th>    
<th style="width:40px; text-align:center;">Action</th>    
</tr>
</thead>    
<tbody>
<?php   
$sql="SELECT * FROM tbl_trafrwho WHERE brid='$brid' ORDER BY apdate DESC,id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){    
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td><?php echo date("d M Y", strtotime($row['apdate']));?></td>
<td><?php echo $row['invno'];?></td>    
<td>
<?php 
if($row['ftype']=='BR'){
if($row['fsourch']!=0){    
echo get_fild_data('tbl_branch',$row['fsourch'],'name');
}else{
echo 'No Branch';    
}
}else{
echo get_fild_data('tbl_warehouse',$row['fsourch'],'name');
}
?>
</td>
<td>
<?php 
if($row['ttype']=='BR'){
if($row['tsourch']!=0){     
echo get_fild_data('tbl_branch',$row['tsourch'],'name');
}else{
echo 'No Branch';    
}    
}else{
echo get_fild_data('tbl_warehouse',$row['tsourch'],'name');
}
?>
</td>    
<td><?php echo $row['note'];?></td>   
<td nowrap="">
<a class="btn btn-flat bg-purple details-invoice" href="#" id="inv_<?php echo $row['id'].'_'.$row['tsourch'].'_'.$row['ttype']; ?>"><i class="fa fa-eye cat-child"></i></a> <?php if($row['brid']==$brid && $row['ftype']=='WH'){?>  
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
<?php } ?>     
<form action="inv_whotra.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delwtra" value="<?php echo $row['id']; ?>" />
</form>
</td>    
</tr>    
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<a href="inv_whtrcreate.php" class="btn btn-flat bg-purple">Create Transfer</a>
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'TRW','A');}else{echo read_activity($aid,'TRW','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>
    
</section>
<!-- /.main content -->
<?php include('../layout/print.php'); ?>    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
});
    
function take_action(id) {
document.getElementById(id).submit(); 
}
    
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});
}
    
$(".details-invoice").click(function (e) {
id_arr = $(this).attr('id');
id = id_arr.split("_");

$.ajax({
url: 'inv_viewwhlist.php',
method: "POST",
data:{ 
invid: id[1],cusid: id[2],type:id[3]
},
success: function(data){
$('#listitem').html(data);
pagelist();    
}
});    
    
$.ajax({
url: 'inv_viewwhtra.php',
method: "POST",
data:{ 
print: id[1]
},
success: function(data){
$('#invhold').html(data);
sethead();    
}
});
    
$('.right-side').toggle('slide', { direction: 'right' }, 300);    

e.preventDefault();
});

$(document).on('click', '#closepop', function() {
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }   
});    

$('#listitem').on('click','li', function(){
   $(this).addClass('active').siblings().removeClass('active');
});
    
$(document).on('click', '.invpiv', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
$.ajax({
url: 'inv_viewwhtra.php',
method: "POST",
data:{ 
print: ids
},
beforeSend: function() {
//$("#invhold").fadeOut('slow');
},    
success: function(data){    
$('#invhold').html(data);
$("#invhold").fadeIn('slow');    
sethead();    
}
});     
});   
</script>    
<!-- /page script -->
</html>    