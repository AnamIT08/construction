<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$_SESSION['cuPages']='sel_sinvlist.php';   
$cuPage='sel_sinvlist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
?>
<?php 
if(isset($_POST['invid'])){
$piid=$_POST['invid'];
$type=$_POST['type'];      
$cusid=$_POST['cusid'];
$sql="SELECT * FROM tbl_trafrbra WHERE ttype='$type' AND tsourch='$cusid' ORDER BY apdate DESC,id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$invno=$row['invno'];   
?>
<li <?php if($row['id']==$piid){echo 'class="invpiv active"';}else{echo 'class="invpiv"';}?> id="pi_<?php echo $row['id'].'_'.$row['ftype'];?>"><p><strong class="pino"><?php echo $row['invno'];?></strong><br><strong><?php echo date("d M Y", strtotime($row['apdate']));?></strong></p>
<div class="sname" style="margin-top: -52px;float: right; position: relative;top: 6px;"><strong>
<?php if($row['ftype']=='BR'){
if($row['fsourch']!=0){    
echo 'F: '.get_fild_data('tbl_branch',$row['fsourch'],'name');
}else{
echo 'F: '.'No Branch';    
}
}else{
echo 'F: '.get_fild_data('tbl_warehouse',$row['fsourch'],'name');
} ?>
</strong><br><strong>
<?php 
if($row['ttype']=='BR'){
if($row['tsourch']!=0){     
echo 'T: '.get_fild_data('tbl_branch',$row['tsourch'],'name');
}else{
echo 'T: '.'No Branch';    
}    
}else{
echo 'T: '.get_fild_data('tbl_warehouse',$row['tsourch'],'name');
} 
?></strong></div>
</li>
<?php }} ?>