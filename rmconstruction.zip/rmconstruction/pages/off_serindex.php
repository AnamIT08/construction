<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){   
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}

$output='';
$output.='<ul style="margin-top: 0;" class="pagination alphabets"><li><a data-id="" href="#"><b>ALL</b></a></li>';
$sql = "SELECT DISTINCT name FROM (SELECT UPPER(SUBSTRING(tbl_item.name,1,1)) AS name,(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0))+(SELECT COALESCE ((SELECT SUM(avqty) FROM tbl_brstock WHERE unqid=tbl_stock.unqid GROUP BY unqid),0)) AS avqty FROM tbl_stock LEFT JOIN tbl_item ON tbl_item.id=tbl_stock.pid ) ofitm WHERE avqty>0 ORDER BY name ASC";

$result = mysqli_query($con, $sql);
while ($row=mysqli_fetch_array($result)){
$output.='<li><a href="#" data-id="'.$row['name'].'"><b>'.$row['name'].'</b></a></li>';    
}
$output.='</ul>';
echo $output;
exit;