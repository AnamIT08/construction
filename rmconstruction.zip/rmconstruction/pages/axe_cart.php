<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}

if(isset($_POST['chexists'])){
$table=$_POST['chexists'];
$fild=$_POST['fild'];
$sval=$_POST['sval'];

$sql = "SELECT COUNT(*) AS rdata FROM ".$table." WHERE ".$fild."='".$sval."' LIMIT 1";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$row = mysqli_fetch_array($result);  
if($row['rdata']>0){
$redata=array('0','PI no alrady exists!');    
}else{
$redata=array('1','Valid PI no!');    
}    
echo json_encode($redata);    
}

if(isset($_POST['cldata'])){
if(isset($_SESSION['axes_pidata'])){
unset($_SESSION['axes_pidata']);    
}
if(isset($_SESSION['axes_piitem'])){
unset($_SESSION['axes_piitem']);    
}    
}

if(isset($_POST['emdata'])){
if(isset($_SESSION['axes_piitem'])){
unset($_SESSION['axes_piitem']);    
}    
}

if(isset($_POST['remove'])){
$id=floatval($_POST['remove']);
remove_piitem($id);    
$max=count($_SESSION['axes_piitem']);
if($max <= 0){
unset($_SESSION['axes_piitem']);    
}       
}

if(isset($_POST['upprice'])){
$id=$_POST['upprice'];
$price=remove_junk(escape($_POST['price']));    
if($price>0){
$_SESSION['axes_piitem'][$id]['price']=$price;
$qty=$_SESSION['axes_piitem'][$id]['qty'];
$percent = $_SESSION['axes_piitem'][$id]['cp'];
if ($percent>0){
$_SESSION['axes_piitem'][$id]['cfamo']=number_format((($percent/100)*$price),2);    
}
$fixed=$_SESSION['axes_piitem'][$id]['cfamo'];          
$_SESSION['axes_piitem'][$id]['subtot']=($price*$qty);
$_SESSION['axes_piitem'][$id]['tcamo']=($fixed*$qty);   
$redata=array($_SESSION['axes_piitem'][$id]['price'],$_SESSION['axes_piitem'][$id]['subtot'],$_SESSION['axes_piitem'][$id]['cfamo'],$_SESSION['axes_piitem'][$id]['tcamo']);    
}else{
$redata=array($_SESSION['axes_piitem'][$id]['price'],$_SESSION['axes_piitem'][$id]['subtot'],$_SESSION['axes_piitem'][$id]['cfamo'],$_SESSION['axes_piitem'][$id]['tcamo']);    
}    
echo json_encode($redata);    
}

if(isset($_POST['upqty'])){
$id=$_POST['upqty'];
$qty=remove_junk(escape($_POST['qty']));    
if($qty>0){
$_SESSION['axes_piitem'][$id]['qty']=$qty;
$price=$_SESSION['axes_piitem'][$id]['price'];
$fixed=$_SESSION['axes_piitem'][$id]['cfamo'];    
$_SESSION['axes_piitem'][$id]['subtot']=($price*$qty);
$_SESSION['axes_piitem'][$id]['tcamo']=($fixed*$qty);   
$redata=array($_SESSION['axes_piitem'][$id]['qty'],$_SESSION['axes_piitem'][$id]['subtot'],$_SESSION['axes_piitem'][$id]['tcamo']);    
}else{
$redata=array($_SESSION['axes_piitem'][$id]['qty'],$_SESSION['axes_piitem'][$id]['subtot'],$_SESSION['axes_piitem'][$id]['tcamo']);    
}    
echo json_encode($redata);    
}

if(isset($_POST['upfixed'])){
$id=$_POST['upfixed'];
$fixed=remove_junk(escape($_POST['cfixed']));    
if($fixed>0){
$_SESSION['axes_piitem'][$id]['cfamo']=$fixed;
$qty=$_SESSION['axes_piitem'][$id]['qty'];
$price=$_SESSION['axes_piitem'][$id]['price'];
$_SESSION['axes_piitem'][$id]['cp']=number_format((($fixed/$price)*100),2);    
$_SESSION['axes_piitem'][$id]['tcamo']=number_format(($fixed*$qty),2);   
$redata=array($_SESSION['axes_piitem'][$id]['cfamo'],$_SESSION['axes_piitem'][$id]['cp'],$_SESSION['axes_piitem'][$id]['tcamo']);    
}else{
$redata=array($_SESSION['axes_piitem'][$id]['cfamo'],$_SESSION['axes_piitem'][$id]['cp'],$_SESSION['axes_piitem'][$id]['tcamo']);    
}    
echo json_encode($redata);    
}

if(isset($_POST['uppercent'])){
$id=$_POST['uppercent'];
$percent=remove_junk(escape($_POST['percent']));    
if($percent>0){
$_SESSION['axes_piitem'][$id]['cp']=$percent;
$qty=$_SESSION['axes_piitem'][$id]['qty'];
$price=$_SESSION['axes_piitem'][$id]['price'];
$_SESSION['axes_piitem'][$id]['cfamo']=number_format((($percent/100)*$price),2); 
$fixed=$_SESSION['axes_piitem'][$id]['cfamo'];    
$_SESSION['axes_piitem'][$id]['tcamo']=number_format(($fixed*$qty),2);   
$redata=array($_SESSION['axes_piitem'][$id]['cfamo'],$_SESSION['axes_piitem'][$id]['cp'],$_SESSION['axes_piitem'][$id]['tcamo']);    
}else{
$redata=array($_SESSION['axes_piitem'][$id]['cfamo'],$_SESSION['axes_piitem'][$id]['cp'],$_SESSION['axes_piitem'][$id]['tcamo']);    
}    
echo json_encode($redata);    
}

if(isset($_POST['uppinv'])){
$inv=remove_junk(escape($_POST['uppinv']));
add_piinfo('pino',$inv);       
$redata=array($_SESSION['axes_pidata']['pino']);
	echo json_encode($redata);    
}

if(isset($_POST['apdate'])){
$inv=remove_junk(escape($_POST['apdate']));
if($inv!=''){
add_piinfo('date',$inv);    
}    
$redata=array($_SESSION['axes_pidata']['date']);
	echo json_encode($redata);    
}

if(isset($_POST['dldate'])){
$inv=remove_junk(escape($_POST['dldate']));
if($inv!=''){
add_piinfo('dldate',$inv);    
}    
$redata=array($_SESSION['axes_pidata']['dldate']);
	echo json_encode($redata);    
}

if(isset($_POST['dldays'])){
$inv=remove_junk(escape($_POST['dldays']));
if($inv!=''){
add_piinfo('dldays',$inv);    
}    
$redata=array($_SESSION['axes_pidata']['dldays']);
	echo json_encode($redata);    
}

if(isset($_POST['pofemb'])){
$inv=remove_junk(escape($_POST['pofemb']));
if($inv!=''){
add_piinfo('pofemb',$inv);    
}    
$redata=array($_SESSION['axes_pidata']['pofemb']);
	echo json_encode($redata);    
}

if(isset($_POST['pofdis'])){
$inv=remove_junk(escape($_POST['pofdis']));
if($inv!=''){
add_piinfo('pofdis',$inv);    
}    
$redata=array($_SESSION['axes_pidata']['pofdis']);
	echo json_encode($redata);    
}

if(isset($_POST['bfbank'])){
$inv=remove_junk(escape($_POST['bfbank']));
if($inv!=''){
add_piinfo('bfbank',$inv);    
}    
$redata=array($_SESSION['axes_pidata']['bfbank']);
	echo json_encode($redata);    
}

if(isset($_POST['bfac'])){
$inv=remove_junk(escape($_POST['bfac']));
if($inv!=''){
add_piinfo('bfac',$inv);    
}    
$redata=array($_SESSION['axes_pidata']['bfac']);
	echo json_encode($redata);    
}

if(isset($_POST['terms'])){
$inv=remove_junk(escape($_POST['terms']));
if($inv!=''){
add_piinfo('terms',$inv);    
}    
$redata=array($_SESSION['axes_pidata']['terms']);
	echo json_encode($redata);    
}

if(isset($_POST['upcurid'])){
$curid=remove_junk(escape($_POST['upcurid']));
if($curid!=''){
add_piinfo('curid',$curid);    
}       
}

if(isset($_POST['upcusid'])){
$cusid=remove_junk(escape($_POST['upcusid']));
if($cusid!=''){
add_piinfo('cusid',$cusid);    
}       
}

if(isset($_POST['upsupid'])){
$supid=remove_junk(escape($_POST['upsupid']));
if($supid!=''){
add_piinfo('supid',$supid);    
}       
}

if(isset($_POST['request'])){
$request = $_POST['request'];   // request
// Get product list
if($request == 1){
    $search = $_POST['search'];
    $sql = "SELECT tbl_item.id,tbl_item.code,tbl_item.name,tbl_color.name AS color FROM tbl_item LEFT JOIN tbl_color ON tbl_color.id=tbl_item.colid WHERE tbl_item.status='1' AND (tbl_item.name LIKE '%$search%' OR tbl_item.code LIKE '%$search%') LIMIT 10";
    $result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
    while($row = mysqli_fetch_array($result) ){
        $response[] = array("value"=>$row['id'],"label"=>$row['code'].' - '.$row['name'].' '.$row['color']);
    }

    // encoding array to json format
    echo json_encode($response);
    exit;
}

if($request == 2){
$proid = $_POST['proid'];
$qty=1;    
addtopi($proid,$qty);
echo json_encode($proid);
exit;
}
}

if(isset($_POST['getpi'])){
$request = $_POST['getpi'];   // request
if($request == 1){
    $search = $_POST['search'];
    $sql = "SELECT tbl_proinv.pino FROM tbl_proinv LEFT JOIN tbl_lcopen ON tbl_lcopen.pino!=tbl_proinv.pino WHERE tbl_proinv.pino LIKE '%$search%' LIMIT 10";
    $result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
    while($row = mysqli_fetch_array($result) ){
        $response[] = array("value"=>$row['pino'],"label"=>$row['pino']);
    }

    // encoding array to json format
    echo json_encode($response);
    exit;
}
}

if(isset($_POST['invpi'])){
$request = $_POST['invpi'];   // request
if($request == 1){
    $search = $_POST['search'];
    $sql = "SELECT tbl_proinv.id,tbl_lcopen.pino FROM tbl_lcopen LEFT JOIN tbl_invoice ON tbl_invoice.pino!=tbl_lcopen.pino LEFT JOIN tbl_proinv ON tbl_proinv.pino=tbl_lcopen.pino WHERE tbl_lcopen.pino LIKE '%$search%' LIMIT 10";
    $result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
    while($row = mysqli_fetch_array($result) ){
        $response[] = array("value"=>$row['id'],"label"=>$row['pino']);
    }

    // encoding array to json format
    echo json_encode($response);
    exit;
}
}

if(isset($_POST['upinv'])){
$inv=remove_junk(escape($_POST['upinv']));
add_invinfo('invno',$inv);      
$redata=array($_SESSION['axes_invdata']['invno']);
	echo json_encode($redata);    
}

if(isset($_POST['iapdate'])){
$inv=remove_junk(escape($_POST['iapdate']));
if($inv!=''){
add_invinfo('date',$inv);    
}    
$redata=array($_SESSION['axes_invdata']['date']);
	echo json_encode($redata);    
}

if(isset($_POST['iemdata'])){
if(isset($_SESSION['axes_invitem'])){
unset($_SESSION['axes_invitem']);    
}    
}

if(isset($_POST['iremove'])){
$id=floatval($_POST['iremove']);
remove_invitem($id);    
$max=count($_SESSION['axes_invitem']);
if($max <= 0){
unset($_SESSION['axes_invitem']);    
}       
}


if(isset($_POST['invclear'])){
if(isset($_SESSION['axes_invdata'])){
unset($_SESSION['axes_invdata']);    
}
if(isset($_SESSION['axes_invitem'])){
unset($_SESSION['axes_invitem']);    
}    
}

if(isset($_POST['pinfo'])){
$pid=$_POST['pinfo'];
$pino=strtoupper(remove_junk($_POST['pino']));   
$sql="SELECT * FROM tbl_proinvde WHERE seid='$pid' ORDER BY id ASC";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));

if(isset($_SESSION['axes_invdata'])){
unset($_SESSION['axes_invdata']);    
}    
if(isset($_SESSION['axes_invitem'])){
unset($_SESSION['axes_invitem']);    
}
    
while($row = mysqli_fetch_array($result)){
$id=$row['id'];
$itemid=$row['itemid'];
$qty = ($row['qty']-$row['rcvqty']);
$price = $row['price'];
$camo = $row['cfamo'];    
addtoinv($id,$itemid,$qty,$price,$camo);    
}
add_invinfo('pino',$pino);
$sql="SELECT * FROM tbl_proinv WHERE id='$pid' ORDER BY id ASC LIMIT 1";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$rop = mysqli_fetch_array($result);
add_invinfo('curid',$rop['curid']);
add_invinfo('cusid',$rop['cusid']);
add_invinfo('supid',$rop['supid']);    
$redata=array($rop['curid'],$rop['cusid'],$rop['supid']);  
echo json_encode($redata);    
}

if(isset($_POST['upiqty'])){
$id=$_POST['upiqty'];
$qty=remove_junk(escape($_POST['qty']));    
if($qty>0){
$_SESSION['axes_invitem'][$id]['qty']=$qty;
$price=$_SESSION['axes_invitem'][$id]['price'];
$fixed=$_SESSION['axes_invitem'][$id]['cfamo'];    
$_SESSION['axes_invitem'][$id]['subtot']=($price*$qty);
$_SESSION['axes_invitem'][$id]['tcamo']=($fixed*$qty);   
$redata=array($_SESSION['axes_invitem'][$id]['qty'],$_SESSION['axes_invitem'][$id]['subtot'],$_SESSION['axes_invitem'][$id]['tcamo']);    
}else{
$redata=array($_SESSION['axes_invitem'][$id]['qty'],$_SESSION['axes_invitem'][$id]['subtot'],$_SESSION['axes_invitem'][$id]['tcamo']);    
}    
echo json_encode($redata);    
}

if(isset($_POST['getdpi'])){
$request = $_POST['getdpi'];   // request
if($request == 1){
    $search = $_POST['search'];
    $sql = "SELECT tbl_invoice.invno,tbl_invoice.pino FROM tbl_invoice LEFT JOIN tbl_delivery ON tbl_delivery.invno!=tbl_invoice.invno WHERE tbl_invoice.invno LIKE '%$search%' LIMIT 10";
    $result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
    while($row = mysqli_fetch_array($result) ){
        $response[] = array("value"=>$row['pino'],"label"=>$row['invno']);
    }

    // encoding array to json format
    echo json_encode($response);
    exit;
}
}

if(isset($_POST['expid'])){
$cid = $_POST['cid'];
$cty = $_POST['cty'];
$expid = $_POST['expid'];
$ref = remove_junk(escape($_POST['ref']));
$amo = floatval($_POST['amount']);
$mtype = remove_junk(escape($_POST['mtype']));
addtoexp($cid,$cty,$expid,$amo,$ref,$mtype);
}

if(isset($_POST['expdate'])){
$inv=remove_junk(escape($_POST['expdate']));
if($inv!=''){
add_expinfo('date',$inv);    
}    
$redata=array($_SESSION['axes_expdata']['date']);
	echo json_encode($redata);    
}

if(isset($_POST['expnote'])){
$inv=ucwords(remove_junk(escape($_POST['expnote'])));
add_expinfo('note',$inv);        
$redata=array($_SESSION['axes_expdata']['note']);
	echo json_encode($redata);    
}

if(isset($_POST['expdata'])){
if(isset($_SESSION['axes_expitem'])){
unset($_SESSION['axes_expitem']);    
}    
}

if(isset($_POST['expremove'])){
$id=floatval($_POST['expremove']);
remove_expitem($id);    
$max=count($_SESSION['axes_expitem']);
if($max <= 0){
unset($_SESSION['axes_expitem']);    
}       
}


if(isset($_POST['expclear'])){
if(isset($_SESSION['axes_expdata'])){
unset($_SESSION['axes_expdata']);    
}
if(isset($_SESSION['axes_expitem'])){
unset($_SESSION['axes_expitem']);    
}    
}

if(isset($_POST['getledger'])){
$dsgrid=intval($_POST['dsgrid']);
$dty = get_ledgertype($dsgrid);    
$did=intval($_POST['did']);    
$amo=floatval($_POST['amo']);    
$cid=intval($_POST['cid']);
$csgrid=intval($_POST['csgrid']);    
$cty = get_ledgertype($csgrid);    
$chkno=strtoupper($_POST['chkno']);
$chkdt=$_POST['chkdt'];
$ref=$_POST['ref'];
addtojou($dsgrid,$dty,$did,$amo,$cid,$cty,$csgrid,$chkno,$chkdt,$ref);      
}

if(isset($_POST['jounote'])){
$inv=ucwords(remove_junk(escape($_POST['jounote'])));
add_jouinfo('note',$inv);        
$redata=array($_SESSION['axes_joudata']['note']);
	echo json_encode($redata);    
}

if(isset($_POST['joudate'])){
$inv=remove_junk(escape($_POST['joudate']));
if($inv!=''){
add_jouinfo('date',$inv);    
}    
$redata=array($_SESSION['axes_joudata']['date']);
	echo json_encode($redata);    
}

if(isset($_POST['joudata'])){
if(isset($_SESSION['axes_jouitem'])){
unset($_SESSION['axes_jouitem']);    
}    
}

if(isset($_POST['jouremove'])){
$id=floatval($_POST['jouremove']);
remove_jouitem($id);    
$max=count($_SESSION['axes_jouitem']);
if($max <= 0){
unset($_SESSION['axes_jouitem']);    
}       
}


if(isset($_POST['jouclear'])){
if(isset($_SESSION['axes_joudata'])){
unset($_SESSION['axes_joudata']);    
}
if(isset($_SESSION['axes_jouitem'])){
unset($_SESSION['axes_jouitem']);    
}    
}

if(isset($_POST['getpayment'])){
$dty = $_POST['dty'];    
$did=intval($_POST['did']);    
$amo=floatval($_POST['amo']);    
$cid=intval($_POST['cid']);   
$cty = $_POST['cty'];    
$chkno=strtoupper($_POST['chkno']);
$chkdt=$_POST['chkdt'];
$ref=$_POST['ref'];
$mtype=$_POST['mtype'];    
addtopay($dty,$did,$amo,$cid,$cty,$chkno,$chkdt,$ref,$mtype);   
}

if(isset($_POST['paynote'])){
$inv=ucwords(remove_junk(escape($_POST['paynote'])));
add_payinfo('note',$inv);        
$redata=array($_SESSION['axes_paydata']['note']);
	echo json_encode($redata);    
}

if(isset($_POST['paydate'])){
$inv=remove_junk(escape($_POST['paydate']));
if($inv!=''){
add_payinfo('date',$inv);    
}    
$redata=array($_SESSION['axes_paydata']['date']);
	echo json_encode($redata);    
}

if(isset($_POST['paydata'])){
if(isset($_SESSION['axes_payitem'])){
unset($_SESSION['axes_payitem']);    
}    
}

if(isset($_POST['payremove'])){
$id=floatval($_POST['payremove']);
remove_payitem($id);    
$max=count($_SESSION['axes_payitem']);
if($max <= 0){
unset($_SESSION['axes_payitem']);    
}       
}


if(isset($_POST['payclear'])){
if(isset($_SESSION['axes_paydata'])){
unset($_SESSION['axes_paydata']);    
}
if(isset($_SESSION['axes_payitem'])){
unset($_SESSION['axes_payitem']);    
}    
}

if(isset($_POST['getreceived'])){
$dty = $_POST['dty'];    
$did=intval($_POST['did']);    
$amo=floatval($_POST['amo']);    
$cid=intval($_POST['cid']);   
$cty = $_POST['cty'];    
$chkno=strtoupper($_POST['chkno']);
$chkdt=$_POST['chkdt'];
$ref=$_POST['ref'];
$mtype=$_POST['mtype'];    
$refinv=$_POST['refinv'];
$xrate=$_POST['xrate'];    
addtorec($dty,$did,$amo,$cid,$cty,$chkno,$chkdt,$ref,$mtype,$refinv,$xrate);   
}

if(isset($_POST['recnote'])){
$inv=ucwords(remove_junk(escape($_POST['recnote'])));
add_recinfo('note',$inv);        
$redata=array($_SESSION['axes_recdata']['note']);
	echo json_encode($redata);    
}

if(isset($_POST['recdate'])){
$inv=remove_junk(escape($_POST['recdate']));
if($inv!=''){
add_recinfo('date',$inv);    
}    
$redata=array($_SESSION['axes_recdata']['date']);
	echo json_encode($redata);    
}

if(isset($_POST['recdata'])){
if(isset($_SESSION['axes_recitem'])){
unset($_SESSION['axes_recitem']);    
}    
}

if(isset($_POST['recremove'])){
$id=floatval($_POST['recremove']);
remove_recitem($id);    
$max=count($_SESSION['axes_recitem']);
if($max <= 0){
unset($_SESSION['axes_recitem']);    
}       
}


if(isset($_POST['recclear'])){
if(isset($_SESSION['axes_recdata'])){
unset($_SESSION['axes_recdata']);    
}
if(isset($_SESSION['axes_recitem'])){
unset($_SESSION['axes_recitem']);    
}    
}

if(isset($_POST['gettransaction'])){
$dty = $_POST['dty'];    
$did=intval($_POST['did']);    
$amo=floatval($_POST['amo']);    
$cid=intval($_POST['cid']);   
$cty = $_POST['cty'];    
$chkno=strtoupper($_POST['chkno']);
$chkdt=$_POST['chkdt'];
$ref=$_POST['ref'];
addtotra($dty,$did,$amo,$cid,$cty,$chkno,$chkdt,$ref);   
}

if(isset($_POST['tranote'])){
$inv=ucwords(remove_junk(escape($_POST['tranote'])));
add_payinfo('note',$inv);        
$redata=array($_SESSION['axes_tradata']['note']);
	echo json_encode($redata);    
}

if(isset($_POST['tradate'])){
$inv=remove_junk(escape($_POST['tradate']));
if($inv!=''){
add_trainfo('date',$inv);    
}    
$redata=array($_SESSION['axes_tradata']['date']);
	echo json_encode($redata);    
}

if(isset($_POST['tradata'])){
if(isset($_SESSION['axes_traitem'])){
unset($_SESSION['axes_traitem']);    
}    
}

if(isset($_POST['traremove'])){
$id=floatval($_POST['traremove']);
remove_traitem($id);    
$max=count($_SESSION['axes_traitem']);
if($max <= 0){
unset($_SESSION['axes_traitem']);    
}       
}


if(isset($_POST['traclear'])){
if(isset($_SESSION['axes_tradata'])){
unset($_SESSION['axes_tradata']);    
}
if(isset($_SESSION['axes_traitem'])){
unset($_SESSION['axes_traitem']);    
}    
}

if(isset($_POST['getbalance'])){
if(strlen($_POST['getbalance'])>0){    
$id=str_replace('_','',$_POST['getbalance']);
$ldebit=get_ledgerval($id,'D','N');
$lcredit=get_ledgerval($id,'C','N');
$lnet=($ldebit-$lcredit);
echo number_format($lnet,2);
}else{
echo '0.00';    
}    
}

if(isset($_POST['invre'])){
$request = $_POST['invre'];   // request
if($request == 1){
$search = $_POST['search'];
$sql = "SELECT * FROM (SELECT invno,sup.supid,totcom,curid,cur.symbol,ROUND((IFNULL(tra.cash,0)),2) AS cash,(totcom-ROUND((IFNULL(tra.cash,0)),2)) AS due FROM (SELECT invno,pino,totcom,curid FROM tbl_invoice WHERE invno LIKE '%$search%') inv LEFT JOIN (SELECT refinv,SUM(IF(xrate=0,amo,amo/xrate)) AS cash FROM tbl_trarecord WHERE (dty='LE' AND did='2') OR (dty='BA')  GROUP BY refinv) tra On tra.refinv=inv.invno LEFT JOIN (SELECT pino,supid FROM tbl_proinv) sup ON sup.pino=inv.pino LEFT JOIN (SELECT id,symbol FROM tbl_currency) cur ON cur.id=inv.curid) resu WHERE due>0 LIMIT 10";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
while($row = mysqli_fetch_array($result) ){
$response[] = array("value"=>$row['invno'],"label"=>$row['invno'],"info"=>$row['supid'].'_'.$row['symbol'].'_'.$row['due']);
}

// encoding array to json format
echo json_encode($response);
exit;
}
}

if(isset($_POST['checkbales'])){
if(strlen($_POST['checkbales'])>0){
$type=substr($_POST['checkbales'],0,2);    
$id=str_replace('_','',$_POST['checkbales']);
if($type=='LE'){    
$ldebit=get_ledgerval($id,'D','N','','',$brid);
$lcredit=get_ledgerval($id,'C','N','','',$brid);
}else{
$ldebit=get_ledgerval($id,'D','N');
$lcredit=get_ledgerval($id,'C','N');    
}
$lnet=($ldebit-$lcredit);
echo number_format($lnet,2);
}else{
echo '0.00';    
}    
}

if(isset($_POST['checkbal'])){
if(strlen($_POST['checkbal'])>0){    
$id=str_replace('_','',$_POST['checkbal']);
$ldebit=get_ledgerval($id,'D','N');
$lcredit=get_ledgerval($id,'C','N');
$lnet=($ldebit-$lcredit);
echo number_format($lnet,2);
}else{
echo '0.00';    
}    
}

if(isset($_POST['glsearch'])){
if(isset($_POST['search']) && strlen($_POST['search'])>=3){
$gserach = strtoupper($_POST['search']);    
$type=substr($gserach,0,3);
if($type=='PUR'){
$sql="SELECT * FROM tbl_purchase LEFT JOIN tbl_supplier ON tbl_supplier.id=tbl_purchase.supid WHERE invno LIKE '%$gserach%' LIMIT 30";    
}elseif($type=='SEL'){
$sql="SELECT * FROM tbl_sales WHERE invno LIKE '%$gserach%' LIMIT 30";     
}else{
$sql="SELECT invno,name FROM (SELECT tbl_serial.purinv AS invno,tbl_supplier.name,tbl_serial.serial FROM tbl_serial LEFT JOIN tbl_purchase ON tbl_purchase.invno=tbl_serial.purinv LEFT JOIN tbl_supplier ON tbl_supplier.id=tbl_purchase.supid WHERE rci='Y' UNION ALL SELECT tbl_serialsale.invno,tbl_sales.name,tbl_serialsale.serial FROM tbl_serialsale LEFT JOIN tbl_sales ON tbl_sales.invno=tbl_serialsale.invno WHERE mods='S' AND dli='Y') AS serial WHERE serial LIKE '%$gserach%' LIMIT 30" ;   
}
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
while($row = mysqli_fetch_array($result) ){
$response[] = array("value"=>$row['invno'],"label"=>$row['invno'].' - '.$row['name']);
}    
}else{    
$response[] = array('');    
}
echo json_encode($response);
exit;    
}