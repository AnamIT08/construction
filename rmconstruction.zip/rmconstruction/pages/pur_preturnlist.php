<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='pur_preturnlist.php';   
$cuPage='pur_preturnlist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='purchase';
$menuh='Purchase';
$phead='prelist';
$page='Purchase Return';
$print='print';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
?>
<?php

if(isset($_POST['tfdate'])){
$fdate=$_POST['tfdate'];	
}else{
$fdate=date('Y-m-d', strtotime('-15 days', time()));	
}
if(isset($_POST['ttdate'])){
$tdate=$_POST['ttdate'];	
}else{
$tdate=$today;	
}

function check_purretdel($invno){
$flage=0;
global $con;

$sql="SELECT * FROM tbl_trarecord WHERE invno!='$invno' AND refinv='$invno'";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
$flage=1;    
}else{
$flage=0;    
}

if($flage>0){
return $flage;
exit;    
}        
}

if(isset($_POST['delpret'])){
$id=$_POST['delpret'];

$sql="SELECT * FROM tbl_preturn WHERE id='$id' LIMIT 1";
$dreturn=mysqli_query($con,$sql) or die(mysqli_error($con));    
$dret=mysqli_fetch_array($dreturn);    

$invno=$dret['invno'];
$refinv=$dret['refinv'];    

if(check_purretdel($invno)){
save_msg('w','Purchase Return Depend on others data!!!');
echo "<script>window.location='pur_preturnlist.php'</script>";
return;    
}    
    
$sql="SELECT * FROM tbl_serial WHERE reinvno='$invno'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query->num_rows > 0) {
while ($row=mysqli_fetch_array($query)){
$serial=$row['serial'];    
$sql="UPDATE tbl_serial SET reinvno=NULL,status='0' WHERE reinvno='$invno' AND serial='$serial'";
mysqli_query($con,$sql)or die(mysqli_error($con));    
}    
}
    
$sql="DELETE FROM tbl_trarecord WHERE invno='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));
    
$sql="DELETE FROM tbl_traproduct WHERE invno='$invno'";
mysqli_query($con,$sql)or die(mysqli_error($con));    

$sql="DELETE FROM tbl_preturn WHERE id='$id'";
$fdel=mysqli_query($con,$sql)or die(mysqli_error($con));    
$efid=mysqli_affected_rows($con);
if($efid>0){
$act =remove_junk(escape('Return invoice: '.$invno));    
write_activity($aid,'PRE','Return has been deleted',$act);        
save_msg('s','Return Successfully Deleted!!!');
}else{
save_msg('s','Return Fail to Delete!!!');    
}
echo "<script>window.location='pur_preturnlist.php'</script>";
}
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-9">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Return Record</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px; text-align:center;">SN</th>   
<th>Date</th>
<th>Vendor</th>
<th>Invoice</th>
<th>Against</th>    
<th>Total</th>
<!--<th>Adjust</th>    
<th>Paid</th>-->
<th>Note</th>     
<th style="width:40px; text-align:center;">Action</th>    
</tr>
</thead>    
<tbody>
<?php
$sql="SELECT * FROM tbl_preturn WHERE apdate BETWEEN '$fdate' AND '$tdate' AND brid='$brid' ORDER BY apdate DESC,id DESC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$invno=$row['invno'];    
?>
<tr>
<td class="text-center"><?php echo count_id();?></td>
<td><?php echo date("d M Y", strtotime($row['apdate']));?></td>      
<td><?php if($row['type']=='SU'){echo get_fild_data('tbl_supplier',$row['cusid'],'name');}else{
if($row['cusid']==0){
if($row['name']!=''){
echo $row['name'];    
}else{
echo 'Local Market';    
}        
}else{
echo get_fild_data('tbl_customer',$row['cusid'],'name');    
}}?>
</td>
<td><?php echo $row['invno'];?></td>
<td><?php echo $row['refinv'];?></td>    
<td><?php echo numtolocal(($row['total']+$row['adjust']),get_fild_data('tbl_currency','1','symbol'));?></td>
<!--<td style="text-align:right;"><?php //echo numtolocal($row['adjust'],get_fild_data('tbl_currency','1','symbol'));?></td>
<td style="text-align:right;"><?php //echo numtolocal(($row['total']),get_fild_data('tbl_currency','1','symbol'));?></td>-->
<td><?php echo $row['note'];?></td>    
<td nowrap="">
<a class="btn btn-flat bg-purple details-invoice" href="#" id="inv_<?php echo $row['id'].'_'.$row['cusid'].'_'.$row['type']; ?>"><i class="fa fa-eye cat-child"></i></a>        
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
<form action="pur_preturnlist.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delpret" value="<?php echo $row['id']; ?>" />
</form>
</td>    
</tr>    
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right">
<a href="pur_preturncteate.php" class="btn btn-flat bg-purple">Create Return</a>
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<!-- tools box -->
<div class="pull-right box-tools">
<a class=" pull-right" data-widget="collapse" style="margin-right: 5px;">
<i class="fa fa-minus"></i></a>
</div>
<!-- /. tools -->
<i class="fa fa-filter" aria-hidden="true"></i>    
<h3 class="box-title">Date Range Filter</h3>
</div>
<!-- /.box-header -->
<div class="box-body" >

<form action="#" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">    
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">    

<div class="row">
<div class="col-md-6">
<div class="form-group">
<label>Date From</label>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
<input type="text" name="tfdate" value="<?php if(isset($_POST['tfdate'])){echo $_POST['tfdate']; }else{echo date('Y-m-d', strtotime('-15 days', time()));} ?>"  class="form-control" placeholder="Date From" readonly="true">
</div>
</div>        
</div>
<div class="col-md-6">
<div class="form-group" >
<label>Date To</label>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
<input type="text" name="ttdate" value="<?php if(isset($_POST['ttdate'])){echo $_POST['ttdate']; }else{echo $today;} ?>"  class="form-control" placeholder="Date To" readonly="true">
</div>    
</div>    
</div>    
</div>     
    
</div>   
<div class="col-md-1"></div>    
</div>    
</div>    
</div>
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="date_filter" id="submit" class="btn btn-flat bg-purple btn-sm " value="Submit"/>
</div> 
</div>     
</form>    
    
</div>
</div>
</div>

</div>    
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'PRE','A');}else{echo read_activity($aid,'PRE','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>        

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->
<?php include('../layout/print.php'); ?>     
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable({stateSave: true});
});
    
function take_action(id) {
document.getElementById(id).submit(); 
}
    
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});
}
    
$(".details-invoice").click(function (e) {
id_arr = $(this).attr('id');
id = id_arr.split("_");

$.ajax({
url: 'pur_viewretlist.php',
method: "POST",
data:{ 
invid: id[1],cusid: id[2],type:id[3]
},
success: function(data){
$('#listitem').html(data);
pagelist();    
}
});    
    
$.ajax({
url: 'pur_viewreinv.php',
method: "POST",
data:{ 
print: id[1]
},
success: function(data){
$('#invhold').html(data);
sethead();    
}
});
    
$('.right-side').toggle('slide', { direction: 'right' }, 300);    

e.preventDefault();
});

$(document).on('click', '#closepop', function() {
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }   
});    

$('#listitem').on('click','li', function(){
   $(this).addClass('active').siblings().removeClass('active');
});
    
$(document).on('click', '.invpiv', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
$.ajax({
url: 'pur_viewreinv.php',
method: "POST",
data:{ 
print: ids
},
beforeSend: function() {
//$("#invhold").fadeOut('slow');
},    
success: function(data){    
$('#invhold').html(data);
$("#invhold").fadeIn('slow');    
sethead();    
}
});     
});   
</script>    
<!-- /page script -->
</html>    