<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
$body='';
$foot='';
$s=0;
$totamo=0;
if(isset($_SESSION['axes_expitem'])){
if(is_array($_SESSION['axes_expitem'])){
$max=count($_SESSION['axes_expitem']);
for($i=($max-1);$i>=0;$i=$i-1){
$expid=$_SESSION['axes_expitem'][$i]['expid'];
$name=get_fild_data('tbl_acledger',$expid,'name');    
$amount=$_SESSION['axes_expitem'][$i]['amount'];
$ref=$_SESSION['axes_expitem'][$i]['ref'];
$mtype=$_SESSION['axes_expitem'][$i]['mtype'];
if($mtype=='1'){
$etype='Civil Work';    
}elseif($mtype=='2'){
$etype='Power Work';    
}else{
$etype='';    
}    
$s+=1;
$body.='<tr>';
$body.='<td style="text-align:center">'.$s.'</td>';
$body.='<td>'.$name.'</td>';
$body.='<td>'.$etype.'</td>';    
$body.='<th class="text-right">'.number_format($amount,2).'</th>';
$body.='<td>'.$ref.'</td>';
$body.='<td style="text-align:center"><a id="'.$i.'" class="remove"><span style="cursor: pointer;" class="fa fa-times"></span></a></td>';    
$body.='</tr>';     
}
$foot.='<tr>';
$foot.='<th colspan="3" class="text-right">TOTAL</th>';
$foot.='<th class="text-right">'.number_format(total_expvalue(),2).'</th>';    
$foot.='<th colspan="2"></th>';    
$foot.='</tr>';    
}else{
$body.='<tr>';
$body.='<td colspan="5" class="text-center">There are no items in your expenses list!</td>';
$body.='</tr>'; 
} 
}else{
$body.='<tr>';
$body.='<td colspan="5" class="text-center">There are no items in your expenses list!</td>';
$body.='</tr>';
}
            
if(isset($_POST['body'])){
echo $body;
}elseif(isset($_POST['foot'])){
echo $foot;	
}
exit;    
?>    