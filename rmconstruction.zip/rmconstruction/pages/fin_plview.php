<?php 

session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/repfunctions.php');
$today = strftime("%Y-%m-%d", time());

if(isset($_POST['tfdate'])){	
$fdate=$_POST['tfdate'];	
}else{
$fdate=date('Y-m-d', strtotime('-29 days', time()));	
}
if(isset($_POST['ttdate'])){
$tdate=$_POST['ttdate'];	
}else{
$tdate=$today;	
}

?>
<div class="col-md-12">
<div class="row">
<div class="col-md-6 text-left">
<h4>FROM: <?php echo date("d-M-Y", strtotime($fdate));?></h4>    
</div>
<div class="col-md-6 text-right">
<h4>To: <?php echo date("d-M-Y", strtotime($tdate));?></h4>    
</div>
</div>
</div>
<div class="clearfix" ></div>
<!-- REVENUE --> 
<table class="table table-bordered   table-hover">
<tbody>
<tr>
<td width="50%" class="bg-gray"><b>REVENUE</b></td>
<td width="16.16%" class="bg-gray"><b>Opening</b></td>
<td width="16.16%" class="bg-gray"><b>During Time</b></td>
<td width="16.16%" class="bg-gray"><b>Closing</b></td>    
</tr>
<?php     
$sql="SELECT DISTINCT grid,groups FROM tbl_ledger WHERE clsid='5' ORDER BY grid ASC";
$result=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowg=mysqli_fetch_array($result)){
$gopval=(get_goupval($rowg['grid'],'C','O','G',$fdate)-get_goupval($rowg['grid'],'D','O','G',$fdate));
$gdebit=get_goupval($rowg['grid'],'D','D','G',$fdate,$tdate);
$gcredit=get_goupval($rowg['grid'],'C','D','G',$fdate,$tdate);
$gnet=($gcredit-$gdebit);
$gcval=($gopval+$gnet);    
?>
<?php if(ABS($gcval)>0){?>     
<tr>
<td ><b><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;<?php echo $rowg['groups'];?></b></td>
<td></td>
<td></td>
<td></td>    
</tr>
<?php } ?>    
<?php     
$sql="SELECT DISTINCT sgrid,sgroup FROM tbl_ledger WHERE clsid='5' AND grid='".$rowg['grid']."' ORDER BY sgrid ASC";
$results=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowsg=mysqli_fetch_array($results)){
$sopval=(get_goupval($rowsg['sgrid'],'C','O','S',$fdate)-get_goupval($rowsg['sgrid'],'D','O','S',$fdate));
$sdebit=get_goupval($rowsg['sgrid'],'D','D','S',$fdate,$tdate);
$scredit=get_goupval($rowsg['sgrid'],'C','D','S',$fdate,$tdate);
$snet=($scredit-$sdebit);
$scval=($sopval+$snet);     
?>
<?php if(ABS($scval)>0){?>     
<tr>
<td style="padding-left: 15px;"><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;<?php echo $rowsg['sgroup'];?></td>
<td></td>
<td></td>
<td></td>    
</tr>
<?php } ?>   
<?php     
$sql="SELECT id,code,ledger FROM tbl_ledger WHERE clsid='5' AND sgrid='".$rowsg['sgrid']."' ORDER BY id ASC";
$resultl=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowl=mysqli_fetch_array($resultl)){
$lopval=(get_ledgerval($rowl['id'],'C','O',$fdate)-get_ledgerval($rowl['id'],'D','O',$fdate));
$ldebit=get_ledgerval($rowl['id'],'D','D',$fdate,$tdate);
$lcredit=get_ledgerval($rowl['id'],'C','D',$fdate,$tdate);
$lnet=($lcredit-$ldebit);
$lcval=($lopval+$lnet);    
?>
<?php if(ABS($lcval)>0){?>    
<tr>
<td style="padding-left:30px;"><?php echo $rowl['code'];?>: <?php echo $rowl['ledger'];?></td>
<td class="text-right"><?php echo number_format($lopval,2);?></td>
<td class="text-right"><?php echo number_format($lnet,2);?></td>
<td class="text-right"><?php echo number_format($lcval,2);?></td>    
</tr>
<?php } ?>   
<?php }} ?>
<?php if(ABS($gcval)>0){?>     
<tr>
<td style="text-align: right;padding-right:20px;"><strong>Total <?php echo $rowg['groups'];?></strong></td>
<td style="text-align: right; border-top: 1px double #000000;"><b><?php echo number_format(ABS($gopval),2);?></b>
</td>
<td style="text-align: right; border-top: 1px double #000000;"><b><?php echo number_format(ABS($gnet),2);?></b>
</td>
<td style="text-align: right; border-top: 1px double #000000;"><b><?php echo number_format(ABS($gcval),2);?></b>
</td>    
</tr>
<?php } ?>    
<?php } ?>
<?php 
$rcopval=(get_goupval('5','C','O','C',$fdate)-get_goupval('5','D','O','C',$fdate));
$rcdebit=get_goupval('5','D','D','C',$fdate,$tdate);
$rccredit=get_goupval('5','C','D','C',$fdate,$tdate);
$rcnet=($rccredit-$rcdebit);
$rccval=($rcopval+$rcnet);    
?>
<?php if(ABS($rccval)>0){?>    
<tr style="border-bottom:none;border-top:none;">
    <td colspan="4"></td>
</tr>     
<tr>    
<td ><b>&nbsp;Total Revenue</b></td>
<td style="text-align: right; border-top: 1px double #000000; border-bottom: 4px double #000000;"><b><?php echo number_format($rcopval,2);?></b></td>
<td style="text-align: right; border-top: 1px double #000000; border-bottom: 4px double #000000;"><b><?php echo number_format($rcnet,2);?></b></td>
<td style="text-align: right; border-top: 1px double #000000; border-bottom: 4px double #000000;"><b><?php echo number_format($rccval,2);?></b></td>    
</tr>
<?php } ?>
</tbody>    
</table>
<!--/REVENUE-->
<!--EXPENSES-->
<table class="table table-bordered   table-hover">
<tbody>
<tr>
<td width="50%" class="bg-gray"><b>EXPENSES</b></td>
<td width="16.16%" class="bg-gray"><b>Opening</b></td>
<td width="16.16%" class="bg-gray"><b>During Time</b></td>
<td width="16.16%" class="bg-gray"><b>Closing</b></td>    
</tr>
<?php     
$sql="SELECT DISTINCT grid,groups FROM tbl_ledger WHERE clsid='4' ORDER BY grid ASC";
$result=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowg=mysqli_fetch_array($result)){
$gopval=(get_goupval($rowg['grid'],'D','O','G',$fdate)-get_goupval($rowg['grid'],'C','O','G',$fdate));
$gdebit=get_goupval($rowg['grid'],'D','D','G',$fdate,$tdate);
$gcredit=get_goupval($rowg['grid'],'C','D','G',$fdate,$tdate);
$gnet=($gdebit-$gcredit);
$gcval=($gopval+$gnet);    
?>
<?php if(ABS($gcval)>0){?>    
<tr>
<td ><b><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;<?php echo $rowg['groups'];?></b></td>
<td></td>
<td></td>
<td></td>    
</tr>
<?php } ?>   
<?php     
$sql="SELECT DISTINCT sgrid,sgroup FROM tbl_ledger WHERE clsid='4' AND grid='".$rowg['grid']."' ORDER BY sgrid ASC";
$results=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowsg=mysqli_fetch_array($results)){
$sopval=(get_goupval($rowsg['sgrid'],'D','O','S',$fdate)-get_goupval($rowsg['sgrid'],'C','O','S',$fdate));
$sdebit=get_goupval($rowsg['sgrid'],'D','D','S',$fdate,$tdate);
$scredit=get_goupval($rowsg['sgrid'],'C','D','S',$fdate,$tdate);
$snet=($sdebit-$scredit);
$scval=($sopval+$snet);    
?>
<?php if(ABS($scval)>0){?>     
<tr>
<td style="padding-left: 15px;"><i class="fa fa-caret-right" aria-hidden="true"></i>&nbsp;<?php echo $rowsg['sgroup'];?></td>
<td></td>
<td></td>
<td></td>    
</tr>
<?php } ?>   
<?php     
$sql="SELECT id,code,ledger FROM tbl_ledger WHERE clsid='4' AND sgrid='".$rowsg['sgrid']."' ORDER BY id ASC";
$resultl=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowl=mysqli_fetch_array($resultl)){
$lopval=(get_ledgerval($rowl['id'],'D','O',$fdate)-get_ledgerval($rowl['id'],'C','O',$fdate));
$ldebit=get_ledgerval($rowl['id'],'D','D',$fdate,$tdate);
$lcredit=get_ledgerval($rowl['id'],'C','D',$fdate,$tdate);
$lnet=($ldebit-$lcredit);
$lcval=($lopval+$lnet);    
?>
<?php if(ABS($lcval)>0){?>    
<tr>
<td style="padding-left:30px;"><?php echo $rowl['code'];?>: <?php echo $rowl['ledger'];?></td>
<td class="text-right"><?php echo number_format($lopval,2);?></td>
<td class="text-right"><?php echo number_format($lnet,2);?></td>
<td class="text-right"><?php echo number_format($lcval,2);?></td>    
</tr> 
<?php } ?>   
<?php }} ?>
<?php if(ABS($gcval)>0){?>    
<tr>
<td style="text-align: right;padding-right:20px;"><strong>Total <?php echo $rowg['groups'];?></strong></td>
<td style="text-align: right; border-top: 1px double #000000;"><b><?php echo number_format(ABS($gopval),2);?></b>
</td>
<td style="text-align: right; border-top: 1px double #000000;"><b><?php echo number_format(ABS($gnet),2);?></b>
</td>
<td style="text-align: right; border-top: 1px double #000000;"><b><?php echo number_format(ABS($gcval),2);?></b>
</td>    
</tr>
<?php } ?>    
<?php } ?>
<?php 
$ecopval=(get_goupval('4','D','O','C',$fdate)-get_goupval('4','C','O','C',$fdate));
$ecdebit=get_goupval('4','D','D','C',$fdate,$tdate);
$eccredit=get_goupval('4','C','D','C',$fdate,$tdate);
$ecnet=($ecdebit-$eccredit);
$eccval=($ecopval+$ecnet);    
?>    
<?php if(ABS($eccval)>0){?>     
<tr style="border-bottom:none;border-top:none;">
    <td colspan="4"></td>
</tr>    
<tr>    
<td><b>&nbsp;Total Expenses</b></td>
<td style="text-align: right; border-top: 1px double #000000; border-bottom: 4px double #000000;"><b><?php echo number_format($ecopval,2);?></b></td>
<td style="text-align: right; border-top: 1px double #000000; border-bottom: 4px double #000000;"><b><?php echo number_format($ecnet,2);?></b></td>
<td style="text-align: right; border-top: 1px double #000000; border-bottom: 4px double #000000;"><b><?php echo number_format($eccval,2);?></b></td>    
</tr>
<?php } ?>
</tbody>    
</table>
<table class="table table-bordered   table-hover">
<tbody>
<tr class="bg-gray">
<td width="50%" style="padding-left:15px;"><b>NET INCOME</b></td>
<td width="16.16%" style="text-align: right; border-top: 1px double #000000; border-bottom: 4px double #000000;"><b><?php echo number_format(($rcopval-$ecopval),2);?></b>
</td>
<td width="16.16%" style="text-align: right; border-top: 1px double #000000; border-bottom: 4px double #000000;"><b><?php echo number_format(($rcnet-$ecnet),2);?></b>
</td>
<td width="16.16%" style="text-align: right; border-top: 1px double #000000; border-bottom: 4px double #000000;"><b><?php echo number_format(($rccval-$eccval),2);?></b>
</td>    
</tr>
</tbody>
</table>    