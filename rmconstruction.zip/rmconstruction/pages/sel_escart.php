<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
include ('../inc/repfunctions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
$today = strftime("%Y-%m-%d", time());    
$dtnow = date("Y-m-d h:i:s", time());    
}else{
header('Location:../index.php');
exit;    
}

if(isset($_POST['additem'])){
$unqid=$_POST['additem'];   
addestimate($brid,$unqid,1);    
}

if(isset($_POST['itmsear'])){
$search = $_POST['search'];
$sql = "SELECT tbl_brstock.unqid,tbl_brstock.code,tbl_brstock.name,tbl_stock.cost,tbl_stock.price FROM tbl_brstock LEFT JOIN tbl_stock ON tbl_stock.unqid=tbl_brstock.unqid WHERE tbl_brstock.brid='$brid' AND tbl_brstock.status='1' AND (tbl_brstock.name LIKE '%$search%' OR tbl_brstock.code LIKE '%$search%') AND tbl_brstock.avqty>0 LIMIT 20";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
while($row = mysqli_fetch_array($result) ){
$response[] = array("value"=>$row['unqid'],"label"=>$row['code'].' | '.$row['name'].' | '.$row['price']);
}

echo json_encode($response);
exit;    
}

if(isset($_POST['remove'])){
$ids = floatval($_POST['remove']);
$unqid=$_SESSION['axes_estimate'][$ids]['unqid'];    
remove_estimate($ids);
$max=count($_SESSION['axes_estimate']);
if($max <= 0){
unset($_SESSION['axes_estimate']);
unset($_SESSION['axes_estimde']);	
}    
}

if(isset($_POST['upqty'])){
$ids=intval($_POST['upqty']);
$qty=floatval($_POST['qty']);
if($qty<0 || $qty==''){
$redata=array($_SESSION['axes_estimate'][$ids]['qty'],$_SESSION['axes_estimate'][$ids]['price'],$_SESSION['axes_estimate'][$ids]['subtot'],$_SESSION['axes_estimate'][$ids]['pnote'],$_SESSION['axes_estimate'][$ids]['disp'],$_SESSION['axes_estimate'][$ids]['disf'],$_SESSION['axes_estimate'][$ids]['disamo']);
echo json_encode($redata);    
exit;
}
$unqid = $_SESSION['axes_estimate'][$ids]['unqid'];
$eqty=(get_selestockinfo($brid,$unqid,'avqty')-get_selestockinfo($brid,$unqid,'sloc'));    
$dis = $_SESSION['axes_estimate'][$ids]['disf'];
if($qty<=$eqty){
$_SESSION['axes_estimate'][$ids]['qty']=$qty;		
}elseif($qty>$eqty){
$_SESSION['axes_estimate'][$ids]['qty']=$eqty;		
}    
$price = $_SESSION['axes_estimate'][$ids]['price'];
$sqty = $_SESSION['axes_estimate'][$ids]['qty'];
$disamo = getfloatval(($dis*$sqty));
$stot = ($price*$sqty);
if($price>0){
$disp=(($dis/$price)*100);
}else{
$disp=0;	
}
$_SESSION['axes_estimate'][$ids]['disp']=getfloatval($disp);
$_SESSION['axes_estimate'][$ids]['disamo']=$disamo;
$_SESSION['axes_estimate'][$ids]['subtot'] = getfloatval(($stot-$disamo));
$redata=array($_SESSION['axes_estimate'][$ids]['qty'],$_SESSION['axes_estimate'][$ids]['price'],$_SESSION['axes_estimate'][$ids]['subtot'],$_SESSION['axes_estimate'][$ids]['pnote'],$_SESSION['axes_estimate'][$ids]['disp'],$_SESSION['axes_estimate'][$ids]['disf'],$_SESSION['axes_estimate'][$ids]['disamo']);
echo json_encode($redata);
}

if(isset($_POST['upprice'])){
$ids=intval($_POST['upprice']);
$amo=floatval($_POST['amo']);
if($amo<0 || $amo==''){
$redata=array($_SESSION['axes_estimate'][$ids]['qty'],$_SESSION['axes_estimate'][$ids]['price'],$_SESSION['axes_estimate'][$ids]['subtot'],$_SESSION['axes_estimate'][$ids]['pnote'],$_SESSION['axes_estimate'][$ids]['disp'],$_SESSION['axes_estimate'][$ids]['disf'],$_SESSION['axes_estimate'][$ids]['disamo']);
echo json_encode($redata);
exit;
}
$qty=$_SESSION['axes_estimate'][$ids]['qty'];
$dis=$_SESSION['axes_estimate'][$ids]['disf'];
$_SESSION['axes_estimate'][$ids]['price']=$amo;
$disamo= getfloatval(($dis*$qty));
$disp=(($dis/$amo)*100);
$_SESSION['axes_estimate'][$ids]['disp']=getfloatval($disp);
$_SESSION['axes_estimate'][$ids]['disamo']=$disamo;
$_SESSION['axes_estimate'][$ids]['subtot']=(($amo*$qty)-$disamo);
$redata=array($_SESSION['axes_estimate'][$ids]['qty'],$_SESSION['axes_estimate'][$ids]['price'],$_SESSION['axes_estimate'][$ids]['subtot'],$_SESSION['axes_estimate'][$ids]['pnote'],$_SESSION['axes_estimate'][$ids]['disp'],$_SESSION['axes_estimate'][$ids]['disf'],$_SESSION['axes_estimate'][$ids]['disamo']);
echo json_encode($redata);	
}

if(isset($_POST['check'])){
$ids=$_POST['pid'];
$val=$_POST['check'];
$max=count($_SESSION['axes_estimate']);
for($i=0;$i<$max;$i++){
if($ids==$i){
$_SESSION['axes_estimate'][$i]['check']=$val;	
}else{
$_SESSION['axes_estimate'][$i]['check']=0;	
}	
}	
}

if(isset($_POST['upnote'])){
$ids=intval($_POST['upnote']);
$note=ucwords(remove_junk(escape($_POST['note'])));
$_SESSION['axes_estimate'][$ids]['pnote']=$note;    
$redata=array($_SESSION['axes_estimate'][$ids]['qty'],$_SESSION['axes_estimate'][$ids]['price'],$_SESSION['axes_estimate'][$ids]['subtot'],$_SESSION['axes_estimate'][$ids]['pnote'],$_SESSION['axes_estimate'][$ids]['disp'],$_SESSION['axes_estimate'][$ids]['disf'],$_SESSION['axes_estimate'][$ids]['disamo']);
echo json_encode($redata);    
}

if(isset($_POST['itemdisp'])){
$ids=intval($_POST['itemdisp']);
$disc=floatval($_POST['disp']);
//if( $disc==''){exit;}
$_SESSION['axes_estimate'][$ids]['disp']=$disc;
$price=$_SESSION['axes_estimate'][$ids]['price'];
$uqty=$_SESSION['axes_estimate'][$ids]['qty'];
$dis=(($price*$disc)*0.01);
$disamo = ($dis*$uqty); 
$_SESSION['axes_estimate'][$ids]['disf']=getfloatval($dis);
$_SESSION['axes_estimate'][$ids]['disamo']=getfloatval($disamo);
$_SESSION['axes_estimate'][$ids]['subtot']=(($price*$uqty)-$disamo);
$redata=array($_SESSION['axes_estimate'][$ids]['qty'],$_SESSION['axes_estimate'][$ids]['price'],$_SESSION['axes_estimate'][$ids]['subtot'],$_SESSION['axes_estimate'][$ids]['pnote'],$_SESSION['axes_estimate'][$ids]['disp'],$_SESSION['axes_estimate'][$ids]['disf'],$_SESSION['axes_estimate'][$ids]['disamo']);
echo json_encode($redata); 
}

if(isset($_POST['itemdisf'])){
$ids=intval($_POST['itemdisf']);
$dica=floatval($_POST['disf']);
$price=$_SESSION['axes_estimate'][$ids]['price'];
$uqty=$_SESSION['axes_estimate'][$ids]['qty'];
$disp=(($dica/$price)*100);
$_SESSION['axes_estimate'][$ids]['disf']=getfloatval($dica);
$disamo = ($dica*$uqty);
$_SESSION['axes_estimate'][$ids]['disamo']=getfloatval($disamo);
if($dica<=0){
$_SESSION['axes_estimate'][$ids]['disp']=getfloatval(0);	
}else{
$_SESSION['axes_estimate'][$ids]['disp']=getfloatval($disp);	
}
$_SESSION['axes_estimate'][$ids]['subtot']=(($price*$uqty)-$disamo);
$redata=array($_SESSION['axes_estimate'][$ids]['qty'],$_SESSION['axes_estimate'][$ids]['price'],$_SESSION['axes_estimate'][$ids]['subtot'],$_SESSION['axes_estimate'][$ids]['pnote'],$_SESSION['axes_estimate'][$ids]['disp'],$_SESSION['axes_estimate'][$ids]['disf'],$_SESSION['axes_estimate'][$ids]['disamo']);
echo json_encode($redata); 
}

if(isset($_POST['foot'])){
$disp=$_SESSION['axes_estimde'][0]['disp'];
$redata=array($_SESSION['axes_estimde'][0]['disp'],(get_estdiscount_total(floatval($disp))-get_estdiscount_total()),get_estdiscount_total($disp),$_SESSION['axes_estimde'][0]['vatp'],$_SESSION['axes_estimde'][0]['vatamo'],$_SESSION['axes_estimde'][0]['aitp'],$_SESSION['axes_estimde'][0]['aitamo'],$_SESSION['axes_estimde'][0]['name'],$_SESSION['axes_estimde'][0]['others'],$_SESSION['axes_estimde'][0]['freight'],$_SESSION['axes_estimde'][0]['less'],$_SESSION['axes_estimde'][0]['gtotal']);
echo json_encode($redata);	
exit;
}

if(isset($_POST['seldis'])){
$disp=floatval($_POST['seldis']);
if(isset($_SESSION['axes_estimde'])){
if($disp>0){
$_SESSION['axes_estimde'][0]['disp']= getfloatval($disp);
$_SESSION['axes_estimde'][0]['disamo']=getfloatval(get_estdiscount_total(floatval($disp)));    
}else{    
$_SESSION['axes_estimde'][0]['disp']= getfloatval(0);
$_SESSION['axes_estimde'][0]['disamo']=getfloatval(0);    
}
}
}

if(isset($_POST['selvat'])){
$rvat=floatval($_POST['selvat']);
$disp=$_SESSION['axes_estimde'][0]['disp'];    
if(isset($_SESSION['axes_estimde'])){
if($rvat>0){	
$_SESSION['axes_estimde'][0]['vatp']= getfloatval($rvat);
$_SESSION['axes_estimde'][0]['vatamo']= getfloatval((((get_estimate_total()-(get_estdiscount_total($disp)-get_estdiscount_total()))*$rvat)*0.01));    
}else{    
$_SESSION['axes_estimde'][0]['vatp']= 0;
$_SESSION['axes_estimde'][0]['vatamo']= 0;    
}
} 
}

if(isset($_POST['seltax'])){
$rtax=floatval($_POST['seltax']);
$disp=$_SESSION['axes_estimde'][0]['disp'];    
if(isset($_SESSION['axes_estimde'])){
if($rtax>0){	
$_SESSION['axes_estimde'][0]['aitp']= getfloatval($rtax);
$_SESSION['axes_estimde'][0]['aitamo']= getfloatval((((get_estimate_total()-(get_estdiscount_total($disp)-get_estdiscount_total()))*$rtax)*0.01));    
}else{    
$_SESSION['axes_estimde'][0]['aitp']= 0;
$_SESSION['axes_estimde'][0]['aitamo']= 0;    
}
}
}

if(isset($_POST['others'])){
$ota=floatval($_POST['others']);
if(isset($_SESSION['axes_estimde'])){
$_SESSION['axes_estimde'][0]['others']=getfloatval($ota);	
}
}

if(isset($_POST['otname'])){
$otn=$_POST['otname'];
if($otn==''){return;}
if(isset($_SESSION['axes_estimde'])){
$_SESSION['axes_estimde'][0]['name']=ucwords($otn);	
}	
}

if(isset($_POST['freight'])){
$fre=floatval($_POST['freight']);
if(isset($_SESSION['axes_estimde'])){
$_SESSION['axes_estimde'][0]['freight']=getfloatval($fre);	
}
}

if(isset($_POST['less'])){
$less=floatval($_POST['less']);
if(isset($_SESSION['axes_estimde'])){
if($less>0){
$_SESSION['axes_estimde'][0]['less']= getfloatval($less);    
}else{    
$_SESSION['axes_estimde'][0]['less']= 0;   
}
}
}

if(isset($_POST['audimei'])){
$id=$_POST['audimei'];
$pid=intval($_SESSION['axes_selse'][$id]['pid']);
$unqid=$_SESSION['axes_selse'][$id]['unqid'];    
$search = $_POST['search'];
$purinv=get_salesinfo($unqid,'invno');
    
$sql="SELECT pid,serial FROM tbl_serial WHERE purinv='$purinv' AND pid='$pid' AND serial LIKE '%$search%' AND brid='$brid' AND rci='Y' AND status='0' ORDER BY serial ASC LIMIT 30";		
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
while($row = mysqli_fetch_array($result) ){
$response[] = array("value"=>$row['pid'],"label"=>$row['serial']);
}

// encoding array to json format
echo json_encode($response);
exit;    
}

if(isset($_SESSION['axes_estimde'])){
if(is_array($_SESSION['axes_estimde'])){    
$disps=$_SESSION['axes_estimde'][0]['disp'];
if($disps>0){
$_SESSION['axes_estimde'][0]['disamo']=getfloatval(get_estdiscount_total(floatval($disps)));	
}else{
$_SESSION['axes_estimde'][0]['disamo']=getfloatval(get_estdiscount_total());	
}
$vatps=$_SESSION['axes_estimde'][0]['vatp'];
if($vatps>0){
$_SESSION['axes_estimde'][0]['vatamo']= getfloatval(((get_estimate_total()-(get_estdiscount_total($disps)- get_estdiscount_total()))*$vatps)*0.01);	
}
$taxps=$_SESSION['axes_estimde'][0]['aitp'];
if($taxps>0){
$_SESSION['axes_estimde'][0]['aitamo']= getfloatval(((get_estimate_total()-(get_estdiscount_total($disps)- get_estdiscount_total()))*$taxps)*0.01);	
}
$freight=$_SESSION['axes_estimde'][0]['freight'];
$vatamos=$_SESSION['axes_estimde'][0]['vatamo'];
$aitamos=$_SESSION['axes_estimde'][0]['aitamo'];
$other=$_SESSION['axes_estimde'][0]['others'];
$lesss=$_SESSION['axes_estimde'][0]['less'];    
}else{
$disps=0;
$vatps=0;
$vatamos=0;
$aitamos=0;
$freight=0;
$other=0;
$lesss=0;    
}
$_SESSION['axes_estimde'][0]['gtotal']=(get_estimate_total()+$vatamos+$other+$aitamos+$freight)-((get_estdiscount_total(floatval($disps))- get_estdiscount_total())+$lesss);
}

if(isset($_POST['clear'])){
if(isset($_SESSION['axes_estimate'])){
unset($_SESSION['axes_estimate']);
unset($_SESSION['axes_estimde']);    
}
}

if(isset($_POST['getcus'])){
$search = $_POST['search'];
$sql="SELECT * FROM (SELECT CONCAT('CU_',id) AS id,code,name,cnumber FROM tbl_customer UNION ALL SELECT CONCAT('SU_',id) AS id,code,name,cnumber FROM tbl_supplier) AS customer WHERE (name LIKE '%$search%' OR code LIKE '%$search%' OR cnumber LIKE '%$search%') ORDER BY name ASC,code ASC LIMIT 30";		
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
while($row = mysqli_fetch_array($result) ){
$response[] = array("value"=>$row['id'],"label"=>$row['code'].' | '.$row['name'].' | '.$row['cnumber']);
}

// encoding array to json format
echo json_encode($response);
exit;
}

if(isset($_POST['checkbal'])){
if(strlen($_POST['checkbal'])>0){    
$id=str_replace('_','',$_POST['checkbal']);
$ldebit=get_ledgerval($id,'D','N');
$lcredit=get_ledgerval($id,'C','N');
$lnet=($ldebit-$lcredit);
echo number_format($lnet,2);
}else{
echo '0.00';    
}    
}

if(isset($_POST['seldata'])){
$edata=array(check_estprice('P'));
echo json_encode($edata);
}

if(isset($_POST['addestimate'])){
$invno = gen_newinvno('tbl_estimate','EST');
$apdate = remove_junk(escape($_POST['seldt']));
$nxtdt = remove_junk(escape($_POST['nextdt']));
    
$cdata=explode('_',remove_junk(escape($_POST['customer'])));
$cty=$cdata['0'];    
$cid = $cdata['1'];    

if($cid!=0){
if($cty=='CU'){    
$cname=get_fild_data('tbl_customer',$cid,'name');
$cmobile=get_fild_data('tbl_customer',$cid,'cnumber');    
}else{
$cname=get_fild_data('tbl_supplier',$cid,'name');
$cmobile=get_fild_data('tbl_supplier',$cid,'cnumber');     
}
}else{
$cname=remove_junk(escape($_POST['wname']));
$cmobile=remove_junk(escape($_POST['wmobile']));    
}    
   
//$pname = remove_junk(escape($_POST['pname']));    
//$dipname = remove_junk(escape($_POST['dipname']));
//$paddress = remove_junk(escape($_POST['paddress']));
    
$ref = remove_junk(escape($_POST['ref']));
$note = remove_junk(escape($_POST['note']));
$selp = remove_junk(escape($_POST['selp']));
if($selp=='' || $selp=='-Select-'){$selp='NULL';}else{$selp="'".$selp."'";} 

$itmdis=remove_junk(escape(get_estdiscount_total()));    
$disp=remove_junk(escape($_SESSION['axes_estimde'][0]['disp']));
$disamo=remove_junk(escape($_SESSION['axes_estimde'][0]['disamo']));   
$vatp=remove_junk(escape($_SESSION['axes_estimde'][0]['vatp']));
$vatamo=remove_junk(escape($_SESSION['axes_estimde'][0]['vatamo']));
$aitp=remove_junk(escape($_SESSION['axes_estimde'][0]['aitp']));
$aitamo=remove_junk(escape($_SESSION['axes_estimde'][0]['aitamo']));
$freight=remove_junk(escape($_SESSION['axes_estimde'][0]['freight']));
$otname=remove_junk(escape($_SESSION['axes_estimde'][0]['name']));
$otamo=remove_junk(escape($_SESSION['axes_estimde'][0]['others']));
$less=remove_junk(escape($_SESSION['axes_estimde'][0]['less']));
$subtot=get_estimate_total();    
$gtotal=remove_junk(escape($_SESSION['axes_estimde'][0]['gtotal']));
if($disp>0){
$invdis=($disamo-$itmdis);    
}else{
$invdis=0;    
}    
   
if(!isset($_SESSION['axes_estimate'])){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! No item found!!'
));
return;
exit;  
}   

if(check_estvalidqty($brid)){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Quantity not available!!'
));
return;
exit;     
}    
    
$sql="INSERT INTO tbl_estimate (invno,type,cusid,name,mobile,itemdis,subtot,disp,disamo,totdis,vatp,vatamo,aitp,aitamo,otname,otamo,freight,less,total,curid,ref,note,apdate,expdate,ocusname,ocusmobile,pname,pdep,paddress,selp,brid,uid,date) VALUES ('$invno','$cty','$cid','$cname','$cmobile','$itmdis','$subtot','$disp','$invdis','$disamo','$vatp','$vatamo','$aitp','$aitamo','$otname','$otamo','$freight','$less','$gtotal','0','$ref','$note','$apdate','$nxtdt',NULL,NULL,NULL,NULL,NULL,$selp,'$brid','$aid','$dtnow')";
   
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sid=$con->insert_id;    
$efid=mysqli_affected_rows($con);     

if($efid>0){
$max=count($_SESSION['axes_estimate']);
for($i=0;$i<$max;$i++){
$pid = $_SESSION['axes_estimate'][$i]['pid'];
$unqid= $_SESSION['axes_estimate'][$i]['unqid'];   
$col=$_SESSION['axes_estimate'][$i]['col'];
$siz=$_SESSION['axes_estimate'][$i]['siz'];
$icdis=$_SESSION['axes_estimate'][$i]['icdis'];
$icinvdis=$_SESSION['axes_estimate'][$i]['icinvdis'];    
$cost=$_SESSION['axes_estimate'][$i]['cost'];  
$qty=$_SESSION['axes_estimate'][$i]['qty'];
    
$taxp=0;
$taxamo=0;
$idisp=$_SESSION['axes_estimate'][$i]['disp'];
$idisf=$_SESSION['axes_estimate'][$i]['disf'];
$disamo=$_SESSION['axes_estimate'][$i]['disamo'];
$sdisp=0;
$sdisf=0;
$price=$_SESSION['axes_estimate'][$i]['price'];
$isubtot=$_SESSION['axes_estimate'][$i]['subtot'];
$wday=$_SESSION['axes_estimate'][$i]['wday'];
$pnote=$_SESSION['axes_estimate'][$i]['pnote'];    
    
$sql="INSERT INTO tbl_estimatede (invno,pid,unqid,colid,sizid,cost,icdis,icinvdis,price,qty,taxp,taxamo,disp,disf,disamo,subtot,wday,pnote) VALUES ('$invno','$pid','$unqid','$col','$siz','$cost','$icdis','$icinvdis','$price','$qty','$taxp','$taxamo','$idisp','$idisf','$disamo','$isubtot','$wday','$pnote')";
    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));    
}
  
unset($_SESSION['axes_estimate']);
unset($_SESSION['axes_estimde']);
   
    
$act =remove_junk(escape('Estimate Invoice: '.$invno));
$bact =remove_junk(escape('নির্ধারণ রশিদ: '.$invno));    
write_activity($aid,'EST','New estimate invoice has been Created',$act,'নতুন বিক্রয় নির্ধারণ রশিদ করেছেন',$bact);
echo json_encode(array(
'status' => 'success',
'message'=> 'Estimate Save Successfully!!',
'invid'=> $sid    
));
exit;    
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));    
}    
    
}
?>

<?php 
if(isset($_POST['checkview'])){
$cusd=explode('_',$_POST['cusid']);
$typ=$cusd[0];    
$cusid=$cusd[1];
$wname = $_POST['wname'];
$wmobil = $_POST['wmobil'];    
if(isset($_SESSION['axes_estimde'])){    
$gtotal=$_SESSION['axes_estimde'][0]['gtotal'];
}else{
$gtotal=0;    
}
$id=str_replace('_','',$_POST['cusid']);
$ldebit=get_ledgerval($id,'D','N');
$lcredit=get_ledgerval($id,'C','N');
if($cusid!=0){
$lnet=($ldebit-$lcredit);     
}else{
$lnet=0;    
}        
?>
<div class="addsersales">
<div class="row">
<div class="col-md-3 col-xs-6">
<div class="small-box">
<div class="inner">
<h3 id="pabamo"><?php echo $gtotal;?></h3>
<p>Total Estimate</p>
</div>

</div>
<input type="hidden" value="<?php echo $_POST['cusid']; ?>" id="customer" name="customer" readonly />
<input type="hidden" value="<?php if($lnet<0){echo ABS($lnet);}else{echo 0;} ?>" id="balance" name="balance" readonly />
<input type="hidden" value="<?php echo $wname;?>" name="wname" readonly />
<input type="hidden" value="<?php echo $wmobil;?>" name="wmobile" readonly />
<input type="hidden" name="addestimate" readonly />
<input type="hidden" name="scusid" id="scusid" value="<?php echo $cusid; ?>" readonly />    
</div>
<div class="col-md-3 col-xs-6">

</div>
<div class="col-md-3 col-xs-6">

</div>
<div class="col-md-3 col-xs-6">

</div>    
</div>
<div class="row">
<div class="col-md-3 col-xs-6">
<div class="form-group">
    
</div>    
</div>
<div class="col-md-3 col-xs-6">
    
</div>
<div class="col-md-3 col-xs-6">
<div class="form-group" >
<label>Estimate Date</label>
<input type="text" class="form-control datetimepicker" name="seldt" id="seldt" value="<?php echo $today;?>" placeholder="Estimate Date" autocomplete="off" readonly>
</div>
</div>
<div class="col-md-3 col-xs-6">
<div class="form-group" >
<label>Expired Date</label>
<input type="text" class="form-control datetimepicker" name="nextdt" id="nextdt" value="<?php echo date('Y-m-d', strtotime('+7 days',strtotime($today)));?>" placeholder="Sales Date" autocomplete="off" readonly>
</div>    
</div>
</div>
<div class="row">
<br>   
<div class="col-md-4">
<div class="form-group">
<label>Ref</label>
<input type="text" maxlength="25" class="form-control" name="ref" id="ref" placeholder="e.g. #ORD8976453" autocomplete="off">    
</div>
<div class="form-group">
<label>Estimate Person</label>    
<select class="form-control select2" name="selp" id="selp">
<option value="">-Select-</option>    
<?php
$sql="SELECT id,name FROM tbl_employe ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>    
</div>    
</div>
<div class="col-md-8">    
<div class="form-group">    
<label>Note</label>
<textarea class="form-control" name="note" id="note" maxlength="150" rows="5" placeholder="Invoice Note"></textarea>    
</div>    
</div>    
</div>
</div>    
<div class="row">
<div class="col-md-12 text-center side-checkhead">
<button class="btn btn-flat bg-blue saveseinv" id="saveinv"><i class="fa fa-floppy-o"></i>&nbsp;&nbsp;Save</button>    
<button class="btn btn-flat bg-gray saveseinv" id="sinvprint"><i class="fa fa-floppy-o"></i>&nbsp;&nbsp; Invoice &nbsp;&nbsp;<i class="fa fa-print"></i></button>   
</div>    
</div>
<script type="text/javascript">   
$(".select2").select2();    
$('.datetimepicker').datepicker({format: "yyyy-mm-dd", autoclose: true, clearBtn: true, orientation: 'auto bottom'});    
</script>    
<?php } ?>

<?php 
if(isset($_POST['checkout'])){
$cusd=explode('_',$_POST['cusid']);
$typ=$cusd[0];    
$cusid=$cusd[1];    
?>
<div class="col-md-12 cart-border-left text-center">
<div class="horizontal-scroll">
<h5 class="text-center" style="font-size: 20px;">Estimate Details</h5> 
<div>
<div class="text-center header-line-height">
<small class="text-center" style="font-size: 15px;"><?php echo get_cominfo('1','name');?></small>
<br> <small class="text-center"><?php echo date("d M Y", strtotime($today));?></small>
<br> <small class="text-center" style="font-size: 12px;"><strong>Estimate Receipt</strong></small>
<!--<br> <small class="text-left">Sold By: John Doe</small>--> 
<br> <small><span>Estimate To: <?php if($cusid!=0){if($typ=='SU'){echo get_fild_data('tbl_supplier',$cusid,'name');}else{echo get_fild_data('tbl_customer',$cusid,'name');}}else{echo 'Walk-In Customer';};?></span></small> 
<small class="text-left invoice-show" style="display: none;">Invoice ID:</small>
</div> 
<div class="invoice-table">
<table class="table product-card-font" style="font-weight: 500;">
<thead class="border-top-0">    
<tr>
<th class="cart-summary-table text-left">Items</th> 
<th class="cart-summary-table text-left">Qty</th> 
<th class="cart-summary-table text-right">Price</th>
<th class="cart-summary-table text-right">Discount</th>
<th class="cart-summary-table text-right">Total</th>
</tr>   
</thead> 
<tbody>
<?php 
$s=0;    
if(isset($_SESSION['axes_estimate'])){
$max=count($_SESSION['axes_estimate']);
for($i=($max-1);$i>=0;$i=$i-1){
$name=$_SESSION['axes_estimate'][$i]['name'];
$col=$_SESSION['axes_estimate'][$i]['col'];
if($col==0){$col='';}
$siz=$_SESSION['axes_estimate'][$i]['siz'];
if($siz==0){$siz='';}    
$qty=$_SESSION['axes_estimate'][$i]['qty'];
$price=$_SESSION['axes_estimate'][$i]['price'];
$disp=$_SESSION['axes_estimate'][$i]['disp'];    
$subtot=$_SESSION['axes_estimate'][$i]['subtot'];
$pnote=$_SESSION['axes_estimate'][$i]['pnote'];
if($col=='' && $siz==''){
$name=$name;    
}elseif($col!='' && $siz==''){
$name= $name.' '.get_fild_data('tbl_color',$col,'name');    
}elseif($col=='' && $siz!=''){
$name= $name.' '.get_fild_data('tbl_size',$siz,'sval');    
}elseif($col!='' && $siz!=''){    
$name= $name.' '.get_fild_data('tbl_color',$col,'name').' '.get_fild_data('tbl_size',$siz,'sval');    
}     
$s+=1;    
?>    
<tr>
<td class="cart-summary-table text-left"><?php echo $name;?><br></td>
<td class="cart-summary-table"><?php echo $qty;?></td> 
<td class="text-right cart-summary-table"><?php echo numtolocal($price,''); ?></td> 
<td class="text-right cart-summary-table"><?php echo $disp;?> %</td> 
<td class="text-right cart-summary-table"><?php echo numtolocal($subtot,''); ?></td>
<?php }} ?>     
</tbody> 
<tfoot>
<?php 
$disp=$_SESSION['axes_estimde'][0]['disp'];
$vatp=$_SESSION['axes_estimde'][0]['vatp'];
$vatamo=$_SESSION['axes_estimde'][0]['vatamo'];
$aitp=$_SESSION['axes_estimde'][0]['aitp'];
$aitamo=$_SESSION['axes_estimde'][0]['aitamo'];
$otname=$_SESSION['axes_estimde'][0]['name'];
$others=$_SESSION['axes_estimde'][0]['others'];
$less=$_SESSION['axes_estimde'][0]['less'];
$freight=$_SESSION['axes_estimde'][0]['freight'];
$gtotal=$_SESSION['axes_estimde'][0]['gtotal'];    
?>    
<tr>
<td class="cart-summary-table font-weight-bold text-left">Sub Total</td> 
<td class="cart-summary-table"></td>
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table"><?php echo numtolocal(get_estimate_total(),'Tk');?></td>
</tr>
<?php if(get_estdiscount_total()>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">Discount(<?php echo $disp.'';?>%)</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal(get_estdiscount_total($disp),'Tk');?></td>
</tr>    
<?php } ?>
<?php if($vatamo>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">VAT(<?php echo $vatp.'';?>%)</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($vatamo,'Tk');?></td>
</tr>    
<?php } ?>
<?php if($aitamo>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">AIT(<?php echo $aitp.'';?>%)</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($aitamo,'Tk');?></td>
</tr>    
<?php } ?>    
<?php if($others>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left"><?php echo $otname;?></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($others,'Tk');?></td>
</tr>    
<?php } ?>
<?php if($freight>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">Freight</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($freight,'Tk');?></td>
</tr>    
<?php } ?> 
<?php if($less>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">Adjust</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($less,'Tk');?></td>
</tr>    
<?php } ?>     
<tr>
<td class="cart-summary-table font-weight-bold text-left">Total</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($gtotal,'Tk');?></td>
</tr> 
</tfoot>
</table>
</div>
</div>
</div>
</div>   
<?php } ?>
