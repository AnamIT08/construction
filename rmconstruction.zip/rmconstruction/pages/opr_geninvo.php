<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('7','creates','R');    
$_SESSION['cuPages']='opr_geninvo.php';   
$cuPage='opr_geninvo.php';    
$aid=$_SESSION['uid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='operation';
$menuh='Operation Process';
$phead='invcre';
$page='Generate Invoice';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['save_invo'])){
    if(!isset($_SESSION['axes_invdata'])){
    save_msg('w','No Invoice data found!!');
	echo "<script>window.location='opr_geninvo.php'</script>";
    exit;    
    }
    
	if(!isset($_SESSION['axes_invitem'])){
    save_msg('w','No Invoice Product found!!');
	echo "<script>window.location='opr_geninvo.php'</script>";
    exit;    
    }
    
    $invno = remove_junk(escape($_SESSION['axes_invdata']['invno']));
    $pino = remove_junk(escape($_SESSION['axes_invdata']['pino']));
    $apdate = remove_junk(escape($_SESSION['axes_invdata']['date']));
    $curid = remove_junk(escape($_SESSION['axes_invdata']['curid']));
    $total = total_invvalue('V');
    $totcom = total_invvalue('C');
    
    if($invno!=''){
	$ducode = mysqli_query($con,"SELECT * FROM tbl_invoice WHERE invno = '$invno'");
	}
	
    if($invno=='' || strlen($invno)<1){
    save_msg('i','Invoice Not Found!!! Data Fail to Save');
	echo "<script>window.location='opr_geninvo.php'</script>";    
    }
    
	if($ducode->num_rows > 0) {
	save_msg('i','Inovoice No alrady exists!!! Data Fail to Save');
	echo "<script>window.location='opr_geninvo.php'</script>";
	}else{
    $sql="INSERT INTO tbl_invoice(invno,pino,curid,total,totcom,apdate,uid,date) VALUES ('$invno','$pino','$curid','$total','$totcom','$apdate','$aid','$dtnow')";
    $result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $sid=$con->insert_id;
    $efid=mysqli_affected_rows($con);    
    if($efid>0){
    if(isset($_SESSION['axes_invitem'])){
    if(is_array($_SESSION['axes_invitem'])){
    $max=count($_SESSION['axes_invitem']);
    for($i=0;$i<$max;$i++){
    $id = $_SESSION['axes_invitem'][$i]['pisid'];    
    $itemid = $_SESSION['axes_invitem'][$i]['itemid'];
    $color = $_SESSION['axes_invitem'][$i]['color'];
    $itemname = $_SESSION['axes_invitem'][$i]['itemname'];
    $qty = $_SESSION['axes_invitem'][$i]['qty'];
    $unit = $_SESSION['axes_invitem'][$i]['unit'];
    $price = $_SESSION['axes_invitem'][$i]['price'];
    $subtot = $_SESSION['axes_invitem'][$i]['subtot'];
    $cfamo = $_SESSION['axes_invitem'][$i]['cfamo'];
    $tcamo = $_SESSION['axes_invitem'][$i]['tcamo'];
        
    $sql="INSERT INTO tbl_invoicede (seid,itemid,itemname,color,price,qty,unit,subtot,cfamo,tcamo) VALUES ('$sid','$itemid','$itemname','$color','$price','$qty','$unit','$subtot','$cfamo','$tcamo')";
    $item=mysqli_query($con,$sql) or die(mysqli_error($con));
    $itid=mysqli_affected_rows($con);
    if($itid>0){
    $sql="UPDATE tbl_proinvde SET rcvqty=rcvqty+$qty WHERE id='$id'";
    mysqli_query($con,$sql) or die(mysqli_error($con));    
    }    
    }}}    
    unset($_SESSION['axes_invdata']);
    unset($_SESSION['axes_invitem']);    
    $act =remove_junk(escape('Invoice No: '.$invno));    
    write_activity($aid,'INV','New Invoice has been Added',$act);    
    save_msg('s','Data Successfully Saved!');    
    }else{
    save_msg('w','Data Fail to Saved!');    
    }    
    }
    echo "<script>window.location='opr_geninvo.php'</script>";
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Generate Invoice</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="opr_geninvo.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">
<div class="row">    
<center>
<h3 class="page-title">INVOICE</h3>
</center>
</div>
<div class="row">    
<div class="col-md-4 col-md-offset-8">
<div class="form-group" >
<div class="input-group">
<span class="input-group-addon"><b>Invoice No:</b></span>
<input type="text" class="form-control" maxlength="25" name="invno" id="invno" value="<?php if(isset($_SESSION['axes_invdata']['invno'])){echo $_SESSION['axes_invdata']['invno'];}?>" placeholder="e.g. AXE121119101" autocomplete="off">
</div>
</div>
<div class="form-group" >
<div class="input-group">
<span class="input-group-addon"><b>PI No:</b></span>
<input type="text" class="form-control" maxlength="25" name="pino" id="pino" value="<?php if(isset($_SESSION['axes_invdata']['pino'])){echo $_SESSION['axes_invdata']['pino'];}?>" placeholder="e.g. XHL20191203003-1" autocomplete="off">
</div>
</div>    
<div class="form-group" >
<div class="input-group">
<span class="input-group-addon"><b>Date:</b></span>
<input type="text" class="form-control datetimepicker" name="apdate" id="apdate" value="<?php if(isset($_SESSION['axes_invdata']['date'])){echo $_SESSION['axes_invdata']['date'];}?>" placeholder="Date:" autocomplete="off">
</div>
</div>
<div class="form-group" >
<div class="input-group">
<span class="input-group-addon"><b>Currency:</b></span>
<select class="form-control select2" name="curid" id="curid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_currency ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<?php if(isset($_SESSION['axes_invdata']['curid'])){?>
<?php if($rows['id']==$_SESSION['axes_invdata']['curid']){?>
<option selected value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>    
<?php }else{ ?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>    
<?php } ?>    
<?php }else{ ?>    
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>    
<?php } ?>
</select>
</div>
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-4">
<div class="form-group">
<label>Customer/Buyer</label>
<select class="form-control select2" name="cusid" id="cusid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_customer ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<?php if(isset($_SESSION['axes_invdata']['cusid'])){?>
<?php if($rows['id']==$_SESSION['axes_invdata']['cusid']){?>
<option selected value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>    
<?php }else{ ?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>    
<?php } ?>    
<?php }else{ ?>    
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?> 
<?php } ?>
</select>    
</div> 
</div>
<div class="col-md-4"></div>
<div class="col-md-4">
<div class="form-group">
<label>Supplier/Expoter</label>
<select class="form-control select2" name="supid" id="supid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_supplier ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<?php if(isset($_SESSION['axes_invdata']['supid'])){?>
<?php if($rows['id']==$_SESSION['axes_invdata']['supid']){?>
<option selected value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>    
<?php }else{ ?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>    
<?php } ?>    
<?php }else{ ?>    
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?> 
<?php } ?>
</select>    
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group" >
<label>Search Product</label>    
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>
<input type="text" class="form-control" maxlength="35" name="search" id="search" placeholder="e.g. Product Code or Name" autocomplete="off">
<span class="input-group-addon"><a href=""><span class="fa fa-plus"></span></a></span>     
</div>
</div>
</div>
<div class="col-md-6">
    
</div> 
</div>
    
<div class="row">
<div class="col-md-12">
<table class="table table-bordered table-striped">
<thead>
<tr>
<th width="40" rowspan="2">SN</th>
<th width="250" rowspan="2">Product</th>
<th width="300" class="text-center" colspan="3">Product Details</th>
<th width="200" class="text-center" colspan="2">Commission Details</th>    
<th width="30" class="text-center" rowspan="2"><a class="empty" style="cursor: pointer;"><i class="fa fa-trash"></i></a></th>
</tr>
<tr>
<th width="100" class="text-center">Price</th>
<th width="100" class="text-center">Qty</th>
<th width="100" class="text-center">Total</th>    
<th width="100" class="text-center">Amount</th>
<th width="100" class="text-center">Total</th>    
</tr>    
</thead>
<tbody id="itemdata">

</tbody>
<tfoot id="itemfoot">

</tfoot>
</table> 
</div>    
</div>
<div class="row">
<div class="col-md-12">
    
    
</div>
</div>    
    
</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row" style="margin-top: 15px" >
<div class="col-md-7"></div>
<div class="col-md-5 text-right" >
<input type="button" id="ireset" class="btn btn-flat bg-red btn-sm " value="Reset"/>
<input type="submit" name="save_invo" id="submit" class="btn btn-flat bg-purple btn-sm " value="Save"/> <a href="opr_invoice.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'INV','A');}else{echo read_activity($aid,'INV','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>    
    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function (){ 
var invno = new LiveValidation('invno');
invno.add(Validate.Presence);
var pino = new LiveValidation('pino');
pino.add(Validate.Presence);    
var apdate = new LiveValidation('apdate');
apdate.add(Validate.Presence)
});
ReadData();
function ReadData(){
$.ajax({
url: "opr_inview.php",
method: "POST",
data:{ 
body:1
},
success: function(data){
$('#itemdata').html(data);
}
})

$.ajax({
url: "opr_inview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})    
};    

function ReadFoot(){
$.ajax({
url: "opr_inview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})	
}
    
$(document).on('blur', '#invno', function() {
$inv=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
upinv: $inv
},
dataType: 'json',
success: function(data){
$('#invno').val(data[0]);
}
});     
});    

$(document).on('blur change', '#apdate', function() {
$apdate=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
iapdate: $apdate
},
dataType: 'json',
success: function(data){
$('#apdate').val(data[0]);
}
});     
});       
    
$(document).on('keydown', '#search', function() {
$('#search' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'axe_cart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term,request:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
var te='';
$(this).val(te); // display the selected text
var proid = ui.item.value; // selected id to input

$.ajax({
url: 'axe_cart.php',
type: 'post',
data: {proid:proid,request:2},
dataType: 'json',
success:function(response){
ReadData();
}
});

return false;
}
});    
});

$(document).on('click','#ireset',function() {
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
invclear: 1
},
success: function(data){
$("#invno").val("");
$("#pino").val("");    
$("#apdate").val("");    
$("#curid").val("").trigger("change");
$("#cusid").val("").trigger("change");
$("#supid").val("").trigger("change");  
ReadData();    
}
});    
}); 

$(document).on('click','.empty',function() {
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
iemdata: 1
},
success: function(data){
ReadData();    
}
});    
});    

$(document).on('click', '.remove', function () {
var id = $(this).attr('id');
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
iremove: id
},
success: function(data){
ReadData();
}
});    
});      

$(document).on('blur', '.quantity', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var qty = parseFloat($('#qty_'+id[1]).val());
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
upiqty: ids, qty: qty
},
dataType: 'json',
success: function(data){
$('#qty_'+id[1]).val(data[0]);
$('#stot_'+id[1]).html(data[1]);
$('#tcom_'+id[1]).html(data[2]);
ReadFoot();    
}
});     
});     
    
$(document).on('keydown', '#pino', function() {
$('#pino' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'axe_cart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term, invpi:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
var te=ui.item.label;
$(this).val(te); // display the selected text
var piid = ui.item.value;

$.ajax({
url: 'axe_cart.php',
type: 'post',
dataType: 'json',    
data: {pinfo:piid,pino:te},
success:function(pinf){
    
$("#curid").val(pinf[0]).trigger("change");
$("#cusid").val(pinf[1]).trigger("change");
$("#supid").val(pinf[2]).trigger("change");    
ReadData();
}
});    
    
return false;
}
});    
});    
</script>    
<!-- /page script -->
</html>    