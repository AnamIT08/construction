<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/invfunctions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='rep_payabsustm.php';   
$cuPage='rep_payabsustm.php';    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='report';
$menuh='Report';
$phead='report';
$page='Supplier Statement';
$ractive='C';
$print='print';
$today = strftime("%Y-%m-%d", time());
$dtnow = date("Y-m-d h:i:s", time());
$oavno='REP'.date("dmy", strtotime($today)).'PSST';
?>
<?php
if(isset($_POST['tfdate'])){
$fdate=$_POST['tfdate'];    		
}else{
$fdate=date('Y-m-d', strtotime('-29 days', time()));	
}
if(isset($_POST['ttdate'])){
$tdate=$_POST['ttdate'];	
}else{
$tdate=$today;	
}

if(isset($_POST['ibrid']) && $_POST['ibrid']!=''){
$ibrid=$_POST['ibrid'];    
}else{
$ibrid=$brid;    
}

$type='SU';
if(isset($_POST['cusid']) && $_POST['cusid']!=''){
$cusid=$_POST['cusid'];	
}else{
$cusid='1';	
}

function st_opval($type,$id,$date){
global $con;
if($type=='SU'){
$sty=",'CLA'";
$wty="";    
}else{
$wty=",'CLA'";    
$sty="";    
}     
$sql="SELECT COALESCE ((SELECT (SUM(IF(invty IN ('PAV','PRE','SEL','SER','PDR','BSC'".$sty."),amount,(debit+jdebit)))-SUM(IF(invty IN ('PUR','REV','SRE'".$wty."),amount,(credit+jcredit)))) FROM (SELECT SUBSTRING(invno,1,3) AS invty,invno,ROUND(ABS(IF(SUBSTRING(invno,1,3) IN ('REV','PAV'),SUM(debit-credit),SUM(IF(type NOT IN('BA','MO') AND seid NOT IN ('LE2'),debit-credit,0)))),2) AS amount,ROUND(SUM(IF(((type='LE' AND (CONVERT(opid USING utf8) COLLATE utf8_general_ci)='2') OR type IN ('BA','MO')),debit,0)),2) AS debit,ROUND(SUM(IF(((type='LE' AND (CONVERT(opid USING utf8) COLLATE utf8_general_ci)='2') OR type IN ('BA','MO')),credit,0)),2) AS credit,ROUND(SUM(IF(SUBSTRING(invno,1,3)='JOU' AND debit>0,debit,0)),2) AS jdebit,ROUND(SUM(IF(SUBSTRING(invno,1,3)='JOU' AND credit>0,credit,0)),2) AS jcredit,apdate FROM (SELECT id,(CASE WHEN dty='$type' THEN did WHEN cty='$type' THEN cid END) AS sid,(CASE WHEN dty='$type' THEN cty WHEN cty='$type' THEN dty END) AS type,(CASE WHEN dty!='$type' THEN did WHEN cty!='$type' THEN cid END)  AS opid,(CASE WHEN dty!='$type' THEN CONCAT(dty,did) WHEN cty!='$type' THEN CONCAT(cty,cid) END)  AS seid,IF(dty='$type',amo,0) AS debit,IF(cty='$type',amo,0) AS credit,invno,ref,apdate,TIME(date) AS time FROM tbl_traledger WHERE (dty='$type' AND (CONVERT(did USING utf8) COLLATE utf8_general_ci)='$id') OR (cty='$type' AND (CONVERT(cid USING utf8) COLLATE utf8_general_ci)='$id')) AS curep GROUP BY invno) AS rec WHERE apdate < '$date'),0) AS opval";
$opval=mysqli_query($con,$sql) or die(mysqli_error($con));    
$opv=mysqli_fetch_array($opval);
return $opv['opval'];    
}

function st_drcrbal($type,$id,$fdate,$tdate,$key){
global $con;
if($type=='SU'){
$sty=",'CLA'";
$wty="";    
}else{
$wty=",'CLA'";    
$sty="";    
}    
if($key=='D'){    
$sql="SELECT COALESCE ((SELECT SUM(IF(invty IN ('PAV','PRE','SEL','SER','PDR','BSC'".$sty."),amount,(debit+jdebit))) FROM (SELECT SUBSTRING(invno,1,3) AS invty,invno,ROUND(ABS(IF(SUBSTRING(invno,1,3) IN ('REV','PAV'),SUM(debit-credit),SUM(IF(type NOT IN('BA','MO') AND seid NOT IN ('LE2'),debit-credit,0)))),2) AS amount,ROUND(SUM(IF(((type='LE' AND (CONVERT(opid USING utf8) COLLATE utf8_general_ci)='2') OR type IN ('BA','MO')),debit,0)),2) AS debit,ROUND(SUM(IF(((type='LE' AND (CONVERT(opid USING utf8) COLLATE utf8_general_ci)='2') OR type IN ('BA','MO')),credit,0)),2) AS credit,ROUND(SUM(IF(SUBSTRING(invno,1,3)='JOU' AND debit>0,debit,0)),2) AS jdebit,ROUND(SUM(IF(SUBSTRING(invno,1,3)='JOU' AND credit>0,credit,0)),2) AS jcredit,apdate FROM (SELECT id,(CASE WHEN dty='$type' THEN did WHEN cty='$type' THEN cid END) AS sid,(CASE WHEN dty='$type' THEN cty WHEN cty='$type' THEN dty END) AS type,(CASE WHEN dty!='$type' THEN did WHEN cty!='$type' THEN cid END)  AS opid,(CASE WHEN dty!='$type' THEN CONCAT(dty,did) WHEN cty!='$type' THEN CONCAT(cty,cid) END)  AS seid,IF(dty='$type',amo,0) AS debit,IF(cty='$type',amo,0) AS credit,invno,ref,apdate,TIME(date) AS time FROM tbl_traledger WHERE (dty='$type' AND (CONVERT(did USING utf8) COLLATE utf8_general_ci)='$id') OR (cty='$type' AND (CONVERT(cid USING utf8) COLLATE utf8_general_ci)='$id')) AS curep GROUP BY invno) AS rec WHERE apdate BETWEEN '$fdate' AND '$tdate'),0) AS result";
}else{
$sql="SELECT COALESCE ((SELECT SUM(IF(invty IN ('PUR','REV','SRE'".$wty."),amount,(credit+jcredit))) FROM (SELECT SUBSTRING(invno,1,3) AS invty,invno,ROUND(ABS(IF(SUBSTRING(invno,1,3) IN ('REV','PAV'),SUM(debit-credit),SUM(IF(type NOT IN('BA','MO') AND seid NOT IN ('LE2'),debit-credit,0)))),2) AS amount,ROUND(SUM(IF(((type='LE' AND (CONVERT(opid USING utf8) COLLATE utf8_general_ci)='2') OR type IN ('BA','MO')),debit,0)),2) AS debit,ROUND(SUM(IF(((type='LE' AND (CONVERT(opid USING utf8) COLLATE utf8_general_ci)='2') OR type IN ('BA','MO')),credit,0)),2) AS credit,ROUND(SUM(IF(SUBSTRING(invno,1,3)='JOU' AND debit>0,debit,0)),2) AS jdebit,ROUND(SUM(IF(SUBSTRING(invno,1,3)='JOU' AND credit>0,credit,0)),2) AS jcredit,apdate FROM (SELECT id,(CASE WHEN dty='$type' THEN did WHEN cty='$type' THEN cid END) AS sid,(CASE WHEN dty='$type' THEN cty WHEN cty='$type' THEN dty END) AS type,(CASE WHEN dty!='$type' THEN did WHEN cty!='$type' THEN cid END)  AS opid,(CASE WHEN dty!='$type' THEN CONCAT(dty,did) WHEN cty!='$type' THEN CONCAT(cty,cid) END)  AS seid,IF(dty='$type',amo,0) AS debit,IF(cty='$type',amo,0) AS credit,invno,ref,apdate,TIME(date) AS time FROM tbl_traledger WHERE (dty='$type' AND (CONVERT(did USING utf8) COLLATE utf8_general_ci)='$id') OR (cty='$type' AND (CONVERT(cid USING utf8) COLLATE utf8_general_ci)='$id')) AS curep GROUP BY invno) AS rec WHERE apdate BETWEEN '$fdate' AND '$tdate'),0) AS result";    
}
$opval=mysqli_query($con,$sql) or die(mysqli_error($con));    
$opv=mysqli_fetch_array($opval);
return $opv['result'];    
}
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
<div class="row">
<div class="col-md-12">
<div class="col-md-3">    
<div class="box box-solid">

<div class="box-body">
<div class="col-md-12">    
<div class="row">    
<div class="roles-menu">   
<ul class="nav">
<li <?php if($ractive=='A'){echo 'class="active"';}?>><a href="rep_payabsuli.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Supplier List';}else{echo ' সরবরাহকারীর তালিকা';}?></a></li>
<li <?php if($ractive=='B'){echo 'class="active"';}?>><a href="rep_payabsubal.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Supplier Balance';}else{echo ' সরবরাহকারীর ব্যালেন্স';}?></a></li>
<li <?php if($ractive=='C'){echo 'class="active"';}?>><a href="rep_payabsustm.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Supplier Statement';}else{echo ' সরবরাহকারীর  প্রতিবেদন';}?></a></li>
<li <?php if($ractive=='D'){echo 'class="active"';}?>><a href="rep_payabsuitmst.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Supplier Statement (Item)';}else{echo ' সরবরাহকারীর প্রতিবেদন পদ অনুযায়ী';}?></a></li>
<li <?php if($ractive=='E'){echo 'class="active"';}?>><a href="rep_payabsuovw.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Supplier Overview';}else{echo ' সরবরাহকারীর ওভারভিউ';}?></a></li>    
</ul>
</div>
</div>
<hr>    
<form action="rep_payabsustm.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<!--From Data-->
<div class="col-md-12">    
<div class="row">
<?php if($uty=='1'){?>   
<div class="form-group" >
<label>Branch</label>
<div class="input-group">
<span class="input-group-addon">BR</span>
<select class="form-control select2" name="ibrid" id="ibrid">
<option <?php if($ibrid=='A'){echo 'selected';}?> value="A">-All Branch-</option>
<option <?php if($ibrid=='0'){echo 'selected';}?> value="0">-Corporate Branch-</option>    
<?php									
$querymt=mysqli_query($con,"SELECT id,name FROM tbl_branch ORDER BY name ASC")or die(mysqli_error($con));
while ($rowmt=mysqli_fetch_array($querymt)){
?>
<?php if($rowmt['id']==$ibrid){?>
<option selected value="<?php echo $rowmt['id'];?>"><?php echo $rowmt['name'];?></option>
<?php }else{ ?>    
<option value="<?php echo $rowmt['id'];?>"><?php echo $rowmt['name'];?></option>
<?php } ?>    
<?php } ?>
</select>
</div>
</div>    
<?php } ?>    
</div>
</div>    
<div class="col-md-12">    
<div class="row">  
<div class="form-group" >
<label>Customer</label>
<div class="input-group">
<span class="input-group-addon">SU</span>
<select class="form-control select2" name="cusid" id="cusid">   
<?php
if($ibrid=='A'){
$sql="SELECT cus.cusid,det.name,det.cnumber,det.cemail FROM (SELECT DISTINCT IF(dty='SU',did,cid) AS cusid FROM tbl_traledger WHERE (dty='SU' AND did!=0) OR (cty='SU' AND cid!=0)) cus LEFT JOIN (SELECT id,name,cnumber,cemail FROM tbl_supplier) det ON det.id=cus.cusid ORDER BY det.name ASC";    
}else{    
$sql="SELECT cus.cusid,det.name,det.cnumber,det.cemail FROM (SELECT DISTINCT IF(dty='SU',did,cid) AS cusid FROM tbl_traledger WHERE ((dty='SU' AND did!=0) OR (cty='SU' AND cid!=0)) AND brid='$ibrid') cus LEFT JOIN (SELECT id,name,cnumber,cemail FROM tbl_supplier) det ON det.id=cus.cusid ORDER BY det.name ASC";
}    
$querycu=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowcu=mysqli_fetch_array($querycu)){
?>
<?php if($rowcu['cusid']==$cusid){?>
<option selected value="<?php echo $rowcu['cusid'];?>"><?php echo $rowcu['name'];?></option>
<?php }else{ ?>    
<option value="<?php echo $rowcu['cusid'];?>"><?php echo $rowcu['name'];?></option>
<?php } ?>    
<?php } ?>
</select>
</div>
</div>       
</div>
</div>
<div class="row"> 
<div class="col-md-6">    
<div class="form-group" >
<label>From</label>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><span class="fa fa-calendar"></span></span>
<input type="text" maxlength="18" class="form-control" name="tfdate" value="<?php echo $fdate; ?>" required autocomplete="off" required>
</div>
</div>
</div>
<div class="col-md-6">    
<div class="form-group" >
<label>To</label>
<div class="input-group date datetimepicker">
<span class="input-group-addon"><span class="fa fa-calendar"></span></span>
<input type="text" maxlength="18" class="form-control" name="ttdate" value="<?php echo $tdate;?>" required autocomplete="off" required>
</div>
</div>
</div>    
</div>    
<!--End From Data-->    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-4"></div>
<div class="col-md-8 text-right" >
<input type="submit" name="filter_submit" id="submit" class="btn btn-flat bg-purple btn-sm " value="Submit"/> <a href="axe_report.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>  
</div>
<div class="col-md-9">
<div class="row">    
<div class="side-head"> 
<div class="col-md-12">    
<div class="col-md-4 text-left">
<button class="btn btn-flat bg-teal" id="print"><i class="fa fa-print"></i></button> 
<button class="btn btn-flat bg-blue"><i class="fa fa-envelope-o"></i></button> 
<button class="btn btn-flat bg-gray"><i class="fa fa-file-pdf-o"></i></button>     
</div>
<div class="col-md-7 text-center">
<select name="Page_resolution" id="resolution" onchange="setPrinterConfig()" style="width: 205px;height: 28px;border: 1px solid red;">
<option value="A4" selected="selected">A4 [210mm × 297mm]</option>   
<option value="A5">A5 [148mm × 210mm]</option>
<option value="Letter">US Letter [216mm × 279mm]</option>
<option value="Legal">US Legal [216mm × 356mm]</option>
</select>
<select name="Page_size" id="rotate" onchange="setPrinterConfig()" style="width: 120px;height: 28px;border: 1px solid red;">
<option value="portrait">Portrait</option>
<option value="landscape">Landscape</option>
</select>    
</div>    
<div class="col-md-1 text-right">

</div>
</div>
</div>    
</div>
<div class="row">
<div class="invhold scrol-y" id="invhold">
<div class="printableArea">
<style media="all" type="text/css">
  @font-face {
    font-family: 'WebFont-Open Sans';
    src: local(Open Sans), url(https://fonts.gstatic.com/s/opensans/v14/K88pR3goAWT7BTt32Z01m4X0hVgzZQUfRDuZrPvH3D8.woff2);
  }

  .pcs-template {
  	font-family: Open Sans, 'WebFont-Open Sans';
    font-size: 9pt;
    color: #333333;
      background:  #ffffff ;
  }

  .pcs-header-content {
    font-size: 9pt;
	color: #333333;
	background-color: #ffffff;
  }
  .pcs-template-body {
  	padding: 0 0.400000in 0 0.550000in;
  }
  .pcs-template-footer {
  	height: 0.700000in;
	font-size: 6pt;
	color: #aaaaaa;
	padding: 0 0.400000in 0 0.550000in;
	background-color: #ffffff;
  }
  .pcs-footer-content {
  word-wrap: break-word;
  color: #aaaaaa;
      border-top: 1px solid #adadad;
  }

  .pcs-label {
    color: #333333;
  }
  .pcs-entity-title {
    font-size: 16pt;
    color: #000000;
  }
  .pcs-orgname {
    font-size: 10pt;
    color: #333333;
  }
  .pcs-customer-name {
    font-size: 9pt;
    color: #333333;
  }
 .pcs-itemtable-header {
    font-size: 9pt;
    color: #ffffff;
    background-color: #3c3d3a;
  }
  .pcs-itemtable-breakword {
    word-wrap: break-word;
  }
  .pcs-taxtable-header {
    font-size: 9pt;
    color: #ffffff;
    background-color: #3c3d3a;
  }
  .breakrow-inside {
    page-break-inside: avoid;
  }
  .breakrow-after {
    page-break-after:auto;
  }
  .pcs-item-row {
    font-size: 9pt;
    border-bottom: 1px solid #adadad;
    background-color: #ffffff;
    color: #000000;
  }
  .pcs-item-sku {
    margin-top: 2px;
  	font-size: 10px;
  	color: #444444;
  }
  .pcs-item-desc {
      color: #727272;
      font-size: 9pt;
   }
  .pcs-balance {
    background-color: #f5f4f3;
    font-size: 9pt;
    color: #000000;
  }
  .pcs-totals {
    font-size: 9pt;
    color: #000000;
    background-color: #ffffff;
  }
  .pcs-notes {
    font-size: 8pt;
  }
  .pcs-terms {
    font-size: 8pt;
  }
  .pcs-header-first {
	background-color: #ffffff;
	font-size: 9pt;
	color: #333333;
      height: auto;
	}

 .pcs-status {
 	color: ;
	font-size: 15pt;
	border: 3px solid ;
	padding: 3px 8px;
 }
 .billto-section {
     padding-top: 0mm;
     padding-left: 0mm;
   }
   .shipto-section {
     padding-top: 0mm;
     padding-left: 0mm;
   }

 @page :first {
 	@top-center {
		content: element(header);
	}
    margin-top: 0.700000in;
  }

  .pcs-template-header {
	padding: 0 0.400000in 0 0.550000in;
    height: 0.700000in;
  }

  .pcs-template-fill-emptydiv {
    display: table-cell;
    content: " ";
    width: 100%;
  }


/* Additional styles for RTL compat */

/* Helper Classes */

.inline {
  display: inline-block;
}
.v-top {
  vertical-align: top;
}
.text-align-right {
  text-align: right;
}
.rtl .text-align-right {
  text-align: left;
}
.text-align-left {
  text-align: left;
}
.rtl .text-align-left {
  text-align: right;
}

/* Helper Classes End */

.item-details-inline {
  display: inline-block;
  margin: 0 10px;
  vertical-align: top;
  max-width: 70%;
}

.total-in-words-container {
  width: 100%;
  margin-top: 10px;
}
.total-in-words-label {
  vertical-align: top;
  padding: 0 10px;
}
.total-in-words-value {
  width: 170px;
}
.total-section-label {
  padding: 5px 10px 5px 0;
  vertical-align: middle;
}
.total-section-value {
  width: 120px;
  vertical-align: middle;
  padding: 10px 10px 10px 5px;
}
.rtl .total-section-value {
  padding: 10px 5px 10px 10px;
}

.tax-summary-description {
  color: #727272;
  font-size: 8pt;
}

.bharatqr-bg {
  background-color: #f4f3f8;
}

/* Overrides/Patches for RTL compat */
  .rtl th {
    text-align: inherit; /* Specifically setting th as inherit for supporting RTL */
  }
/* Overrides/Patches End */


/* Subject field styles */
.subject-block {
    margin-top: 20px;
}
.subject-block-value {
    word-wrap: break-word;
    white-space: pre-wrap;
    line-height: 14pt;
    margin-top:5px;
}
/* Subject field styles End*/
</style>
<style>
    .trclass_evenrow { background-color:#f6f5f5; }
    .trclass_oddrow { background-color: #ffffff; }

    table {
      -fs-table-paginate: paginate;
    }
    .title-section {
      float: right;
      margin-top:20px;
    }
    .rtl .title-section {
      float: left;
    }
    .pcs-itemtable-header {
      padding: 4px 4px;
    }
    .summary-section {
      float: right;
    }
    .rtl .summary-section {
      float: left;
    }
    .box-padding {
      padding:8px 4px;
    }
    </style>
<div class="pcs-template ">
<div class="pcs-template-header pcs-header-content" id="header">
<div class="pcs-template-fill-emptydiv"></div>
</div>


<div class="pcs-template-body">
<table style="line-height:18px;" cellpadding="0" cellspacing="0" border="0" width="100%">
<tbody><tr>
<td>
<img src="../img/<?php if(empty(get_cominfo('1','logo'))){echo "no_logo.png";}else{echo get_cominfo('1','logo');}?>" alt="<?php echo get_cominfo('1','name');?>" style="width:100.00px;height:87.00px;" id="logo_content">
</td>

<td width="50%" class="pcs-orgname text-align-right">
<b><?php echo get_cominfo('1','name');?></b><br>
<span style="white-space: pre-wrap;" id="tmp_org_address"><?php echo get_cominfo('1','');?></span>
</td>
</tr>
<tr>
<td colspan="2">
<table cellpadding="0" cellspacing="0" border="0" class="title-section">
<tbody><tr>
<td class="pcs-entity-title" style="padding-top:6px;line-height:30px;"><b>Statement of Accounts</b></td>
</tr>
<tr>
<td style="font-size:12px; border-top: 1px solid #000;border-bottom: 1px solid #000;" height="24" class="text-align-right"><?php echo date('d M Y', strtotime($fdate)).' To '.date("d M Y", strtotime($tdate));?></td>
</tr>
</tbody></table>
</td>
</tr>
<tr>
<td style="padding:20px 0px 0px 5px;">
<table cellpadding="0" cellspacing="0" border="0" width="70%">
<tbody><tr>
<td class="pcs-label"><b>To</b></td>
</tr>
<tr>
<td>
<span style="white-space: pre-wrap;" id="tmp_billing_address"><strong><span class="pcs-customer-name" id="zb-pdf-customer-detail"><?php if($type=='CU'){echo get_csinfogen($cusid,'tbl_customer');}else{echo get_csinfogen($cusid,'tbl_supplier');}?></span></strong></span>
</td>
</tr>
</tbody></table>
</td>
<td style="padding:20px 0px 30px 0px;" valign="bottom">
<table cellpadding="5" cellspacing="0" width="79%" border="0" class="summary-section">
<tbody><tr>
<td class="pcs-label" style="padding:4px 6px 4px 6px; border-bottom:1px solid #dcdcdc;" bgcolor="#e8e8e8" colspan="5"><b>Account Summary</b></td>
</tr>
<tr>
<td class="pcs-label" style="padding-top:6px;" width="50%">Opening Balance</td>
<td style="padding:6px 0px 0px 6px;" class="text-align-right"><?php echo numtolocal(st_opval($type,$cusid,$fdate,get_fild_data('tbl_currency','1','symbol')));?></td>
</tr>
<tr>
<td class="pcs-label" style="padding-top:4px;">Debit Amount</td>
<td style="padding:6px 0px 0px 6px;" class="text-align-right"><?php echo numtolocal(st_drcrbal($type,$cusid,$fdate,$tdate,'D'),get_fild_data('tbl_currency','1','symbol'));?></td>
</tr>
<tr>
<td class="pcs-label">Credit Amount</td>
<td style="padding:4px 0px 2px 6px;" class="text-align-right"><?php echo numtolocal(st_drcrbal($type,$cusid,$fdate,$tdate,'C'),get_fild_data('tbl_currency','1','symbol'));?></td>
</tr>
<?php 
$stclbal=((st_opval($type,$cusid,$fdate)+st_drcrbal($type,$cusid,$fdate,$tdate,'D'))-st_drcrbal($type,$cusid,$fdate,$tdate,'C'))    
?>    
<tr>
<td class="pcs-label" style="padding-top:6px;border-top:1px solid #000;">Outstanding Balance</td>
<td style="padding:6px 0px 0px 6px;border-top:1px solid #000;" class="text-align-right"><?php echo numtolocal($stclbal,get_fild_data('tbl_currency','1','symbol'));?></td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>
<table style="line-height:18px;margin-top:10px;" cellpadding="2" cellspacing="0" border="0" width="100%" class="trpadding">
<thead>
<tr height="26">
<th width="15%" class="pcs-itemtable-header"><b>Date</b></th>
<th width="14%" class="pcs-itemtable-header"><b>Transactions</b></th>
<th width="25%" class="pcs-itemtable-header"><b>Details</b></th>
<th width="13%" class="text-align-right pcs-itemtable-header"><b>Amount</b></th>
<th width="13%" class="text-align-right pcs-itemtable-header"><b>Payments</b></th>
<th width="20%" class="text-align-right pcs-itemtable-header"><b>Balance</b></th>
</tr>
</thead>
<tbody class="itemBody">
<?php    
if($type=='SU'){
$sty=",'CLA'";
$wty="";    
}else{
$wty=",'CLA'";    
$sty="";    
}    
$stotdebit=0; $stotcredit=0;    
$sopdate=$fdate;    
$sopval=st_opval($type,$cusid,$sopdate);
    
$sql="SELECT apdate,invty,invno,ref,debit,credit,@b := ROUND((@b + debit - credit),2) AS balance FROM (SELECT @b := ".$sopval.") AS dummy CROSS JOIN (SELECT apdate,time,invty,invno,ref,IF(invty IN ('PAV','PRE','SEL','SER','PDR','BSC'".$sty."),amount,(debit+jcredit)) AS debit,IF(invty IN ('PUR','REV','SRE'".$wty."),amount,(credit+jcredit)) AS credit FROM (SELECT SUBSTRING(invno,1,3) AS invty,invno,ROUND(ABS(IF(SUBSTRING(invno,1,3) IN ('REV','PAV'),SUM(debit-credit),SUM(IF(type NOT IN('BA','MO') AND seid NOT IN ('LE2'),debit-credit,0)))),2) AS amount,ROUND(SUM(IF(((type='LE' AND (CONVERT(opid USING utf8) COLLATE utf8_general_ci)='2') OR type IN ('BA','MO')),debit,0)),2) AS debit,ROUND(SUM(IF(((type='LE' AND (CONVERT(opid USING utf8) COLLATE utf8_general_ci)='2') OR type IN ('BA','MO')),credit,0)),2) AS credit,ROUND(SUM(IF(SUBSTRING(invno,1,3)='JOU' AND debit>0,debit,0)),2) AS jdebit,ROUND(SUM(IF(SUBSTRING(invno,1,3)='JOU' AND credit>0,credit,0)),2) AS jcredit,ref,apdate,time FROM (SELECT id,(CASE WHEN dty='$type' THEN did WHEN cty='$type' THEN cid END) AS sid,(CASE WHEN dty='$type' THEN cty WHEN cty='$type' THEN dty END) AS type,(CASE WHEN dty!='$type' THEN did WHEN cty!='$type' THEN cid END)  AS opid,(CASE WHEN dty!='$type' THEN CONCAT(dty,did) WHEN cty!='$type' THEN CONCAT(cty,cid) END)  AS seid,IF(dty='$type',amo,0) AS debit,IF(cty='$type',amo,0) AS credit,invno,ref,apdate,TIME(date) AS time FROM tbl_traledger WHERE (dty='$type' AND (CONVERT(did USING utf8) COLLATE utf8_general_ci)='$cusid') OR (cty='$type' AND (CONVERT(cid USING utf8) COLLATE utf8_general_ci)='$cusid')) AS curep GROUP BY invno) AS rec WHERE apdate BETWEEN '$sopdate' AND '$today') AS stdata ORDER BY apdate ASC,time ASC";
?>    
<tr class="trclass_oddrow breakrow-inside breakrow-after">
<td class="box-padding"><?php echo date('d M Y', strtotime($fdate)); ?></td>
<td class="box-padding">***Opening Balance***</td>
<td class="box-padding"></td>
<td class="text-align-right box-padding"><?php echo numtolocal($sopval,'');?></td>
<td class="text-align-right box-padding"></td>
<td class="text-align-right box-padding"><?php echo numtolocal($sopval,'');?></td>
</tr> 
<?php    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$stotdebit+=$row['debit'];
$stotcredit+=$row['credit'];
if($row['invty']=='SEL'){
$icon='Sales Invoice';    
}elseif($row['invty']=='PUR'){
$icon='Purchase Invoice';
}elseif($row['invty']=='SER'){
$icon='Service Invoice';
}elseif($row['invty']=='SRE'){
$icon='Sales Return';
}elseif($row['invty']=='PRE'){
$icon='Paurchase Return';
}elseif($row['invty']=='PAV'){
$icon='Payment Receipt';
}elseif($row['invty']=='REV'){
$icon='Collection Receipt';
}elseif($row['invty']=='CLA'){
$icon='Warranty Claim';
}elseif($row['invty']=='PDR'){
$icon='Damage Purchase';
}elseif($row['invty']=='BSC'){
$icon='Bad Stock Claim';    
}    
?>    
<tr class="trclass_oddrow breakrow-inside breakrow-after">
<td class="box-padding"><?php echo date("d M Y", strtotime($row['apdate']));?></td>
<td class="box-padding"><?php echo $icon.' <strong>'.$row['invno'].'</strong>';?></td>
<td class="box-padding"><?php echo $row['ref'];?></td>
<td class="text-align-right box-padding"><?php if($row['debit']>0){echo '<strong>'.numtolocal($row['debit'],'').'</strong>';}?></td>
<td class="text-align-right box-padding"><?php if($row['credit']>0){echo '<strong>'.numtolocal($row['credit'],'').'</strong>';}?></td>
<td class="text-align-right box-padding"><strong><?php if($row['balance']>0){echo numtolocal(ABS($row['balance']),'').'&nbsp;&nbsp;[ + ]';}else{echo numtolocal(ABS($row['balance']),'').'&nbsp;&nbsp;[ - ]';}?></strong></td>
</tr>
<?php } ?>
</tbody>
</table>
<table width="100%" style="border-top: 1px solid #dcdcdc;">
<tbody>
<tr>
<td></td>
<td width="50%">
<table width="100%">
<tbody>
<tr>
<td width="50%" class="box-padding" align="right" valign="middle"><b>Outstanding Balance</b></td>
<td class="box-padding" align="right" valign="middle"><strong><?php echo numtolocal($stclbal,'');?></strong></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
  
</div>
<div class="pcs-template-footer">
<div>
      
</div>  
</div>
</div>    
</div>    
    
</div>
</div>
</div>
    
</div>    
</div> 

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(function(){
$('.invhold').css({ height: $(window).innerHeight()-190 });
$(window).resize(function(){
$('.invhold').css({ height: $(window).innerHeight()-190 });
});
});   
</script>    
<!-- /page script -->
</html>    