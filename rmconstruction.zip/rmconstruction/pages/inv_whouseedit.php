<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='inv_whouseedit.php';   
$cuPage='inv_whouseedit.php';    
$aid=$_SESSION['uid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='inventor';
$menuh='Inventory';
$phead='wholist';
$page='Warehouse Edit';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['update_whouse'])){
    $warid = remove_junk(escape($_POST['warid']));
	$name = ucwords(remove_junk(escape($_POST['name'])));
    //$bname = remove_junk(escape($_POST['bname']));
    $phone = remove_junk(escape($_POST['phone']));
    $email = remove_junk(escape($_POST['email']));
    $address = remove_junk(escape($_POST['address']));
	//$baddress = $_POST['baddress'];
    
	if(isset($_POST['name'])){
	//$ducode = mysqli_query($con,"SELECT * FROM tbl_warehouse WHERE ((name IS NOT NULL AND name = '$name') OR (bname IS NOT NULL AND bname='$bname')) AND id!='$warid'");
    $ducode = mysqli_query($con,"SELECT * FROM tbl_warehouse WHERE name = '$name' AND id!='$warid'");    
	}
	
	if($ducode->num_rows > 0) {
		save_msg('i','Warehouse alrady exists! Plz try another');
		echo "<script>window.location='inv_whouselist.php'</script>";
	}else{
    //$sql="UPDATE tbl_warehouse SET name='$name',bname='$bname',address='$address',baddress='$baddress',phone='$phone',email='$email' WHERE id='$warid'"; $result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $sql="UPDATE tbl_warehouse SET name='$name',address='$address',phone='$phone',email='$email' WHERE id='$warid'"; $result = mysqli_query($con,$sql) or die(mysqli_error($con));    
    $efid=mysqli_affected_rows($con);    
    if($efid>0){
    $act =remove_junk(escape('Warehouse name: '.$name));    
    write_activity($aid,'WAR','Warehouse has been Updated',$act);
    save_msg('s','Data Successfully Update!');    
    }else{
    save_msg('w','Data Fail to Update!');    
    }
    echo "<script>window.location='inv_whouselist.php'</script>";  
	}  
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Edit Warehouse';}else{echo 'গুদাম ঘরের (ওয়্যারহাউজ) হালনাগাদ করুন';}?></h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="inv_whouseedit.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">    

<div class="row">
<div class="col-md-12">
<div class="col-md-2"></div>
<div class="col-md-8">
<div class="col-md-12">
<?php 
if(isset($_POST['editwar'])){
$ids = $_POST['editwar'];
$sql="SELECT * FROM tbl_warehouse WHERE id='".$ids."' ORDER BY id ASC LIMIT 1";    
$admin=mysqli_query($con,$sql) or die(mysqli_error($con));    
$adm=mysqli_fetch_array($admin);
?>     
<div class="row">   
<div class="form-group">
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Name';}else{echo 'নাম (ইংলিশ)';}?></label>
<input type="text" name="name" maxlength="45" value="<?php echo $adm['name'];?>" id="name" class="form-control" placeholder="e.g. Taltola" />
<input type="hidden" maxlength="11" value="<?php echo $adm['id'];?>" class="form-control" name="warid" autocomplete="off" readonly>
</div>
<!--<div class="form-group">
<label><?php //if(get_fild_data('tbl_setting','1','sval')==0){echo 'Name (Bangla)';}else{echo 'নাম (বাংলায়)';}?></label>
<input type="text" name="bname" maxlength="255" value="" id="bname" class="form-control" placeholder="e.g. তালতলা" />
</div>-->    
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group" >
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Phone';}else{echo 'ফোন';}?></label>
<input type="text" name="phone" maxlength="18" value="<?php echo $adm['phone'];?>" id="phone" class="form-control" placeholder="e. g. 0161xx700xx" />    
</div>
</div>
<div class="col-md-6">
<div class="form-group" >
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Email';}else{echo 'ইমেইল';}?></label>
<input type="text" name="email" maxlength="45" value="<?php echo $adm['email'];?>" id="email" class="form-control" placeholder="e.g. info@axesgl.com" />     
</div>
</div>    
</div>
<div class="row">
<div class="form-group">
<label><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Address (English)';}else{echo 'ঠিকানা (ইংলিশ)';}?></label>
<textarea class="form-control" maxlength="250" rows="6" name="address" id="address" placeholder="Address"><?php echo $adm['address'];?></textarea>
</div>
<!--<div class="form-group">
<label><?php //if(get_fild_data('tbl_setting','1','sval')==0){echo 'Address (Bengoli)';}else{echo 'ঠিকানা (বাংলায়)';}?></label>
<textarea class="form-control" maxlength="350" rows="6" name="baddress" id="baddress" placeholder="ঠিকানা"><?php //echo $adm['baddress'];?></textarea>
</div>-->    
</div>
<?php } ?>    
</div>
</div>    
<div class="col-md-2"></div>    
</div>    
</div>    
    
</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="submit" name="update_whouse" id="submit" class="btn btn-flat bg-purple btn-sm " value="<?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Update';}else{echo 'হালনাগাদ';}?>"/> <a href="inv_whouselist.php" class="btn btn-flat bg-gray"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'Close';}else{echo 'বন্দ';}?></a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo 'History';}else{echo 'ইতিহাস';}?> </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'WAR','A');}else{echo read_activity($aid,'WAR','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>    

<?php include('../layout/quick.php');?>     
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
<?php if(get_fild_data('tbl_setting','1','sval')==0){?>    
var name = new LiveValidation('name');
name.add(Validate.Presence);
    
var address = new LiveValidation('address');
address.add(Validate.Presence);    
<?php }else{ ?>
var bname = new LiveValidation('bname');
bname.add(Validate.Presence); 
    
var baddress = new LiveValidation('baddress');
baddress.add(Validate.Presence);    
<?php } ?>
var phone = new LiveValidation('phone');
phone.add(Validate.Presence);
var address = new LiveValidation('address');
address.add(Validate.Presence);
var email = new LiveValidation('email');
email.add(Validate.Email);    
});   
</script>    
<!-- /page script -->
</html>    