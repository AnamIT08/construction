<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('28','creates','R');     
$_SESSION['cuPages']='acc_joulcreate.php';   
$cuPage='acc_joulcreate.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='account';
$menuh='Account';
$phead='joucre';
$page='Journal Create';
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php 
if(isset($_POST['save_journal'])){
	//if(!isset($_SESSION['axes_joudata'])){
    //save_msg('w','No Journal data found!!');
	//echo "<script>window.location='acc_joulcreate.php'</script>";
    //exit;    
    //}
    
	if(!isset($_SESSION['axes_jouitem'])){
    save_msg('w','No Journal Head found!!');
	echo "<script>window.location='acc_joulcreate.php'</script>";
    exit;    
    }
    
    $jouno = gen_newinvno('tbl_journal','JOU');
    $apdate = remove_junk(escape($_POST['apdate']));
    $prjid = remove_junk(escape($_POST['prjid']));
    $epjid = remove_junk(escape($_POST['prjid']));
    if($prjid==''){$prjid='NULL'; $prjno='NULL';}else{$prjid="'".$prjid."'"; $prjno="'".get_fild_data('tbl_project',$epjid,'prjid')."'";}
    $note = remove_junk(escape($_POST['note']));
    $total = total_jouvalue();
    
    $sql="INSERT INTO tbl_journal (invno,note,amount,apdate,pjid,brid,uid,date) VALUES ('$jouno','$note','$total','$apdate',$prjid,'$brid','$aid','$dtnow')";    
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $sid=$con->insert_id;
    $efid=mysqli_affected_rows($con);
    
    if($efid>0){
    if(isset($_SESSION['axes_jouitem'])){
    if(is_array($_SESSION['axes_jouitem'])){
    $max=count($_SESSION['axes_jouitem']);
    for($i=0;$i<$max;$i++){
     
    $dty = $_SESSION['axes_jouitem'][$i]['dty'];
    $did=$_SESSION['axes_jouitem'][$i]['did'];    
    $amo=$_SESSION['axes_jouitem'][$i]['amo'];
    $cid=$_SESSION['axes_jouitem'][$i]['cid'];
    $cty=$_SESSION['axes_jouitem'][$i]['cty'];   
    $chkno=$_SESSION['axes_jouitem'][$i]['chkno'];
    $chkdt=$_SESSION['axes_jouitem'][$i]['chkdt'];
    if($chkno=='' || strlen($chkno)<2){$chkdt='NULL';$chkno='NULL';}else{$chkdt="'".$chkdt."'";$chkno="'".$chkno."'";}    
    $ref=$_SESSION['axes_jouitem'][$i]['ref'];
        
    $sql="INSERT INTO tbl_trarecord (invno,pjid,prjno,dty,did,amo,cid,cty,chkno,chkdt,ref,curid,xrate,apdate,brid,uid,date) VALUES ('$jouno',$prjid,$prjno,'$dty','$did','$amo','$cid','$cty',$chkno,$chkdt,'$ref','0','0','$apdate','$brid','$aid','$dtnow')";
    mysqli_query($con,$sql) or die(mysqli_error($con)); 
        
    }}}
    unset($_SESSION['axes_joudata']);
    unset($_SESSION['axes_jouitem']);    
    $act =remove_junk(escape('Journal No: '.$jouno));    
    write_activity($aid,'JOU','Journal has been Added',$act);    
    save_msg('s','Data Successfully Saved!');
    }else{
    save_msg('w','Data Fail to Saved!');    
    }
    echo "<script>window.location='acc_joulcreate.php'</script>";  
	}  
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Add Journal</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="acc_joulcreate.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">
<div class="row">    
<center>
<h3 class="page-title">JOURNAL VOUCHER</h3>
</center>
</div>
<br>    
<div class="row">
<div class="col-md-4">
<div class="form-group" >
<div class="input-group">
<span class="input-group-addon"><b>Journal No</b></span>    
<input type="text" class="form-control" maxlength="15" name="invno" id="invno" value="<?php if(isset($_SESSION['axes_joudata']['invno'])){$_SESSION['axes_joudata']['invno']=gen_newinvno('tbl_journal','JOU');echo $_SESSION['axes_joudata']['invno'];}else{echo gen_newinvno('tbl_journal','JOU');}?>" placeholder="e.g. JOU010120101" autocomplete="off">
</div>    
</div>
<div class="form-group" >
<div class="input-group">
<span class="input-group-addon"><b>Date:</b></span>     
<input type="text" class="form-control datetimepicker" name="apdate" id="apdate" value="<?php if(isset($_SESSION['axes_joudata']['date'])){echo $_SESSION['axes_joudata']['date'];}else{echo date('Y-m-d');}?>" placeholder="Date:" autocomplete="off" readonly>
</div>    
</div>
<div class="form-group" >
<div class="input-group">
<span class="input-group-addon"><b>Project:</b></span>    
<select class="form-control select2" name="prjid" id="prjid">
<option value="">-Select-</option>
<?php
$sql="SELECT * FROM tbl_project WHERE status IN ('0','1') ORDER BY date DESC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($prj=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $prj['id'];?>"><?php echo $prj['prjid'];?></option>
<?php } ?>
</select>    
</div>   
</div>    
</div>
<div class="col-md-8">
<div class="form-group">
<label>Narration</label>
<textarea class="form-control" name="note" id="note" maxlength="250" rows="5" placeholder="e.g. Narration"><?php if(isset($_SESSION['axes_joudata']['note'])){echo $_SESSION['axes_joudata']['note'];}?></textarea>
</div>    
</div>
</div>
<div class="row">
<div class="col-md-12">
<table class="table table-bordered table-striped">
<thead>
<tr>
<th rowspan="2" style="text-align:center;"></th>    
<th colspan="2" style="text-align:center;">Debit</th>
<th rowspan="2" style="text-align:center;">Amount</th>
<th colspan="2" style="text-align:center;">Credit</th>
<th colspan="2" style="text-align:center;">Cheque Details</th>
<th rowspan="2" style="text-align:center;">Ref.</th>
<th rowspan="2" style="text-align:center;"><a class="empty" style="cursor: pointer;"><i class="fa fa-trash"></i></a></th>    
</tr>
<tr>
<th style="text-align:center;">Sub-Group</th>
<th style="text-align:center;">Ledger</th>
<th style="text-align:center;">Ledger</th>
<th style="text-align:center;">Sub-Group</th>
<th style="text-align:center;">Cheque No</th>
<th style="text-align:center;">Date</th>    
</tr>    
<tr>
<th style="width:30px;">SN</th>    
<th style="width:200px;">
<select class="form-control select2" name="dsgrid" id="dsgrid" onchange="getDebitledger(this.value)">
<option value="">-Select-</option>
<?php
$sql="SELECT * FROM tbl_acsubgroup ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>       
</th>
<th style="width:200px;">
<select class="form-control select2" name="did" id="did">
<option value="">-Select-</option>
</select>         
</th>
<th style="width:120px;">
<input type="text" maxlength="10" class="form-control" name="amo" id="amo"  onkeypress="return isNumberKey(event)" placeholder="e.g. 500" autocomplete="off">    
</th>
<th style="width:200px;">
<select class="form-control select2" name="cid" id="cid">
<option value="">-Select-</option>
</select>    
</th>
<th style="width:200px;">
<select class="form-control select2" name="csgrid" id="csgrid" onchange="getCreditledger(this.value)">
<option value="">-Select-</option>
<?php
$sql="SELECT * FROM tbl_acsubgroup ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>    
</th>
<th style="width:150px;">
<input type="text" maxlength="25" class="form-control" name="chkno" id="chkno" placeholder="e.g. KA56458976" autocomplete="off">    
</th>
<th style="width:100px;">
<input type="text" class="form-control datetimepicker" id="chkdt" value="" placeholder="Date:" autocomplete="off" readonly>
</th>
<th style="width:200px;">
<input type="text" maxlength="35" class="form-control" name="ref" id="ref" placeholder="e.g. KA56458976" autocomplete="off">    
</th>
<th style="width:30px;"><a class="btn btn-flat bg-purple" href="#" id="addjou"><i class="fa fa-plus"></i></a></th>    
</tr>    
</thead>
<tbody id="itemdata">

</tbody>
<tfoot id="itemfoot">
    
</tfoot>    
</table>    
</div>
</div>    
    
</div>    
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="joureset" class="btn btn-flat bg-red btn-sm " value="Reset"/>    
<input type="submit" name="save_journal" id="submit" class="btn btn-flat bg-purple btn-sm" value="Save"/> <a href="acc_joulist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
</div>    

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function (){ 
var apdate = new LiveValidation('apdate');
apdate.add(Validate.Presence);
});

ReadData();
function ReadData(){
$.ajax({
url: "acc_jouview.php",
method: "POST",
data:{ 
body:1
},
success: function(data){
$('#itemdata').html(data);
}
})

$.ajax({
url: "acc_jouview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})    
};    

function ReadFoot(){
$.ajax({
url: "acc_jouview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})	
}

$(document).on('click', '#addjou', function(e) {
dsgrid = $('#dsgrid').val();
did = $('#did').val();
amo = parseFloat($('#amo').val());
cid = $('#cid').val();    
csgrid = $('#csgrid').val();
chkno = $('#chkno').val();
chkdt = $('#chkdt').val();
ref = $('#ref').val();    
toastr.options = {'positionClass': 'toast-top-center'};

if(dsgrid == '-Select-' || dsgrid == ''){
toastr.info('Please Select Debit Sub-Group!');
return;
}    

if(did == '-Select-' || did == ''){
toastr.info('Please Select Debit Ledger!');
return;
}
    
if(isNaN(amo) != false || amo <= 0){
toastr.info('Please Enter Amount!');
return;
}    

if(csgrid == '-Select-' || csgrid == ''){
toastr.info('Please Select Credit Sub-Group!');
return;
}    

if(cid == '-Select-' || cid == ''){
toastr.info('Please Select Credit Ledger!');
return;
}

if(chkno.length>0 && chkno.length<5){
toastr.info('Please Enter Valid Cheque No!');
return;    
}    

if(chkno.length>0){
if(chkdt.length<=0){
toastr.info('Please Enter Cheque Date!');
return;    
}    
}    

$.ajax({
url: 'axe_cart.php',
type: 'post',
data: {getledger:1,dsgrid:dsgrid,did:did,amo:amo,cid:cid,csgrid:csgrid,chkno:chkno,chkdt:chkdt,ref:ref},
success:function(data) {
$("#dsgrid").val("").trigger("change");
$("#did").val("").trigger("change");
$('#amo').val("");
$("#csgrid").val("").trigger("change");
$("#cid").val("").trigger("change");
$('#chkno').val(""); 
$('#chkdt').val("");     
$('#ref').val("");
ReadData();
}
});    
    
e.preventDefault();     
});   

$(document).on('blur change', '#apdate', function() {
$apdate=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
joudate: $apdate
},
dataType: 'json',
success: function(data){
$('#apdate').val(data[0]);
}
});     
});    

$(document).on('blur', '#note', function() {
note = $(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
jounote: note
},
dataType: 'json',
success: function(data){
$('#note').val(data[0]);
}
});     
});     

$(document).on('click','.empty',function() {
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
joudata: 1
},
success: function(data){
ReadData();    
}
});    
});    

$(document).on('click', '.remove', function () {
var id = $(this).attr('id');
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
jouremove: id
},
success: function(data){
ReadData();
}
});    
});

$(document).on('click','#joureset',function() {
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
jouclear: 1
},
success: function(data){
$("#note").val("");   
ReadData();    
}
});    
});    
    
function getDebitledger(id){
if(id == '-Select-' || id == ''){
return;    
}   
$.ajax({
url: 'axe_getsub.php',
type: 'post',
data: {getledger : 1, sgrid:id},
success:function(data) {
$('#did').html(data);
}
});
};
    
function getCreditledger(id){
if(id == '-Select-' || id == ''){
return;    
}    
$.ajax({
url: 'axe_getsub.php',
type: 'post',
data: {getledger : 1, sgrid:id},
success:function(data) {
$('#cid').html(data);
}
});
};    
</script>    
<!-- /page script -->
</html>