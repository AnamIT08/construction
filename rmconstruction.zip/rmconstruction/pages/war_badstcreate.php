<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='war_manbadstock.php';   
$cuPage='war_manbadstock.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];
$uty=$_SESSION['utype'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='waaranty';
$menuh='Warranty Management';
$phead='badsman';
$page='Create Bad Stock Claim';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-7">
<div class="box box-solid">
<div class="box-body">
<div class="col-md-12">
<div class="row">
<div class="col-md-5">
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-truck"></span></span>     
<select class="form-control select2" name="isupid" id="isupid">   
<?php
$sql="SELECT DISTINCT supid AS id FROM (SELECT pid,colid,sizid,IFNULL(b_in,0) AS b_in,IFNULL(b_out,0) AS b_out,supid,serial,exp_date FROM (SELECT supid,IF(rep_pid IS NULL,pid,rep_pid) AS pid,colid,sizid,b_in,b_out,IF(rep_pid IS NULL,serial,rep_serial) AS serial,exp_date FROM tbl_waranty WHERE b_in>0 AND (b_in-b_out)>0 AND brid='$brid') stwar) wst LEFT JOIN (SELECT id,name,image,code FROM tbl_item) itm ON itm.id=wst.pid ORDER BY name ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($bra=mysqli_fetch_array($query)){
?>   
<option value="<?php echo $bra['id'];?>"><?php echo get_fild_data('tbl_supplier',$bra['id'],'name');?></option>    
<?php } ?>    
</select>
</div>    
</div>    
</div>
<div class="col-md-7">
<div class="form-group">  
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>
<input type="text" class="form-control search" placeholder="e.g. Product Code or Name" autocomplete="off">    
</div>
</div>    
</div>    
</div>
    
<div class="row">
<div class="cart cart-sm">     
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<thead>
<tr>    
<th width="30px" class="text-center">SN</th>
<th width="60px" class="text-center">Image</th>
<th width="380px">Product</th>
<th width="95px" class="text-center">Code</th>
<th width="130px" class="text-center">Serial</th>    
<th width="30px" class="text-center"><i class="fa fa-paper-plane-o"></i></th>
</tr>    
</thead>
</table>
<div class="cart-tra style-3 item" style="padding:0px;">    
<table class="table table-bordered table-striped results" style="margin-bottom: 0;">        
<tbody id="traitem">

</tbody>    
</table>
</div>   
</div>    
</div>    
    
</div>    
</div>
</div>
</div>
<div class="col-md-5">
<div class="box box-solid">
<div class="box-body">

<div class="col-md-12">

<div class="row">
<div class="cart cart-sm">     
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<thead>
<th width="30px">SN</th>
<th width="326px">Item</th>
<th width="144px">Serial</th>
<th width="25px"><a class="empty" style="cursor: pointer;"><i class="fa fa-trash"></i></a></th>    
</thead>
</table>
<div class="cart-msg style-3 item" style="padding:0px;">    
<table class="table table-bordered table-striped" style="margin-bottom: 0;">    
<tbody id="itemdata">

</tbody>    
</table>
</div>
<table class="table table-bordered table-striped" style="margin-bottom: 0;">
<tfoot id="itemfoot">

</tfoot>
</table>    
</div>    
</div>    

<div class="row" id="serialpro">
        
</div>    
  
<div class="row" id="extra">
 
</div>    
    
</div> 
    
</div>
</div>
</div>
</div>
<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->
<?php include('../layout/rside.php'); ?>     
</div>
<?php include('../layout/footer.php');?>
<!-- page script -->
<script type="text/javascript">
ReadItem();
    
function ReadItem(){
$.ajax({
url: "war_badstraitem.php",
method: "POST",
success: function(data) {
$('#traitem').html(data);
}
})
}
    
$(document).on('change', '#isupid', function() {
var ids = $(this).val();
$.ajax({
url: "war_badstraitem.php",
method: "POST",
data: {
supid:ids
},
success: function(data) {
$('#traitem').html(data);
ReadData();
}
});
});

function ReadButon(){
$.ajax({
url: "war_viewbst.php",
method: "POST",
data:{ 
buton:1
},
success: function(data){
$('#extra').html(data);
}
})	
}     
    
ReadData();
function ReadData(){
$.ajax({
url: "war_viewbst.php",
method: "POST",
data:{ 
body:1
},
success: function(data){
$('#itemdata').html(data);
}
})

$.ajax({
url: "war_viewbst.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})
ReadButon();   
};
    
function ReadFoot(){
$.ajax({
url: "war_viewbst.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})	
}
    
$(document).ready(function() {
$(document).on('keyup', '.search', function () {     
var searchTerm = $(".search").val();
var listItem = $('.results tbody').children('tr');
var searchSplit = searchTerm.replace(/ /g, "'):containsi('")
    
$.extend($.expr[':'], {'containsi': function(elem, i, match, array){
return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
}
});
    
$(".results tbody tr").not(":containsi('" + searchSplit + "')").each(function(e){
$(this).css("display", "none");
});

$(".results tbody tr:containsi('" + searchSplit + "')").each(function(e){
$(this).css("display", "");
});

var jobCount = $('.results tbody tr[visible="true"]').length;
$('.counter').text(jobCount + ' item');

if(jobCount == '0') {$('.no-result').show();}
else {$('.no-result').hide();}
});
});

$(document).on('click', '.climbad', function () {    
var id = $(this).attr('id');
pid_arr = $(this).attr('id');
unid = pid_arr.split("_");    
var unqid = unid[1];
   
$.ajax({
url: 'war_badcart.php',
method: "POST",
data:{ 
additem: unqid
},
success: function(data){
ReadData();
}
});    
});
    
$(document).on('click', '.remove', function () {
var id = $(this).attr('id');
$.ajax({
url: 'war_badcart.php',
method: "POST",
data:{ 
remove: id
},
success: function(data){
ReadData();
}
});    
});
    
$(document).on('click', '#emptycart', function () {
var id = $(this).attr('id');    
$.ajax({
url: 'war_badcart.php',
method: "POST",
data:{ 
clear: id
},
success: function(data){
ReadData();
}
});    
});
    
//$(document).on('click', function(e){    
//if (!$(e.target).is(".right-side-add, .side-cont") && !$(e.target).parents(".right-side-add").length && $('.right-side-add').hasClass('open-right-add')) {
//if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }
//$('#addsitem').html('');
//}    
//});
    
$(document).on('click', '#save_claim', function() {     
var suid=$('#isupid').val();    
$.ajax({
url: "war_badcart.php",
method: "POST",
data:{savecla:1,supid:suid},
success: function(data){
$('#addsitem').html(data);
$('.right-side-add').toggle('slide', { direction: 'right' }, 300);     
}
})         
});    
   
$(document).on('click', '#closepop', function() {    
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
});
    
$(document).on('click', '#fincla', function() { 
var cash_data = $('.addtransfer input, .addtransfer textarea');
toastr.options = {'positionClass': 'toast-top-center'};    
if(!chek_error()){   
return;   
}
$.ajax({
url: "war_badcart.php",
data: cash_data,
type: 'post',
dataType: 'json',    
beforeSend: function () {
chek_error();    
},    
success: function(data){
if(data.status === "success"){
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');
ReadItem();    
ReadData();    
toastr.success(data.message);    
}else{
toastr.error(data.message);    
}         
}
})    
});    
</script>    
<!-- /page script -->
</html>    