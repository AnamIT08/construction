<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='opr_pigen.php';   
$cuPage='opr_pigen.php';    
$aid=$_SESSION['uid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='operation';
$menuh='Operation Process';
$phead='pire';
$page='Generate PI';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['save_pinv'])){
	if(!isset($_SESSION['axes_pidata'])){
    save_msg('w','No PI data found!!');
	echo "<script>window.location='opr_pigen.php'</script>";
    exit;    
    }
    
	if(!isset($_SESSION['axes_piitem'])){
    save_msg('w','No PI Product found!!');
	echo "<script>window.location='opr_pigen.php'</script>";
    exit;    
    }
    
    $pino = remove_junk(escape($_SESSION['axes_pidata']['pino']));
    $apdate = remove_junk(escape($_SESSION['axes_pidata']['date']));
    $curid = remove_junk(escape($_SESSION['axes_pidata']['curid']));
    $cusid = remove_junk(escape($_SESSION['axes_pidata']['cusid']));
    $cusname = get_fild_data('tbl_customer',$cusid,'name');    
    $supid = remove_junk(escape($_SESSION['axes_pidata']['supid']));
    $supname = get_fild_data('tbl_supplier',$supid,'name');    
    $terms = remove_junk(escape($_SESSION['axes_pidata']['terms']));
    $dldate = remove_junk(escape($_SESSION['axes_pidata']['dldate']));
    if($dldate!=''){$dldate="'".$dldate."'";}else{$dldate='NULL';}    
    $dldays = remove_junk(escape($_SESSION['axes_pidata']['dldays']));
    if($dldays!=''){$dldays="'".$dldays."'";}else{$dldays='NULL';}    
    $pofemb = remove_junk(escape($_SESSION['axes_pidata']['pofemb'])); 
    $pofdis = remove_junk(escape($_SESSION['axes_pidata']['pofdis']));
    $bfbank = remove_junk(escape($_SESSION['axes_pidata']['bfbank']));
    $bfac = remove_junk(escape($_SESSION['axes_pidata']['bfac']));
    $total = total_pivalue('V');
    $totcom = total_pivalue('C');
    
	if($pino!=''){
	$ducode = mysqli_query($con,"SELECT * FROM tbl_proinv WHERE pino = '$pino'");
	}
	
	if($ducode->num_rows > 0) {
	save_msg('i','PI No alrady exists!!! Data Fail to Save');
	echo "<script>window.location='opr_pigen.php'</script>";
	}else{
    $sql="INSERT INTO tbl_proinv(pino,cusid,cusname,supid,supname,curid,total,totcom,apdate,dldate,dldays,country,pofemb,pofdis,terms,bfbank,bfac,uid,date) VALUES ('$pino','$cusid','$cusname','$supid','$supname','$curid','$total','$totcom','$apdate',$dldate,$dldays,NULL,'$pofemb','$pofdis','$terms','$bfbank','$bfac','$aid','$dtnow')";    
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $sid=$con->insert_id;
    $efid=mysqli_affected_rows($con);    
    if($efid>0){
    if(isset($_SESSION['axes_piitem'])){
    if(is_array($_SESSION['axes_piitem'])){
    $max=count($_SESSION['axes_piitem']);
    for($i=0;$i<$max;$i++){
    $itemid = $_SESSION['axes_piitem'][$i]['itemid'];
    $color = $_SESSION['axes_piitem'][$i]['color'];
    $itemname = $_SESSION['axes_piitem'][$i]['itemname'];
    $qty = $_SESSION['axes_piitem'][$i]['qty'];
    $unit = $_SESSION['axes_piitem'][$i]['unit'];
    $price = $_SESSION['axes_piitem'][$i]['price'];
    $subtot = $_SESSION['axes_piitem'][$i]['subtot'];
    $cfamo = $_SESSION['axes_piitem'][$i]['cfamo'];
    $cp = $_SESSION['axes_piitem'][$i]['cp'];
    $tcamo = $_SESSION['axes_piitem'][$i]['tcamo'];
        
    $sql="INSERT INTO tbl_proinvde (seid,itemid,color,itemname,qty,unit,price,subtot,cfamo,cp,tcamo) VALUES ('$sid','$itemid','$color','$itemname','$qty','$unit','$price','$subtot','$cfamo','$cp','$tcamo')";
    mysqli_query($con,$sql) or die(mysqli_error($con));    
    }}}
    unset($_SESSION['axes_pidata']);
    unset($_SESSION['axes_piitem']);    
    $act =remove_junk(escape('PI No: '.$pino));    
    write_activity($aid,'PIN','New PI has been Added',$act);    
    save_msg('s','Data Successfully Saved!');
    }else{
    save_msg('w','Data Fail to Saved!');    
    }
    echo "<script>window.location='opr_pigen.php'</script>";  
	}  
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Generate Proforma Invoice</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="opr_pigen.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">
<div class="row">    
<center>
<h3 class="page-title">PROFORMA INVOICE</h3>
</center>
</div>
<div class="row">    
<div class="col-md-4 col-md-offset-8">
<div class="form-group" >
<div class="input-group">
<span class="input-group-addon"><b>PI No:</b></span>
<input type="text" class="form-control" maxlength="25" name="invno" id="invno" value="<?php if(isset($_SESSION['axes_pidata']['pino'])){echo $_SESSION['axes_pidata']['pino'];}?>" placeholder="e.g. XHL20191203003-1" autocomplete="off">
</div>
</div>
<div class="form-group" >
<div class="input-group">
<span class="input-group-addon"><b>Date:</b></span>
<input type="text" class="form-control datetimepicker" name="apdate" id="apdate" value="<?php if(isset($_SESSION['axes_pidata']['date'])){echo $_SESSION['axes_pidata']['date'];}?>" placeholder="Date:" autocomplete="off">
</div>
</div>
<div class="form-group" >
<div class="input-group">
<span class="input-group-addon"><b>Currency:</b></span>
<select class="form-control select2" name="curid" id="curid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_currency ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<?php if(isset($_SESSION['axes_pidata']['curid'])){?>
<?php if($rows['id']==$_SESSION['axes_pidata']['curid']){?>
<option selected value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>    
<?php }else{ ?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>    
<?php } ?>    
<?php }else{ ?>    
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>    
<?php } ?>
</select>
</div>
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-4">
<div class="form-group">
<label>Customer/Buyer</label>
<div class="input-group">    
<select class="form-control select2" name="cusid" id="cusid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_customer ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<?php if(isset($_SESSION['axes_pidata']['cusid'])){?>
<?php if($rows['id']==$_SESSION['axes_pidata']['cusid']){?>
<option selected value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>    
<?php }else{ ?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>    
<?php } ?>    
<?php }else{ ?>    
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?> 
<?php } ?>
</select>
<span class="input-group-addon"><a id="addcus"><span class="fa fa-plus"></span></a></span>    
</div>    
</div> 
</div>
<div class="col-md-4"></div>
<div class="col-md-4">
<div class="form-group">
<label>Supplier/Expoter</label>
<div class="input-group">    
<select class="form-control select2" name="supid" id="supid">
<option value="">-Select-</option>
<?php									
$querys=mysqli_query($con,"SELECT * FROM tbl_supplier ORDER BY id ASC")or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<?php if(isset($_SESSION['axes_pidata']['supid'])){?>
<?php if($rows['id']==$_SESSION['axes_pidata']['supid']){?>
<option selected value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>    
<?php }else{ ?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>    
<?php } ?>    
<?php }else{ ?>    
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?> 
<?php } ?>
</select>
<span class="input-group-addon"><a id="addsup"><span class="fa fa-plus"></span></a></span>    
</div>    
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group">
<label>Search Product</label>    
<div class="input-group">
<span class="input-group-addon"><span class="fa fa-search"></span></span>
<input type="text" class="form-control" maxlength="35" name="search" id="search" placeholder="e.g. Product Code or Name" autocomplete="off">
<span class="input-group-addon"><a id="addpro"><span class="fa fa-plus"></span></a></span>     
</div>
</div>
</div>
<div class="col-md-6">
    
</div> 
</div>
    
<div class="row">
<div class="col-md-12">
<table class="table table-bordered table-striped">
<thead>
<tr>
<th width="40" rowspan="2">SN</th>
<th width="250" rowspan="2">Product</th>
<th width="300" class="text-center" colspan="3">Product Details</th>
<th width="300" class="text-center" colspan="3">Commission Details</th>    
<th width="30" class="text-center" rowspan="2"><a class="empty" style="cursor: pointer;"><i class="fa fa-trash"></i></a></th>
</tr>
<tr>
<th width="100" class="text-center">Price</th>
<th width="100" class="text-center">Qty</th>
<th width="100" class="text-center">Total</th>    
<th width="100" class="text-center">Fixed</th>
<th width="100" class="text-center">Percent (%)</th> 
<th width="100" class="text-center">Total</th>    
</tr>    
</thead>
<tbody id="itemdata">

</tbody>
<tfoot id="itemfoot">

</tfoot>
</table> 
</div>    
</div>
    
<div class="row">
<div class="col-md-12">
<div class="form-group">
<label>Terms &amp; Condition</label>
<textarea class="form-control" name="terms" id="terms" maxlength="650" rows="3" placeholder="e.g. Terms &amp; Condition"><?php if(isset($_SESSION['axes_pidata']['terms'])){echo $_SESSION['axes_pidata']['terms'];}?></textarea>
</div>    
</div>   
</div>    
<div class="row">
<div class="col-md-4">
<div class="col-md-6">    
<div class="form-group" >
<label>Delivery Date</label>
<input type="text" class="form-control datetimepicker" name="dldate" id="dldate" value="<?php if(isset($_SESSION['axes_pidata']['dldate'])){echo $_SESSION['axes_pidata']['dldate'];}?>" placeholder="Date:" autocomplete="off">
</div>
</div>
<div class="col-md-6">     
<div class="form-group" >
<label>Delivery Days</label>
<input type="text" class="form-control" maxlength="3" name="dldays" id="dldays" onkeypress="return isNumberKey(event)" value="<?php if(isset($_SESSION['axes_pidata']['dldays'])){echo $_SESSION['axes_pidata']['dldays'];}?>" placeholder="e.g. 45" autocomplete="off">
</div>
</div>    
</div>
<div class="col-md-4"></div>
<div class="col-md-4">
<div class="form-group">
<label>Port of Embarkation</label>
<input type="text" class="form-control" maxlength="150" name="pofemb" id="pofemb" value="<?php if(isset($_SESSION['axes_pidata']['pofemb'])){echo $_SESSION['axes_pidata']['pofemb'];}?>" placeholder="e.g. Ningbo Port,China " autocomplete="off">
</div>
<div class="form-group">
<label>Port of Discharge</label>
<input type="text" class="form-control" maxlength="150" name="pofdis" id="pofdis" value="<?php if(isset($_SESSION['axes_pidata']['pofdis'])){echo $_SESSION['axes_pidata']['pofdis'];}?>" placeholder="e.g. CFR Chattogram Port" autocomplete="off">
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-5">
<div class="form-group">
<label>Beneficiary Bank</label>
<div class="input-group">
<span class="input-group-addon"><b>Bank:</b></span>
<input type="text" class="form-control" maxlength="45" name="bfbank" id="bfbank" value="<?php if(isset($_SESSION['axes_pidata']['bfbank'])){echo $_SESSION['axes_pidata']['bfbank'];}?>" placeholder="e.g. Bank Of China Shaoxing Branch" autocomplete="off">   
</div>
<br>    
<div class="input-group">
<span class="input-group-addon"><b>AC No:</b></span>
<input type="text" class="form-control" maxlength="25" name="bfac" id="bfac" value="<?php if(isset($_SESSION['axes_pidata']['bfac'])){echo $_SESSION['axes_pidata']['bfac'];}?>" placeholder="e.g. 351968912885" autocomplete="off">   
</div>    
</div>    
</div>
<div class="col-md-7"></div>    
</div>    
    
</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row" style="margin-top: 15px" >
<div class="col-md-7"></div>
<div class="col-md-5 text-right" >
<input type="button" id="ireset" class="btn btn-flat bg-red btn-sm " value="Reset"/>
<input type="submit" name="save_pinv" id="submit" class="btn btn-flat bg-purple btn-sm " value="Save"/> <a href="opr_pilist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'PIN','A');}else{echo read_activity($aid,'PIN','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>
    
</section>
<!-- /.main content -->
<?php include('../layout/rside.php'); ?>    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function (){ 
var invno = new LiveValidation('invno');
invno.add(Validate.Presence);
var apdate = new LiveValidation('apdate');
apdate.add(Validate.Presence)
var curid = new LiveValidation('curid');
curid.add(Validate.Presence) 
var cusid = new LiveValidation('cusid');
cusid.add(Validate.Presence)
var supid = new LiveValidation('supid');
supid.add(Validate.Presence)    
});
    
ReadData();
function ReadData(){
$.ajax({
url: "opr_piview.php",
method: "POST",
data:{ 
body:1
},
success: function(data){
$('#itemdata').html(data);
}
})

$.ajax({
url: "opr_piview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})    
};    

function ReadFoot(){
$.ajax({
url: "opr_piview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})	
}    
    
$(document).on('blur', '#invno', function() {
$piinv=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
uppinv: $piinv
},
dataType: 'json',
success: function(data){
$('#invno').val(data[0]);
}
});     
});    

$(document).on('blur change', '#apdate', function() {
$apdate=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
apdate: $apdate
},
dataType: 'json',
success: function(data){
$('#apdate').val(data[0]);
}
});     
});    

$(document).on('blur change', '#dldate', function() {
$dldate=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
dldate: $dldate
},
dataType: 'json',
success: function(data){
$('#dldate').val(data[0]);
}
});     
});     
    
$(document).on('change', '#curid', function() {
curid=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
upcurid: curid
},
success: function(data){

}
});     
});
    
$(document).on('change', '#cusid', function() {
cusid=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
upcusid: cusid
},
success: function(data){

}
});     
});
    
$(document).on('change', '#supid', function() {
supid=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
upsupid: supid
},
success: function(data){

}
});     
});    

$(document).on('blur', '#dldays', function() {
dldays=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
dldays: dldays
},
dataType: 'json',
success: function(data){
$('#dldays').val(data[0]);
}
});     
}); 
    
$(document).on('blur', '#pofemb', function() {
pofemb=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
pofemb: pofemb
},
dataType: 'json',
success: function(data){
$('#pofemb').val(data[0]);
}
});     
}); 
    
$(document).on('blur', '#pofdis', function() {
pofdis=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
pofdis: pofdis
},
dataType: 'json',
success: function(data){
$('#pofdis').val(data[0]);
}
});     
});
    
$(document).on('blur', '#bfbank', function() {
bfbank=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
bfbank: bfbank
},
dataType: 'json',
success: function(data){
$('#bfbank').val(data[0]);
}
});     
});
    
$(document).on('blur', '#bfac', function() {
bfac=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
bfac: bfac
},
dataType: 'json',
success: function(data){
$('#bfac').val(data[0]);
}
});     
});    

$(document).on('blur', '#terms', function() {
terms=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
terms: terms
},
dataType: 'json',
success: function(data){
$('#terms').val(data[0]);
}
});     
});     
    
$(document).on('keydown', '#search', function() {
$('#search' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'axe_cart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term,request:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
var te='';
$(this).val(te); // display the selected text
var proid = ui.item.value; // selected id to input

$.ajax({
url: 'axe_cart.php',
type: 'post',
data: {proid:proid,request:2},
dataType: 'json',
success:function(response){
ReadData();
}
});

return false;
}
});    
});

$(document).on('blur', '.price', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var price = parseFloat($('#price_'+id[1]).val());
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
upprice: ids, price: price
},
dataType: 'json',
success: function(data){
$('#price_'+id[1]).val(data[0]);
$('#stot_'+id[1]).html(data[1]);
$('#cfixed_'+id[1]).val(data[2]);    
$('#tcom_'+id[1]).html(data[3]);
ReadFoot();    
}
});     
});
    
$(document).on('blur', '.quantity', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var qty = parseFloat($('#qty_'+id[1]).val());
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
upqty: ids, qty: qty
},
dataType: 'json',
success: function(data){
$('#qty_'+id[1]).val(data[0]);
$('#stot_'+id[1]).html(data[1]);
$('#tcom_'+id[1]).html(data[2]);
ReadFoot();    
}
});     
});    

$(document).on('blur', '.cfixed', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var cfixed = parseFloat($('#cfixed_'+id[1]).val());
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
upfixed: ids, cfixed: cfixed
},
dataType: 'json',
success: function(data){
$('#cfixed_'+id[1]).val(data[0]);
$('#cpercet_'+id[1]).val(data[1]);    
$('#tcom_'+id[1]).html(data[2]);
ReadFoot();    
}
});     
});    

$(document).on('blur', '.cpercet', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
var percent = parseFloat($('#cpercet_'+id[1]).val());
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
uppercent: ids, percent: percent
},
dataType: 'json',
success: function(data){
$('#cfixed_'+id[1]).val(data[0]);
$('#cpercet_'+id[1]).val(data[1]);    
$('#tcom_'+id[1]).html(data[2]);
ReadFoot();    
}
});     
});    

$(document).on('click','.empty',function() {
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
emdata: 1
},
success: function(data){
ReadData();    
}
});    
});    

$(document).on('click', '.remove', function () {
var id = $(this).attr('id');
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
remove: id
},
success: function(data){
ReadData();
}
});    
});    
    
$(document).on('click','#ireset',function() {
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
cldata: 1
},
success: function(data){
$("#invno").val("");
$("#apdate").val("");    
$("#curid").val("").trigger("change");
$("#cusid").val("").trigger("change");
$("#supid").val("").trigger("change");
$("#terms").val("");
$("#dldate").val("");
$("#dldays").val("");
$("#pofemb").val("");
$("#pofdis").val("");
$("#bfbank").val("");
$("#bfac").val("");   
ReadData();    
}
});    
});    
    
$(document).on('click', '.quantity ,.price ,.cfixed ,.cpercet', function(e) {
    e.preventDefault();
});
    
$(document).on('click', '#addcus', function() {
$('#addsitem').html('');    
$.ajax({
url: "axe_additem.php",
method: "POST",
data:{addcus:1},
success: function(data){
$('#addsitem').html(data);
$('.right-side-add').toggle('slide', { direction: 'right' }, 300);     
}
})       
});

$(document).on('click', '#addsup', function() {
$('#addsitem').html('');    
$.ajax({
url: "axe_additem.php",
method: "POST",
data:{addsup:1},
success: function(data){
$('#addsitem').html(data);
$('.right-side-add').toggle('slide', { direction: 'right' }, 300);     
}
})       
});
    
$(document).on('click', '#addpro', function() {
$('#addsitem').html('');    
$.ajax({
url: "axe_additem.php",
method: "POST",
data:{addpro:1},
success: function(data){
$('#addsitem').html(data);    
$('.right-side-add').toggle('slide', { direction: 'right' }, 300);     
}
})       
});    
    
$(document).on('click', '#closepop', function() {    
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }
$('#addsitem').html('');    
});    
</script>    
<!-- /page script -->
</html>    