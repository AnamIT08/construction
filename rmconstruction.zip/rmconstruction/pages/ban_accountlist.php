<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/repfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('42','views','R');     
$_SESSION['cuPages']='ban_accountlist.php';   
$cuPage='ban_accountlist.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='bank';
$menuh='Bank';
$phead='acclist';
$page='Account Record';
$print='print';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>
<?php 
if(isset($_POST['delacc'])){
$id=$_POST['delacc'];
if(delete_check('tbl_banktra','acid',$id)>0){
save_msg('w','Account Depend On Other Table!!!');
echo "<script>window.location='ban_accountlist.php'</script>";
return;    
}
$name= get_fild_data('tbl_bacount',$id,'acno');   
$sql="DELETE FROM tbl_bacount WHERE id='$id'";
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
if($query){    
$act =remove_junk(escape('Account number: '.$name));    
write_activity($aid,'ACC','Account number has been deleted',$act);    
}    
save_msg('s','Account number Successfully Deleted!!!');
echo "<script>window.location='ban_accountlist.php'</script>";
}
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
    
<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">All Account</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>    
<div class="col-md-12 table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th style="width:40px;">SN</th>   
<th>Bank</th>
<th>A/C No</th>
<th>Title</th>
<th>Branch</th>
<th>Location</th>
<th>Debit</th>
<th>Credit</th>
<th>Balance</th>    
<th style="width:40px; text-align:center;">Action</th>    
</tr>
</thead>    
<tbody>
<?php
$sql="SELECT * FROM tbl_bacount ORDER BY id ASC";    
$query=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($row=mysqli_fetch_array($query)){
$id=$row['id'];
   
$bnid='BA'.$row['id'];
$ldebit=get_ledgerval($bnid,'D','N');
$lcredit=get_ledgerval($bnid,'C','N');
$lnet=($ldebit-$lcredit);    
?>
<tr>
<td class="center"><?php echo count_id();?></td>
<td><?php echo get_fild_data('tbl_bank',$row['bid'],'name');?></td>       
<td><?php echo $row['acno'];?></td>
<td><?php echo $row['title'];?></td>    
<td><?php if($row['brcode']!=''){echo $row['branch'].' - '.$row['brcode'];}else{echo $row['branch'];}?></td>      
<td><?php echo $row['location'];?></td>
<td><?php echo numtolocal($ldebit,get_fild_data('tbl_currency','1','symbol'));?></td>
<td><?php echo numtolocal($lcredit,get_fild_data('tbl_currency','1','symbol'));?></td>
<td><strong><?php echo numtolocal($lnet,get_fild_data('tbl_currency','1','symbol'));?></strong></td>    
<td nowrap="">
<a class="btn btn-flat bg-purple details-invoice" href="#" id="stm_<?php echo $row['id']; ?>"><i class="fa fa-eye cat-child"></i></a>    
<a class="btn btn-flat bg-purple" href="#" onclick="edit_item('ED_<?php echo $row['id'];?>')"><i class="fa fa-edit"></i></a> 
<a class="btn btn-flat bg-purple" href="#" onclick="remove_item('DL_<?php echo $row['id'];?>')"><i class="fa fa-trash"></i></a>
<form action="ban_accountlist.php" id="DL_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="delacc" value="<?php echo $row['id']; ?>" />
</form>
<form action="ban_accountedit.php" id="ED_<?php echo $row['id'];?>" method="post" >
<input type="hidden" name="editacc" value="<?php echo $row['id']; ?>" />
</form>    
</td>    
</tr>    
<?php } ?>    
</tbody>   
</table>
</div>
<div class="clearfix" ></div>  
<div class="row"style="margin-top: 15px" >
<div class="col-md-12 table-responsive">    
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<a href="ban_accountcreate.php" class="btn btn-flat bg-purple">Add Account</a>
</div>
</div>    
</div>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'ACC','A');}else{echo read_activity($aid,'ACC','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->
<?php include('../layout/print.php'); ?>  
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function() {
$('#datarec').DataTable();
} );
function edit_item(id) {
document.getElementById(id).submit(); 
} 
function remove_item(id) {
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
document.getElementById(id).submit();
}
}
});
}
    
$(document).on('click','.details-invoice',function(e) {      
id_arr = $(this).attr('id');
id = id_arr.split("_");

$.ajax({
url: 'ban_viewlist.php',
method: "POST",
data:{ 
acid: id[1]
},
success: function(data){
$('#listitem').html(data);
pagelist();    
}
});    
    
$.ajax({
url: 'ban_viewstm.php',
method: "POST",
data:{ 
print: id[1]
},
success: function(data){
$('#invhold').html(data);
sethead();    
}
});
    
$('.right-side').toggle('slide', { direction: 'right' }, 300);    

e.preventDefault();
});

$(document).on('click', '#closepop', function() {
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }   
});
    
$('#listitem').on('click','li', function(){
   $(this).addClass('active').siblings().removeClass('active');
});
    
$(document).on('click', '.invpiv', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
$.ajax({
url: 'ban_viewstm.php',
method: "POST",
data:{ 
print: ids
},
beforeSend: function() {
//$("#invhold").fadeOut('slow');
},    
success: function(data){    
$('#invhold').html(data);
$("#invhold").fadeIn('slow');    
sethead();    
}
});     
});    
</script>    
<!-- /page script -->
</html>    