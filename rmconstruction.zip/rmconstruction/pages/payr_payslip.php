<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='payr_payslip.php';   
$cuPage='payr_payslip.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='payroll';
$menuh='Payroll';
$phead='payslip';
$page='Payslip Generate';
$print='print';
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-9">    
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Salary Sheet</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<div class="col-md-12 popup_details_div">    
<div class="row">
<input type="hidden" id="syear" name="year" value="" readonly> 
<input type="hidden" id="smonth" name="month" value="" readonly>     
<div class="table-responsive">
<table class="table table-bordered table-striped" id="datarec">
<thead>
<tr>
<th width="3%">#</th>
<th width="18%">Name</th>
<th width="14%">Designation</th>
<th width="12%">G.Salary</th>
<th width="7%">D.Absent</th>
<th width="6%">D.Late</th>
<th width="6%">A.Leave</th>
<th width="6%">P.Day</th>
<th width="6%">P.Amo</th>
<th width="10%">Net.Pay</th>
<th width="7%"></th>
</tr>
</thead>
<tbody id="dataemploye">
		
</tbody>    
</table>    
</div>    
</div>
</div>        
</div>
</div>    
</div>
<div class="col-md-3">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">Salary Month</h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<div class="col-md-12 popup_details_div">
<div class="col-md-1"></div>
<div class="col-md-10">    

<div class="row">
<div class="col-md-6">
<label>Year</label>
<select class="form-control" id="year" name="year">
<?php 
for ($x = (date('Y')-4); $x <= (date('Y')+5); $x++) {
if ($x==date('Y')){
echo "<option selected value='$x'>$x</option>"; 
}else{
echo "<option value='$x'>$x</option>";
}    
}
?>
</select>
</div>
<div class="col-md-6">
<label>Salary Month</label>
<select class="form-control" id="month" name="month" onchange="getAllEmploye(this.value)">
<?php 
for ($x = 01; $x <= 12; $x++) {
if ($x== (date('m')-1)){
if ($x== 0){$x == 12;}    
echo "<option selected value='$x'>".getMonthName($x)."</option>"; 
}else{
echo "<option value='$x'>".getMonthName($x)."</option>";
}    
}
?>
</select>
</div>
</div>
<div class="row">
<div class="col-md-6">
<label>Branch</label>
<select class="form-control" name="pono" id="brid" onchange="getAllSalary(this.value)">
<option value=" ">-Select Branch-</option>
<option value="0">-No Branch-</option>
<?php									
$queryd=mysqli_query($con,"SELECT * FROM tbl_branch ORDER BY id ASC")or die(mysqli_error($con));
while ($rowd=mysqli_fetch_array($queryd)){
?>
<option value="<?php echo $rowd['id'];?>"><?php echo $rowd['name'];?></option>
<?php } ?>
</select>
</div>    
</div>
    
</div>    
<div class="col-md-1"></div>    
</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-6"></div>
<div class="col-md-6 text-right" >
<input type="button" id="reset" class="btn btn-flat bg-red btn-sm " value="Reset"/>    
<input type="button" id="triview" class="btn btn-flat bg-purple btn-sm" value="Submit"/>
</div> 
</div>    
</div>
</div>
</div>
</div>    
</div>
</div>    
 
<?php include('../layout/quick.php');?>     
</section>    
<!-- /.main content -->
<?php include('../layout/print.php'); ?>    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
    
function take_action(id) {
document.getElementById(id).submit(); 
}
    
function remove_item(id) {
ide = id.split("_");
var ids = ide[1];
toastr.options = {'positionClass': 'toast-top-center'};    
bootbox.confirm({
title: "Confirm",
message: "Are you sure to delete ?",
buttons: {
confirm: {
label: 'Yes',
className: 'btn-flat bg-purple'
},
cancel: {
label: 'Cancel',
className: 'btn-flat bg-gray'
}
},
callback: function (result) {
if (result == true) {
    
$.ajax({
url: 'payr_ecart.php',
method: "POST",
data:{ delsal: ids},    
success: function(data){
toastr.info(data);    
getAllSalary(ids);   
}
});
    
}
}
});
}    

$(document).on('click', '.details-invoice', function(e) {    
id_arr = $(this).attr('id');
id = id_arr.split("_");
$.ajax({
url: 'payr_payviewlist.php',
method: "POST",
data:{ 
invid: id[1],supid: id[2]
},
success: function(data){
$('#listitem').html(data);
pagelist();    
}
});    
    
$.ajax({
url: 'payr_payprint.php',
method: "POST",
data:{ 
print: id[1]
},
success: function(data){
$('#invhold').html(data);
sethead();    
}
});
    
$('.right-side').toggle('slide', { direction: 'right' }, 300);    

e.preventDefault();
});    

    
$(document).on('click', '#closepop', function() {
if($('.right-side').is(':visible')) { $('.right-side').toggle('slide', { direction: 'right' }, 300); }   
});    

$('#listitem').on('click','li', function(){
   $(this).addClass('active').siblings().removeClass('active');
});
    
$(document).on('click', '.invpiv', function() {
id_arr = $(this).attr('id');
id = id_arr.split("_");
var ids = id[1];
$.ajax({
url: 'payr_payprint.php',
method: "POST",
data:{ 
print: ids
},
beforeSend: function() {
//$("#invhold").fadeOut('slow');
},    
success: function(data){    
$('#invhold').html(data);
$("#invhold").fadeIn('slow');    
sethead();    
}
});     
});    
    
function getAllSalary(id){
var month = $('#month').val();
var year = $('#year').val();    
var brid = $('#brid').val();
  
$.ajax({
url: 'payr_ecart.php',
type: 'post',
data: {salary : '', month: month, year: year, branch : brid},
beforeSend: function () {
$('#datarec').DataTable().clear().destroy();    
},
success:function(data) {
$('#dataemploye').html(data);
$('#datarec').DataTable({stateSave: true});     
}
});
}
</script>    
<!-- /page script -->
</html>    