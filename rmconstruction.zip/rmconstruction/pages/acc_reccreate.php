<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
get_pagesecurity('27','creates','R');    
$_SESSION['cuPages']='acc_reccreate.php';   
$cuPage='acc_reccreate.php';    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
}else{
header('Location:../index.php');
exit;    
}
$mhead='account';
$menuh='Account';
$phead='reccre';
$page='Received Create';
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
$dtnow = date("Y-m-d h:i:s", time());
?>
<?php 
if(isset($_POST['save_received'])){
	//if(!isset($_SESSION['axes_recdata'])){
    //save_msg('w','No Received data found!!');
	//echo "<script>window.location='acc_reccreate.php'</script>";
    //exit;    
    //}
    
	if(!isset($_SESSION['axes_recitem'])){
    save_msg('w','No Received Head found!!');
	echo "<script>window.location='acc_reccreate.php'</script>";
    exit;    
    }
    
    $recno = gen_newinvno('tbl_recvoucher','REV');
    $apdate = remove_junk(escape($_POST['apdate']));
    $prjid = remove_junk(escape($_POST['prjid']));
    $epjid = remove_junk(escape($_POST['prjid']));
    if($prjid==''){$prjid='NULL'; $prjno='NULL';}else{$prjid="'".$prjid."'"; $prjno="'".get_fild_data('tbl_project',$epjid,'prjid')."'";}
    $note = remove_junk(escape($_POST['note']));
    $total = total_recvalue();
    
    $sql="INSERT INTO tbl_recvoucher (invno,note,amount,apdate,pjid,brid,uid,date) VALUES ('$recno','$note','$total','$apdate',$prjid,'$brid','$aid','$dtnow')";    
	$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    $sid=$con->insert_id;
    $efid=mysqli_affected_rows($con);
    
    if($efid>0){
    if(isset($_SESSION['axes_recitem'])){
    if(is_array($_SESSION['axes_recitem'])){
    $max=count($_SESSION['axes_recitem']);
    for($i=0;$i<$max;$i++){
        
    $dty = $_SESSION['axes_recitem'][$i]['dty'];
    $did=$_SESSION['axes_recitem'][$i]['did'];    
    $amo=$_SESSION['axes_recitem'][$i]['amo'];
    $cid=$_SESSION['axes_recitem'][$i]['cid'];
    $cty=$_SESSION['axes_recitem'][$i]['cty'];   
    $chkno=$_SESSION['axes_recitem'][$i]['chkno'];
    $chkdt=$_SESSION['axes_recitem'][$i]['chkdt'];
    if($chkno=='' || strlen($chkno)<2){$chkdt='NULL';$chkno='NULL';}else{$chkdt="'".$chkdt."'";$chkno="'".$chkno."'";}    
    $ref=$_SESSION['axes_recitem'][$i]['ref'];
    $mtype=$_SESSION['axes_recitem'][$i]['mtype'];    
    $refinv=$_SESSION['axes_recitem'][$i]['refinv'];
    if($refinv=='' || strlen($refinv)<1){$refinv='NULL';}else{$refinv="'".$refinv."'";}    
    $xrate=$_SESSION['axes_recitem'][$i]['xrate'];    
    if($xrate=='' || strlen($xrate)<1){$xrate=0;} 
      
    $sql="INSERT INTO tbl_trarecord (invno,refinv,pjid,prjno,mtype,dty,did,amo,cid,cty,chkno,chkdt,ref,curid,xrate,apdate,uid,brid,date) VALUES ('$recno',$refinv,$prjid,$prjno,'$mtype','$dty','$did','$amo','$cid','$cty',$chkno,$chkdt,'$ref','0','$xrate','$apdate','$aid','$brid','$dtnow')";
    mysqli_query($con,$sql) or die(mysqli_error($con)); 
        
    }}}
    unset($_SESSION['axes_recdata']);
    unset($_SESSION['axes_recitem']);    
    $act =remove_junk(escape('Receipt No: '.$recno));    
    write_activity($aid,'REC','Receipt has been Added',$act);    
    save_msg('s','Data Successfully Saved!');
    }else{
    save_msg('w','Data Fail to Saved!');    
    }
    echo "<script>window.location='acc_reccreate.php'</script>";  
	}  
?>
<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">

<div class="row">
<div class="col-md-8">
<div class="box box-solid">
<div class="box-header with-border">
<h3 class="box-title">Add Receipt</h3>
</div>
<div class="box-body">
<?php echo display_msg();?>  
<form action="acc_reccreate.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<div class="col-md-12 popup_details_div">
<div class="row">    
<center>
<h3 class="page-title">RECEIPT VOUCHER</h3>
</center>
</div>
<div class="row">    
<div class="col-md-4 col-md-offset-8">
<div class="form-group">
<div class="input-group">
<span class="input-group-addon"><b>Voucher No:</b></span>
<input type="text" class="form-control" maxlength="15" name="invno" id="invno" value="<?php if(isset($_SESSION['axes_recdata']['invno'])){$_SESSION['axes_recdata']['invno']=gen_newinvno('tbl_recvoucher','REV');echo $_SESSION['axes_recdata']['invno'];}else{echo gen_newinvno('tbl_recvoucher','REV');}?>" placeholder="e.g. REV121119101" readonly>
</div>
</div>
<div class="form-group" >
<div class="input-group">
<span class="input-group-addon"><b>Date:</b></span>
<input type="text" class="form-control datetimepicker" name="apdate" id="apdate" value="<?php if(isset($_SESSION['axes_recdata']['date'])){echo $_SESSION['axes_recdata']['date'];}else{ echo date('Y-m-d');}?>" placeholder="Date:" autocomplete="off" readonly>
</div>
</div>
<div class="form-group" >
<div class="input-group">
<span class="input-group-addon"><b>Project:</b></span>    
<select class="form-control select2" name="prjid" id="prjid">
<option value="">-Select-</option>
<?php
$sql="SELECT * FROM tbl_project WHERE status IN ('0','1','3') ORDER BY date DESC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($prj=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $prj['id'];?>"><?php echo $prj['prjid'];?></option>
<?php } ?>
</select>    
</div>   
</div>     
</div>
</div>
<div class="row">    
<div class="col-md-4">    
<div class="form-group">
<label>Received To</label>    
<select class="form-control select2" name="did" id="did">
<option value="">-Select-</option>
<option value="LE_2">Cash</option>    
<?php
$sql="SELECT tbl_bacount.id,CONCAT(tbl_bank.sort,' - ',tbl_bacount.acno) AS name FROM tbl_bacount LEFT JOIN tbl_bank ON tbl_bank.id=tbl_bacount.bid ORDER BY tbl_bank.sort ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'BA_'.$rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
<?php
$sql="SELECT id,CONCAT(name,' - ',mobile) AS cname,name FROM tbl_acmobile ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'MO_'.$rows['id'];?>"><?php echo $rows['cname'];?></option>
<?php } ?>    
</select>
</div>    
</div>
<div class="col-md-2">    
<div class="form-group">
<label>Balance</label>
<div style="font-size: 20px;color: red;"><span>$ </span><span id="cbalance">0.00</span></div>    
</div>    
</div>    
<div class="col-md-2">    
<div class="form-group">
<label>Cheque No</label>
<input type="text" maxlength="20" class="form-control" name="chkno" id="chkno" value="" placeholder="e.g. KA7865467" autocomplete="off" disabled="disabled">
</div>    
</div>
<div class="col-md-2">    
<div class="form-group" >
<label>Cheque Date</label>
<input type="text" class="form-control datetimepicker" name="chkdt" id="chkdt" value="" placeholder="Cheque Date" autocomplete="off" disabled="disabled">
</div>    
</div>    
<div class="col-md-4">    
    
</div>    
</div>

<!--<div class="row">
<div class="col-md-4">    
<div class="form-group">
<label>Type Invoice No</label>    
<div class="input-group">
<span class="input-group-addon"><b>Inv.No:</b></span>    
<input type="text" class="form-control" maxlength="25" name="dinvno" id="dinvno" value="" placeholder="e.g. AXE121119101" autocomplete="off">    
</div>    
</div>    
</div>
<div class="col-md-2">    
<div class="form-group">
<label>Due</label>
<div style="font-size: 20px;color: red;"><span id="symbol">$ </span><span id="dueamo">0.00</span></div>    
</div>    
</div>
<div class="col-md-2">    
<div class="form-group">
<label>Exchange Rate</label>    
<input type="text" maxlength="7" class="form-control" name="xrate" id="xrate"  onkeypress="return isNumberKey(event)" placeholder="e.g. 500" autocomplete="off">
</div>    
</div>    
</div>--> 
    
<div class="row">
<div class="col-md-4">
<div class="form-group" >
<label>Received From</label>
<select class="form-control select2" name="cid" id="cid">
<option value="">-Select-</option>
<optgroup label="Customer">
<?php
$sql="SELECT * FROM tbl_customer ORDER BY id ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'CU_'.$rows['id'];?>"><?php echo $rows['code'].' - '.$rows['name'].' - '.$rows['cnumber'];?></option>
<?php } ?>
</optgroup>
<optgroup label="Supplier">
<?php
$sql="SELECT * FROM tbl_supplier ORDER BY id ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'SU_'.$rows['id'];?>"><?php echo $rows['code'].' - '.$rows['name'].' - '.$rows['cnumber'];?></option>
<?php } ?>
</optgroup>
<optgroup label="Contructor">
<?php
$sql="SELECT * FROM tbl_contractor ORDER BY id ASC";    
$queryc=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rowc=mysqli_fetch_array($queryc)){
?>
<option value="<?php echo 'CO_'.$rowc['id'];?>"><?php echo $rowc['code'].' - '.$rowc['name'].' - '.$rows['mobile'];?></option>
<?php } ?>
</optgroup>    
<optgroup label="Employee">
<?php
$sql="SELECT * FROM tbl_employe ORDER BY id ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'EM_'.$rows['id'];?>"><?php echo $rows['code'].' - '.$rows['name'];?></option>
<?php } ?>
</optgroup>
<optgroup label="Loan">
<?php
$sql="SELECT * FROM tbl_loanid ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'LO_'.$rows['id'];?>"><?php echo $rows['code'].' - '.$rows['name'];?></option>
<?php } ?>
</optgroup>    
<optgroup label="Other">    
<?php
$sql="SELECT * FROM tbl_acledger WHERE sgrid NOT IN (1,2,3,4,13) ORDER BY id ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'LE_'.$rows['id'];?>"><?php echo $rows['code'].' - '.$rows['name'];?></option>
<?php } ?>
</optgroup>    
</select>   
</div>
</div>
<div class="col-md-1">    
<div class="form-group">
<label>Bal.</label>
<div style="font-size: 14px;color: red;"><span>$ </span><span id="balance">0.00</span></div>    
</div>    
</div>    
<div class="col-md-2">
<div class="form-group" >
<label>Ref</label>
<input type="text" maxlength="25" class="form-control" name="ref" id="ref" placeholder="e.g. Sumon" autocomplete="off">    
</div>    
</div>
<div class="col-md-2">
<div class="form-group">
<label>Amount</label>    
<input type="text" maxlength="10" class="form-control" name="amo" id="amo"  onkeypress="return isNumberKey(event)" placeholder="e.g. 500" autocomplete="off">    
</div> 
</div>
<div class="col-md-2">
<div class="form-group">
<label>Type</label>    
<select class="form-control select2" name="mtype" id="mtype">
<option value="0">-Select-</option>
<?php
$sql="SELECT id,name FROM tbl_prjtype ORDER BY date DESC";    
$quer=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($typ=mysqli_fetch_array($quer)){
?>
<option value="<?php echo $typ['id'];?>"><?php echo $typ['name'];?></option>
<?php } ?>
</select>    
</div>
</div>    
<div class="col-md-1">
<div class="form-group">
<label>&nbsp;</label>    
<input type="button" id="addrec" class="btn btn-flat bg-red" value="Add"/>    
</div>
</div>    
</div>
<div class="row">
<div class="col-md-12">
<table class="table table-bordered table-striped">
<thead>    
<th style="width:40px; text-align:center">SN</th>
<th>Received</th>
<th>Received From</th>
<th>Type</th>    
<th>Amount</th>
<th>Cheque</th>
<th>Date</th>    
<th>Ref</th>
<th style="width:40px; text-align:center"><a class="empty" style="cursor: pointer;"><i class="fa fa-trash"></i></a></th>    
</thead>
<tbody id="itemdata">

</tbody>
<tfoot id="itemfoot">

</tfoot>    
</table> 
</div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="form-group">
<label>Note</label>
<textarea class="form-control" name="note" id="note" maxlength="250" rows="3" placeholder="e.g. Note"><?php if(isset($_SESSION['axes_recdata']['note'])){echo $_SESSION['axes_recdata']['note'];}?></textarea>
</div>    
</div>   
</div>    
    
</div>    
    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="recreset" class="btn btn-flat bg-red btn-sm " value="Reset"/>    
<input type="submit" name="save_received" id="submit" class="btn btn-flat bg-purple btn-sm" value="Save"/> <a href="acc_reclist.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>
<div class="col-md-4">
<div class="row">
<div class="col-md-12">
<div class="box box-solid">
<div class="box-header">
<h3 class="box-title">History </h3>
</div>
<!-- /.box-header -->
<div class="box-body" >
<?php if($_SESSION['utype']=='1'){echo read_activity($aid,'REC','A');}else{echo read_activity($aid,'REC','U');}?>
</div>
</div>
</div>
</div>
</div>
</div>    

<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>

<?php 
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(document).ready(function (){ 
var apdate = new LiveValidation('apdate');
apdate.add(Validate.Presence);
});
    
$(document).on('change', '#did', function() {
id_arr = $(this).val();
id = id_arr.split("_");
type=id[0];
if(type=='BA'){
document.getElementById("chkno").disabled=false; 
document.getElementById("chkdt").disabled=false;     
}else{
$('#chkno').val('');
$('#chkdt').val('');    
document.getElementById("chkno").disabled=true; 
document.getElementById("chkdt").disabled=true;    
}    
});
    
ReadData();
function ReadData(){
$.ajax({
url: "acc_recview.php",
method: "POST",
data:{ 
body:1
},
success: function(data){
$('#itemdata').html(data);
}
})

$.ajax({
url: "acc_recview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})    
};    

function ReadFoot(){
$.ajax({
url: "acc_recview.php",
method: "POST",
data:{ 
foot:1
},
success: function(data){
$('#itemfoot').html(data);
}
})	
}
    
$(document).on('click', '#addrec', function(e) {
sdid = $('#did').val();    
chkno = $('#chkno').val();
chkdt = $('#chkdt').val();
scid = $('#cid').val();    
amo = parseFloat($('#amo').val());
mtype = $('#mtype').val();    
ref = $('#ref').val();
refinv = $('#dinvno').val();
xrate = $('#xrate').val();    
toastr.options = {'positionClass': 'toast-top-center'};

if(sdid == '-Select-' || sdid == ''){
toastr.info('Please Select Received To!');
return;
};    

edid = sdid.split("_");
dty=edid[0];
did=edid[1];

/*if(dty=='BA'){    
if(chkno.length>=0 && chkno.length<5){
toastr.info('Please Enter Valid Cheque No!');
return;    
}    

if(chkno.length>0){
if(chkdt.length<=0){
toastr.info('Please Enter Cheque Date!');
return;    
}    
}    
}*/
    
if(scid == '-Select-' || scid == ''){
toastr.info('Please Select Received From!');
return;
}
    
ecid = scid.split("_");
cty=ecid[0];
cid=ecid[1];
    
if(isNaN(amo) != false || amo <= 0){
toastr.info('Please Enter Amount!');
return;
}    

$.ajax({
url: 'axe_cart.php',
type: 'post',
data: {getreceived:1,did:did,dty:dty,amo:amo,cty:cty,cid:cid,chkno:chkno,chkdt:chkdt,ref:ref,mtype:mtype,refinv:refinv,xrate:xrate},
success:function(data) {
$("#cid").val("").trigger("change");    
$("#did").val("").trigger("change");
$('#amo').val("");
$('#chkno').val(""); 
$('#chkdt').val("");     
$('#ref').val("");
ReadData();
}
});    
    
e.preventDefault();     
});
    
$(document).on('blur change', '#apdate', function() {
apdate=$(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
recdate: apdate
},
dataType: 'json',
success: function(data){
$('#apdate').val(data[0]);
}
});     
});    

$(document).on('blur', '#note', function() {
note = $(this).val();
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
recnote: note
},
dataType: 'json',
success: function(data){
$('#note').val(data[0]);
}
});     
});    

$(document).on('click','.empty',function() {
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
recdata: 1
},
success: function(data){
ReadData();    
}
});    
});    

$(document).on('click', '.remove', function () {
var id = $(this).attr('id');
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
recremove: id
},
success: function(data){
ReadData();
}
});    
});    

$(document).on('click','#recreset',function() {
$.ajax({
url: 'axe_cart.php',
method: "POST",
data:{ 
recclear: 1
},
success: function(data){
$("#note").val("");   
ReadData();    
}
});    
});

$(document).on('keydown', '#dinvno', function() {
$('#dinvno' ).autocomplete({
source: function( request, response ) {
$.ajax({
url: 'axe_cart.php',
type: 'post',
dataType: 'json',
data: {
search: request.term, invre:1
},
success: function(data) {
response(data);
}
});
},
select: function (event, ui) {
var te=ui.item.label;
$(this).val(te); // display the selected text
var invno = ui.item.info;
einf = invno.split("_");   
$("#cid").val('SU_'+einf[0]).trigger("change");    
$("#symbol").html(einf[1]+' '); 
$("#dueamo").html(einf[2]);    
return false;
}
});    
});
    
$(document).on('change keyup blur', '#xrate', function() {
var due = parseFloat($('#dueamo').html());
var xrate = parseFloat($(this).val());
var cash = 0;

cash = (due*xrate);
if(cash != '' && typeof(cash) != "undefined" && !isNaN(cash)){    
$("#amo").val(cash.toFixed(2));
}else{
$("#amo").val('');    
}
});

$(document).on('change', '#did', function () {
id = $(this).val();
$.ajax({
url: 'axe_cart.php',
type: 'post',
data: {checkbales:id},
success:function(data){
$('#cbalance').html(data);
}
});   
});    
    
$(document).on('change', '#cid', function () {
id = $(this).val();
$.ajax({
url: 'axe_cart.php',
type: 'post',
data: {checkbal:id},
success:function(data){
$('#balance').html(data);
}
});   
});    
</script>    
<!-- /page script -->
</html>