<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
$body='';
$foot='';
$s=0;
$totqty=0;
$totamo=0;
$totcom=0;
if(isset($_SESSION['axes_invitem'])){
if(is_array($_SESSION['axes_invitem'])){
$max=count($_SESSION['axes_invitem']);
for($i=($max-1);$i>=0;$i=$i-1){
$pid=$_SESSION['axes_invitem'][$i]['itemid'];
$name=$_SESSION['axes_invitem'][$i]['itemname'];
$color=$_SESSION['axes_invitem'][$i]['color'];
$price=$_SESSION['axes_invitem'][$i]['price'];
$qty=$_SESSION['axes_invitem'][$i]['qty'];
$unit=$_SESSION['axes_invitem'][$i]['unit'];
$subtot=$_SESSION['axes_invitem'][$i]['subtot'];
$fixed=$_SESSION['axes_invitem'][$i]['cfamo'];
$totcom=$_SESSION['axes_invitem'][$i]['tcamo'];
   
$s=$s+1;    
$body.='<tr>';
$body.='<td>'.$s.'</td>';
$body.='<td>'.$name.'</td>';
$body.='<td><input type="text" min="0" onkeypress="return isNumberKey(event)" class="form-control price" id="price_'.$i.'" value="'.$price.'" step="any" size="2" style="height: 24px;" readonly></td>';    
$body.='<td><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control quantity" id="qty_'.$i.'" value="'.$qty.'"  size="2" style="height: 24px;"/></td>';
$body.='<td class="text-right" id="stot_'.$i.'">'.$subtot.'</td>';
$body.='<td><input type="text" min="0" onkeypress="return isNumberKey(event)" class="form-control cfixed" id="cfixed_'.$i.'" value="'.$fixed.'" step="any" size="2" style="height: 24px;" readonly></td>';    
$body.='<td class="text-right" id="tcom_'.$i.'">'.$totcom.'</td>';
$body.='<td align="center"><a id="'.$i.'" class="remove"><span style="cursor: pointer;" class="fa fa-times"></span></a></td>';    
$body.='</tr>';     
}
$foot.='<tr>';
$foot.='<th colspan="3" class="text-right">TOTAL</th>';
$foot.='<th class="text-right">'.total_invvalue('Q').'</th>';
$foot.='<th class="text-right">'.number_format(total_invvalue('V'),2).'</th>';
$foot.='<th class="text-right"></th>';
$foot.='<th class="text-right">'.number_format(total_invvalue('C'),2).'</th>';     
$foot.='<th></th>';    
$foot.='</tr>';    
}else{
$body.='<tr>';
$body.='<td colspan="8" class="text-center">There are no items in your invoice list!</td>';
$body.='</tr>'; 
} 
}else{
$body.='<tr>';
$body.='<td colspan="8" class="text-center">There are no items in your invoice list!</td>';
$body.='</tr>';
}
            
if(isset($_POST['body'])){
echo $body;
}elseif(isset($_POST['foot'])){
echo $foot;	
}
exit;    
?>