<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){
$_SESSION['cuPages']='rep_emppayli.php';   
$cuPage='rep_emppayli.php';    
$aid=$_SESSION['uid'];
$uty=$_SESSION['utype'];    
$brid=$_SESSION['abrid'];     
}else{
header('Location:../index.php');
exit;    
}
$mhead='report';
$menuh='Report';
$phead='report';
$page='Employee List';
$ractive='A';
$print='print';
$dtnow = date("Y-m-d h:i:s", time());
$today = strftime("%Y-%m-%d", time());
$oavno='REP'.date("dmy", strtotime($today)).'PINR';
?>
<?php
include('../layout/head.php');
include('../layout/header.php');
include('../layout/side_nav.php');
?>

<div class="content-wrapper">
<?php include('../layout/page_head.php'); ?>
<!-- Main content -->
<section class="content">
<div class="row">
<div class="col-md-12">
<div class="col-md-3">    
<div class="box box-solid">

<div class="box-body">
<div class="col-md-12">    
<div class="row">    
<div class="roles-menu">   
<ul class="nav">
<li <?php if($ractive=='A'){echo 'class="active"';}?>><a href="rep_emppayli.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Employee List';}else{echo ' কর্মচারীর তালিকা';}?></a></li>
<li <?php if($ractive=='B'){echo 'class="active"';}?>><a href="rep_empattre.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Attendance';}else{echo ' উপস্থিতি';}?></a></li>
<li <?php if($ractive=='C'){echo 'class="active"';}?>><a href="rep_emplevre.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Leave Record';}else{echo ' ছুটির তালিকা';}?></a></li>
<li <?php if($ractive=='D'){echo 'class="active"';}?>><a href="rep_empsalre.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Salary Report';}else{echo 'বেতন রিপোর্ট';}?></a></li>
<li <?php if($ractive=='E'){echo 'class="active"';}?>><a href="rep_empcomre.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Commission Report';}else{echo ' কমিশন রিপোর্ট';}?></a></li>
 <li <?php if($ractive=='F'){echo 'class="active"';}?>><a href="rep_empovrview.php"><?php if(get_fild_data('tbl_setting','1','sval')==0){echo ' Overview';}else{echo ' সামগ্রিক অবস্থা (ওভারভিউ';}?></a></li>         
</ul>
</div>
</div>
<hr>    
<form action="rep_dailycashst.php" onsubmit="return validate()" enctype="multipart/form-data" method="post" accept-charset="utf-8">
<!--From Data-->
    
<!--End From Data-->    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-4"></div>
<div class="col-md-8 text-right" >
<input type="submit" name="filter_submit" id="submit" class="btn btn-flat bg-purple btn-sm " value="Submit"/> <a href="axe_report.php" class="btn btn-flat bg-gray  ">Close</a>
</div> 
</div>     
</form>    
</div>
</div>
</div>  
</div>
<div class="col-md-9">
<div class="row">    
<div class="side-head"> 
<div class="col-md-12">    
<div class="col-md-4 text-left">
<button class="btn btn-flat bg-teal" id="print"><i class="fa fa-print"></i></button> 
<button class="btn btn-flat bg-blue"><i class="fa fa-envelope-o"></i></button> 
<button class="btn btn-flat bg-gray"><i class="fa fa-file-pdf-o"></i></button>     
</div>
<div class="col-md-7 text-center">
<select name="Page_resolution" id="resolution" onchange="setPrinterConfig()" style="width: 205px;height: 28px;border: 1px solid red;">
<option value="A4" selected="selected">A4 [210mm × 297mm]</option>   
<option value="A5">A5 [148mm × 210mm]</option>
<option value="Letter">US Letter [216mm × 279mm]</option>
<option value="Legal">US Legal [216mm × 356mm]</option>
</select>
<select name="Page_size" id="rotate" onchange="setPrinterConfig()" style="width: 120px;height: 28px;border: 1px solid red;">
<option value="portrait">Portrait</option>
<option value="landscape">Landscape</option>
</select>    
</div>    
<div class="col-md-1 text-right">

</div>
</div>
</div>    
</div>
<div class="row">
<div class="invhold scrol-y" id="invhold">
<div class="printableArea">
    
</div>    
    
</div>
</div>
</div>
    
</div>    
</div>
    
<?php include('../layout/quick.php');?>    
</section>
<!-- /.main content -->    
</div>
<?php
include('../layout/footer.php');
?>
<!-- page script -->
<script type="text/javascript">
$(function(){
$('.invhold').css({ height: $(window).innerHeight()-190 });
$(window).resize(function(){
$('.invhold').css({ height: $(window).innerHeight()-190 });
});
});    
</script>    
<!-- /page script -->
</html>    