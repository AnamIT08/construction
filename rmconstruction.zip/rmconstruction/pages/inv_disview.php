<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
$body='';
$foot='';
$buton='';
$s=0;
$totqty=0;

if(isset($_SESSION['axes_dispos'])){
if(is_array($_SESSION['axes_dispos'])){
$max=count($_SESSION['axes_dispos']);
for($i=($max-1);$i>=0;$i=$i-1){
$unqid=$_SESSION['axes_dispos'][$i]['unqid'];
$pid=$_SESSION['axes_dispos'][$i]['pid'];    
$code=$_SESSION['axes_dispos'][$i]['code'];
$name=$_SESSION['axes_dispos'][$i]['name'];
$unit=$_SESSION['axes_dispos'][$i]['unid'];
$col=$_SESSION['axes_dispos'][$i]['col'];
if($col==0){$col='';}    
$siz=$_SESSION['axes_dispos'][$i]['siz'];
if($siz==0){$siz='';}      
$qty=$_SESSION['axes_dispos'][$i]['qty'];
$cost=$_SESSION['axes_dispos'][$i]['cost'];
$price=$_SESSION['axes_dispos'][$i]['price'];
$subtot=$_SESSION['axes_dispos'][$i]['subtot'];    
    
if($col=='' && $siz==''){
$name=$name;    
}elseif($col!='' && $siz==''){
$name= $name.' '.get_fild_data('tbl_color',$col,'name');    
}elseif($col=='' && $siz!=''){
$name= $name.' '.get_fild_data('tbl_size',$siz,'sval');    
}elseif($col!='' && $siz!=''){    
$name= $name.' '.get_fild_data('tbl_color',$col,'name').' '.get_fild_data('tbl_size',$siz,'sval');    
}    
$s+=1;
$totqty+=$qty;    

$body.='<tr>';
$body.='<td class="text-center" width="30px">'.$s.'</td>';    
$body.='<td width="214px">'.$name.'</td>';
$body.='<td width="60px" style="text-align:right;">'.$cost.'</td>';
$body.='<td width="56px"><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control quantity" id="qty_'.$i.'" value="'.$qty.'"  size="2" style="height: 24px; text-align:center;"/></td>';
$body.='<td width="70px"><input type="text" min="1" onkeypress="return isNumberKey(event)" class="form-control price" id="price_'.$i.'" value="'.$price.'"  size="2" style="height: 24px; text-align:right;"/></td>';
$body.='<td width="60px" id="subtot_'.$i.'" style="text-align:right;">'.$subtot.'</td>';    
$body.='<td class="text-center" width="25px"><a id="'.$i.'" class="remove"><span style="cursor: pointer;" class="fa fa-times"></span></a></td>';    
$body.='</tr>';    
}    

$foot.='<tr>';
$foot.='<td width="30px"></td>';
$foot.='<td width="214px"></td>';
$foot.='<td width="60px"></td>';
$foot.='<td width="56px"></td>';
$foot.='<td width="70px"></td>';
$foot.='<td width="60px"></td>';    
$foot.='<td width="25px"></td>';
$foot.='</tr>';    
$foot.='<tr>';
$foot.='<td colspan="2" class="text-center" width="244px"><strong>-Total-</strong></td>';
$foot.='<td width="60px" style="text-align:right;"><strong>'.get_dispos_total('C').'</strong></td>';     
$foot.='<td width="126px" colspan="2" class="text-center"><strong>'.$totqty.'</strong></td>';
$foot.='<td width="85px" colspan="2" style="text-align:right;"><strong>'.get_dispos_total('P').'</strong></td>';    
$foot.='</tr>';	
   
}else{
$body.='<tr>';
$body.='<td colspan="7" class="text-center">There are no Disposal Item!</td>';
$body.='</tr>'; 
} 
}else{
$body.='<tr>';
$body.='<td colspan="7" class="text-center">There are no Disposal Item!</td>';
$body.='</tr>';
}

if(isset($_SESSION['axes_dispos'])){
$buton.='<div class="col-md-6">';
$buton.='<input type="button" id="emptycart" class="btn btn-flat bg-red btn-sm" value="Empty"/></div>';
$buton.='<div class="col-md-6 text-right">';   
$buton.='<input type="button" id="save_disposal" class="btn btn-flat bg-purple btn-sm" value="Disposed"/>'; 
$buton.='</div>';
}

if(isset($_POST['body'])){
echo $body;
}elseif(isset($_POST['foot'])){
echo $foot;
}elseif(isset($_POST['buton'])){
echo $buton;    
}
exit; 