<?php session_start();
include ('../inc/dbcon.php');
include ('../inc/functions.php');
include ('../inc/cartfunctions.php');
include ('../inc/repfunctions.php');
include ('../inc/invfunctions.php');
if(isset($_SESSION["axeslogin"]) && $_SESSION["axeslogin"] == true){    
$aid=$_SESSION['uid'];
$brid=$_SESSION['abrid'];    
$today = strftime("%Y-%m-%d", time());    
$dtnow = date("Y-m-d h:i:s", time());    
}else{
header('Location:../index.php');
exit;    
}

if(isset($_POST['additem'])){
$code=$_POST['additem'];   
addtoselser($code,1);    
}

if(isset($_POST['itmsear'])){
$search = $_POST['search'];
$sql = "SELECT id,code,name,price FROM tbl_seritem WHERE status='1' AND (name LIKE '%$search%' OR code LIKE '%$search%') LIMIT 15";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
while($row = mysqli_fetch_array($result) ){
$response[] = array("value"=>$row['code'],"label"=>$row['code'].' | '.$row['name'].' | '.$row['price']);
}

echo json_encode($response);
exit;    
}

if(isset($_POST['addmanser'])){
$name = ucwords(remove_junk(escape($_POST['name'])));    
$cost = remove_junk(escape($_POST['cost']));
$price = remove_junk(escape($_POST['price']));   
addtoselser('',1,$name,$cost,$price);
echo json_encode(array(
'status' => 'success',
'message'=> 'Service Add To Cart Successfully!!'   
));    
}

if(isset($_POST['remove'])){
$ids = floatval($_POST['remove']);    
remove_service($ids);
$max=count($_SESSION['axes_service']);
if($max <= 0){
unset($_SESSION['axes_service']);
unset($_SESSION['axes_servide']);	
}    
}

if(isset($_POST['clear'])){
if(isset($_SESSION['axes_service'])){
unset($_SESSION['axes_service']);
unset($_SESSION['axes_servide']);    
}
}

if(isset($_POST['upqty'])){
$ids=intval($_POST['upqty']);
$qty=floatval($_POST['qty']);
if($qty<0 || $qty==''){
$redata=array($_SESSION['axes_service'][$ids]['qty'],$_SESSION['axes_service'][$ids]['price'],$_SESSION['axes_service'][$ids]['subtot'],$_SESSION['axes_service'][$ids]['snote'],$_SESSION['axes_service'][$ids]['disp'],$_SESSION['axes_service'][$ids]['disf'],$_SESSION['axes_service'][$ids]['disamo']);
echo json_encode($redata);    
exit;
}
$dis = $_SESSION['axes_service'][$ids]['disf'];    
$_SESSION['axes_service'][$ids]['qty']=$qty;		    
$price = $_SESSION['axes_service'][$ids]['price'];
$sqty = $_SESSION['axes_service'][$ids]['qty'];
$disamo = getfloatval(($dis*$sqty));
$stot = ($price*$sqty);
if($price>0){
$disp=(($dis/$price)*100);
}else{
$disp=0;	
}
$_SESSION['axes_service'][$ids]['disp']=getfloatval($disp);
$_SESSION['axes_service'][$ids]['disamo']=$disamo;
$_SESSION['axes_service'][$ids]['subtot'] = getfloatval(($stot-$disamo));
$redata=array($_SESSION['axes_service'][$ids]['qty'],$_SESSION['axes_service'][$ids]['price'],$_SESSION['axes_service'][$ids]['subtot'],$_SESSION['axes_service'][$ids]['snote'],$_SESSION['axes_service'][$ids]['disp'],$_SESSION['axes_service'][$ids]['disf'],$_SESSION['axes_service'][$ids]['disamo']);
echo json_encode($redata);
}

if(isset($_POST['upprice'])){
$ids=intval($_POST['upprice']);
$amo=floatval($_POST['amo']);
if($amo<0 || $amo==''){exit;}
$qty=$_SESSION['axes_service'][$ids]['qty'];
$dis=$_SESSION['axes_service'][$ids]['disf'];
$_SESSION['axes_service'][$ids]['price']=$amo;
$disamo= getfloatval(($dis*$qty));
$disp=(($dis/$amo)*100);
$_SESSION['axes_service'][$ids]['disp']=getfloatval($disp);
$_SESSION['axes_service'][$ids]['disamo']=$disamo;
$_SESSION['axes_service'][$ids]['subtot']=(($amo*$qty)-$disamo);
$redata=array($_SESSION['axes_service'][$ids]['qty'],$_SESSION['axes_service'][$ids]['price'],$_SESSION['axes_service'][$ids]['subtot'],$_SESSION['axes_service'][$ids]['snote'],$_SESSION['axes_service'][$ids]['disp'],$_SESSION['axes_service'][$ids]['disf'],$_SESSION['axes_service'][$ids]['disamo']);
echo json_encode($redata);	
}

if(isset($_POST['upnote'])){
$ids=intval($_POST['upnote']);
$note=ucwords(remove_junk(escape($_POST['note'])));
$_SESSION['axes_service'][$ids]['snote']=$note;    
$redata=array($_SESSION['axes_service'][$ids]['qty'],$_SESSION['axes_service'][$ids]['price'],$_SESSION['axes_service'][$ids]['subtot'],$_SESSION['axes_service'][$ids]['snote'],$_SESSION['axes_service'][$ids]['disp'],$_SESSION['axes_service'][$ids]['disf'],$_SESSION['axes_service'][$ids]['disamo']);
echo json_encode($redata);    
}

if(isset($_POST['itemdisp'])){
$ids=intval($_POST['itemdisp']);
$disc=floatval($_POST['disp']);
//if( $disc==''){exit;}
$_SESSION['axes_service'][$ids]['disp']=$disc;
$price=$_SESSION['axes_service'][$ids]['price'];
$uqty=$_SESSION['axes_service'][$ids]['qty'];
$dis=(($price*$disc)*0.01);
$disamo = ($dis*$uqty); 
$_SESSION['axes_service'][$ids]['disf']=getfloatval($dis);
$_SESSION['axes_service'][$ids]['disamo']=getfloatval($disamo);
$_SESSION['axes_service'][$ids]['subtot']=(($price*$uqty)-$disamo);
$redata=array($_SESSION['axes_service'][$ids]['qty'],$_SESSION['axes_service'][$ids]['price'],$_SESSION['axes_service'][$ids]['subtot'],$_SESSION['axes_service'][$ids]['snote'],$_SESSION['axes_service'][$ids]['disp'],$_SESSION['axes_service'][$ids]['disf'],$_SESSION['axes_service'][$ids]['disamo']);
echo json_encode($redata); 
}

if(isset($_POST['itemdisf'])){
$ids=intval($_POST['itemdisf']);
$dica=floatval($_POST['disf']);
$price=$_SESSION['axes_service'][$ids]['price'];
$uqty=$_SESSION['axes_service'][$ids]['qty'];
$disp=(($dica/$price)*100);
$_SESSION['axes_service'][$ids]['disf']=getfloatval($dica);
$disamo = ($dica*$uqty);
$_SESSION['axes_service'][$ids]['disamo']=getfloatval($disamo);
if($dica<=0){
$_SESSION['axes_service'][$ids]['disp']=getfloatval(0);	
}else{
$_SESSION['axes_service'][$ids]['disp']=getfloatval($disp);	
}
$_SESSION['axes_service'][$ids]['subtot']=(($price*$uqty)-$disamo);
$redata=array($_SESSION['axes_service'][$ids]['qty'],$_SESSION['axes_service'][$ids]['price'],$_SESSION['axes_service'][$ids]['subtot'],$_SESSION['axes_service'][$ids]['snote'],$_SESSION['axes_service'][$ids]['disp'],$_SESSION['axes_service'][$ids]['disf'],$_SESSION['axes_service'][$ids]['disamo']);
echo json_encode($redata); 
}

if(isset($_POST['foot'])){
$disp=$_SESSION['axes_servide'][0]['disp'];
$redata=array($_SESSION['axes_servide'][0]['disp'],(get_serdiscount_total(floatval($disp))-get_serdiscount_total()),get_serdiscount_total($disp),$_SESSION['axes_servide'][0]['vatp'],$_SESSION['axes_servide'][0]['vatamo'],$_SESSION['axes_servide'][0]['aitp'],$_SESSION['axes_servide'][0]['aitamo'],$_SESSION['axes_servide'][0]['name'],$_SESSION['axes_servide'][0]['others'],$_SESSION['axes_servide'][0]['freight'],$_SESSION['axes_servide'][0]['less'],$_SESSION['axes_servide'][0]['gtotal']);
echo json_encode($redata);	
exit;
}

if(isset($_POST['seldis'])){
$disp=floatval($_POST['seldis']);
if(isset($_SESSION['axes_servide'])){
if($disp>0){
$_SESSION['axes_servide'][0]['disp']= getfloatval($disp);
$_SESSION['axes_servide'][0]['disamo']=getfloatval(get_serdiscount_total(floatval($disp)));    
}else{    
$_SESSION['axes_servide'][0]['disp']= getfloatval(0);
$_SESSION['axes_servide'][0]['disamo']=getfloatval(0);    
}
}
}

if(isset($_POST['selvat'])){
$rvat=floatval($_POST['selvat']);
$disp=$_SESSION['axes_servide'][0]['disp'];    
if(isset($_SESSION['axes_servide'])){
if($rvat>0){	
$_SESSION['axes_servide'][0]['vatp']= getfloatval($rvat);
$_SESSION['axes_servide'][0]['vatamo']= getfloatval((((get_service_total()-(get_serdiscount_total($disp)-get_serdiscount_total()))*$rvat)*0.01));    
}else{    
$_SESSION['axes_servide'][0]['vatp']= 0;
$_SESSION['axes_servide'][0]['vatamo']= 0;    
}
} 
}

if(isset($_POST['seltax'])){
$rtax=floatval($_POST['seltax']);
$disp=$_SESSION['axes_servide'][0]['disp'];    
if(isset($_SESSION['axes_servide'])){
if($rtax>0){	
$_SESSION['axes_servide'][0]['aitp']= getfloatval($rtax);
$_SESSION['axes_servide'][0]['aitamo']= getfloatval((((get_service_total()-(get_serdiscount_total($disp)-get_serdiscount_total()))*$rtax)*0.01));    
}else{    
$_SESSION['axes_servide'][0]['aitp']= 0;
$_SESSION['axes_servide'][0]['aitamo']= 0;    
}
}
}

if(isset($_POST['others'])){
$ota=floatval($_POST['others']);
if(isset($_SESSION['axes_servide'])){
$_SESSION['axes_servide'][0]['others']=getfloatval($ota);	
}
}

if(isset($_POST['otname'])){
$otn=$_POST['otname'];
if($otn==''){return;}
if(isset($_SESSION['axes_servide'])){
$_SESSION['axes_servide'][0]['name']=ucwords($otn);	
}	
}

if(isset($_POST['freight'])){
$fre=floatval($_POST['freight']);
if(isset($_SESSION['axes_servide'])){
$_SESSION['axes_servide'][0]['freight']=getfloatval($fre);	
}
}

if(isset($_POST['less'])){
$less=floatval($_POST['less']);
if(isset($_SESSION['axes_servide'])){
if($less>0){
$_SESSION['axes_servide'][0]['less']= getfloatval($less);    
}else{    
$_SESSION['axes_servide'][0]['less']= 0;   
}
}
}

if(isset($_SESSION['axes_servide'])){
if(is_array($_SESSION['axes_servide'])){    
$disps=$_SESSION['axes_servide'][0]['disp'];
if($disps>0){
$_SESSION['axes_servide'][0]['disamo']=getfloatval(get_serdiscount_total(floatval($disps)));	
}else{
$_SESSION['axes_servide'][0]['disamo']=getfloatval(get_serdiscount_total());	
}
$vatps=$_SESSION['axes_servide'][0]['vatp'];
if($vatps>0){
$_SESSION['axes_servide'][0]['vatamo']= getfloatval(((get_service_total()-(get_serdiscount_total($disps)- get_serdiscount_total()))*$vatps)*0.01);	
}
$taxps=$_SESSION['axes_servide'][0]['aitp'];
if($taxps>0){
$_SESSION['axes_servide'][0]['aitamo']= getfloatval(((get_service_total()-(get_serdiscount_total($disps)- get_serdiscount_total()))*$taxps)*0.01);	
}
$freight=$_SESSION['axes_servide'][0]['freight'];
$vatamos=$_SESSION['axes_servide'][0]['vatamo'];
$aitamos=$_SESSION['axes_servide'][0]['aitamo'];
$other=$_SESSION['axes_servide'][0]['others'];
$lesss=$_SESSION['axes_servide'][0]['less'];    
}else{
$disps=0;
$vatps=0;
$vatamos=0;
$aitamos=0;
$freight=0;
$other=0;
$lesss=0;    
}
$_SESSION['axes_servide'][0]['gtotal']=getfloatval(get_service_total()+$vatamos+$other+$aitamos+$freight)-((get_serdiscount_total(floatval($disps))- get_serdiscount_total())+$lesss);
}

if(isset($_POST['getcus'])){
$search = $_POST['search'];
$sql="SELECT * FROM (SELECT CONCAT('CU_',id) AS id,code,name,cnumber FROM tbl_customer UNION ALL SELECT CONCAT('SU_',id) AS id,code,name,cnumber FROM tbl_supplier) AS customer WHERE (name LIKE '%$search%' OR code LIKE '%$search%' OR cnumber LIKE '%$search%') ORDER BY name ASC,code ASC LIMIT 30";		
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
    
while($row = mysqli_fetch_array($result) ){
$response[] = array("value"=>$row['id'],"label"=>$row['code'].' | '.$row['name'].' | '.$row['cnumber']);
}

// encoding array to json format
echo json_encode($response);
exit;
}

if(isset($_POST['checkbal'])){
if(strlen($_POST['checkbal'])>0){    
$id=str_replace('_','',$_POST['checkbal']);
$ldebit=get_ledgerval($id,'D','N');
$lcredit=get_ledgerval($id,'C','N');
$lnet=($ldebit-$lcredit);
echo number_format($lnet,2);
}else{
echo '0.00';    
}    
}

if(isset($_POST['savecus'])){
$name = ucwords(remove_junk(escape($_POST['name'])));
$code = get_genid('CU');
$cperson = remove_junk(escape($_POST['cperson']));
$cnumber = remove_junk(escape($_POST['cnumber']));
$cemail = remove_junk(escape($_POST['cemail']));    
$address = remove_junk(escape($_POST['address']));
if(isset($_POST['cnumber'])){
$ducode = mysqli_query($con,"SELECT * FROM tbl_customer WHERE cnumber = '$cnumber'");
}
	
if($ducode->num_rows > 0) {
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! This contact number already exists!!'
));
return;
exit;
}else{
$sql="INSERT INTO tbl_customer(code,name,cperson,cnumber,cemail,address,uid,date) VALUES ('$code','$name','$cperson','$cnumber','$cemail','$address','$aid','$dtnow')";    
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sid=$con->insert_id;    
$efid=mysqli_affected_rows($con);    
if($efid>0){
$act =remove_junk(escape('Customer name: '.$name));    
write_activity($aid,'CUS','New customer has been Added',$act);
echo json_encode(array(
'status' => 'success',
'cbal'=> '0.00',
'cudata'=> $code.'|'.$name.'|'.$cnumber,
'cuid'=> 'CU_'.$sid    
));
exit;   
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Customer Fail to Saved!!'
));    
} 
}    
}

if(isset($_POST['addsales'])){
$invno = gen_newinvno('tbl_sersales','SER');
$apdate = remove_junk(escape($_POST['seldt']));
$nxtdt = remove_junk(escape($_POST['nextdt']));

$cdata=explode('_',remove_junk(escape($_POST['customer'])));
$cty=$cdata['0'];    
$cid = $cdata['1'];    

if($cid!=0){
if($cty=='CU'){    
$cname=get_fild_data('tbl_customer',$cid,'name');
$cmobile=get_fild_data('tbl_customer',$cid,'cnumber');    
}else{
$cname=get_fild_data('tbl_supplier',$cid,'name');
$cmobile=get_fild_data('tbl_supplier',$cid,'cnumber');     
}
}else{
$cname=remove_junk(escape($_POST['wname']));
$cmobile=remove_junk(escape($_POST['wmobile']));    
}    
    
$baid = remove_junk(escape($_POST['baid']));    
$chkno = remove_junk(escape($_POST['chkno']));
$chkdt = remove_junk(escape($_POST['chkdt']));
if($chkno=='' || strlen($chkno)<2){$chkdt='NULL';$chkno='NULL';}//else{$chkdt="'".$chkdt."'";$chkno="'".$chkno."'";} 

$caname = remove_junk(escape($_POST['caname']));    
$chbid = remove_junk(escape($_POST['chbid']));
$caid = remove_junk(escape($_POST['caid']));
if(strlen($caname)<2){$chbid='NULL';$caid='NULL';}//else{$chbid="'".$chbid."'";$caid="'".$caid."'";}    

$mobid = remove_junk(escape($_POST['mobid']));    
$trxid = remove_junk(escape($_POST['trxid']));

if($baid!=''){
$debitid=$baid;
$details="'".'CHK_'.$chkno.'_'.$chkdt."'";    
}elseif(strlen($caname)>0){
$debitid=$caid;
$details="'".'CRD_'.$caname.'_'.$chbid."'";    
}elseif($mobid!=''){
$debitid=$mobid;
$details="'".'MOB_'.$trxid."'";    
}else{
$debitid='LE_2';
$details='NULL';    
}    
    
$pname = remove_junk(escape($_POST['pname']));    
$dipname = remove_junk(escape($_POST['dipname']));
$paddress = remove_junk(escape($_POST['paddress']));
    
$ref = remove_junk(escape($_POST['ref']));
$note = remove_junk(escape($_POST['note']));
$selp = remove_junk(escape($_POST['selp']));
if($selp=='' || $selp=='-Select-'){$selp='NULL';}else{$selp="'".$selp."'";} 

$otclient = remove_junk(escape($_POST['otclient']));
$otmobile = remove_junk(escape($_POST['otmobile']));

$adjust = remove_junk(escape($_POST['adjust']));
if($adjust==''){$adjust=0;}    
$cash = remove_junk(escape($_POST['cash']));
if($cash==''){$cash=0;}
    
$itmdis=remove_junk(escape(get_serdiscount_total()));    
$disp=remove_junk(escape($_SESSION['axes_servide'][0]['disp']));
$disamo=remove_junk(escape($_SESSION['axes_servide'][0]['disamo']));   
$vatp=remove_junk(escape($_SESSION['axes_servide'][0]['vatp']));
$vatamo=remove_junk(escape($_SESSION['axes_servide'][0]['vatamo']));
$aitp=remove_junk(escape($_SESSION['axes_servide'][0]['aitp']));
$aitamo=remove_junk(escape($_SESSION['axes_servide'][0]['aitamo']));
$freight=remove_junk(escape($_SESSION['axes_servide'][0]['freight']));
$otname=remove_junk(escape($_SESSION['axes_servide'][0]['name']));
$otamo=remove_junk(escape($_SESSION['axes_servide'][0]['others']));
$less=remove_junk(escape($_SESSION['axes_servide'][0]['less']));
$subtot=get_service_total();    
$gtotal=remove_junk(escape($_SESSION['axes_servide'][0]['gtotal']));
if($disp>0){
$invdis=($disamo-$itmdis);    
}else{
$invdis=0;    
}     

if(($adjust+$cash)>=$gtotal){
$rcash=($gtotal-$adjust);
$change=(($adjust+$cash)-$gtotal);
$due=0;
$duedt='NULL';    
}else{
$rcash=$cash;
$change=0;
$due=($gtotal-($adjust+$cash));
$duedt="'".$nxtdt."'";    
}    

if(!isset($_SESSION['axes_service'])){
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! No item found!!'
));
return;
exit;  
}     

$sql="INSERT INTO tbl_sersales (invno,refinv,type,cusid,name,	mobile,itemdis,subtot,disp,disamo,totdis,vatp,vatamo,aitp,aitamo,otname,otamo,freight,less,adamo,total,curid,ref,note,apdate,nxtduedate,ocusname,ocusmobile,pname,pdep,paddress,rawcash,changes,selp,debitid,details,brid,uid,date) VALUES ('$invno',NULL,'$cty','$cid','$cname','$cmobile','$itmdis','$subtot','$disp','$invdis','$disamo','$vatp','$vatamo','$aitp','$aitamo','$otname','$otamo','$freight','$less','$adjust','$gtotal','0','$ref','$note','$apdate',$duedt,'$otclient','$otmobile','$pname','$dipname','$paddress','$cash','$change',$selp,'$debitid',$details,'$brid','$aid','$dtnow')";
   
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
$sid=$con->insert_id;    
$efid=mysqli_affected_rows($con);

if($efid>0){

$max=count($_SESSION['axes_service']);
for($i=0;$i<$max;$i++){
    
$code = $_SESSION['axes_service'][$i]['code'];
$pid = $_SESSION['axes_service'][$i]['sid'];    
$sname = $_SESSION['axes_service'][$i]['name'];      
$scost = $_SESSION['axes_service'][$i]['cost']; 
$qty = $_SESSION['axes_service'][$i]['qty'];
$sprice = $_SESSION['axes_service'][$i]['price'];
$disp = $_SESSION['axes_service'][$i]['disp'];
$disf = $_SESSION['axes_service'][$i]['disf'];    
$disamo = $_SESSION['axes_service'][$i]['disamo'];
$snote = $_SESSION['axes_service'][$i]['snote']; 
$stype = $_SESSION['axes_service'][$i]['stype'];     
$subtot = $_SESSION['axes_service'][$i]['subtot'];
    
$sql="INSERT INTO tbl_sersalesde (seid,invno,sid,code,name,cost,price,qty,disp,disf,disamo,taxp,taxamo,subtot,snote,brid,stype) VALUES ('$sid','$invno','$pid','$code','$sname','$scost','$sprice','$qty','$disp','$disf','$disamo','0','0','$subtot','$snote','$brid','$stype')";        
$result = mysqli_query($con,$sql) or die(mysqli_error($con));     
}    
    
//sales_update($sid,'tbl_sersales',$dtnow);    
unset($_SESSION['axes_service']);
unset($_SESSION['axes_servide']);
       
$act =remove_junk(escape('Service Sales Invoice: '.$invno));    
write_activity($aid,'SER','New service sales invoice has been Created',$act);
echo json_encode(array(
'status' => 'success',
'message'=> 'Sales Save Successfully!!',
'invid'=> $sid     
));
exit;     
}else{
echo json_encode(array(
'status' => 'error',
'message'=> 'Sorry! Data Fail to Saved!!'
));    
}    
    
}
?>

<?php if(isset($_POST['addseritem'])){ ?>
<div class="col-md-12 popup_details_div addourseritem">
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">    
<div class="form-group">
<label>Name</label>
<input type="text" maxlength="35" value="" name="name" id="name" class="form-control" placeholder="e.g. Mother Board Repair"/>
<input type="hidden" name="addmanser" readonly />    
</div>
<div class="row">
<div class="col-md-6"> 
<div class="form-group">
<label>Cost</label>    
<input type="text" maxlength="10" class="form-control" name="cost" id="cost"  onkeypress="return isNumberKey(event)" placeholder="e.g. 500" autocomplete="off">    
</div>    
</div>
<div class="col-md-6"> 
<div class="form-group">
<label>Price</label>    
<input type="text" maxlength="10" class="form-control" name="price" id="price"  onkeypress="return isNumberKey(event)" placeholder="e.g. 500" autocomplete="off">    
</div>    
</div>    
</div>
    
</div>    
<div class="col-md-1"></div>
</div>    
</div>
    
</div>    
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-4 text-right" >
<input type="button" id="addmseri" class="btn btn-flat bg-purple btn-sm " value="Add Service"/>
</div> 
</div>
<script type="text/javascript">
function chek_error(){
var result = true;
var name = $('#name').val();
var cost = parseFloat($('#cost').val()); 
var price = parseFloat($('#price').val()); 

$('.LV_invalid_field').removeClass('LV_invalid_field');     
$('.LV_validation_message').remove();     

if(name.length<1){
$('#name').addClass('LV_invalid_field');   
$('#name').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
}else{
$('#name').removeClass('LV_invalid_field');
result=true;    
}    

if(isNaN(cost) != false || cost < 0){
$('#cost').addClass('LV_invalid_field');   
$('#cost').after("<span class='LV_validation_message LV_invalid'>Enter Valid Cost!</span>").addClass('has-error');
result=false;    
}else{
$('#cost').removeClass('LV_invalid_field');
result=true;     
}    

if(isNaN(price) != false || price < 0){
$('#price').addClass('LV_invalid_field');   
$('#price').after("<span class='LV_validation_message LV_invalid'>Enter Valid Price!</span>").addClass('has-error');
result=false;    
}else{
$('#price').removeClass('LV_invalid_field');
result=true;     
}    

if(cost.length<0 || cost.length<0 || !result){
return false;    
}else{
return true;     
}        
}
    
$(document).on('blur', '#name, #cost, #price', function() {
chek_error();    
});    
</script>  
<?php } ?>

<?php if(isset($_POST['addcus'])){ ?>
<div class="col-md-12 popup_details_div addcustomer">
<div class="row">
<div id="server-results"><!-- For server results --></div>    
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-1"></div>
<div class="col-md-10">
<div class="form-group">
<label>Name</label>
<input type="text" name="name" maxlength="45" value="" id="name" class="form-control" placeholder="e.g. Md.Sumon Rahman"/>
<input type="hidden" name="savecus" readonly />    
</div>    
<div class="form-group">
<label>Contact Name</label>    
<input type="text" name="cperson" maxlength="45" value="" id="cperson" class="form-control" placeholder="e.g. Md.Rahman Sumon(CEO)"/>
</div>
<div class="form-group">
<label>Contact Number</label>    
<input type="text" name="cnumber" maxlength="18" value="" id="cnumber" class="form-control" placeholder="e.g. +88016161xxxxx70"/>
</div>
<div class="form-group">
<label>Contact Email</label>    
<input type="text" name="cemail" maxlength="45" value="" id="cemail" class="form-control" placeholder="e.g. info@axesgl.com"/>
</div>
<div class="form-group">    
<label>Address</label>
<textarea class="form-control" name="address" id="address" maxlength="250" rows="5" placeholder="Address"></textarea>    
</div>    
</div>    
<div class="col-md-1"></div>    
</div>    
</div>    

</div>
<div class="clearfix" ></div>
<div class="col-md-12 nopadding widgets_area"></div>    
<div class="row"style="margin-top: 15px" >
<div class="col-md-8"></div>
<div class="col-md-2 text-right" >
<input type="button" id="adcus" class="btn btn-flat bg-purple btn-sm " value="Save"/>
</div>
<div class="col-md-2"></div>    
</div>

<script type="text/javascript">
function chek_error(){
var name = $('#name').val();
var cnumber = $('#cnumber').val();
var address = $('#address').val();    
var cemail = $('#cemail').val();    
var result = true;
    
var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,8}|[0-9]{1,3})(\]?)$/;
    
$('.LV_validation_message').remove();
    
if(name.length<=0){
$('#name').addClass('LV_invalid_field');   
$('#name').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); } else {
$('#name').removeClass('LV_invalid_field'); 
}    
    
if(cnumber.length<=0){
$('#cnumber').addClass('LV_invalid_field');   
$('#cnumber').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); } else {
$('#cnumber').removeClass('LV_invalid_field'); 
}    

if(address.length<=0){
$('#address').addClass('LV_invalid_field');   
$('#address').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); } else {
$('#address').removeClass('LV_invalid_field'); 
}    
    
if(cemail.length >0){
result = expr.test(cemail);
if(result){
$('#cemail').removeClass('LV_invalid_field');        
}else{
$('#cemail').addClass('LV_invalid_field');
$('#cemail').after("<span class='LV_validation_message LV_invalid'>Not a valid email address!</span>").addClass('has-error');    
}    
}    
    
if(name.length<=0 || address.length<=0 || cnumber.length<=0 || !result){
return false;    
}else{
return true;     
}    
}
    
$(document).on('blur', '#name, #cnumber, #cemail', function() {
chek_error();    
});        
</script>    
<?php } ?>

<?php 
if(isset($_POST['checkview'])){
$cusd=explode('_',$_POST['cusid']);
$typ=$cusd[0];    
$cusid=$cusd[1];
$wname = $_POST['wname'];
$wmobil = $_POST['wmobil'];    
if(isset($_SESSION['axes_servide'])){    
$gtotal=$_SESSION['axes_servide'][0]['gtotal'];
}else{
$gtotal=0;    
}
$id=str_replace('_','',$_POST['cusid']);
$ldebit=get_ledgerval($id,'D','N');
$lcredit=get_ledgerval($id,'C','N');
if($cusid!=0){
$lnet=($ldebit-$lcredit);     
}else{
$lnet=0;    
}        
?>
<div class="addsersales">
<div class="row">
<div class="col-md-3 col-xs-6">
<div class="small-box">
<div class="inner">
<h3 id="pabamo"><?php echo $gtotal;?></h3>
<p>Total Receivable</p>
</div>

</div>
<input type="hidden" value="<?php echo $_POST['cusid']; ?>" id="customer" name="customer" readonly />
<input type="hidden" value="<?php if($lnet<0){echo ABS($lnet);}else{echo 0;} ?>" id="balance" name="balance" readonly />
<input type="hidden" value="<?php echo $wname;?>" name="wname" readonly />
<input type="hidden" value="<?php echo $wmobil;?>" name="wmobile" readonly />
<input type="hidden" name="addsales" readonly />
<input type="hidden" name="scusid" id="scusid" value="<?php echo $cusid; ?>" readonly />    
</div>
<div class="col-md-3 col-xs-6">
<div class="small-box">
<div class="inner">
<h3 id="paidamo">0</h3>
<p>Receive Amount</p>
<input type="hidden" value="" id="recamo" name="recamo" readonly />    
</div>

</div>
</div>
<div class="col-md-3 col-xs-6">
<div class="small-box">
<div class="inner">
<h3 id="dueamo"><?php echo $gtotal;?></h3>
<p>Total Due</p>
</div>

</div>
</div>
<div class="col-md-3 col-xs-6">
<div class="small-box">
<div class="inner">
<h3 id="changamo">0</h3>
<p>Change</p>
</div>

</div>
</div>    
</div>
<div class="row">
<div class="col-md-4 col-xs-6">
<div class="form-group">
<label>Balance (<?php echo $lnet;?>)</label>    
<input type="text" maxlength="10" class="form-control cashr" value="0" name="adjust" id="adjust"  onkeypress="return isNumberKey(event)" placeholder="e.g. 500" autocomplete="off" <?php if($lnet>=0){echo 'disabled';}?>>    
</div>    
</div>
<div class="col-md-4 col-xs-6">
<div class="form-group">
<label>Cash</label>    
<input type="text" maxlength="10" class="form-control cashr" name="cash" id="cash"  onkeypress="return isNumberKey(event)" placeholder="e.g. 500" autocomplete="off">    
</div>    
</div>
<div class="col-md-2 col-xs-6">
<div class="form-group" >
<label>Sales Date</label>
<input type="text" class="form-control datetimepicker" name="seldt" id="seldt" value="<?php echo $today;?>" placeholder="Sales Date" autocomplete="off" readonly>
</div>
</div>
<div class="col-md-2 col-xs-6">
<div class="form-group" >
<label>Next Due Date</label>
<input type="text" class="form-control datetimepicker" name="nextdt" id="nextdt" value="<?php echo date('Y-m-d', strtotime('+7 days',strtotime($today)));?>" placeholder="Sales Date" autocomplete="off" readonly>
</div>    
</div>
</div>
<div class="row" style="border-top: 2px solid red; border-bottom: 2px solid black;">
<div class="col-xs-3"> <!-- required for floating -->
<!-- Nav tabs -->
<ul class="nav nav-tabs tabs-left sideways">
<li class="active"><a href="#bankpay" data-toggle="tab" class="tabpoint" id="tbank">Bank</a></li>
<li><a href="#cardpay" data-toggle="tab" class="tabpoint" id="tcard">Card</a></li>
<li><a href="#mobilepay" data-toggle="tab" class="tabpoint" id="tmobile">Mobile</a></li>
<li><a href="#project" data-toggle="tab">Project</a></li>
</ul>
</div>

<div class="col-xs-9">
<!-- Tab panes -->
<div class="tab-content" style="padding-top: 10px;">
<div class="tab-pane active" id="bankpay">
<div class="row">
<div class="col-md-8">
<div class="form-group">
<label>Select Bank</label>    
<select class="form-control select2" name="baid" id="baid">
<option value="">-Select-</option>    
<?php
$sql="SELECT tbl_bacount.id,CONCAT(tbl_bank.sort,' - ',tbl_bacount.acno) AS name FROM tbl_bacount LEFT JOIN tbl_bank ON tbl_bank.id=tbl_bacount.bid ORDER BY tbl_bank.sort ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'BA_'.$rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>   
</div>    
</div>    
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group">
<label>Cheque No</label>
<input type="text" maxlength="20" class="form-control" name="chkno" id="chkno" value="" placeholder="e.g. KA7865467" autocomplete="off" disabled="disabled">
</div>    
</div>
<div class="col-md-6">
<div class="form-group" >
<label>Cheque Date</label>
<input type="text" class="form-control datetimepicker" name="chkdt" id="chkdt" value="" placeholder="Cheque Date" autocomplete="off" disabled="disabled" readonly>
</div>    
</div>    
</div>    
</div>
<div class="tab-pane" id="cardpay">
<div class="row">
<div class="col-md-8">    
<div class="form-group">
<label>Card Holder Name</label>
<input type="text" maxlength="35" class="form-control" name="caname" id="caname" value="" placeholder="e.g. Md.Sumon" autocomplete="off">
</div> 
</div>     
</div>
<div class="row">
<div class="col-md-6">
<div class="form-group">
<label>Card Holder Bank</label>    
<select class="form-control select2" name="chbid" id="chbid">
<option value="">-Select-</option>    
<?php
$sql="SELECT id,name FROM tbl_bank ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'BA_'.$rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>   
</div>    
</div>    
<div class="col-md-6">    
<div class="form-group">
<label>Deposit Bank</label>    
<select class="form-control select2" name="caid" id="caid">
<option value="">-Select-</option>    
<?php
$sql="SELECT tbl_bacount.id,CONCAT(tbl_bank.sort,' - ',tbl_bacount.acno) AS name FROM tbl_bacount LEFT JOIN tbl_bank ON tbl_bank.id=tbl_bacount.bid ORDER BY tbl_bank.sort ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'BA_'.$rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>   
</div>
</div>
</div>     
</div>
<div class="tab-pane" id="mobilepay">
<div class="row">
<div class="col-md-6">
<div class="form-group">
<label>Mobile Account</label>    
<select class="form-control select2" name="mobid" id="mobid">
<option value="">-Select-</option>    
<?php
$sql="SELECT id,name,mobile FROM tbl_acmobile ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo 'MO_'.$rows['id'];?>"><?php echo $rows['name'].' - '.$rows['mobile'];?></option>
<?php } ?>
</select>   
</div>    
</div> 
<div class="col-md-6">
<div class="form-group">
<label>TrxID</label>
<input type="text" maxlength="20" class="form-control" name="trxid" id="trxid" value="" placeholder="e.g. KA7865467" autocomplete="off">
</div>    
</div>     
</div>    
</div>
<div class="tab-pane" id="project">
<div class="col-xs-5">
<div class="form-group">
<label>Person/Project Name</label>
<input type="text" name="pname" id="pname" maxlength="35" class="form-control" placeholder="Md.Nur Hossain, CEO" autocomplete="off">
</div>
<div class="form-group">
<label>Section/Department</label>
<input type="text" name="dipname" id="dipname" maxlength="35" class="form-control" placeholder="e.g Infomation Technology" autocomplete="off">
</div>    
</div>    
<div class="col-xs-7">    
<div class="form-group">    
<label>Address</label>
<textarea class="form-control" name="paddress" id="paddress" maxlength="150" rows="5" placeholder="Address"></textarea>    
</div>    
</div>    
</div>
</div>
</div>
<div class="clearfix"></div>    
</div>
<div class="row">
<br>   
<div class="col-md-4">
<div class="form-group">
<label>Ref</label>
<input type="text" maxlength="25" class="form-control" name="ref" id="ref" placeholder="e.g. #ORD8976453" autocomplete="off">    
</div>
<div class="form-group">
<label>Sales Person</label>    
<select class="form-control select2" name="selp" id="selp">
<option value="">-Select-</option>    
<?php
$sql="SELECT id,name FROM tbl_employe ORDER BY name ASC";    
$querys=mysqli_query($con,$sql)or die(mysqli_error($con));
while ($rows=mysqli_fetch_array($querys)){
?>
<option value="<?php echo $rows['id'];?>"><?php echo $rows['name'];?></option>
<?php } ?>
</select>    
</div>    
</div>
<div class="col-md-8">    
<div class="form-group">    
<label>Note</label>
<textarea class="form-control" name="note" id="note" maxlength="150" rows="5" placeholder="Invoice Note"></textarea>    
</div>    
</div>    
</div>
<div class="row">
<div class="secdiv" style="margin-bottom: 10px;"><span>Other Billing Name (Optional)</span></div>    
<div class="col-md-6">
<div class="form-group">
<label>Name</label>
<input type="text" name="otclient" maxlength="35" class="form-control" placeholder="e.g Sumon">
</div>    
</div>
<div class="col-md-6">    
<div class="form-group">
<label>Mobile</label>
<input type="text" name="otmobile" maxlength="18" class="form-control" placeholder="e.g 016161700">
</div>
</div>    
</div>
</div>    
<div class="row">
<div class="col-md-12 text-center side-checkhead">
<button class="btn btn-flat bg-blue saveseinv" id="saveinv"><i class="fa fa-floppy-o"></i>&nbsp;&nbsp;Save</button>    
<button class="btn btn-flat bg-gray saveseinv" id="sinvprint"><i class="fa fa-floppy-o"></i>&nbsp;&nbsp; Invoice &nbsp;&nbsp;<i class="fa fa-print"></i></button>
<button class="btn btn-flat bg-gray saveseinv" id="srecprint"><i class="fa fa-floppy-o"></i>&nbsp;&nbsp; Receipt &nbsp;&nbsp;<i class="fa fa-print"></i></button>
<button class="btn btn-flat bg-gray saveseinv" id="sichprint"><i class="fa fa-floppy-o"></i>&nbsp;&nbsp; Invoice &amp; Challan &nbsp;&nbsp;<i class="fa fa-print"></i></button>    
</div>    
</div>
<script type="text/javascript">
function cashcalculation(){
var pab = parseFloat($('#pabamo').html());
var cash = parseFloat($('#cash').val());
var adv = parseFloat($('#balance').val());
var adj = parseFloat($('#adjust').val());    
var paid=0; due=0; chang=0;
if(isNaN(cash)){
cash=0;    
}
if(isNaN(adj)){
adj=0;    
}
    
if((cash+adj)<=pab){
paid=cash;
due=(pab-(cash+adj));
chang=0;    
}else{
paid=pab;
due=0;
chang=((cash+adj)-pab);   
}
$('#paidamo').html(paid);
$('#dueamo').html(due);
$('#changamo').html(chang);   
}
    
$(document).on('keyup', '#cash', function() { 
cashcalculation();
});
    
$(document).on('keyup', '#adjust', function() {
var pab = parseFloat($('#pabamo').html());    
var adv = parseFloat($('#balance').val());
var adj = parseFloat($('#adjust').val());    
var maxad = 0;
if(pab<=adv){
maxad=pab;
}else{
maxad=adv;    
}
if(adj>maxad){
$('#adjust').val(maxad);    
}    
cashcalculation();
});
    
$(document).on('change', '#baid', function() {
id_arr = $(this).val();
id = id_arr.split("_");
type=id[0];
if(type=='BA'){
document.getElementById("chkno").disabled=false; 
document.getElementById("chkdt").disabled=false;     
}else{
$('#chkno').val('');
$('#chkdt').val('');    
document.getElementById("chkno").disabled=true; 
document.getElementById("chkdt").disabled=true;    
}    
});    
    
$(document).on('click', '.tabpoint', function() { 
var tval=$(this).attr('id');
if (tval=='tbank'){
$("#caname").val("");    
$("#chbid").val("").trigger("change");
$("#caid").val("").trigger("change");
$("#mobid").val("").trigger("change");
$("#trxid").val("");    
}else if(tval=='tcard'){
$("#baid").val("").trigger("change");
$("#chkno").val("");
$("#chkdt").val("");    
$("#mobid").val("").trigger("change");
$("#trxid").val("");
}else if(tval=='tmobile'){
$("#baid").val("").trigger("change");
$("#chkno").val("");
$("#chkdt").val("");
$("#caname").val("");    
$("#chbid").val("").trigger("change");
$("#caid").val("").trigger("change");    
}
          
});    

function chek_error(){
var result = true;    
var baid = $('#baid').val();
var chkno = $('#chkno').val();
var chkdt = $('#chkdt').val();
    
var caname = $('#caname').val();
var chbid = $('#chbid').val();
var caid = $('#caid').val();
    
var mobid = $('#mobid').val();
var trxid = $('#trxid').val(); 

$('.LV_invalid_field').removeClass('LV_invalid_field');     
$('.LV_validation_message').remove();    
    
if(baid != ''){
if(chkno.length>=0 && chkno.length<5){
$('#chkno').addClass('LV_invalid_field');   
$('#chkno').after("<span class='LV_validation_message LV_invalid'>Enter Valid Cheque No!</span>").addClass('has-error'); 
result=false;
}else{
$('#chkno').removeClass('LV_invalid_field');
result=true;    
} 

if(chkdt.length<=0){
$('#chkdt').addClass('LV_invalid_field');   
$('#chkdt').after("<span class='LV_validation_message LV_invalid'>Enter Cheque Date!</span>").addClass('has-error');
result=false;    
}else{
$('#chkdt').removeClass('LV_invalid_field');
result=true;    
}    
}    

if(caname.length>0){
if(chbid == '-Select-' || chbid == ''){
$('#chbid').addClass('LV_invalid_field');   
$('#chbid').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
} else {
$('#chbid').removeClass('LV_invalid_field');
result=true;    
}
    
if(caid == '-Select-' || caid == ''){
$('#caid').addClass('LV_invalid_field');   
$('#caid').after("<span class='LV_validation_message LV_invalid'>Can't be empty!</span>").addClass('has-error'); 
result=false;
} else {
$('#caid').removeClass('LV_invalid_field');
result=true;    
}    
}    

if(mobid != ''){
if(trxid.length>=0 && trxid.length<5){
$('#trxid').addClass('LV_invalid_field');   
$('#trxid').after("<span class='LV_validation_message LV_invalid'>Enter Valid TrxID No!</span>").addClass('has-error'); 
result=false;
}else{
$('#trxid').removeClass('LV_invalid_field');
result=true;    
}    
}    

if(!result){
return false;    
}else{
return true;     
}    
    
}
    
$(".select2").select2();    
$('.datetimepicker').datepicker({format: "yyyy-mm-dd", autoclose: true, clearBtn: true, orientation: 'auto bottom'});    
</script>    
<?php } ?>

<?php 
if(isset($_POST['checkout'])){
$cusd=explode('_',$_POST['cusid']);
$typ=$cusd[0];    
$cusid=$cusd[1];    
?>
<div class="col-md-12 cart-border-left text-center">
<div class="horizontal-scroll">
<h5 class="text-center" style="font-size: 20px;">Sales Details</h5> 
<div>
<div class="text-center header-line-height">
<small class="text-center" style="font-size: 15px;"><?php echo get_cominfo('1','name');?></small>
<br> <small class="text-center"><?php echo date("d M Y", strtotime($today));?></small>
<br> <small class="text-center" style="font-size: 12px;"><strong>Sales Receipt</strong></small>
<!--<br> <small class="text-left">Sold By: John Doe</small>--> 
<br> <small><span>Sold To: <?php if($cusid!=0){if($typ=='SU'){echo get_fild_data('tbl_supplier',$cusid,'name');}else{echo get_fild_data('tbl_customer',$cusid,'name');}}else{echo 'Walk-In Customer';};?></span></small> 
<small class="text-left invoice-show" style="display: none;">Invoice ID:</small>
</div> 
<div class="invoice-table">
<table class="table product-card-font" style="font-weight: 500;">
<thead class="border-top-0">    
<tr>
<th class="cart-summary-table text-left">Items</th> 
<th class="cart-summary-table text-left">Qty</th> 
<th class="cart-summary-table text-right">Price</th>
<th class="cart-summary-table text-right">Discount</th>
<th class="cart-summary-table text-right">Total</th>
</tr>   
</thead> 
<tbody>
<?php 
$s=0;    
if(isset($_SESSION['axes_service'])){
$max=count($_SESSION['axes_service']);
for($i=($max-1);$i>=0;$i=$i-1){
$name=$_SESSION['axes_service'][$i]['name'];
$qty=$_SESSION['axes_service'][$i]['qty'];
$price=$_SESSION['axes_service'][$i]['price'];
$disp=$_SESSION['axes_service'][$i]['disp'];    
$subtot=$_SESSION['axes_service'][$i]['subtot'];
$snote=$_SESSION['axes_service'][$i]['snote'];    
$s+=1;    
?>    
<tr>
<td class="cart-summary-table text-left"><?php echo $name;?><br></td>
<td class="cart-summary-table"><?php echo $qty;?></td> 
<td class="text-right cart-summary-table"><?php echo numtolocal($price,''); ?></td> 
<td class="text-right cart-summary-table"><?php echo $disp;?> %</td> 
<td class="text-right cart-summary-table"><?php echo numtolocal($subtot,''); ?></td>
<?php }} ?>     
</tbody> 
<tfoot>
<?php 
$disp=$_SESSION['axes_servide'][0]['disp'];
$vatp=$_SESSION['axes_servide'][0]['vatp'];
$vatamo=$_SESSION['axes_servide'][0]['vatamo'];
$aitp=$_SESSION['axes_servide'][0]['aitp'];
$aitamo=$_SESSION['axes_servide'][0]['aitamo'];
$otname=$_SESSION['axes_servide'][0]['name'];
$others=$_SESSION['axes_servide'][0]['others'];
$less=$_SESSION['axes_servide'][0]['less'];
$freight=$_SESSION['axes_servide'][0]['freight'];
$gtotal=$_SESSION['axes_servide'][0]['gtotal'];    
?>    
<tr>
<td class="cart-summary-table font-weight-bold text-left">Sub Total</td> 
<td class="cart-summary-table"></td>
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table"><?php echo numtolocal(get_service_total(),'Tk');?></td>
</tr>
<?php if(get_serdiscount_total()>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">Discount(<?php echo $disp.'';?>%)</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal(get_serdiscount_total($disp),'Tk');?></td>
</tr>    
<?php } ?>
<?php if($vatamo>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">VAT(<?php echo $vatp.'';?>%)</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($vatamo,'Tk');?></td>
</tr>    
<?php } ?>
<?php if($aitamo>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">AIT(<?php echo $aitp.'';?>%)</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($aitamo,'Tk');?></td>
</tr>    
<?php } ?>    
<?php if($others>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">(<?php echo $otname;?>)</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($others,'Tk');?></td>
</tr>    
<?php } ?>
<?php if($freight>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">Freight</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($freight,'Tk');?></td>
</tr>    
<?php } ?> 
<?php if($less>0){?>
<tr>
<td class="cart-summary-table font-weight-bold text-left">Adjust</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($less,'Tk');?></td>
</tr>    
<?php } ?>     
<tr>
<td class="cart-summary-table font-weight-bold text-left">Total</td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="cart-summary-table"></td> 
<td class="text-right cart-summary-table "><?php echo numtolocal($gtotal,'Tk');?></td>
</tr> 
</tfoot>
</table>
</div>
</div>
</div>
</div>   
<?php } ?>